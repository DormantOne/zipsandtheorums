#!/usr/bin/env python3
"""ABIM Question Nudge 2 — a local Tkinter study-reminder app.

* Questions live in JSON files inside the "banks" folder next to this script.
  Every *.json file there is loaded; add, remove, or swap files to change the bank.
  The format is documented in BANK_FORMAT.md.
* Stems and explanations accept a small subset of HTML (bold, italics, sub/superscript,
  lists, tables, links, colored spans) rendered natively in Tkinter.
* Questions can carry diagrams (ECG strips, flow-volume loops, plots, vector sketches)
  that are drawn from JSON specs — see qn_diagrams.py.
* Difficulty 1–5; points are proportional to difficulty (10 × difficulty).

Python 3.9+ with Tkinter. Standard library only.
"""
from __future__ import annotations

import json
import os
import random
import re
import subprocess
import sys
import threading
import time
import tkinter as tk
import urllib.parse
import urllib.request
import webbrowser
from html.parser import HTMLParser
from pathlib import Path
from tkinter import filedialog, font as tkfont, messagebox, ttk
from typing import Any

FROZEN = bool(getattr(sys, "frozen", False))  # True when running as a PyInstaller .exe
APP_DIR = Path(sys.executable).resolve().parent if FROZEN else Path(__file__).resolve().parent
BUNDLE_DIR = Path(getattr(sys, "_MEIPASS", APP_DIR))  # read-only files packed inside the .exe
sys.path.insert(0, str(BUNDLE_DIR))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from qn_diagrams import render_diagram, validate_diagram  # noqa: E402

APP_NAME = "ABIM Question Nudge"
BANKS_DIR = APP_DIR / "banks"  # editable banks live next to the script / .exe
DEFAULT_REMOTE_URL = "https://dormantone.github.io/zipsandtheorums/quizdata.json"
SOURCE_MODES = ["All (online + local)", "Online only", "Local only"]
DEFAULT_INTERVAL = 15
POINTS_PER_LEVEL = 10
LEVEL_NAMES = {1: "Foundation", 2: "Standard", 3: "Board-level", 4: "Hard", 5: "Expert"}
ORDER_MODES = ["Mixed", "Adaptive", "Easy → hard", "Hard → easy"]
BG = "#f7f8fa"
NAVY = "#17324d"


def app_data_dir() -> Path:
    if os.name == "nt":
        root = os.environ.get("APPDATA")
        base = Path(root) if root else Path.home() / "AppData" / "Roaming"
    else:
        base = Path.home() / ".config"
    path = base / "ABIMQuestionNudge"
    path.mkdir(parents=True, exist_ok=True)
    return path


SETTINGS_PATH = app_data_dir() / "settings_v2.json"
REMOTE_CACHE_PATH = app_data_dir() / "online_bank_cache.json"


def seed_banks_folder() -> None:
    """First run of the .exe: copy the banks packed inside it to a folder next to it."""
    if BUNDLE_DIR == APP_DIR or (BANKS_DIR.exists() and any(BANKS_DIR.glob("*.json"))):
        return
    packed = BUNDLE_DIR / "banks"
    if packed.is_dir():
        try:
            BANKS_DIR.mkdir(parents=True, exist_ok=True)
            for f in packed.glob("*.json"):
                (BANKS_DIR / f.name).write_bytes(f.read_bytes())
        except Exception:
            pass


# =============================================================================
# Bank loading and validation
# =============================================================================
def _strip_html(s: str) -> str:
    return re.sub(r"<[^>]+>", "", s or "")


def validate_question(q: Any, where: str) -> tuple[dict[str, Any] | None, list[str]]:
    errs: list[str] = []
    if not isinstance(q, dict):
        return None, [f"{where}: entry is not an object"]
    qid = q.get("id")
    if not isinstance(qid, str) or not qid.strip():
        return None, [f"{where}: missing string 'id'"]
    where = f"{where} [{qid}]"
    for key in ("stem", "explanation"):
        if not isinstance(q.get(key), str) or not q[key].strip():
            errs.append(f"{where}: missing '{key}'")
    opts = q.get("options")
    if isinstance(opts, list):
        opts = {chr(65 + i): str(o) for i, o in enumerate(opts)}
    if not isinstance(opts, dict) or not 3 <= len(opts) <= 8:
        errs.append(f"{where}: 'options' must have 3–8 choices")
        opts = {}
    if q.get("answer") not in opts:
        errs.append(f"{where}: 'answer' must be one of the option letters")
    try:
        diff = int(q.get("difficulty", 3))
        if not 1 <= diff <= 5:
            raise ValueError
    except (TypeError, ValueError):
        errs.append(f"{where}: 'difficulty' must be 1–5")
        diff = 3
    diagrams = q.get("diagrams") or ([q["diagram"]] if q.get("diagram") else [])
    for i, d in enumerate(diagrams):
        err = validate_diagram(d)
        if err:
            errs.append(f"{where}: diagram {i + 1}: {err}")
    for link in q.get("links", []) or []:
        if not isinstance(link, dict) or not str(link.get("url", "")).startswith(("http://", "https://")):
            errs.append(f"{where}: each link needs a label and an http(s) url")
    if errs:
        return None, errs
    out = dict(q)
    out["options"] = {str(k): str(v) for k, v in opts.items()}
    out["difficulty"] = diff
    out["diagrams"] = diagrams
    out["section"] = str(q.get("section") or "General")
    out["points"] = diff * POINTS_PER_LEVEL
    return out, []


def parse_bank_data(data: Any, label: str) -> tuple[list[dict[str, Any]], list[str], str]:
    """Validate one bank (dict with 'questions' or a bare list). Returns (questions, warnings, title)."""
    warnings: list[str] = []
    out: list[dict[str, Any]] = []
    seen: set[str] = set()
    items = data.get("questions", []) if isinstance(data, dict) else data
    title = data.get("title", label) if isinstance(data, dict) else label
    default_section = data.get("section") if isinstance(data, dict) else None
    for i, raw in enumerate(items if isinstance(items, list) else []):
        if isinstance(raw, dict) and default_section and not raw.get("section"):
            raw = dict(raw, section=default_section)
        q, errs = validate_question(raw, f"{label} #{i + 1}")
        if errs or q is None:
            warnings.extend(errs)
            continue
        if q["id"] in seen:
            warnings.append(f"{label}: duplicate id '{q['id']}' skipped")
            continue
        seen.add(q["id"])
        q["_bank"] = label
        out.append(q)
    return out, warnings, str(title)


def github_raw_fallbacks(url: str) -> list[str]:
    """https://USER.github.io/REPO/file.json -> raw.githubusercontent.com copies (works without Pages deployed)."""
    m = re.match(r"https?://([^./]+)\.github\.io/([^/]+)/(.+)$", url.strip())
    if not m:
        return []
    user, repo, path = m.groups()
    return [f"https://raw.githubusercontent.com/{user}/{repo}/{branch}/{path}" for branch in ("main", "master")]


def fetch_remote_bank(url: str, timeout: float = 12.0) -> dict[str, Any]:
    """Download the online bank (and any files it lists under "includes"). Saves a cache for offline use."""
    def get(u: str) -> Any:
        sep = "&" if "?" in u else "?"
        req = urllib.request.Request(f"{u}{sep}nocache={int(time.time() // 60)}",
                                     headers={"User-Agent": "ABIM-Question-Nudge", "Cache-Control": "no-cache"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8-sig"))

    used, data, last_exc = url, None, None
    for candidate in [url] + github_raw_fallbacks(url):
        try:
            data, used = get(candidate), candidate
            break
        except Exception as exc:  # Pages not deployed yet, 404, etc. -> try the raw GitHub copy
            last_exc = exc
    if data is None:
        raise last_exc or OSError("no data")
    url_for_includes = used
    if isinstance(data, dict) and isinstance(data.get("includes"), list):
        merged = list(data.get("questions", []) or [])
        for inc in data["includes"][:100]:
            sub = get(urllib.parse.urljoin(url_for_includes, str(inc)))
            sub_q = sub.get("questions", []) if isinstance(sub, dict) else sub
            sec = sub.get("section") if isinstance(sub, dict) else None
            merged.extend(dict(q, section=q.get("section") or sec) if sec and isinstance(q, dict) else q for q in sub_q)
        data = dict(data, questions=merged)
    cache = {"url": url, "served_from": used, "fetched_at": time.time(), "data": data}
    try:
        REMOTE_CACHE_PATH.write_text(json.dumps(cache), encoding="utf-8")
    except Exception:
        pass
    return cache


def read_remote_cache(url: str) -> dict[str, Any] | None:
    try:
        cache = json.loads(REMOTE_CACHE_PATH.read_text(encoding="utf-8"))
        return cache if cache.get("url") == url else None
    except Exception:
        return None


def load_banks(disabled: list[str] | None = None, remote: dict[str, Any] | None = None,
               source_mode: str = SOURCE_MODES[0]) -> tuple[list[dict[str, Any]], list[str], list[dict[str, Any]]]:
    """Load local banks/*.json plus the online bank. Returns (questions, warnings, file_info).
    Online questions replace local ones that share an id, so editing the GitHub file updates questions."""
    disabled = set(disabled or [])
    use_local = source_mode != "Online only"
    use_remote = source_mode != "Local only"
    BANKS_DIR.mkdir(exist_ok=True)
    by_id: dict[str, dict[str, Any]] = {}
    warnings: list[str] = []
    files: list[dict[str, Any]] = []
    for path in sorted(BANKS_DIR.glob("*.json")):
        info = {"file": path.name, "title": path.stem, "count": 0, "enabled": use_local and path.name not in disabled, "error": None}
        files.append(info)
        try:
            data = json.loads(path.read_text(encoding="utf-8-sig"))
        except Exception as exc:
            info["error"] = f"could not read JSON: {exc}"
            warnings.append(f"{path.name}: {info['error']}")
            continue
        qs, warns, info["title"] = parse_bank_data(data, path.name)
        warnings.extend(warns)
        info["count"] = len(qs)
        if not info["enabled"]:
            continue
        for q in qs:
            if q["id"] in by_id:
                warnings.append(f"{path.name}: id '{q['id']}' already loaded from {by_id[q['id']]['_bank']}; skipped")
                continue
            by_id[q["id"]] = q
    if remote is not None:
        qs, warns, title = parse_bank_data(remote.get("data"), "online")
        warnings.extend(f"online bank: {w}" for w in warns)
        enabled = use_remote and "__online__" not in disabled
        files.append({"file": "__online__", "title": f"Online: {title}", "count": len(qs), "enabled": enabled, "error": None})
        if enabled:
            for q in qs:
                by_id[q["id"]] = q  # online version wins
    return list(by_id.values()), warnings, files


# =============================================================================
# Settings
# =============================================================================
def default_settings() -> dict[str, Any]:
    return {
        "interval_minutes": DEFAULT_INTERVAL,
        "order_mode": "Mixed",
        "section_filter": "All specialties",
        "min_difficulty": 1,
        "hide_specialty": True,
        "requeue_missed": True,
        "disabled_banks": [],
        "remote_url": DEFAULT_REMOTE_URL,
        "source_mode": SOURCE_MODES[0],
        "cycle_seen": [],
        "next_due_epoch": None,
        "paused": False,
        "pending_question_id": None,
        "adaptive_level": 3.0,
        "served": 0,
        "missed_queue": [],
        "stats": {"seen": 0, "attempts": 0, "correct": 0, "revealed": 0, "points": 0, "possible": 0,
                  "by_level": {}, "by_section": {}},
        "history": {},
        "startup_enabled": False,
        "auto_close_minutes": 10,
    }


def load_settings() -> dict[str, Any]:
    s = default_settings()
    if SETTINGS_PATH.exists():
        try:
            loaded = json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                stats = s["stats"]
                stats.update(loaded.get("stats", {}) or {})
                s.update(loaded)
                s["stats"] = stats
        except Exception:
            pass
    s["interval_minutes"] = max(1, min(240, int(s.get("interval_minutes", DEFAULT_INTERVAL))))
    if s.get("order_mode") not in ORDER_MODES:
        s["order_mode"] = "Mixed"
    if s.get("source_mode") not in SOURCE_MODES:
        s["source_mode"] = SOURCE_MODES[0]
    s["section_filter"] = "All specialties"  # every launch starts from the full pool
    return s


def save_settings(settings: dict[str, Any]) -> None:
    try:
        tmp = SETTINGS_PATH.with_suffix(".tmp")
        tmp.write_text(json.dumps(settings, indent=1), encoding="utf-8")
        tmp.replace(SETTINGS_PATH)
    except Exception:
        pass


def format_duration(seconds: float) -> str:
    seconds = max(0, int(seconds))
    minutes, secs = divmod(seconds, 60)
    if minutes >= 60:
        hours, minutes = divmod(minutes, 60)
        return f"{hours}h {minutes:02d}m"
    return f"{minutes:02d}:{secs:02d}"


def stars(n: int) -> str:
    return "★" * n + "☆" * (5 - n)


# =============================================================================
# Mini-HTML → tk.Text renderer
# =============================================================================
class RichText:
    """Owns the tag/font setup for a tk.Text and inserts a small HTML subset into it.

    Supported: b strong i em u sup sub code br p div h3 h4 ul ol li hr a(href)
    span class="hi|lo|crit|good|bad|muted|key", table/tr/th/td (td class="hi|lo|crit|muted").
    """

    def __init__(self, text: tk.Text, base_size: int = 11, wrap_px: int = 860) -> None:
        self.text = text
        self.base_size = base_size
        self.wrap_px = wrap_px
        self._fonts: dict[tuple, str] = {}
        self._font_objs: list[tkfont.Font] = []
        self._link_n = 0
        family = "Segoe UI"
        self.family = family
        text.tag_configure("hi", foreground="#b42318")
        text.tag_configure("crit", foreground="#ffffff", background="#b42318")
        text.tag_configure("lo", foreground="#1d5fa8")
        text.tag_configure("good", foreground="#207245")
        text.tag_configure("bad", foreground="#a13333")
        text.tag_configure("muted", foreground="#66737f")
        text.tag_configure("key", background="#fff2b3")
        text.tag_configure("link", foreground="#1a5fb4", underline=True)
        text.tag_configure("li", lmargin1=18, lmargin2=34)
        text.tag_configure("li2", lmargin1=38, lmargin2=54)
        text.tag_configure("indent", lmargin1=16, lmargin2=16)

    def font_tag(self, bold: bool, italic: bool, mono: bool, size_delta: int, offset: int) -> str:
        key = (bold, italic, mono, size_delta, offset)
        if key not in self._fonts:
            name = "f%d" % len(self._fonts)
            f = tkfont.Font(family="Consolas" if mono else self.family, size=self.base_size + size_delta,
                            weight="bold" if bold else "normal", slant="italic" if italic else "roman")
            self.text.tag_configure(name, font=f, offset=offset)
            self._fonts[key] = name
            self._font_objs.append(f)  # keep a reference, or Tk deletes the named font
        return self._fonts[key]

    def insert(self, html: str, extra_tags: tuple[str, ...] = (), bold: bool = False, size_delta: int = 0) -> None:
        parser = _HtmlInserter(self, extra_tags, bold, size_delta)
        parser.feed(html or "")
        parser.close()

    def link(self, label: str, url: str, extra_tags: tuple[str, ...] = ()) -> None:
        self._link_n += 1
        tag = f"link{self._link_n}"
        self.text.tag_bind(tag, "<Button-1>", lambda _e, u=url: webbrowser.open(u))
        self.text.tag_bind(tag, "<Enter>", lambda _e: self.text.configure(cursor="hand2"))
        self.text.tag_bind(tag, "<Leave>", lambda _e: self.text.configure(cursor=""))
        self.text.insert("end", label, ("link", tag, self.font_tag(False, False, False, 0, 0)) + extra_tags)

    def ensure_newline(self) -> None:
        if self.text.get("end-2c", "end-1c") not in ("\n", ""):
            self.text.insert("end", "\n")

    def table(self, rows: list[list[dict[str, Any]]]) -> None:
        if not rows:
            return
        frame = tk.Frame(self.text, bg="#c9d2db", bd=0)
        ncols = max(len(r) for r in rows)
        for r_i, row in enumerate(rows):
            for c_i, cell in enumerate(row):
                head = cell["th"]
                cls = cell.get("cls", "")
                fg = {"hi": "#b42318", "lo": "#1d5fa8", "crit": "#ffffff", "muted": "#66737f", "good": "#207245"}.get(cls, "#1f2d3a")
                bg = "#e6edf4" if head else ("#b42318" if cls == "crit" else ("#ffffff" if r_i % 2 else "#f8fafc"))
                weight = "bold" if (head or cell["bold"] or cls in ("hi", "lo", "crit")) else "normal"
                lbl = tk.Label(frame, text=cell["text"].strip(), bg=bg, fg=fg, anchor="w", justify="left",
                               font=(self.family, self.base_size - 1, weight), padx=8, pady=3,
                               wraplength=max(140, int(self.wrap_px / max(ncols, 1)) - 10))
                span = int(cell.get("colspan", 1))
                lbl.grid(row=r_i, column=c_i, columnspan=span, sticky="nsew", padx=(0, 1), pady=(0, 1))
        self.ensure_newline()
        self.text.window_create("end", window=frame, padx=2, pady=4)
        self.text.insert("end", "\n")

    def hr(self) -> None:
        self.ensure_newline()
        line = tk.Frame(self.text, height=1, width=self.wrap_px, bg="#c9d2db")
        self.text.window_create("end", window=line, pady=6)
        self.text.insert("end", "\n")


class _HtmlInserter(HTMLParser):
    def __init__(self, rt: RichText, extra: tuple[str, ...], bold: bool, size_delta: int) -> None:
        super().__init__(convert_charrefs=True)
        self.rt = rt
        self.extra = extra
        self.bold = 1 if bold else 0
        self.italic = 0
        self.mono = 0
        self.size_delta = size_delta
        self.h = 0
        self.v_shift = 0
        self.sub_shrink = 0
        self.classes: list[str] = []
        self.links: list[str | None] = []
        self.lists: list[list[Any]] = []  # [kind, counter]
        self.table_rows: list[list[dict[str, Any]]] | None = None
        self.cell: dict[str, Any] | None = None
        self.underline = 0

    # --- tags ---------------------------------------------------------------
    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        a = dict(attrs)
        t = self.rt.text
        if self.table_rows is not None:
            if tag == "tr":
                self.table_rows.append([])
            elif tag in ("td", "th"):
                if not self.table_rows:
                    self.table_rows.append([])
                self.cell = {"text": "", "th": tag == "th", "bold": False, "cls": a.get("class") or "", "colspan": a.get("colspan") or 1}
                self.table_rows[-1].append(self.cell)
            elif tag in ("b", "strong") and self.cell is not None:
                self.cell["bold"] = True
            elif tag == "br" and self.cell is not None:
                self.cell["text"] += "\n"
            return
        if tag in ("b", "strong"):
            self.bold += 1
        elif tag in ("i", "em"):
            self.italic += 1
        elif tag == "u":
            self.underline += 1
        elif tag == "code":
            self.mono += 1
        elif tag == "sup":
            self.v_shift += 4
            self.sub_shrink += 1
        elif tag == "sub":
            self.v_shift -= 3
            self.sub_shrink += 1
        elif tag in ("h3", "h4"):
            self.rt.ensure_newline()
            self.h += 1
            self.bold += 1
        elif tag == "br":
            t.insert("end", "\n")
        elif tag in ("p", "div"):
            self.rt.ensure_newline()
        elif tag in ("ul", "ol"):
            self.rt.ensure_newline()
            self.lists.append([tag, 0])
        elif tag == "li":
            self.rt.ensure_newline()
            if self.lists:
                self.lists[-1][1] += 1
                bullet = f"{self.lists[-1][1]}. " if self.lists[-1][0] == "ol" else "•  "
            else:
                bullet = "•  "
            self._emit(bullet)
        elif tag == "span":
            self.classes.append(a.get("class") or "")
        elif tag == "a":
            self.links.append(a.get("href"))
        elif tag == "table":
            self.table_rows = []
        elif tag == "hr":
            self.rt.hr()

    def handle_endtag(self, tag: str) -> None:
        if self.table_rows is not None:
            if tag in ("td", "th"):
                self.cell = None
            elif tag == "table":
                rows = self.table_rows
                self.table_rows = None
                self.rt.table(rows)
            return
        if tag in ("b", "strong"):
            self.bold = max(0, self.bold - 1)
        elif tag in ("i", "em"):
            self.italic = max(0, self.italic - 1)
        elif tag == "u":
            self.underline = max(0, self.underline - 1)
        elif tag == "code":
            self.mono = max(0, self.mono - 1)
        elif tag == "sup":
            self.v_shift -= 4
            self.sub_shrink -= 1
        elif tag == "sub":
            self.v_shift += 3
            self.sub_shrink -= 1
        elif tag in ("h3", "h4"):
            self.h = max(0, self.h - 1)
            self.bold = max(0, self.bold - 1)
            self.rt.text.insert("end", "\n")
        elif tag == "p":
            self.rt.text.insert("end", "\n")
        elif tag in ("ul", "ol"):
            if self.lists:
                self.lists.pop()
            self.rt.ensure_newline()
        elif tag == "span":
            if self.classes:
                self.classes.pop()
        elif tag == "a":
            if self.links:
                self.links.pop()

    def handle_startendtag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        self.handle_starttag(tag, attrs)

    def handle_data(self, data: str) -> None:
        if self.table_rows is not None:
            if self.cell is not None:
                self.cell["text"] += re.sub(r"\s+", " ", data)
            return
        self._emit(data)

    def _emit(self, data: str) -> None:
        if not data:
            return
        size = self.size_delta + (2 if self.h else 0) - (2 if self.sub_shrink > 0 else 0)
        tags: list[str] = [self.rt.font_tag(bool(self.bold), bool(self.italic), bool(self.mono), size, self.v_shift)]
        tags.extend(c for c in self.classes if c)
        if self.underline:
            self.rt.text.tag_configure("u", underline=True)
            tags.append("u")
        if self.lists:
            tags.append("li" if len(self.lists) == 1 else "li2")
        tags.extend(self.extra)
        url = next((u for u in reversed(self.links) if u), None)
        if url:
            self.rt.link(data, url, tuple(tags[1:]))
            return
        self.rt.text.insert("end", data, tuple(tags))


# =============================================================================
# The app
# =============================================================================
class ABIMQuestionNudge:
    def __init__(self, root: tk.Tk, background_start: bool = False) -> None:
        self.root = root
        self.settings = load_settings()
        self.questions: list[dict[str, Any]] = []
        self.by_id: dict[str, dict[str, Any]] = {}
        self.bank_warnings: list[str] = []
        self.bank_files: list[dict[str, Any]] = []
        self.popup: tk.Toplevel | None = None
        self.popup_text: tk.Text | None = None
        self.popup_q: dict[str, Any] | None = None
        self.popup_state = "unanswered"
        self.selected_answer = tk.StringVar(value="")
        self.option_widgets: dict[str, tk.Radiobutton] = {}
        self.struck: set[str] = set()
        self.next_due: float | None = None
        self.is_destroying = False
        self.interval_var = tk.StringVar(value=str(self.settings["interval_minutes"]))
        self.main_interval_var = tk.StringVar(value=str(self.settings["interval_minutes"]))
        self.order_var = tk.StringVar(value=self.settings["order_mode"])
        self.section_var = tk.StringVar(value=self.settings.get("section_filter", "All specialties"))
        self.min_diff_var = tk.StringVar(value=str(self.settings.get("min_difficulty", 1)))
        self.hide_var = tk.BooleanVar(value=bool(self.settings.get("hide_specialty", True)))
        self.requeue_var = tk.BooleanVar(value=bool(self.settings.get("requeue_missed", True)))
        self.startup_var = tk.BooleanVar(value=bool(self.settings.get("startup_enabled", False)))
        self.autoclose_var = tk.StringVar(value=str(self.settings.get("auto_close_minutes", 10)))
        self._autoclose_job: str | None = None
        self.source_var = tk.StringVar(value=self.settings.get("source_mode", SOURCE_MODES[0]))
        self.url_var = tk.StringVar(value=self.settings.get("remote_url", DEFAULT_REMOTE_URL))
        self.remote = read_remote_cache(self.settings.get("remote_url", DEFAULT_REMOTE_URL))
        self.online_status = "Online bank: not loaded yet"
        self._fetching = False
        self._fetch_result: tuple[str, Any] | None = None

        self._configure_ttk()
        self.reload_banks(initial=True)
        self._build_main_window()
        self.root.protocol("WM_DELETE_WINDOW", self.minimize_main_window)
        self.root.bind("<Control-q>", lambda _e: self.quit_app())
        self.root.bind("<F8>", lambda _e: self.show_question_now())

        pending = self.settings.get("pending_question_id")
        if pending in self.by_id:
            self.root.after(800, lambda q=pending: self.show_question(q, count_as_seen=False))
        elif not self.settings.get("paused"):
            due = self.settings.get("next_due_epoch")
            if due is None:
                self.schedule_next()
            else:
                self.next_due = float(due)
                if self.next_due <= time.time():
                    self.root.after(900, self.show_question_now)
        self._tick()
        if self.settings.get("source_mode") != "Local only":
            self.root.after(400, self.fetch_online)
        if background_start:
            self.root.after(500, self.root.iconify)

    # ------------------------------------------------------------------ banks
    # ------------------------------------------------------------ online bank
    def fetch_online(self) -> None:
        url = self.url_var.get().strip()
        if not url.startswith(("http://", "https://")):
            self._set_online_status("Online bank: enter an http(s) URL", "#9a5c08")
            return
        if self._fetching:
            return
        self.settings["remote_url"] = url
        save_settings(self.settings)
        self._fetching = True
        self._set_online_status("Online bank: downloading…", "#586777")

        def work() -> None:
            try:
                self._fetch_result = ("ok", fetch_remote_bank(url))
            except Exception as exc:
                self._fetch_result = ("error", exc)

        threading.Thread(target=work, daemon=True).start()
        self.root.after(250, self._poll_fetch)

    def _poll_fetch(self) -> None:
        if self._fetch_result is None:
            self.root.after(250, self._poll_fetch)
            return
        kind, value = self._fetch_result
        self._fetch_result = None
        self._fetching = False
        if kind == "ok":
            self.remote = value
            self.reload_banks(quiet=True)
            n = next((f["count"] for f in self.bank_files if f["file"] == "__online__"), 0)
            via = " (via raw GitHub — Pages not live yet)" if value.get("served_from", "").startswith("https://raw.githubusercontent.com") and "raw.githubusercontent.com" not in value.get("url", "") else ""
            self._set_online_status(f"Online bank: {n} questions · updated {time.strftime('%b %d %H:%M')}{via}", "#28704a")
        else:
            cached = read_remote_cache(self.url_var.get().strip())
            when = time.strftime("%b %d %H:%M", time.localtime(cached["fetched_at"])) if cached else None
            note = f"using the copy saved {when}" if when else "no saved copy yet; using local banks"
            self._set_online_status(f"Online bank: couldn't connect ({value.__class__.__name__}); {note}", "#9a5c08")

    def _set_online_status(self, text: str, color: str) -> None:
        self.online_status = text
        if hasattr(self, "online_label"):
            self.online_label.configure(text=text, foreground=color)

    def change_source(self, _event: Any = None) -> None:
        self.settings["source_mode"] = self.source_var.get()
        self.settings["cycle_seen"] = []
        save_settings(self.settings)
        self.reload_banks(quiet=True)
        if self.settings["source_mode"] != "Local only" and self.remote is None:
            self.fetch_online()
        self._set_main_status(f"{len(self.pool())} questions in the pool ({self.settings['source_mode']}).", "#586777")

    def reload_banks(self, initial: bool = False, quiet: bool = False) -> None:
        self.questions, self.bank_warnings, self.bank_files = load_banks(
            self.settings.get("disabled_banks", []), self.remote, self.settings.get("source_mode", SOURCE_MODES[0]))
        self.by_id = {q["id"]: q for q in self.questions}
        if quiet and not initial:
            self._refresh_filters()
            self._refresh_main()
            return
        if not initial:
            self._refresh_filters()
            self._refresh_main()
            if self.settings.get("source_mode") != "Local only":
                self.fetch_online()
            msg = f"Loaded {len(self.questions)} questions from {sum(1 for f in self.bank_files if f['enabled'])} source(s)."
            if self.bank_warnings:
                msg += f"\n\n{len(self.bank_warnings)} problem(s) found — invalid questions were skipped:\n\n" + "\n".join(self.bank_warnings[:25])
                messagebox.showwarning(APP_NAME, msg, parent=self.root)
            else:
                self._set_main_status(msg, "#28704a")
        elif self.bank_warnings:
            self.root.after(600, lambda: messagebox.showwarning(
                APP_NAME, f"Some questions could not be loaded and were skipped:\n\n" + "\n".join(self.bank_warnings[:25]), parent=self.root))

    def sections(self) -> list[str]:
        return sorted({q["section"] for q in self.questions})

    def pool(self) -> list[dict[str, Any]]:
        sec = self.settings.get("section_filter", "All specialties")
        lo = int(self.settings.get("min_difficulty", 1))
        out = [q for q in self.questions if q["difficulty"] >= lo and (sec == "All specialties" or q["section"] == sec)]
        return out or self.questions

    def open_banks_folder(self) -> None:
        BANKS_DIR.mkdir(exist_ok=True)
        try:
            if os.name == "nt":
                os.startfile(str(BANKS_DIR))  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(BANKS_DIR)])
            else:
                subprocess.Popen(["xdg-open", str(BANKS_DIR)])
        except Exception as exc:
            messagebox.showinfo(APP_NAME, f"Banks folder:\n{BANKS_DIR}\n\n({exc})", parent=self.root)

    def add_bank_file(self) -> None:
        path = filedialog.askopenfilename(parent=self.root, title="Add a question-bank JSON file",
                                          filetypes=[("JSON question bank", "*.json"), ("All files", "*.*")])
        if not path:
            return
        src = Path(path)
        try:
            data = json.loads(src.read_text(encoding="utf-8-sig"))
            items = data.get("questions", []) if isinstance(data, dict) else data
            if not isinstance(items, list) or not items:
                raise ValueError("no 'questions' list found")
        except Exception as exc:
            messagebox.showerror(APP_NAME, f"That file isn't a usable bank:\n\n{exc}", parent=self.root)
            return
        dest = BANKS_DIR / src.name
        if dest.exists() and dest.resolve() != src.resolve():
            if not messagebox.askyesno(APP_NAME, f"{dest.name} already exists in the banks folder. Replace it?", parent=self.root):
                return
        if dest.resolve() != src.resolve():
            dest.write_text(src.read_text(encoding="utf-8-sig"), encoding="utf-8")
        self.reload_banks()

    def choose_banks(self) -> None:
        win = tk.Toplevel(self.root)
        win.title("Question banks")
        win.configure(bg=BG, padx=16, pady=14)
        win.transient(self.root)
        tk.Label(win, text="Tick the bank files to include. Files live in the banks folder; drop new *.json files there and press Reload.",
                 bg=BG, wraplength=520, justify="left", font=("Segoe UI", 10)).pack(anchor="w", pady=(0, 10))
        vars_: dict[str, tk.BooleanVar] = {}
        for f in self.bank_files:
            v = tk.BooleanVar(value=f["file"] not in self.settings.get("disabled_banks", []))
            vars_[f["file"]] = v
            if f["file"] == "__online__":
                label = f"{f['title']}  ({f['count']} questions)"
            else:
                label = f"{f['title']}  —  {f['file']}  ({f['count']} questions)" if not f["error"] else f"{f['file']}  — ERROR: {f['error']}"
            ttk.Checkbutton(win, text=label, variable=v).pack(anchor="w", pady=1)

        def apply() -> None:
            self.settings["disabled_banks"] = [name for name, v in vars_.items() if not v.get()]
            save_settings(self.settings)
            win.destroy()
            self.reload_banks()

        row = tk.Frame(win, bg=BG)
        row.pack(fill="x", pady=(12, 0))
        ttk.Button(row, text="Apply", style="Accent.TButton", command=apply).pack(side="left")
        ttk.Button(row, text="Cancel", command=win.destroy).pack(side="left", padx=8)

    # -------------------------------------------------------------- main UI
    def _configure_ttk(self) -> None:
        self.root.title(APP_NAME)
        self.root.geometry("820x760")
        self.root.minsize(700, 620)
        try:
            style = ttk.Style(self.root)
            if "clam" in style.theme_names():
                style.theme_use("clam")
            style.configure("TButton", font=("Segoe UI", 10), padding=(10, 6))
            style.configure("Accent.TButton", font=("Segoe UI", 10, "bold"), padding=(12, 7))
            style.configure("TLabel", font=("Segoe UI", 10))
            style.configure("Title.TLabel", font=("Segoe UI", 21, "bold"), foreground=NAVY)
            style.configure("SubTitle.TLabel", font=("Segoe UI", 10), foreground="#586777")
            style.configure("Card.TLabelframe", padding=12)
            style.configure("Card.TLabelframe.Label", font=("Segoe UI", 10, "bold"), foreground=NAVY)
        except tk.TclError:
            pass
        self.root.configure(background="#f3f5f7")

    def _build_main_window(self) -> None:
        outer = ttk.Frame(self.root, padding=18)
        outer.pack(fill="both", expand=True)
        ttk.Label(outer, text="ABIM Question Nudge", style="Title.TLabel").pack(anchor="w")
        ttk.Label(outer, text="One hard case at a time, on a timer. Harder questions are worth more points.",
                  style="SubTitle.TLabel", wraplength=760).pack(anchor="w", pady=(2, 12))

        top = ttk.Frame(outer)
        top.pack(fill="x")
        timer_card = ttk.LabelFrame(top, text="NEXT QUESTION", style="Card.TLabelframe")
        timer_card.pack(side="left", fill="both", expand=True, padx=(0, 8))
        self.timer_label = ttk.Label(timer_card, text="15:00", font=("Segoe UI", 26, "bold"), foreground=NAVY)
        self.timer_label.pack(anchor="w")
        self.status_label = ttk.Label(timer_card, text="Running", foreground="#28704a", wraplength=330)
        self.status_label.pack(anchor="w", pady=(2, 0))

        score_card = ttk.LabelFrame(top, text="SCORE", style="Card.TLabelframe")
        score_card.pack(side="left", fill="both", expand=True)
        self.score_big = ttk.Label(score_card, text="0 pts", font=("Segoe UI", 22, "bold"), foreground="#7a4b00")
        self.score_big.pack(anchor="w")
        self.score_sub = ttk.Label(score_card, text="", wraplength=330, justify="left")
        self.score_sub.pack(anchor="w")

        settings_card = ttk.LabelFrame(outer, text="SETTINGS", style="Card.TLabelframe")
        settings_card.pack(fill="x", pady=10)
        r1 = ttk.Frame(settings_card)
        r1.pack(fill="x", pady=2)
        ttk.Label(r1, text="Ask every").pack(side="left")
        ttk.Spinbox(r1, from_=1, to=240, width=5, textvariable=self.main_interval_var).pack(side="left", padx=(6, 4))
        ttk.Label(r1, text="min").pack(side="left")
        ttk.Button(r1, text="Apply", command=self.apply_main_interval).pack(side="left", padx=(8, 0))
        ttk.Label(r1, text="Order").pack(side="left", padx=(18, 6))
        order_box = ttk.Combobox(r1, textvariable=self.order_var, values=ORDER_MODES, state="readonly", width=12)
        order_box.pack(side="left")
        order_box.bind("<<ComboboxSelected>>", self.change_filters)
        ttk.Label(r1, text="Min difficulty").pack(side="left", padx=(18, 6))
        diff_box = ttk.Combobox(r1, textvariable=self.min_diff_var, values=["1", "2", "3", "4", "5"], state="readonly", width=3)
        diff_box.pack(side="left")
        diff_box.bind("<<ComboboxSelected>>", self.change_filters)

        r2 = ttk.Frame(settings_card)
        r2.pack(fill="x", pady=(8, 2))
        ttk.Label(r2, text="Specialty").pack(side="left")
        self.section_box = ttk.Combobox(r2, textvariable=self.section_var, state="readonly", width=34)
        self.section_box.pack(side="left", padx=(6, 0))
        self.section_box.bind("<<ComboboxSelected>>", self.change_filters)
        ttk.Checkbutton(r2, text="Hide specialty until answered", variable=self.hide_var, command=self.change_filters).pack(side="left", padx=(16, 0))

        r3 = ttk.Frame(settings_card)
        r3.pack(fill="x", pady=(8, 2))
        ttk.Checkbutton(r3, text="Re-ask missed questions later", variable=self.requeue_var, command=self.change_filters).pack(side="left")
        ttk.Label(r3, text="Auto-close unanswered after").pack(side="left", padx=(16, 4))
        ac = ttk.Spinbox(r3, from_=0, to=120, width=4, textvariable=self.autoclose_var, command=self.change_autoclose)
        ac.pack(side="left")
        ac.bind("<FocusOut>", self.change_autoclose)
        ac.bind("<Return>", self.change_autoclose)
        ttk.Label(r3, text="min (0 = never)").pack(side="left", padx=(4, 0))
        r4 = ttk.Frame(settings_card)
        r4.pack(fill="x", pady=(8, 2))
        ttk.Checkbutton(r4, text="Launch in the background when I sign in to Windows", variable=self.startup_var,
                        command=self.toggle_startup).pack(side="left", padx=(16, 0))

        bank_card = ttk.LabelFrame(outer, text="QUESTION BANKS", style="Card.TLabelframe")
        bank_card.pack(fill="x", pady=(0, 10))
        self.bank_label = ttk.Label(bank_card, text="", wraplength=760, justify="left")
        self.bank_label.pack(anchor="w")
        br = ttk.Frame(bank_card)
        br.pack(fill="x", pady=(8, 0))
        ttk.Button(br, text="Choose banks…", command=self.choose_banks).pack(side="left")
        ttk.Button(br, text="Add bank file…", command=self.add_bank_file).pack(side="left", padx=6)
        ttk.Button(br, text="Open banks folder", command=self.open_banks_folder).pack(side="left")
        ttk.Button(br, text="Reload", command=self.reload_banks).pack(side="left", padx=6)
        orow = ttk.Frame(bank_card)
        orow.pack(fill="x", pady=(10, 0))
        ttk.Label(orow, text="Source").pack(side="left")
        src_box = ttk.Combobox(orow, textvariable=self.source_var, values=SOURCE_MODES, state="readonly", width=20)
        src_box.pack(side="left", padx=(6, 12))
        src_box.bind("<<ComboboxSelected>>", self.change_source)
        ttk.Label(orow, text="Online URL").pack(side="left")
        ttk.Entry(orow, textvariable=self.url_var, width=46).pack(side="left", padx=(6, 6), fill="x", expand=True)
        ttk.Button(orow, text="Fetch now", command=self.fetch_online).pack(side="left")
        self.online_label = ttk.Label(bank_card, text=self.online_status, foreground="#586777", wraplength=760)
        self.online_label.pack(anchor="w", pady=(4, 0))

        action_row = ttk.Frame(outer)
        action_row.pack(fill="x", pady=(2, 8))
        ttk.Button(action_row, text="Show a question now  (F8)", style="Accent.TButton", command=self.show_question_now).pack(side="left")
        self.pause_button = ttk.Button(action_row, text="Pause", command=self.toggle_pause)
        self.pause_button.pack(side="left", padx=8)
        ttk.Button(action_row, text="Reset score…", command=self.reset_stats).pack(side="left")
        ttk.Button(action_row, text="Quit app", command=self.quit_app).pack(side="right")

        self.breakdown = ttk.Label(outer, text="", justify="left", wraplength=780, font=("Consolas", 9))
        self.breakdown.pack(anchor="w", fill="x")
        ttk.Label(outer, text="Educational review only — verify clinical decisions against current primary sources. Progress stays on this computer.",
                  style="SubTitle.TLabel", wraplength=780).pack(anchor="w", side="bottom", pady=(8, 0))
        self._refresh_filters()
        self._refresh_main()

    def _refresh_filters(self) -> None:
        values = ["All specialties"] + self.sections()
        self.section_box.configure(values=values)
        if self.section_var.get() not in values:
            self.section_var.set("All specialties")
            self.settings["section_filter"] = "All specialties"
        enabled = [f for f in self.bank_files if f["enabled"] and f["file"] != "__online__"]
        online = next((f for f in self.bank_files if f["file"] == "__online__" and f["enabled"]), None)
        levels = {lvl: sum(1 for q in self.questions if q["difficulty"] == lvl) for lvl in range(1, 6)}
        lvl_txt = "   ".join(f"{stars(l)} {n}" for l, n in levels.items() if n)
        warn = f"   ⚠ {len(self.bank_warnings)} skipped (see Reload)" if self.bank_warnings else ""
        src = f"{len(enabled)} local file(s)" + (f" + online ({online['count']})" if online else "")
        self.bank_label.configure(text=f"{len(self.questions)} questions from {src}{warn}\n{lvl_txt}")

    def change_filters(self, _event: Any = None) -> None:
        self.settings["order_mode"] = self.order_var.get()
        self.settings["section_filter"] = self.section_var.get()
        try:
            self.settings["min_difficulty"] = int(self.min_diff_var.get())
        except ValueError:
            self.settings["min_difficulty"] = 1
        self.settings["hide_specialty"] = bool(self.hide_var.get())
        self.settings["requeue_missed"] = bool(self.requeue_var.get())
        self.settings["cycle_seen"] = []
        save_settings(self.settings)
        n = len(self.pool())
        self._set_main_status(f"{n} questions in the current pool · {self.settings['order_mode']} order.", "#586777")

    def apply_main_interval(self) -> None:
        try:
            minutes = int(self.main_interval_var.get().strip())
            if not 1 <= minutes <= 240:
                raise ValueError
        except ValueError:
            messagebox.showwarning(APP_NAME, "Choose a whole number of minutes from 1 to 240.", parent=self.root)
            self.main_interval_var.set(str(self.settings["interval_minutes"]))
            return
        self.apply_interval_value(minutes, reset_timer=True)

    def apply_interval_value(self, minutes: int, reset_timer: bool = True) -> None:
        self.settings["interval_minutes"] = minutes
        self.main_interval_var.set(str(minutes))
        self.interval_var.set(str(minutes))
        if reset_timer and not self.settings.get("paused") and self.popup is None:
            self.schedule_next(minutes)
        save_settings(self.settings)
        self._refresh_main()

    def toggle_startup(self) -> None:
        enabled = bool(self.startup_var.get())
        try:
            self.set_windows_startup(enabled)
        except Exception as exc:
            self.startup_var.set(not enabled)
            messagebox.showerror(APP_NAME, f"Could not change the sign-in setting.\n\n{exc}", parent=self.root)
            return
        self.settings["startup_enabled"] = enabled
        save_settings(self.settings)
        self._set_main_status(f"Windows sign-in launch {'enabled' if enabled else 'disabled'}.", "#28704a")

    def set_windows_startup(self, enabled: bool) -> None:
        if os.name != "nt":
            raise OSError("Automatic sign-in launch is supported on Windows only.")
        import winreg
        key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE) as key:
            if enabled:
                if FROZEN:
                    command = f'"{Path(sys.executable).resolve()}" --background'
                else:
                    python_path = Path(sys.executable)
                    if python_path.name.lower() == "python.exe" and python_path.with_name("pythonw.exe").exists():
                        python_path = python_path.with_name("pythonw.exe")
                    command = f'"{python_path}" "{Path(__file__).resolve()}" --background'
                winreg.SetValueEx(key, APP_NAME, 0, winreg.REG_SZ, command)
            else:
                try:
                    winreg.DeleteValue(key, APP_NAME)
                except FileNotFoundError:
                    pass

    def toggle_pause(self) -> None:
        paused = not bool(self.settings.get("paused"))
        self.settings["paused"] = paused
        if paused:
            self.next_due = None
            self.settings["next_due_epoch"] = None
            self._set_main_status("Paused — no new questions until you resume.", "#9a5c08")
        else:
            self.schedule_next()
            self._set_main_status("Reminders resumed.", "#28704a")
        save_settings(self.settings)
        self._refresh_main()

    def reset_stats(self) -> None:
        if not messagebox.askyesno(APP_NAME, "Reset your score, history, and adaptive level?", parent=self.root):
            return
        d = default_settings()
        for k in ("stats", "history", "adaptive_level", "missed_queue", "cycle_seen", "served"):
            self.settings[k] = d[k]
        save_settings(self.settings)
        self._refresh_main()

    def _set_main_status(self, text: str, color: str) -> None:
        self.status_label.configure(text=text, foreground=color)

    def _refresh_main(self) -> None:
        paused = bool(self.settings.get("paused"))
        if paused:
            self.timer_label.configure(text="PAUSED")
            self.pause_button.configure(text="Resume")
        elif self.popup is not None:
            self.timer_label.configure(text="QUESTION OPEN")
            self.pause_button.configure(text="Pause")
        elif self.next_due is not None:
            self.timer_label.configure(text=format_duration(self.next_due - time.time()))
            self.pause_button.configure(text="Pause")
        st = self.settings["stats"]
        attempts, correct = int(st.get("attempts", 0)), int(st.get("correct", 0))
        pts, possible = int(st.get("points", 0)), int(st.get("possible", 0))
        weighted = (100 * pts / possible) if possible else 0
        raw = (100 * correct / attempts) if attempts else 0
        self.score_big.configure(text=f"{pts:,} pts")
        level = float(self.settings.get("adaptive_level", 3.0))
        self.score_sub.configure(text=f"Difficulty-weighted: {weighted:.0f}%  ·  Raw: {correct}/{attempts} ({raw:.0f}%)\n"
                                      f"Revealed unscored: {st.get('revealed', 0)}  ·  Adaptive level: {level:.1f} / 5")
        lines = ["Level            Correct   Pts earned"]
        by_level = st.get("by_level", {})
        for lvl in range(1, 6):
            row = by_level.get(str(lvl))
            if row:
                lines.append(f"{stars(lvl)} {LEVEL_NAMES[lvl]:<11} {row[1]:>3}/{row[0]:<3}   {row[1] * lvl * POINTS_PER_LEVEL:>6}")
        by_sec = st.get("by_section", {})
        weak = sorted(((v[1] / v[0], k, v) for k, v in by_sec.items() if v[0] >= 3))[:3]
        if weak:
            lines.append("Weakest: " + "  ·  ".join(f"{k} {v[1]}/{v[0]}" for _, k, v in weak))
        self.breakdown.configure(text="\n".join(lines) if len(lines) > 1 else "")

    # ------------------------------------------------------------ scheduling
    def schedule_next(self, minutes: int | None = None) -> None:
        if self.settings.get("paused"):
            self.next_due = None
            self.settings["next_due_epoch"] = None
        else:
            actual = self.settings["interval_minutes"] if minutes is None else minutes
            self.next_due = time.time() + int(actual) * 60
            self.settings["next_due_epoch"] = self.next_due
        save_settings(self.settings)
        self._refresh_main()

    def _tick(self) -> None:
        if self.is_destroying:
            return
        if self.popup is None and not self.settings.get("paused") and self.next_due is not None:
            remaining = self.next_due - time.time()
            self.timer_label.configure(text=format_duration(remaining))
            if remaining <= 0:
                self.show_question_now()
        # Backstop for the <Unmap> hook: a question minimized for ~2 s evaporates.
        if self.popup is not None:
            try:
                iconic = self.popup.state() == "iconic"
            except tk.TclError:
                iconic = False
            self._iconic_ticks = getattr(self, "_iconic_ticks", 0) + 1 if iconic else 0
            if self._iconic_ticks >= 4:
                self._iconic_ticks = 0
                self._auto_close(self.popup, reason="minimized")
        self.root.after(500, self._tick)

    def _pick_question(self) -> str | None:
        pool = self.pool()
        if not pool:
            return None
        served = int(self.settings.get("served", 0))
        # 1) A missed question that has come due again.
        if self.settings.get("requeue_missed", True):
            mq = [m for m in self.settings.get("missed_queue", []) if m[0] in self.by_id]
            due = [m for m in mq if m[1] <= served]
            if due:
                mq.remove(due[0])
                self.settings["missed_queue"] = mq
                return due[0][0]
            self.settings["missed_queue"] = mq
        # 2) Otherwise, the next question in the cycle according to the order mode.
        seen = set(self.settings.get("cycle_seen", []))
        fresh = [q for q in pool if q["id"] not in seen]
        if not fresh:
            self.settings["cycle_seen"] = []
            fresh = pool[:]
        mode = self.settings.get("order_mode", "Mixed")
        if mode == "Easy → hard":  # climb the ladder; specialties mixed within each rung
            low = min(q["difficulty"] for q in fresh)
            choice = random.choice([q for q in fresh if q["difficulty"] == low])
        elif mode == "Hard → easy":
            high = max(q["difficulty"] for q in fresh)
            choice = random.choice([q for q in fresh if q["difficulty"] == high])
        elif mode == "Adaptive":
            target = float(self.settings.get("adaptive_level", 3.0))
            best = min(abs(q["difficulty"] - target) for q in fresh)
            choice = random.choice([q for q in fresh if abs(q["difficulty"] - target) - best < 0.51])
        else:
            choice = random.choice(fresh)
        self.settings.setdefault("cycle_seen", []).append(choice["id"])
        return choice["id"]

    def show_question_now(self) -> None:
        if self.popup is not None:
            self._bring_popup_to_front()
            return
        qid = self._pick_question()
        if qid is None:
            messagebox.showwarning(APP_NAME, "No questions are loaded. Put a bank JSON file in the banks folder and press Reload.", parent=self.root)
            self.schedule_next()
            return
        self.settings["served"] = int(self.settings.get("served", 0)) + 1
        self.show_question(qid)

    # --------------------------------------------------------------- popup
    def show_question(self, qid: str, count_as_seen: bool = True) -> None:
        if self.popup is not None:
            self._bring_popup_to_front()
            return
        q = self.by_id.get(qid)
        if not q:
            self.settings["pending_question_id"] = None
            self.schedule_next()
            return
        self.settings["pending_question_id"] = qid
        self.next_due = None
        self.settings["next_due_epoch"] = None
        if count_as_seen:
            self.settings["stats"]["seen"] = int(self.settings["stats"].get("seen", 0)) + 1
        save_settings(self.settings)

        win = tk.Toplevel(self.root)
        self.popup = win
        self.popup_q = q
        self.popup_state = "unanswered"
        self.selected_answer.set("")
        self.struck = set()
        self.option_widgets = {}
        hide = bool(self.settings.get("hide_specialty", True))
        win.title(f"{APP_NAME} — {stars(q['difficulty'])}")
        win.configure(background=BG)
        sw, sh = win.winfo_screenwidth(), win.winfo_screenheight()
        w, h = min(1040, sw - 40), min(880, sh - 80)
        win.geometry(f"{w}x{h}+{max(0, (sw - w) // 2)}+{max(0, (sh - h) // 2 - 20)}")
        win.minsize(780, 560)
        win.attributes("-topmost", True)
        win.protocol("WM_DELETE_WINDOW", self.dismiss_popup)

        header = tk.Frame(win, background=NAVY, padx=20, pady=12)
        header.pack(fill="x")
        left = tk.Frame(header, bg=NAVY)
        left.pack(side="left", fill="x", expand=True)
        self.header_section = tk.Label(left, text="Internal Medicine" if hide else q["section"],
                                       font=("Segoe UI", 16, "bold"), fg="white", bg=NAVY)
        self.header_section.pack(anchor="w")
        self.header_sub = tk.Label(left, text=f"{LEVEL_NAMES[q['difficulty']]} · worth {q['points']} points",
                                   font=("Segoe UI", 10), fg="#dce7ef", bg=NAVY)
        self.header_sub.pack(anchor="w", pady=(2, 0))
        tk.Label(header, text=stars(q["difficulty"]), font=("Segoe UI", 20), fg="#ffd166", bg=NAVY).pack(side="right")

        footer = tk.Frame(win, background="#e8edf2", padx=14, pady=10)
        footer.pack(fill="x", side="bottom")
        self.feedback_label = tk.Label(footer, text="Select an answer (A–E keys), then Check. Right-click an option to strike it out.",
                                       font=("Segoe UI", 10, "bold"), bg="#e8edf2", fg="#4b5b6a", anchor="w", justify="left", wraplength=w - 40)
        self.feedback_label.pack(fill="x", pady=(0, 8))
        buttons = tk.Frame(footer, bg="#e8edf2")
        buttons.pack(fill="x")
        self.check_btn = ttk.Button(buttons, text="Check answer  ⏎", style="Accent.TButton", command=self.check_answer)
        self.check_btn.pack(side="left")
        ttk.Button(buttons, text="Reveal (0 pts)", command=self.reveal_answer).pack(side="left", padx=(8, 0))
        ttk.Button(buttons, text="Snooze 5 min", command=lambda: self.dismiss_popup(snooze_minutes=5)).pack(side="left", padx=(8, 0))
        ttk.Button(buttons, text="Dismiss", command=self.dismiss_popup).pack(side="right")
        tk.Label(buttons, text="min", font=("Segoe UI", 10), bg="#e8edf2").pack(side="right", padx=(4, 14))
        self.interval_var.set(str(self.settings["interval_minutes"]))
        ttk.Spinbox(buttons, from_=1, to=240, width=4, textvariable=self.interval_var).pack(side="right")
        tk.Label(buttons, text="Next in", font=("Segoe UI", 10), bg="#e8edf2").pack(side="right", padx=(0, 6))

        body = tk.Frame(win, bg=BG)
        body.pack(fill="both", expand=True)
        text = tk.Text(body, wrap="word", bg=BG, relief="flat", padx=26, pady=18, cursor="arrow",
                       spacing1=1, spacing3=3, highlightthickness=0, borderwidth=0)
        sb = ttk.Scrollbar(body, orient="vertical", command=text.yview)
        text.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        text.pack(side="left", fill="both", expand=True)
        self.popup_text = text
        wrap_px = w - 110
        self.rich = RichText(text, base_size=11, wrap_px=wrap_px)

        self.rich.insert(q["stem"])
        self.rich.ensure_newline()
        for d in q.get("diagrams", []):
            text.insert("end", "\n")
            text.window_create("end", window=render_diagram(text, d, width=min(wrap_px, 900), bg=BG, base_dir=BANKS_DIR), padx=2)
            text.insert("end", "\n")
        if q.get("question"):
            text.insert("end", "\n")
            self.rich.insert(q["question"], bold=True)
            self.rich.ensure_newline()
        text.insert("end", "\n")
        for letter, option in q["options"].items():
            rb = tk.Radiobutton(text, text=f"{letter}.  {_strip_html(option)}", variable=self.selected_answer, value=letter,
                                font=("Segoe UI", 11), bg=BG, activebackground="#e9f0f7", fg="#233746", selectcolor="#dceaf5",
                                justify="left", anchor="w", wraplength=wrap_px - 40, padx=8, pady=5, bd=0, highlightthickness=0,
                                cursor="hand2")
            rb.bind("<Button-3>", lambda _e, L=letter: self.toggle_strike(L))
            rb.bind("<Button-2>", lambda _e, L=letter: self.toggle_strike(L))
            self.option_widgets[letter] = rb
            text.window_create("end", window=rb, stretch=1)
            text.insert("end", "\n")
        text.mark_set("explanation_start", "end-1c")
        text.mark_gravity("explanation_start", "left")
        text.configure(state="disabled")

        self._bind_scroll(win, text)
        win.bind("<Return>", lambda _e: self.check_answer())
        for letter in q["options"]:
            win.bind(f"<KeyPress-{letter.lower()}>", lambda _e, L=letter: self._key_select(L))
            win.bind(f"<KeyPress-{letter}>", lambda _e, L=letter: self._key_select(L))
        self._refresh_main()
        self._bring_popup_to_front()
        try:
            win.bell()
        except tk.TclError:
            pass
        self._arm_autoclose(win)
        # Minimizing the question = "not now": it evaporates instead of freezing the timer.
        win.bind("<Unmap>", lambda e, w=win: self.root.after(1200, lambda: self._check_minimized(w)) if e.widget is w else None)
        # Any interaction restarts the idle countdown.
        for seq in ("<ButtonPress>", "<KeyPress>", "<MouseWheel>"):
            win.bind_all(seq, lambda e, w=win: self._touch(w, e), add="+")

    def _arm_autoclose(self, win: tk.Toplevel) -> None:
        if self._autoclose_job is not None:
            try:
                self.root.after_cancel(self._autoclose_job)
            except tk.TclError:
                pass
            self._autoclose_job = None
        minutes = int(self.settings.get("auto_close_minutes", 10) or 0)
        if minutes > 0 and self.popup is win:
            self._autoclose_job = self.root.after(minutes * 60_000, lambda w=win: self._auto_close(w))

    def _touch(self, win: tk.Toplevel, event: tk.Event) -> None:
        if self.popup is win and str(event.widget).startswith(str(win)):
            self._arm_autoclose(win)

    def _check_minimized(self, win: tk.Toplevel) -> None:
        try:
            if self.popup is win and win.winfo_exists() and win.state() == "iconic":
                self._auto_close(win, reason="minimized")
        except tk.TclError:
            pass

    def change_autoclose(self, _event: Any = None) -> None:
        try:
            minutes = max(0, min(120, int(self.autoclose_var.get().strip())))
        except ValueError:
            minutes = int(self.settings.get("auto_close_minutes", 10))
        self.autoclose_var.set(str(minutes))
        self.settings["auto_close_minutes"] = minutes
        save_settings(self.settings)
        self._set_main_status("Questions stay until answered." if minutes == 0 else
                              f"Unanswered questions close themselves after {minutes} min and come back later.", "#586777")

    def _auto_close(self, win: tk.Toplevel, reason: str = "idle") -> None:
        """Nobody answered: close the window (no score change), bring the question back a few questions later."""
        self._autoclose_job = None
        if self.popup is not win:
            return
        q = self.popup_q
        if self.popup_state == "unanswered" and q is not None:
            mq = [m for m in self.settings.get("missed_queue", []) if m[0] != q["id"]]
            mq.append([q["id"], int(self.settings.get("served", 0)) + 3])
            self.settings["missed_queue"] = mq
        answered = self.popup_state != "unanswered"
        self.dismiss_popup()
        why = "was minimized" if reason == "minimized" else "sat untouched"
        tail = "" if answered else " — it will come back later, unscored"
        self._set_main_status(f"Last question {why}, so it closed itself{tail}. Timer is running.", "#9a5c08")

    def _bind_scroll(self, win: tk.Toplevel, text: tk.Text) -> None:
        def wheel(event: tk.Event) -> str | None:
            if self.popup is not win:
                return None
            if getattr(event, "num", None) == 4:
                text.yview_scroll(-3, "units")
            elif getattr(event, "num", None) == 5:
                text.yview_scroll(3, "units")
            else:
                text.yview_scroll(int(-1 * (event.delta / 120)) * 3, "units")
            return "break"

        def bind_tree(widget: tk.Misc) -> None:
            widget.bind("<MouseWheel>", wheel, add="+")
            widget.bind("<Button-4>", wheel, add="+")
            widget.bind("<Button-5>", wheel, add="+")
            for child in widget.winfo_children():
                bind_tree(child)

        bind_tree(win)
        win._bind_tree = bind_tree  # type: ignore[attr-defined]

    def _key_select(self, letter: str) -> None:
        if self.popup_state == "unanswered" and letter not in self.struck:
            self.selected_answer.set(letter)

    def toggle_strike(self, letter: str) -> None:
        if self.popup_state != "unanswered":
            return
        rb = self.option_widgets.get(letter)
        if rb is None:
            return
        if letter in self.struck:
            self.struck.discard(letter)
            rb.configure(font=("Segoe UI", 11), fg="#233746")
        else:
            self.struck.add(letter)
            if not hasattr(self, "_strike_font"):
                self._strike_font = tkfont.Font(family="Segoe UI", size=11, overstrike=True)
            rb.configure(font=self._strike_font, fg="#9aa5b1")
            if self.selected_answer.get() == letter:
                self.selected_answer.set("")

    def _bring_popup_to_front(self) -> None:
        if self.popup is None:
            return
        try:
            self.popup.deiconify()
            self.popup.attributes("-topmost", True)
            self.popup.lift()
            self.popup.focus_force()
            active = self.popup
            self.root.after(150, lambda p=active: p.lift() if self.popup is p else None)
        except tk.TclError:
            pass

    def _record(self, q: dict[str, Any], correct: bool) -> None:
        st = self.settings["stats"]
        lvl = str(q["difficulty"])
        st["attempts"] = int(st.get("attempts", 0)) + 1
        st["possible"] = int(st.get("possible", 0)) + q["points"]
        if correct:
            st["correct"] = int(st.get("correct", 0)) + 1
            st["points"] = int(st.get("points", 0)) + q["points"]
        row = st.setdefault("by_level", {}).setdefault(lvl, [0, 0])
        row[0] += 1
        row[1] += int(correct)
        srow = st.setdefault("by_section", {}).setdefault(q["section"], [0, 0])
        srow[0] += 1
        srow[1] += int(correct)
        h = self.settings.setdefault("history", {}).setdefault(q["id"], {"attempts": 0, "correct": 0})
        h["attempts"] += 1
        h["correct"] += int(correct)
        h["last"] = int(time.time())
        # Adaptive level: climbs faster after beating hard questions, drops after missing easy ones.
        level = float(self.settings.get("adaptive_level", 3.0))
        d = q["difficulty"]
        level += (0.25 + 0.1 * max(0, d - level)) if correct else -(0.35 + 0.1 * max(0, level - d))
        self.settings["adaptive_level"] = round(max(1.0, min(5.0, level)), 2)
        if not correct and self.settings.get("requeue_missed", True):
            mq = [m for m in self.settings.get("missed_queue", []) if m[0] != q["id"]]
            mq.append([q["id"], int(self.settings.get("served", 0)) + 12])
            self.settings["missed_queue"] = mq

    def check_answer(self) -> None:
        if self.popup is None or self.popup_state != "unanswered" or self.popup_q is None:
            return
        picked = self.selected_answer.get()
        q = self.popup_q
        if picked not in q["options"]:
            self.feedback_label.configure(text="Choose an option first — or Reveal if you're stuck (scores 0).", fg="#9a5c08")
            return
        correct = picked == q["answer"]
        self._record(q, correct)
        if correct:
            self.popup_state = "correct"
            self.feedback_label.configure(text=f"✔ Correct — {q['answer']}.  +{q['points']} points.", fg="#207245")
        else:
            self.popup_state = "incorrect"
            requeue = "  It will come back in a while." if self.settings.get("requeue_missed", True) else ""
            self.feedback_label.configure(text=f"✘ Not quite — you chose {picked}; the answer is {q['answer']}.  0 of {q['points']} points.{requeue}", fg="#a13333")
        self._finish(q, picked)

    def reveal_answer(self) -> None:
        if self.popup is None or self.popup_state != "unanswered" or self.popup_q is None:
            return
        q = self.popup_q
        self.popup_state = "revealed"
        self.settings["stats"]["revealed"] = int(self.settings["stats"].get("revealed", 0)) + 1
        self.feedback_label.configure(text=f"Answer: {q['answer']} (revealed — not scored).", fg="#315f8c")
        self._finish(q, None)

    def _finish(self, q: dict[str, Any], picked: str | None) -> None:
        for letter, rb in self.option_widgets.items():
            rb.configure(state="disabled", disabledforeground="#233746")
            if letter == q["answer"]:
                rb.configure(bg="#d7f0df", disabledforeground="#14532d")
            elif letter == picked:
                rb.configure(bg="#f8d7d7", disabledforeground="#7f1d1d")
        self.check_btn.state(["disabled"])
        self.header_section.configure(text=q["section"] + (f"  ·  {q['topic']}" if q.get("topic") else ""))
        self._show_explanation(q, picked)
        save_settings(self.settings)
        self._refresh_main()

    def _show_explanation(self, q: dict[str, Any], picked: str | None) -> None:
        text = self.popup_text
        if text is None:
            return
        rt = self.rich
        text.configure(state="normal")
        text.insert("end", "\n")
        rt.hr()
        rt.insert("<h3>Explanation</h3>")
        rt.insert(q["explanation"])
        rt.ensure_newline()
        why_not = q.get("why_not") or {}
        if why_not:
            text.insert("end", "\n")
            rt.insert("<b>The other options</b>")
            rt.ensure_newline()
            for letter in q["options"]:
                if letter == q["answer"] or letter not in why_not:
                    continue
                mark = "  ← your choice" if letter == picked else ""
                rt.insert(f"<ul><li><b>{letter}.</b> {why_not[letter]}<span class=\"bad\">{mark}</span></li></ul>")
        if q.get("pearl"):
            text.insert("end", "\n")
            rt.insert(f"<span class=\"key\"><b>Pearl:</b> {q['pearl']}</span>")
            rt.ensure_newline()
        for d in q.get("answer_diagrams", []) or []:
            text.insert("end", "\n")
            wrap = rt.wrap_px
            text.window_create("end", window=render_diagram(text, d, width=min(wrap, 900), bg=BG, base_dir=BANKS_DIR), padx=2)
            text.insert("end", "\n")
        links = list(q.get("links") or [])
        query = q.get("image_query")
        if links or query:
            text.insert("end", "\n")
            rt.insert("<b>See it</b>")
            rt.ensure_newline()
            for link in links:
                text.insert("end", "  🔗 ")
                rt.link(link.get("label") or link["url"], link["url"])
                text.insert("end", "\n")
            if query:
                enc = urllib.parse.quote_plus(query)
                text.insert("end", "  🖼 ")
                rt.link(f"Image search: “{query}”", f"https://www.google.com/search?tbm=isch&q={enc}")
                text.insert("end", "    ")
                rt.link("Wikimedia Commons", f"https://commons.wikimedia.org/w/index.php?search={enc}&title=Special:MediaSearch&type=image")
                text.insert("end", "\n")
        refs = q.get("references") or []
        if refs:
            text.insert("end", "\n")
            rt.insert("<span class=\"muted\"><i>References: " + "; ".join(refs) + "</i></span>")
            rt.ensure_newline()
        h = self.settings.get("history", {}).get(q["id"])
        if h:
            text.insert("end", "\n")
            rt.insert(f"<span class=\"muted\">Your record on this question: {h['correct']}/{h['attempts']} · id {q['id']} · bank {q.get('_bank', '')}</span>")
        text.configure(state="disabled")
        if self.popup is not None:
            getattr(self.popup, "_bind_tree", lambda _w: None)(self.popup)
        self.root.after(80, lambda: text.see("explanation_start") if self.popup_text is text else None)
        self.root.after(90, lambda: text.yview("explanation_start") if self.popup_text is text else None)

    def dismiss_popup(self, snooze_minutes: int | None = None) -> None:
        if self.popup is None:
            return
        win = self.popup
        self.popup = None
        self.popup_text = None
        if self._autoclose_job is not None:
            try:
                self.root.after_cancel(self._autoclose_job)
            except tk.TclError:
                pass
            self._autoclose_job = None
        try:
            edited = int(self.interval_var.get().strip())
            if 1 <= edited <= 240:
                self.apply_interval_value(edited, reset_timer=False)
        except (ValueError, AttributeError):
            pass
        try:
            win.destroy()
        except tk.TclError:
            pass
        if self.popup_state == "unanswered" and snooze_minutes is not None and self.popup_q is not None:
            # Snoozed without answering: bring the same question back.
            self.settings["missed_queue"] = [m for m in self.settings.get("missed_queue", []) if m[0] != self.popup_q["id"]] + [[self.popup_q["id"], 0]]
        self.popup_q = None
        self.settings["pending_question_id"] = None
        if self.settings.get("paused"):
            self.next_due = None
            self.settings["next_due_epoch"] = None
        else:
            minutes = snooze_minutes if snooze_minutes is not None else int(self.settings["interval_minutes"])
            self.next_due = time.time() + minutes * 60
            self.settings["next_due_epoch"] = self.next_due
        save_settings(self.settings)
        self._refresh_main()

    def minimize_main_window(self) -> None:
        self.root.iconify()

    def quit_app(self) -> None:
        if not messagebox.askyesno(APP_NAME, "Quit the reminder app completely?\n\nNo more questions will appear until you launch it again.", parent=self.root):
            return
        self.is_destroying = True
        if self.popup is not None:
            try:
                self.popup.destroy()
            except tk.TclError:
                pass
            self.popup = None
        save_settings(self.settings)
        self.root.destroy()


def validate_cli() -> int:
    remote = None
    if "--online" in sys.argv[1:]:
        url = sys.argv[sys.argv.index("--online") + 1] if len(sys.argv) > sys.argv.index("--online") + 1 else DEFAULT_REMOTE_URL
        try:
            remote = fetch_remote_bank(url)
            print(f"Fetched {url}")
        except Exception as exc:
            print(f"Could not fetch {url}: {exc}")
    qs, warnings, files = load_banks(remote=remote)
    for f in files:
        print(f"{f['file']:<40} {f['count']:>4} questions" + (f"  ERROR {f['error']}" if f["error"] else ""))
    levels = {l: sum(1 for q in qs if q["difficulty"] == l) for l in range(1, 6)}
    print(f"Total {len(qs)} · by difficulty {levels}")
    for w in warnings:
        print("WARN", w)
    return 1 if warnings else 0


def main() -> None:
    seed_banks_folder()
    if "--validate" in sys.argv[1:]:
        sys.exit(validate_cli())
    background_start = "--background" in sys.argv[1:]
    try:
        root = tk.Tk()
        app = ABIMQuestionNudge(root, background_start=background_start)
        if "--show" in sys.argv[1:]:  # testing aid: --show <question id>
            qid = sys.argv[sys.argv.index("--show") + 1]
            root.after(300, lambda: app.show_question(qid))
        root.mainloop()
    except Exception as exc:
        try:
            temp = tk.Tk()
            temp.withdraw()
            messagebox.showerror(APP_NAME, f"The app couldn't start.\n\n{exc}", parent=temp)
            temp.destroy()
        except Exception:
            print(f"{APP_NAME}: {exc}", file=sys.stderr)
        raise


if __name__ == "__main__":
    main()
