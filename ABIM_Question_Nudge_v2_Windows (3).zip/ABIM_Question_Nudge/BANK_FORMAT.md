# Question bank format (v2)

Every `*.json` file in the **banks** folder is loaded at startup (and when you press **Reload**).
Add a file to expand the bank; remove or untick it (**Choose banks…**) to switch it out.
Questions that fail validation are skipped and listed in a warning. Nothing else breaks.
Double-click `Validate_Banks.bat` to check your files without opening the app.

## Online bank (GitHub Pages)

The dashboard's **Online URL** (default `https://dormantone.github.io/zipsandtheorums/quizdata.json`) is fetched at launch, on **Reload**, and on **Fetch now**, then cached for offline use. It uses the same format as below. Online questions override local questions with the same `id`. A file can also pull in others (relative or absolute URLs):

```json
{"title": "Board Quiz", "includes": ["cardiology.json", "neurology.json"], "questions": []}
```

## File layout

```json
{
  "title": "My cardiology set",
  "section": "Cardiology",          // default specialty for questions that don't set one
  "format_version": 2,
  "questions": [ { ...question... }, { ... } ]
}
```

A bare list `[ {...}, {...} ]` also works.

## Question fields

| Field | Required | Notes |
|---|---|---|
| `id` | yes | Unique across **all** files (e.g. `"card-brugada-icd"`). Duplicates are skipped. Your history is keyed by id. |
| `difficulty` | yes | 1–5 (rubric below). **Points = 10 × difficulty.** |
| `stem` | yes | The vignette. Mini-HTML allowed (see below), including lab tables. |
| `question` | no | The lead-in, shown in bold after any diagrams ("Which of the following is the most appropriate next step?"). |
| `options` | yes | Object `{"A": "...", "B": "...", ...}` (3–8 choices) or a plain list. |
| `answer` | yes | The correct letter. |
| `explanation` | yes | Why the answer is right. Mini-HTML allowed. |
| `why_not` | no | `{"A": "why A is wrong", ...}` for each distractor. Shown as a list after answering. |
| `pearl` | no | One-line takeaway, highlighted. |
| `section` | no | Specialty (falls back to the file's `section`). Used for the filter and weak-area stats. Hidden until answered if "Hide specialty" is on. |
| `topic` | no | Shown in the header after answering (e.g. "Brugada syndrome"). |
| `diagrams` | no | List of diagram specs shown under the stem (see below). |
| `answer_diagrams` | no | Diagrams shown only after answering (e.g. an annotated version). |
| `links` | no | `[{"label": "LITFL: Brugada", "url": "https://..."}]` shown after answering. Clicking opens your browser. |
| `image_query` | no | Text for automatic **Google Images** and **Wikimedia Commons** search links after answering, so every question can show real images without hard-coded URLs that might break. |
| `references` | no | List of citation strings. |

## Difficulty rubric

| Level | Name | What it means |
|---|---|---|
| 1 | Foundation | Single-step recall; the diagnosis is named. (The legacy 200 live here.) |
| 2 | Standard | One inference: recognize the unnamed diagnosis *or* pick standard management. |
| 3 | Board-level | Two steps: infer the hidden diagnosis from data, then choose the next step. At least one tempting distractor. |
| 4 | Hard | Multi-step with a trap: the usual answer is wrong because of one discriminating detail, or the key finding is in a lab table or diagram. |
| 5 | Expert | Subtle discriminators, recent guideline changes, quantitative reasoning, or an uncommon-but-tested entity. |

**Hide the ball, but disambiguate.** Don't name the diagnosis in the stem; show it through findings, labs, or a diagram. Then include the one detail that makes exactly one option defensible (e.g. *ADAMTS13 64%* rules out TTP, *afebrile ECG* makes the Brugada pattern spontaneous).

## Mini-HTML (stems, explanations, why_not, pearls)

`<b> <i> <u> <sup> <sub> <code> <br> <p> <h3> <ul>/<ol>/<li> <hr> <a href="...">`
and `<span class="hi|lo|crit|good|bad|muted|key">` for colored text.

Tables become real grids:

```html
<table>
 <tr><th>Test</th><th>Result</th><th>Reference</th></tr>
 <tr><td>Potassium</td><td class="hi">6.8 mEq/L</td><td>3.5–5.0</td></tr>
 <tr><td>Sodium</td><td class="lo">128 mEq/L</td><td>135–145</td></tr>
 <tr><td>INR</td><td class="crit">4.2</td><td>0.9–1.1</td></tr>
</table>
```

## Diagrams

All diagrams are drawn natively from JSON; no image files or internet needed. Each spec may include a `"caption"`.

### `ecg`: synthesized rhythm strips on ECG paper (25 mm/s, 10 mm/mV)

```json
{"type": "ecg", "duration": 6,
 "rhythm": {"type": "sinus", "rate": 72},
 "leads": [{"label": "II"},
           {"label": "V1", "r_amp": 0.35, "s_amp": 0.9, "st": 0.38, "st_shape": "coved", "t_amp": -0.28}]}
```

**Rhythm types** (the rhythm is shared by all leads):

- `sinus`: `rate`, `pr`, `pvc_every`
- `avb1`: `rate`, `pr`
- `mobitz1`: `atrial_rate`, `group` (4 = 4:3), `pr`, `increment`
- `mobitz2`: `atrial_rate`, `ratio` (every Nth P blocked), `pr`
- `chb`: `atrial_rate`, `ventricular_rate`, `wide_escape`
- `afib`: `rate`, `irregularity`, `variable_qrs` (pre-excited AF)
- `flutter`: `atrial_rate`, `conduction` (2, 4, or `"variable"`)
- `vt`: `rate`, `p_rate` (AV dissociation)
- `torsades`: `onset` (s), `pre_rate`, `rate`, `twist_period`
- `junctional`: `rate`
- All rhythm types also take `seed` (makes irregular rhythms repeatable).

**Per-lead morphology** (amplitudes in mV, times in s):
`p_amp, p_dur, qrs_dur, q_amp, r_amp, s_amp, r2_amp` (R′, e.g. RBBB), `delta` (pre-excitation, 0–1),
`st` (+ elevation / − depression), `st_shape` (`flat | coved | upsloping | downsloping`), `j_wave` (Osborn),
`t_amp` (negative = inverted), `t_width`, `qt`, `u_amp`, `alternans` (0–1), `invert`, `noise`, `f_amp` (fibrillation/flutter wave size).
`wide` / `pvc` sub-objects override morphology for wide beats.
Strip options: `strip_mv` (height per lead, default 3), `baseline_frac`.

### `flow_volume`: spirometry loops

```json
{"type": "flow_volume", "pattern": "variable_extrathoracic", "show_normal": true}
```

Patterns: `normal | obstructive | restrictive | fixed_upper | variable_extrathoracic | variable_intrathoracic`.

### `plot`: any line or point chart (hemodynamic tracings, ventilator waveforms, drug levels…)

```json
{"type": "plot", "x_label": "Time (s)", "y_label": "Pressure (mmHg)", "x_range": [0, 6], "y_range": [0, 125],
 "bands": [{"x0": 2.4, "x1": 5.0, "label": "Inspiration"}],
 "series": [{"label": "LV", "color": "#c0392b", "points": [[0, 22], [0.1, 80]]},
            {"label": "RV", "dashed": true, "points": [[0, 22], [0.1, 35]]}],
 "annotations": [{"x": 1, "y": 110, "text": "peak", "bold": true}]}
```

Series options: `markers`, `markers_only`, `width`, `dashed`.

### `vector`: schematic drawings (smears, crystals, anatomy, flow charts)

Coordinates are in your own `width` × `height` box and scale to fit.

```json
{"type": "vector", "width": 400, "height": 200, "bg": "#a85a88",
 "shapes": [
   {"kind": "circle", "x": 50, "y": 50, "r": 18, "fill": "#f4c7c3"},
   {"kind": "ellipse", "x": 120, "y": 60, "rx": 20, "ry": 7, "angle": -15, "fill": "#7c5aa6"},
   {"kind": "needle", "x": 200, "y": 100, "length": 40, "thickness": 3, "angle": 20, "fill": "#f2d64b"},
   {"kind": "polygon", "points": [10,10, 40,10, 45,25, 15,25], "fill": "#3a7bd5"},
   {"kind": "line", "points": [30,150, 140,150], "color": "white", "arrow": "end"},
   {"kind": "rect", "x": 250, "y": 20, "w": 60, "h": 30, "fill": "#eef"},
   {"kind": "box", "x": 250, "y": 120, "w": 120, "h": 40, "text": "Flow-chart box"},
   {"kind": "text", "x": 85, "y": 165, "text": "label", "size": 9, "color": "white"}]}
```

### `image`: a local PNG or GIF

`{"type": "image", "file": "images/smear1.png", "caption": "..."}`. The path is relative to the banks folder.

## Writing new questions with an AI assistant

Paste this file plus one example question from `banks/01_cardiology.json` and ask:

> Write 10 new ABIM-style questions on <topic> as JSON matching this schema. Difficulty 3–5. Hide the diagnosis in the stem but include one detail that makes exactly one answer defensible. Put labs in a `<table>`. Use an `ecg`, `plot`, `flow_volume`, or `vector` diagram where a figure is the natural way to present the data. Give `why_not` for every distractor, a `pearl`, guideline `references` with years, and an `image_query`. Vary which letter is correct.

Always verify AI-written content against primary sources before trusting it.
