@echo off
setlocal
cd /d "%~dp0"
title Building ABIM Question Nudge.exe
echo ============================================================
echo  Builds a single "ABIM Question Nudge.exe" you can double-click.
echo  Needs internet once (to install PyInstaller). Takes 1-3 minutes.
echo ============================================================
echo.

set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY (
    where python >nul 2>nul && set "PY=python"
)
if not defined PY (
    echo Python 3 was not found. Install it from https://www.python.org/downloads/windows/
    echo ^(tick "Add python.exe to PATH" during setup^), then run this again.
    pause
    exit /b 1
)

echo [1/3] Installing or updating PyInstaller...
%PY% -m pip install --upgrade --quiet pyinstaller
if errorlevel 1 (
    echo PyInstaller could not be installed. Check your internet connection and try again.
    pause
    exit /b 1
)

echo [2/3] Building the executable...
%PY% -m PyInstaller --noconfirm --clean --onefile --windowed ^
    --name "ABIM Question Nudge" ^
    --paths "%~dp0." ^
    --hidden-import qn_diagrams ^
    --add-data "banks;banks" ^
    "ABIM_Question_Nudge.py"
if errorlevel 1 (
    echo The build failed. Scroll up for the error.
    pause
    exit /b 1
)

echo [3/3] Copying the app next to this file...
copy /y "dist\ABIM Question Nudge.exe" "%~dp0ABIM Question Nudge.exe" >nul
rmdir /s /q build >nul 2>nul
del /q "ABIM Question Nudge.spec" >nul 2>nul

echo.
echo Done:  "%~dp0ABIM Question Nudge.exe"
echo You can move the .exe anywhere (Desktop, OneDrive...). On first run it creates a
echo "banks" folder beside itself; the online bank downloads automatically.
echo.
pause
