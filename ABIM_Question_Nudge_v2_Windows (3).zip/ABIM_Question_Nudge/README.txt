ABIM QUESTION NUDGE 2 — WINDOWS QUICK START
==========================================

START IT
--------
Easiest: double-click Build_EXE.bat once. It makes "ABIM Question Nudge.exe" — after that, just double-click the .exe.
Or run without building:
1. Extract the whole folder (keep the .py files and the "banks" folder together).
2. Double-click Start_ABIM_Question_Nudge.bat.
3. Press "Show a question now (F8)" to try one immediately. Minimize the dashboard to keep it running;
   the X button also minimizes. "Quit app" stops it.

Requires Python 3.9+ with Tkinter (the standard python.org installer includes it). No other installs.

WHAT'S NEW
----------
- 143 new board-level questions across 11 specialties, rated difficulty 2–5. Most are 3–5 ("board-level"
  to "expert"). Diagnoses are hidden in the findings; each item includes the one detail that makes a single
  answer correct.
- Diagrams drawn right in the window: ECG rhythm strips (Brugada, pre-excited AF, torsades, heart block,
  hyperkalemia…), hemodynamic tracings, ventilator waveforms, flow-volume loops, blood smears, and
  polarized-light crystals.
- Lab tables with high and low values flagged in color.
- After you answer: an explanation, why each wrong option is wrong, a one-line pearl, references, and
  clickable links (LITFL, DermNet, MDCalc, CDC, Wikipedia) plus Google Images and Wikimedia Commons
  image searches.
- Scoring is proportional to difficulty: 10 points × difficulty (a 5-star question is worth 50).
  Reveal = 0 points. The dashboard shows total points, difficulty-weighted %, raw %, per-level results,
  and your weakest specialties.
- Order modes: Mixed · Adaptive (moves toward your level: up after correct answers, down after misses) ·
  Easy → hard · Hard → easy. Filters by specialty and minimum difficulty.
- Missed questions come back about 12 questions later ("Re-ask missed questions later").
- The specialty stays hidden until you answer (toggle on the dashboard), like the real exam.
- A question you minimize evaporates within ~2 seconds. One left untouched closes after 10 min (dashboard
  setting; 0 = never; any click or key resets it). Unanswered ones come back later, unscored. The timer keeps running.
- In a question: A–E keys select, Enter checks, right-click strikes out an option.

ONLINE BANK (GITHUB)
--------------------
- On launch (and on Reload / Fetch now) the app downloads the bank at the "Online URL" on the dashboard
  (default https://dormantone.github.io/zipsandtheorums/quizdata.json) and saves a copy for offline use.
  If GitHub Pages isn't switched on, it reads the same file straight from the repo (raw.githubusercontent.com).
- Online questions replace local ones with the same id, so editing the GitHub file updates the app for everyone.
- Source: "All (online + local)" (default), "Online only", or "Local only". Specialty always starts at "All".
- quizdata.json uses the same format as the files in "banks" (see BANK_FORMAT.md). To split it up, list
  other files under "includes": {"title": "...", "includes": ["cardiology.json", "neuro.json"], "questions": []}

QUESTION BANKS (SWAP OR EXPAND)
-------------------------------
- Every .json file in the "banks" folder is loaded. Add files to expand; untick them in "Choose banks…"
  (or delete them) to switch them out. "Add bank file…" copies a JSON file into the folder for you.
- BANK_FORMAT.md documents the format, the difficulty rubric, every diagram option, and a ready-made
  prompt for having an AI write more questions in this format.
- Double-click Validate_Banks.bat after editing a bank to check it. Bad questions are listed and skipped,
  never fatal.
- extra_banks\legacy_200_foundation.json is the original 200-question bank converted to the new format
  (difficulty 1, not re-verified). Copy it into "banks" if you want it in the rotation.

LOCAL DATA
----------
Settings and progress: %APPDATA%\ABIMQuestionNudge\settings_v2.json (your old v1 counts are not carried over).
The app opens web links only when you click them.

Educational review only — verify clinical decisions against current primary sources.
