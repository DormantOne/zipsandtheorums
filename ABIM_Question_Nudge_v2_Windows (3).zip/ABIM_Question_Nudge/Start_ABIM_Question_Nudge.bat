@echo off
setlocal
cd /d "%~dp0"

where pyw >nul 2>nul
if not errorlevel 1 (
    start "" pyw -3 "%~dp0ABIM_Question_Nudge.py"
    goto :eof
)

where pythonw >nul 2>nul
if not errorlevel 1 (
    start "" pythonw "%~dp0ABIM_Question_Nudge.py"
    goto :eof
)

echo ABIM Question Nudge could not find Python 3 with Tkinter.
echo.
echo Install Python 3 from https://www.python.org/downloads/windows/
echo During setup, enable the Python Launcher and Tcl/Tk support if offered.
echo Then run this file again.
echo.
pause
