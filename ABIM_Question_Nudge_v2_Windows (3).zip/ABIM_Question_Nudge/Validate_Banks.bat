@echo off
setlocal
cd /d "%~dp0"
echo Checking every .json file in the banks folder...
echo.
where py >nul 2>nul
if not errorlevel 1 (
    py -3 "%~dp0ABIM_Question_Nudge.py" --validate
    goto done
)
python "%~dp0ABIM_Question_Nudge.py" --validate
:done
echo.
echo Lines starting with WARN are questions that will be skipped.
pause
