"""Diagram renderers for ABIM Question Nudge (standard library only).

Each diagram is described in the question JSON as a small spec, e.g.
    {"type": "ecg", "rhythm": {"type": "sinus", "rate": 72}, "leads": [{"label": "V1", "st": 0.3, "st_shape": "coved"}]}
and drawn on a Tk Canvas. See BANK_FORMAT.md for every option.

Supported types: ecg, flow_volume, plot, vector, image.
"""
from __future__ import annotations

import math
import random
import tkinter as tk
from pathlib import Path
from typing import Any, Callable

INK = "#1b2733"
GRID_MINOR = "#f6c9c9"
GRID_MAJOR = "#e79a9a"
PAPER = "#fff7f7"
PALETTE = ["#1f5f9e", "#c0392b", "#2e8b57", "#8e44ad", "#d17a00", "#4a4a4a"]


# ----------------------------------------------------------------------------
# Small helpers
# ----------------------------------------------------------------------------
def _gauss(t: float, mu: float, sigma: float) -> float:
    if sigma <= 0:
        return 0.0
    z = (t - mu) / sigma
    if z * z > 60:
        return 0.0
    return math.exp(-0.5 * z * z)


def _smoothstep(x: float) -> float:
    x = max(0.0, min(1.0, x))
    return x * x * (3 - 2 * x)


def _nice_ticks(lo: float, hi: float, target: int = 6) -> list[float]:
    if hi <= lo:
        return [lo]
    raw = (hi - lo) / max(1, target)
    mag = 10 ** math.floor(math.log10(raw))
    step = mag
    for m in (1, 2, 2.5, 5, 10):
        if raw <= m * mag:
            step = m * mag
            break
    start = math.ceil(lo / step) * step
    ticks = []
    v = start
    while v <= hi + 1e-9:
        ticks.append(round(v, 10))
        v += step
    return ticks


def _fmt(v: float) -> str:
    if abs(v - round(v)) < 1e-9:
        return str(int(round(v)))
    return f"{v:g}"


def _wrap_with_caption(parent: tk.Misc, canvas_builder: Callable[[tk.Misc], tk.Canvas], caption: str | None, bg: str) -> tk.Frame:
    frame = tk.Frame(parent, bg=bg, padx=0, pady=4)
    canvas = canvas_builder(frame)
    canvas.pack(anchor="w")
    if caption:
        tk.Label(frame, text=caption, font=("Segoe UI", 9, "italic"), bg=bg, fg="#4b5b6a",
                 justify="left", anchor="w", wraplength=int(canvas["width"])).pack(anchor="w", pady=(3, 0))
    return frame


# ----------------------------------------------------------------------------
# ECG synthesis
# ----------------------------------------------------------------------------
NORMAL_BEAT = {
    "p_amp": 0.15, "p_dur": 0.10, "pr": 0.16,
    "qrs_dur": 0.09, "q_amp": 0.05, "r_amp": 1.1, "s_amp": 0.25, "r2_amp": 0.0,
    "delta": 0.0, "st": 0.0, "st_shape": "flat", "j_wave": 0.0,
    "t_amp": 0.30, "t_width": 0.18, "qt": 0.38, "u_amp": 0.0,
    "alternans": 0.0, "invert": False,
}
WIDE_BEAT = {"qrs_dur": 0.16, "q_amp": 0.0, "r_amp": 1.4, "s_amp": 0.15, "r2_amp": 0.0,
             "st": -0.08, "st_shape": "downsloping", "t_amp": -0.45, "t_width": 0.22, "qt": 0.44,
             "delta": 0.0, "j_wave": 0.0}


def _ecg_schedule(r: dict[str, Any], duration: float) -> tuple[list[dict[str, Any]], list[float], str]:
    """Return (beats, lone P times, baseline style). Each beat: {t, p (time or None), kind, scale}."""
    kind = str(r.get("type", "sinus")).lower()
    rng = random.Random(int(r.get("seed", 7)))
    start = float(r.get("start", 0.30))
    beats: list[dict[str, Any]] = []
    lone_p: list[float] = []
    baseline = "flat"
    end = duration + 1.2

    if kind in ("sinus", "avb1", "sinus_brady", "sinus_tachy"):
        rate = float(r.get("rate", 75))
        pr = float(r.get("pr", 0.28 if kind == "avb1" else 0.16))
        rr = 60.0 / rate
        pvc_every = int(r.get("pvc_every", 0))
        t = start + pr
        n = 0
        while t < end:
            n += 1
            if pvc_every and n % pvc_every == 0:
                beats.append({"t": t - 0.42 * rr, "p": None, "kind": "pvc"})
                t += rr  # sinus P is buried in the PVC; full compensatory pause
                continue
            beats.append({"t": t, "p": t - pr, "kind": "normal", "pr": pr})
            t += rr
    elif kind == "mobitz1":
        pp = 60.0 / float(r.get("atrial_rate", 80))
        group = max(3, int(r.get("group", 4)))  # e.g. 4 P waves : 3 QRS
        pr0 = float(r.get("pr", 0.18))
        inc = float(r.get("increment", 0.12))
        t = start
        k = 0
        while t < end:
            pos = k % group
            if pos == group - 1:
                lone_p.append(t)
            else:
                pr = pr0 + inc * (1 - 0.5 ** pos) * 1.6 if pos else pr0
                beats.append({"t": t + pr, "p": t, "kind": "normal", "pr": pr})
            t += pp
            k += 1
    elif kind == "mobitz2":
        pp = 60.0 / float(r.get("atrial_rate", 80))
        ratio = max(2, int(r.get("ratio", 3)))  # every Nth P is blocked
        pr = float(r.get("pr", 0.16))
        t = start
        k = 0
        while t < end:
            k += 1
            if k % ratio == 0:
                lone_p.append(t)
            else:
                beats.append({"t": t + pr, "p": t, "kind": "normal", "pr": pr})
            t += pp
    elif kind in ("chb", "complete_heart_block", "avb3"):
        pp = 60.0 / float(r.get("atrial_rate", 85))
        rr = 60.0 / float(r.get("ventricular_rate", 38))
        t = start
        while t < end:
            lone_p.append(t)
            t += pp
        t = start + float(r.get("v_offset", 0.37))
        esc = "wide" if r.get("wide_escape", True) else "normal"
        while t < end:
            beats.append({"t": t, "p": None, "kind": esc})
            t += rr
    elif kind in ("afib", "af"):
        mean = 60.0 / float(r.get("rate", 110))
        spread = float(r.get("irregularity", 0.35))
        t = start
        variable = bool(r.get("variable_qrs"))  # pre-excited AF: QRS width/delta vary beat to beat
        while t < end:
            b = {"t": t, "p": None, "kind": "normal"}
            if variable:
                b["wmul"] = rng.uniform(1.0, 2.1)
                b["dmul"] = rng.uniform(0.25, 1.0)
            beats.append(b)
            t += mean * (1 + rng.uniform(-spread, spread))
        baseline = "fib"
    elif kind == "flutter":
        ff = 60.0 / float(r.get("atrial_rate", 300))
        conduction = r.get("conduction", 2)
        t = start
        k = 0
        next_conducted = 0
        while t < end:
            if k == next_conducted:
                beats.append({"t": t + 0.24, "p": None, "kind": "normal"})
                step = conduction if isinstance(conduction, int) else rng.choice([2, 4, 3])
                next_conducted = k + int(step)
            t += ff
            k += 1
        baseline = "flutter"
    elif kind == "vt":
        rr = 60.0 / float(r.get("rate", 170))
        t = start
        while t < end:
            beats.append({"t": t, "p": None, "kind": "wide"})
            t += rr
        p_rate = float(r.get("p_rate", 0))
        if p_rate:
            t = start + 0.13
            while t < end:
                lone_p.append(t)
                t += 60.0 / p_rate
    elif kind in ("torsades", "polymorphic_vt"):
        # Optional sinus beats (often with a long QT) before the run starts at `onset` seconds.
        onset = float(r.get("onset", 0.0))
        if onset > 0:
            rr = 60.0 / float(r.get("pre_rate", 60))
            t = start + 0.16
            while t < onset - 0.25:
                beats.append({"t": t, "p": t - 0.16, "kind": "normal"})
                t += rr
        baseline = "torsades"
    elif kind == "junctional":
        rr = 60.0 / float(r.get("rate", 50))
        t = start
        while t < end:
            beats.append({"t": t, "p": None, "kind": "normal"})
            t += rr
    else:
        raise ValueError(f"Unknown ECG rhythm type '{kind}'")
    return beats, lone_p, baseline


def _beat_value(t: float, b: dict[str, Any], m: dict[str, Any], beat_index: int) -> float:
    o = b["t"]
    dt = t - o
    if dt < -0.45 or dt > 0.95:
        return 0.0
    d = m["qrs_dur"] * b.get("wmul", 1.0)
    scale = b.get("scale", 1.0) * b.get("sign", 1)
    r_amp = m["r_amp"]
    if m.get("alternans") and beat_index % 2:
        r_amp *= (1 - float(m["alternans"]))
    v = 0.0
    # Pre-excitation: slurred delta wave starting before the nominal onset.
    if m.get("delta"):
        v += m["delta"] * b.get("dmul", 1.0) * r_amp * _smoothstep((dt + 0.06) / 0.07) * (1 - _smoothstep((dt - 0.25 * d) / (0.2 * d + 1e-6)))
    v -= m["q_amp"] * _gauss(dt, 0.15 * d, 0.07 * d)
    v += r_amp * _gauss(dt, 0.40 * d, 0.12 * d)
    v -= m["s_amp"] * _gauss(dt, 0.68 * d, 0.09 * d)
    if m.get("r2_amp"):
        v += m["r2_amp"] * _gauss(dt, 0.86 * d, 0.08 * d)
    j = d
    tw = m["t_width"]
    sig_t = tw / 4.5
    t_peak = m["qt"] - 2.3 * sig_t
    t_end = m["qt"]
    if m.get("j_wave"):
        v += m["j_wave"] * _gauss(dt, j + 0.008, 0.03)
    st = m["st"]
    if st:
        shape = m.get("st_shape", "flat")
        if dt >= j - 0.01 and dt <= t_end:
            rise = _smoothstep((dt - (j - 0.01)) / 0.02)
            u = (dt - j) / max(0.05, (t_peak - j))
            if shape == "coved":
                body = math.cos(min(1.0, max(0.0, u)) * math.pi / 2) ** 0.6 if u <= 1 else 0.0
            elif shape == "downsloping":
                body = max(0.0, 1 - u)
            elif shape == "upsloping":
                body = max(0.0, 1 - u) * 0.6 + 0.4 * (1 - _smoothstep((dt - t_peak) / (t_end - t_peak + 1e-6)))
                body = body if u < 1 else 1 - _smoothstep((dt - t_peak) / (t_end - t_peak + 1e-6))
            else:  # flat / convex: hold, then fade through the T wave
                body = 1 - _smoothstep((dt - t_peak) / (t_end - t_peak + 1e-6))
            v += st * rise * body
    v += m["t_amp"] * _gauss(dt, t_peak, sig_t * (1.0 if dt < t_peak else 1.25))
    if m.get("u_amp"):
        v += m["u_amp"] * _gauss(dt, t_end + 0.10, 0.045)
    v *= scale
    if m.get("invert"):
        v = -v
    return v


def ecg_traces(spec: dict[str, Any]) -> tuple[list[float], list[tuple[str, list[float]]]]:
    duration = float(spec.get("duration", 6.0))
    fs = 250
    rhythm = spec.get("rhythm", {"type": "sinus", "rate": 75})
    beats, lone_p, baseline = _ecg_schedule(rhythm, duration)
    rng = random.Random(int(rhythm.get("seed", 7)) + 1)
    times = [i / fs for i in range(int(duration * fs) + 1)]
    leads = spec.get("leads") or [{"label": "II"}]
    out: list[tuple[str, list[float]]] = []
    phase = [rng.uniform(0, 6.28) for _ in range(4)]
    for lead in leads:
        m = dict(NORMAL_BEAT)
        m.update({k: v for k, v in lead.items() if k in NORMAL_BEAT})
        wide = dict(m)
        wide.update(WIDE_BEAT)
        wide.update(lead.get("wide", {}) or {})
        pvc = dict(wide)
        pvc.update(lead.get("pvc", {}) or {})
        p_amp = float(lead.get("p_amp", m["p_amp"]))
        p_dur = float(lead.get("p_dur", m["p_dur"]))
        f_amp = float(lead.get("f_amp", 0.06 if baseline == "fib" else 0.22))
        noise = float(lead.get("noise", 0.01))
        vals: list[float] = []
        for t in times:
            v = 0.0
            for i, b in enumerate(beats):
                if abs(t - b["t"]) > 1.0:
                    continue
                k = b["kind"]
                morph = m if k == "normal" else (pvc if k == "pvc" else wide)
                v += _beat_value(t, b, morph, i)
                if b.get("p") is not None and p_amp:
                    v += p_amp * _gauss(t, b["p"] + p_dur / 2, p_dur / 5)
            for p in lone_p:
                if abs(t - p) < 0.3 and p_amp:
                    v += p_amp * _gauss(t, p + p_dur / 2, p_dur / 5)
            if baseline == "fib":
                v += f_amp * (0.6 * math.sin(2 * math.pi * 6.1 * t + phase[0]) + 0.4 * math.sin(2 * math.pi * 8.7 * t + phase[1])
                              + 0.3 * math.sin(2 * math.pi * 4.3 * t + phase[2]))
            elif baseline == "torsades":
                onset = float(rhythm.get("onset", 0.0))
                if t >= onset:
                    f = float(rhythm.get("rate", 240)) / 60.0
                    period = float(rhythm.get("twist_period", 2.0))
                    ramp = _smoothstep((t - onset) / 0.25)
                    cv = math.cos(math.pi * (t - onset) / period + 0.4)
                    env = math.copysign(0.15 + 0.75 * abs(cv), cv)  # signed envelope: the spikes' polarity "twists"
                    x = 2 * math.pi * f * (t - onset)
                    carrier = math.sin(x) + 0.45 * math.sin(2 * x + 0.7)
                    v += ramp * env * carrier * float(lead.get("torsades_gain", 1.0))
            elif baseline == "flutter":
                rate = float(rhythm.get("atrial_rate", 300)) / 60.0
                frac = (t * rate + 0.15) % 1.0
                saw = (frac / 0.8) if frac < 0.8 else (1 - (frac - 0.8) / 0.2)
                v -= f_amp * (saw - 0.5)
            v += noise * math.sin(2 * math.pi * 0.33 * t + phase[3]) + noise * 0.5 * rng.uniform(-1, 1)
            vals.append(v)
        out.append((str(lead.get("label", "")), vals))
    return times, out


def render_ecg(parent: tk.Misc, spec: dict[str, Any], width: int, bg: str) -> tk.Frame:
    duration = float(spec.get("duration", 6.0))
    times, traces = ecg_traces(spec)
    px_mm = (width - 2) / (duration * 25.0)
    strip_mv = float(spec.get("strip_mv", 3.0))
    strip_h = strip_mv * 10 * px_mm
    height = int(strip_h * len(traces)) + 2

    def build(frame: tk.Misc) -> tk.Canvas:
        c = tk.Canvas(frame, width=width, height=height, bg=PAPER, highlightthickness=1, highlightbackground="#d9b3b3")
        mm_w = int(duration * 25)
        mm_h = int(strip_mv * 10 * len(traces))
        for i in range(mm_w + 1):
            x = 1 + i * px_mm
            c.create_line(x, 0, x, height, fill=GRID_MAJOR if i % 5 == 0 else GRID_MINOR)
        for i in range(mm_h + 1):
            y = 1 + i * px_mm
            c.create_line(0, y, width, y, fill=GRID_MAJOR if i % 5 == 0 else GRID_MINOR)
        for idx, (label, vals) in enumerate(traces):
            top = idx * strip_h
            base = top + strip_h * float(spec.get("baseline_frac", 0.52 if str(spec.get("rhythm", {}).get("type", "")).startswith(("torsades", "polymorphic")) else 0.62))
            pts: list[float] = []
            for t, v in zip(times, vals):
                pts.extend([1 + t * 25 * px_mm, base - v * 10 * px_mm])
            c.create_line(*pts, fill=INK, width=1.6, smooth=False)
            if label:
                c.create_text(6, top + 6, text=label, anchor="nw", font=("Segoe UI", 11, "bold"), fill=INK)
            if idx and spec.get("separators", True):
                c.create_line(0, top, width, top, fill="#b07f7f", dash=(3, 3))
        c.create_text(width - 6, height - 4, anchor="se", text="25 mm/s · 10 mm/mV", font=("Segoe UI", 8), fill="#8a6060")
        return c

    return _wrap_with_caption(parent, build, spec.get("caption"), bg)


# ----------------------------------------------------------------------------
# Axes-based charts
# ----------------------------------------------------------------------------
class _Axes:
    def __init__(self, c: tk.Canvas, width: int, height: int, xr: tuple[float, float], yr: tuple[float, float],
                 x_label: str = "", y_label: str = "", invert_x: bool = False, left: int = 62, bottom: int = 46) -> None:
        self.c = c
        self.x0, self.x1 = left, width - 18
        self.y0, self.y1 = height - bottom, 16
        self.xr, self.yr = xr, yr
        self.invert_x = invert_x
        self.x_label, self.y_label = x_label, y_label

    def px(self, x: float, y: float) -> tuple[float, float]:
        fx = (x - self.xr[0]) / (self.xr[1] - self.xr[0] or 1)
        if self.invert_x:
            fx = 1 - fx
        fy = (y - self.yr[0]) / (self.yr[1] - self.yr[0] or 1)
        return self.x0 + fx * (self.x1 - self.x0), self.y0 - fy * (self.y0 - self.y1)

    def draw(self, zero_line: bool = True, show_x_ticks: bool = True, show_y_ticks: bool = True) -> None:
        c = self.c
        for xt in _nice_ticks(*self.xr):
            x, _ = self.px(xt, self.yr[0])
            c.create_line(x, self.y0, x, self.y1, fill="#eceff3")
            if show_x_ticks:
                c.create_text(x, self.y0 + 12, text=_fmt(xt), font=("Segoe UI", 8), fill="#55606b")
        for yt in _nice_ticks(*self.yr):
            _, y = self.px(self.xr[0], yt)
            c.create_line(self.x0, y, self.x1, y, fill="#eceff3")
            if show_y_ticks:
                c.create_text(self.x0 - 8, y, text=_fmt(yt), anchor="e", font=("Segoe UI", 8), fill="#55606b")
        c.create_rectangle(self.x0, self.y1, self.x1, self.y0, outline="#9aa5b1")
        if zero_line and self.yr[0] < 0 < self.yr[1]:
            _, y = self.px(self.xr[0], 0)
            c.create_line(self.x0, y, self.x1, y, fill="#5d6874")
        if self.x_label:
            c.create_text((self.x0 + self.x1) / 2, self.y0 + 30, text=self.x_label, font=("Segoe UI", 9, "bold"), fill="#33414e")
        if self.y_label:
            c.create_text(14, (self.y0 + self.y1) / 2, text=self.y_label, angle=90, font=("Segoe UI", 9, "bold"), fill="#33414e")

    def polyline(self, pts: list[tuple[float, float]], color: str, width: float = 2.0, dash: tuple[int, ...] | None = None) -> None:
        flat: list[float] = []
        for x, y in pts:
            flat.extend(self.px(x, y))
        if len(flat) >= 4:
            kw: dict[str, Any] = {"fill": color, "width": width}
            if dash:
                kw["dash"] = dash
            self.c.create_line(*flat, **kw)


def _legend(c: tk.Canvas, ax: _Axes, items: list[tuple[str, str, bool]]) -> None:
    x = ax.x1 - 8
    y = ax.y1 + 8
    for label, color, dashed in items:
        if not label:
            continue
        c.create_text(x, y, text=label, anchor="ne", font=("Segoe UI", 9), fill=color)
        w = 7 * len(label) + 8
        kw: dict[str, Any] = {"fill": color, "width": 2}
        if dashed:
            kw["dash"] = (4, 3)
        c.create_line(x - w - 22, y + 7, x - w - 4, y + 7, **kw)
        y += 16


def _flow_volume_curve(pattern: str) -> tuple[list[tuple[float, float]], float, float]:
    """Return points (absolute lung volume L, flow L/s), TLC, RV for a named pattern."""
    p = pattern.lower()
    tlc, rv, pef, insp = 6.5, 1.5, 8.5, 6.0
    exp_shape = "normal"
    exp_cap = None
    insp_cap = None
    if p == "obstructive":
        tlc, rv, pef, exp_shape = 7.6, 3.6, 4.6, "scooped"
    elif p == "restrictive":
        tlc, rv, pef, insp = 4.3, 1.4, 7.0, 4.8
    elif p == "fixed_upper":
        exp_cap, insp_cap = 3.4, 3.2
    elif p == "variable_extrathoracic":
        insp_cap = 2.4
    elif p == "variable_intrathoracic":
        exp_cap = 2.8
    elif p != "normal":
        raise ValueError(f"Unknown flow-volume pattern '{pattern}'")
    fvc = tlc - rv
    pts: list[tuple[float, float]] = []
    n = 120
    # Expiration: TLC -> RV, flow positive
    for i in range(n + 1):
        f = i / n
        vol = tlc - f * fvc
        if f < 0.12:
            flow = pef * math.sin(f / 0.12 * math.pi / 2)
        else:
            g = (f - 0.12) / 0.88
            flow = pef * ((1 - g) ** 2.6 if exp_shape == "scooped" else (1 - g) ** 1.05)
        if exp_cap is not None:
            flow = min(flow, exp_cap * (1 if f > 0.02 else f / 0.02))
            if f > 0.6:
                flow = min(flow, exp_cap * (1 - (f - 0.6) / 0.4) ** 0.9)
        pts.append((vol, flow))
    # Inspiration: RV -> TLC, flow negative
    for i in range(n + 1):
        f = i / n
        vol = rv + f * fvc
        flow = -insp * math.sin(f * math.pi) ** 0.8
        if insp_cap is not None:
            flow = max(flow, -insp_cap * min(1.0, math.sin(f * math.pi) * 4))
        pts.append((vol, flow))
    return pts, tlc, rv


def render_flow_volume(parent: tk.Misc, spec: dict[str, Any], width: int, bg: str) -> tk.Frame:
    height = int(spec.get("height", 330))
    pattern = spec.get("pattern", "normal")

    def build(frame: tk.Misc) -> tk.Canvas:
        c = tk.Canvas(frame, width=width, height=height, bg="white", highlightthickness=1, highlightbackground="#cfd6de")
        ax = _Axes(c, width, height, (0.0, 8.5), (-9.0, 10.0), "Lung volume (L)  — exhalation runs left to right, TLC → RV",
                   "Flow (L/s)", invert_x=True)
        ax.draw()
        legend = []
        if spec.get("show_normal", False) and pattern != "normal":
            npts, _, _ = _flow_volume_curve("normal")
            ax.polyline(npts, "#9aa5b1", 1.6, (5, 4))
            legend.append(("Predicted normal", "#7d8893", True))
        pts, tlc, rv = _flow_volume_curve(pattern)
        ax.polyline(pts, PALETTE[0], 2.4)
        legend.append(("Patient", PALETTE[0], False))
        _legend(c, ax, legend)
        x, y = ax.px(8.3, 0)
        c.create_text(x + 2, y - 10, text="Expiration ↑", anchor="w", font=("Segoe UI", 8), fill="#55606b")
        c.create_text(x + 2, y + 10, text="Inspiration ↓", anchor="w", font=("Segoe UI", 8), fill="#55606b")
        return c

    return _wrap_with_caption(parent, build, spec.get("caption"), bg)


def render_plot(parent: tk.Misc, spec: dict[str, Any], width: int, bg: str) -> tk.Frame:
    height = int(spec.get("height", 300))
    series = spec.get("series", [])
    all_x = [p[0] for s in series for p in s.get("points", [])] or [0, 1]
    all_y = [p[1] for s in series for p in s.get("points", [])] or [0, 1]
    xr = tuple(spec.get("x_range", (min(all_x), max(all_x))))
    yr = tuple(spec.get("y_range", (min(all_y), max(all_y) * 1.08 if max(all_y) > 0 else 1)))

    def build(frame: tk.Misc) -> tk.Canvas:
        c = tk.Canvas(frame, width=width, height=height, bg="white", highlightthickness=1, highlightbackground="#cfd6de")
        ax = _Axes(c, width, height, (float(xr[0]), float(xr[1])), (float(yr[0]), float(yr[1])),
                   spec.get("x_label", ""), spec.get("y_label", ""))
        ax.draw(zero_line=spec.get("zero_line", True), show_x_ticks=spec.get("x_ticks", True), show_y_ticks=spec.get("y_ticks", True))
        for band in spec.get("bands", []):
            xa, ya = ax.px(band.get("x0", xr[0]), band.get("y1", yr[1]))
            xb, yb = ax.px(band.get("x1", xr[1]), band.get("y0", yr[0]))
            c.create_rectangle(xa, ya, xb, yb, fill=band.get("color", "#eef4fb"), outline="")
            if band.get("label"):
                c.create_text(xa + 4, ya + 4, text=band["label"], anchor="nw", font=("Segoe UI", 8), fill="#55606b")
        legend = []
        for i, s in enumerate(series):
            color = s.get("color", PALETTE[i % len(PALETTE)])
            dash = (5, 4) if s.get("dashed") else None
            pts = [(float(p[0]), float(p[1])) for p in s.get("points", [])]
            if s.get("markers"):
                for x, y in pts:
                    px, py = ax.px(x, y)
                    c.create_oval(px - 3.5, py - 3.5, px + 3.5, py + 3.5, fill=color, outline="white")
            if not s.get("markers_only"):
                ax.polyline(pts, color, float(s.get("width", 2.2)), dash)
            legend.append((s.get("label", ""), color, bool(dash)))
        for a in spec.get("annotations", []):
            x, y = ax.px(float(a["x"]), float(a["y"]))
            c.create_text(x, y, text=a.get("text", ""), anchor=a.get("anchor", "center"),
                          font=("Segoe UI", int(a.get("size", 9)), "bold" if a.get("bold") else "normal"),
                          fill=a.get("color", "#33414e"))
        _legend(c, ax, legend)
        return c

    return _wrap_with_caption(parent, build, spec.get("caption"), bg)


# ----------------------------------------------------------------------------
# Vector sketches (crystals, smears, anatomy, flow diagrams)
# ----------------------------------------------------------------------------
def _rotated_ellipse(x: float, y: float, rx: float, ry: float, angle: float, n: int = 36) -> list[float]:
    a = math.radians(angle)
    pts: list[float] = []
    for i in range(n):
        th = 2 * math.pi * i / n
        ex, ey = rx * math.cos(th), ry * math.sin(th)
        pts.extend([x + ex * math.cos(a) - ey * math.sin(a), y + ex * math.sin(a) + ey * math.cos(a)])
    return pts


def render_vector(parent: tk.Misc, spec: dict[str, Any], width: int, bg: str) -> tk.Frame:
    vw = float(spec.get("width", 400))
    vh = float(spec.get("height", 200))
    max_w = int(spec.get("display_width", width))
    k = max_w / vw
    W, H = int(vw * k), int(vh * k)

    def S(v: float) -> float:
        return v * k

    def build(frame: tk.Misc) -> tk.Canvas:
        c = tk.Canvas(frame, width=W, height=H, bg=spec.get("bg", "white"), highlightthickness=1, highlightbackground="#cfd6de")
        for sh in spec.get("shapes", []):
            kind = sh.get("kind")
            fill = sh.get("fill", "")
            outline = sh.get("outline", sh.get("color", INK))
            lw = float(sh.get("line_width", 1.5))
            if kind == "circle":
                x, y, r = S(sh["x"]), S(sh["y"]), S(sh["r"])
                c.create_oval(x - r, y - r, x + r, y + r, fill=fill, outline=outline, width=lw)
            elif kind == "ellipse":
                pts = _rotated_ellipse(S(sh["x"]), S(sh["y"]), S(sh["rx"]), S(sh["ry"]), float(sh.get("angle", 0)))
                c.create_polygon(*pts, fill=fill, outline=outline, width=lw, smooth=True)
            elif kind == "rect":
                c.create_rectangle(S(sh["x"]), S(sh["y"]), S(sh["x"] + sh["w"]), S(sh["y"] + sh["h"]), fill=fill, outline=outline, width=lw)
            elif kind == "needle":
                # thin rotated bar: x, y center, length, thickness, angle
                L, T, a = S(sh["length"]) / 2, S(sh.get("thickness", 2)) / 2, math.radians(float(sh.get("angle", 0)))
                cx, cy = S(sh["x"]), S(sh["y"])
                ux, uy = math.cos(a), math.sin(a)
                vx, vy = -uy, ux
                pts = [cx - L * ux - T * vx, cy - L * uy - T * vy, cx + L * ux - T * vx, cy + L * uy - T * vy,
                       cx + L * ux + T * vx, cy + L * uy + T * vy, cx - L * ux + T * vx, cy - L * uy + T * vy]
                c.create_polygon(*pts, fill=fill or outline, outline=outline, width=lw)
            elif kind in ("line", "polygon"):
                pts = [S(v) for v in sh["points"]]
                if kind == "line":
                    kw: dict[str, Any] = {"fill": sh.get("color", INK), "width": lw, "smooth": bool(sh.get("smooth"))}
                    if sh.get("arrow"):
                        kw["arrow"] = {"end": tk.LAST, "start": tk.FIRST, "both": tk.BOTH}.get(sh["arrow"], tk.LAST)
                    if sh.get("dashed"):
                        kw["dash"] = (5, 4)
                    c.create_line(*pts, **kw)
                else:
                    c.create_polygon(*pts, fill=fill, outline=outline, width=lw, smooth=bool(sh.get("smooth")))
            elif kind == "text":
                c.create_text(S(sh["x"]), S(sh["y"]), text=sh.get("text", ""), anchor=sh.get("anchor", "center"),
                              font=("Segoe UI", int(sh.get("size", 10)), "bold" if sh.get("bold") else "normal"),
                              fill=sh.get("color", INK), width=S(sh["wrap"]) if sh.get("wrap") else 0)
            elif kind == "box":  # rectangle with centered text, for flow diagrams
                x, y, w, h = S(sh["x"]), S(sh["y"]), S(sh["w"]), S(sh["h"])
                c.create_rectangle(x, y, x + w, y + h, fill=fill or "#eef3f8", outline=outline, width=lw)
                c.create_text(x + w / 2, y + h / 2, text=sh.get("text", ""), width=w - 8,
                              font=("Segoe UI", int(sh.get("size", 9)), "bold" if sh.get("bold") else "normal"), fill=sh.get("color", INK))
        return c

    return _wrap_with_caption(parent, build, spec.get("caption"), bg)


def render_image(parent: tk.Misc, spec: dict[str, Any], width: int, bg: str, base_dir: Path | None) -> tk.Frame:
    path = Path(spec["file"])
    if not path.is_absolute() and base_dir is not None:
        path = base_dir / path
    img = tk.PhotoImage(file=str(path))
    factor = max(1, math.ceil(img.width() / width))
    if factor > 1:
        img = img.subsample(factor, factor)
    frame = tk.Frame(parent, bg=bg, pady=4)
    lbl = tk.Label(frame, image=img, bg=bg)
    lbl.image = img  # type: ignore[attr-defined]
    lbl.pack(anchor="w")
    if spec.get("caption"):
        tk.Label(frame, text=spec["caption"], font=("Segoe UI", 9, "italic"), bg=bg, fg="#4b5b6a").pack(anchor="w")
    return frame


RENDERERS = {
    "ecg": render_ecg,
    "flow_volume": render_flow_volume,
    "plot": render_plot,
    "vector": render_vector,
}


def render_diagram(parent: tk.Misc, spec: dict[str, Any], width: int = 860, bg: str = "white", base_dir: Path | None = None) -> tk.Widget:
    try:
        kind = spec.get("type")
        if kind == "image":
            return render_image(parent, spec, width, bg, base_dir)
        fn = RENDERERS.get(str(kind))
        if fn is None:
            raise ValueError(f"unknown diagram type '{kind}'")
        return fn(parent, spec, width, bg)
    except Exception as exc:  # A broken diagram must never break the question.
        return tk.Label(parent, text=f"[Diagram could not be drawn: {exc}]", fg="#a13333", bg=bg, font=("Segoe UI", 9, "italic"))


def validate_diagram(spec: Any) -> str | None:
    """Return an error string, or None if the spec looks drawable."""
    if not isinstance(spec, dict):
        return "diagram must be an object"
    kind = spec.get("type")
    if kind not in (*RENDERERS, "image"):
        return f"unknown diagram type '{kind}'"
    try:
        if kind == "ecg":
            ecg_traces(spec)
        elif kind == "flow_volume":
            _flow_volume_curve(spec.get("pattern", "normal"))
        elif kind == "plot":
            for s in spec.get("series", []):
                for p in s.get("points", []):
                    float(p[0]); float(p[1])
        elif kind == "image" and "file" not in spec:
            return "image diagram needs 'file'"
    except Exception as exc:
        return str(exc)
    return None
