# Companion · Vision & Gait

A small MuJoCo companion with a walking spine, a moving head, binocular eyes, and a mind that can keep learning to follow a red ball.

**Start on Mac:** unzip the complete folder and double-click **START_MAC.command**. On Windows, double-click **START_WINDOWS.bat**. Then press **Follow target**. The page opens at **http://127.0.0.1:8797**.

Node.js 22 or newer is required. The complete download includes the physics and viewer dependencies. No API key, Python, model download, or package installation is needed for the complete package. Everything runs on your computer. If you downloaded a source-only copy, use `npm ci` first.

## A few things to try

- Click the ground to move the red ball. Drag to orbit; scroll to zoom. **Ball left / Ahead / Ball right** places it relative to the animal.
- **Follow target** uses the best validated continuous learner. The best ternary descendant is available as a separate comparison in More controls. **Rest** stops locomotion. **Start position** puts the animal and ball back at their starting positions, preserving all learning.
- Choose a still ball, a gentle sway, a slowly leading ball, or a circle. Adjust pace, following space, and walk/trot. Following space is estimated from retinal size; it is approximate.
- Watch both eye images. The animal has physical neck yaw and pitch joints; moving the spectator camera does not change its vision.
- **Start learning / Continue learning** runs real MuJoCo training in another worker. The live companion remains interactive. **Pause learning** finishes the current evaluation before pausing.
- A learning window is **180 updates total**, shared among up to three active learners, followed by eight evolution generations. Choose **600** or **1,800** for longer continuous learning. The parent minds persist across windows.
- **Test on reserved targets** runs a separate evaluation, after training is paused. A high validation score does not guarantee every new path will work.
- Expand **See the mind and spine** for actual live network activity. **More controls & experiment notes** exposes manual driving, eye covering, steering on/off, and the explicit visual-reflex comparison.

Use **STOP_MAC.command** or **STOP_WINDOWS.bat** to stop the server. Closing the browser tab alone leaves it running. The launchers only operate this Companion instance. Your other labs use their own folders and ports.

## How the three projects fit together

The dark Metamorphosis dashboard, stage flow, score history, learner table, and nursery table form the interface's base. The page keeps the playground and everyday controls large, with the experimental detail below.

```mermaid
flowchart TD
    E["Physical binocular cameras"] --> P["RGB pixels → red features"]
    P --> B["Recurrent visual brain"]
    J["Neck, balance and movement senses"] --> B
    B --> S["Fixed Neural Gait spine"]
    B --> H["Physical neck and steering joints"]
    S --> M["16 opposing leg muscles"]
    M --> A["MuJoCo body and contacts"]
    H --> A
    A --> E
    A --> J
    T["Metamorphosis: evolve, learn, nurture"] --> B
    A --> R["Following reward and separate evaluation"]
    R --> T
```

**Neural Gait v13:** `rig/gait/spinal_cord.mjs` and `tuned.json` are copied unchanged. The original 80-node, hand-designed locomotor network drives the original sixteen opposing muscle commands. The muscle model still computes bounded hip/knee torques at every 4 ms physics step. The control period remains 20 ms. The higher brain controls speed, turning intent, neck yaw velocity, neck pitch velocity, muscle tone, and a small rhythm modulation. Walk/trot selection is a visible user control. The original spinal turning pattern is recruited when a turn is needed at low speed.

**QuadMind v4:** its two-axis head/neck layout, binocular camera placement, 64 × 48 retina, and red-pixel segmentation are adapted into the Node/MuJoCo body. The head has real mass, joints, damping, and bounded torque actuators. The Python/PyTorch PPO gaze learner is replaced by the Metamorphosis visual controller. It is not run alongside it.

**Metamorphosis v14:** `rig/core/hybrid.mjs` is copied unchanged. It supplies frozen-topology continuous heirs, paired SPSA reward-difference learning, protected validated bests, sign/guided ternary projections, persistent continuous lineages, inherited shadow weights, a bounded ternary nursery, and renewed nursery mutation trials. `rig/companion/trainer.mjs` adapts its plant/scoring interfaces to this visual task. Evolution changes strict ternary wiring; learning changes continuous weights. SPSA estimates reward gradients through real rollouts; this is not backpropagation through MuJoCo.

The original `engine/plant.js` receives one additive extension point for the expanded body XML. Its original leg and muscle equations remain intact. A small yaw joint at each shoulder/hip rotates the leg's stroke plane through at most ±0.42 rad (24°). Left/right stride differences remain spinal commands. Body motion comes from bounded actuators, gravity, and contact, never edits to its world pose. Replacing the direct torso–thigh ancestry required preserving MuJoCo's four original neighbour collision exclusions. The new neck is extended enough to reach both yaw limits without touching the torso.

## Vision and the starting behavior

**The brain has no target-position, target-bearing, or true-distance sensor.** Its 24 inputs are retinal features, neck proprioception, balance/movement senses, previous commands, and a constant. Absolute world position and absolute compass yaw are excluded from the higher brain. The old plant's target channels are zeroed.

The eye images are **CPU raycasts of the compiled MuJoCo spheres, capsules, boxes and ellipsoids, from the physical MuJoCo camera poses**. They include depth-tested occlusion and floor pixels. This is a portable software renderer, not MuJoCo's OpenGL framebuffer. Training and the live retina use the same renderer, at 12.5 Hz. The 3D spectator view uses Three.js; its lighting and decorative collar are presentation only. There is no browser-to-policy vision shortcut.

The visual front end is intentionally simple: count red pixels, measure their centroid and area in each eye, and compute binocular disparity. A pinhole-camera angular-size calibration sets the desired retinal size for the chosen following gap. Head scanning and a consistent in-place turn provide an explicit search reflex after sight is lost.

The founders have a **hand-wired visual-reflex prior**: retinal error can orient the head; retinal error plus neck yaw can steer; apparent target size can regulate forward drive. This makes the starter usable. Initial following is therefore **not evidence of learned discovery**. The shipped training report separately records the original continuous baseline, learned improvements, strict projections, nursery results, and reserved evaluation. Better training rewards alone do not replace a protected validation best.

The task uses fixed validation scenarios for selection and rotating training starts for learning. True target position is allowed in the reward and reporting path, but not in policy observations. The primary score rewards approach progress, time near the requested gap, visual contact, body alignment and safe posture. Fallen or incomplete episodes are penalized; unrun frames receive no visual/following credit. Health uses the original leg/foot ledger; neck and shoulder limits are separately enforced by physics, rather than being additional health-ledger organs. Sliding is measured and reported. Scores are task measures, not guarantees of animal-like understanding.

The reserved suite is never used to adopt weights or choose elites. Metamorphosis also reports that suite at cycle boundaries, so repeated viewing makes it a **reserved reporting suite**, not a perpetually untouched final benchmark. `tests/physics_check.mjs` uses an additional seed for its generalization check.

## Saving and continuing

Learning autosaves atomically to `data_companion/checkpoint.json`, about every 20 seconds at completed updates and on a normal stop. **Save progress** saves the latest complete snapshot. **Download checkpoint** makes a portable JSON backup; **Restore checkpoint** loads one while learning is paused. The family, protected bests, pending stage, archive, nursery, counters, random-generator state and training settings are saved together.

If there is no personal checkpoint, the included `starter/ready-to-follow.json` is loaded. The live follower defaults to the continuous family; a high short-trial ternary score alone does not replace it. The shipped starter contains an actual training run, including a completed learning-to-projection cycle and nursery trials. It starts paused so you can follow the ball immediately.

The old v13/v14 checkpoints control whole-body muscles, whereas this brain controls spinal commands and gaze. They are intentionally rejected, with an explanation, rather than being interpreted as compatible visual brains. The three supplied original ZIPs are not modified.

## Running checks or modifying the code

```sh
npm test
npm run verify
npm start
```

- `tests/launch_check.mjs`: quick real-body, muscle, neck, steering and binocular check, also used on first launch.
- `tests/contracts.test.mjs`: mutation, frozen topology, inheritance, bounded outputs, whole-family restoration and corrupt-checkpoint rejection.
- `tests/vision.test.mjs`: real left/right eye images, occlusion, blindness, and policy isolation from private target/world coordinates.
- `tests/physics_check.mjs`: forward walking, both turns, full neck range, visual following, moving targets, and additional reserved seeds.
- `scripts/pretrain.mjs`: reproduce a starter training campaign. It writes a new starter, so copy your current starter first if you want to preserve it.

The Mac and Windows entry files are included. The implementation and browser were exercised on Linux; native Finder/Gatekeeper and Windows shell behavior cannot be certified from that environment. If macOS blocks the command, right-click it and choose Open. Node.js must be installed on each computer.

The source is local and inspectable: `server.mjs`, `rig/companion/`, `web/`. See `TEST_REPORT.md` for what was actually checked and measured.
