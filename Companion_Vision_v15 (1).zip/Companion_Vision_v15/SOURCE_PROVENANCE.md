# Source provenance

The supplied archives were read locally and left unchanged. This combined build is a separate project.

| Supplied archive | SHA-256 |
| --- | --- |
| Walker_Neural_Gait_v13 (1).zip | `67462a0058cd035b17cc5a717304f5e9363f280af49ef1ae43bfade881607f8d` |
| QuadMind_v4_0_Active_Neck_Gaze_COMPLETE(1).zip | `de8e5a699d91cddead6735d03a57e2dffdd3bb424f077c39d2c6da6f882143d1` |
| Walker_Metamorphosis_v14 (2).zip | `81249d805df5894b8d60da87345010f328899c79fdfbd84d1a9150c2a8d7199a` |

These modules are byte-for-byte copies:

| Module | Source | SHA-256 |
| --- | --- | --- |
| `rig/gait/spinal_cord.mjs` | Neural Gait v13 | `5c14769dc97c6210bbd9ce447b861cd38c2c1dabb3914146a63938acff344f65` |
| `rig/gait/tuned.json` | Neural Gait v13 | `59bf317da837f2c6e7e385f737edd36ff72ff1a80d5335f5cf7555e748216c9e` |
| `rig/core/hybrid.mjs` | Metamorphosis v14 | `bbe173437a75a6cce060c25e37f2ff0cefe288baf10c061347317d22c2af3773` |
| `rig/brain.mjs` | Metamorphosis v14 | `03f0f5593b172af7e9fcd8f33c99ea38461cf1817a23fd376b4d879e5ebf0193` |

QuadMind's Python head, camera and RGB segmentation design was ported and adapted, rather than importing its PyTorch learner. `rig/companion/` contains that adaptation and the visual task. The Metamorphosis GUI's dark cards, stage flow, histories and lineage/nursery tables were adapted into the new `web/` interface.

The original plant receives a named-model XML extension point for the new joints and head. The original leg muscle equations remain intact. See README.md for the exact boundaries and the software-rendered retina.
