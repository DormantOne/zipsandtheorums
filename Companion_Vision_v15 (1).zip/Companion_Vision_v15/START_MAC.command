#!/bin/bash
cd "$(dirname "$0")" || exit 1
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
echo 'COMPANION · Vision & Gait'
if ! command -v node >/dev/null 2>&1; then
  echo 'Install Node.js 22 or newer from https://nodejs.org, then double-click START again.'
  read -r -p 'Press Enter to close.' _
  exit 1
fi
if ! node scripts/launch.mjs; then
  read -r -p 'Press Enter to close.' _
  exit 1
fi
