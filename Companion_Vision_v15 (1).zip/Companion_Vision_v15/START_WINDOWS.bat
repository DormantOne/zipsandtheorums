@echo off
cd /d "%~dp0"
echo COMPANION - Vision and Gait
where node >nul 2>nul
if errorlevel 1 (
 echo Install Node.js 22 or newer from https://nodejs.org then open START again.
 pause
 exit /b 1
)
node scripts\launch.mjs
if errorlevel 1 pause
