# Companion v15 — test report

Measured October 21, 2026. Environment: Linux, Node.js 24.19.0, pinned MuJoCo WASM 3.12.0 and Three.js 0.185.0; a fresh headless Chromium browser for interface checks. The tests were run from the release folder with the bundled, trimmed runtime dependencies.

## Result

**Seven contract/vision tests passed. The real-physics check passed. The desktop/phone browser checks passed with zero page errors.** The additional first-launch/reopen/stop check is recorded separately below.

The default live follower is the best validated **continuous** learner. Strict ternary descendants remain available through the controller selector. This keeps the learned parent usable while offspring continue evolving.

## Included starter

| Measurement | Result |
| --- | ---: |
| Initial continuous visual-reflex baseline, validation | 89.20 / 100 |
| Best continuous learner, validation | 89.94 / 100 |
| Highest ternary validation score | 92.94 / 100 |
| Continuous follower, reserved reporting suite | 88.95 / 100 |
| Reserved suite visual contact | 92.5% |
| Reserved suite falls | 0 / 8 |
| Continuous learning updates | 36 |
| Living continuous lineages | 3 |
| Living ternary offspring | 4 |
| Additional nursery trials | 3 |

One learning window, projection, three evolutionary generations, and a second learning entry were exercised. Continuous parents remain in the checkpoint. No nursery improvement or promotion is claimed: the three included nursery trials produced none. The offspring remain alive for more trials.

The continuous learner improved from 89.20 to 89.94 on the fixed validation task; conversion from strict to continuous is excluded from that learning gain. The stronger short-trial ternary score did not imply better long-trial tracking, so the live follower uses the continuous family by design. The ternary comparison is explicit.

## Physical checks

| Test | Measurement |
| --- | --- |
| Straight trot, 10 s | 1.75 m forward, 99.46% health |
| Left turn, 10 s | 84.8° body rotation, 99.44% health |
| Right turn, 10 s | -84.7° body rotation, 99.47% health |
| Physical neck limit | yaw -0.9994 rad; pitch 0.5002 rad |
| Physical neck limit | yaw 0.9994 rad; pitch 0.5002 rad |
| Fixed target [1.8, 0.65, 0.38], 24 s | final gap 0.91 m; visible 100%; health 99.70% |
| Fixed target [1.8, -0.65, 0.38], 24 s | final gap 0.91 m; visible 100%; health 99.69% |
| Fixed target [1.6, 0, 0.38], 24 s | final gap 0.90 m; visible 100%; health 99.78% |
| Sway, 36 s | visible 80%; final gap 0.31 m; no fall |
| Lead, 36 s | visible 100%; final gap 0.93 m; no fall |
| Circle, 36 s | visible 74%; final gap 0.82 m; no fall |

Additional reserved seed **71611**, eight 24-second trials: score **89.81**, visual contact **94.5%**, **zero falls**. These seeds were not used in the starter training campaign.

All measurements are on the flat floor. The 0.85 m gap setting is a retinal-size estimate: fixed-target stopping gaps were 0.90–0.91 m in these checks. Tight moving loops can bring the target too close or temporarily outside the eye field; the 36-second sway/circle runs retained visual contact for 80%/74% of ticks and used the search behavior. Forward-plus-stop pursuit and in-place search are the autonomous actions; manual reverse is available. This is a functioning learning experiment, not a fully trained autonomous pet.

## Vision and persistence checks

- Physical left and right target images produce the correct retinal signs.
- A depth-tested occluding screen removes the target from both eyes.
- Covering the eyes produces black RGB images and zero target features.
- Changing private target coordinates, or absolute floor coordinates, cannot alter a policy input until new retinal data is supplied.
- Deploying a restored/improved brain does not reset the body or stop physics.
- Frozen-topology heirs and shadow inheritance preserve audited ternary source contracts.
- Save/restore preserves the continuous family, nursery, counters and protected bests; corrupt imports are rejected before mutation.
- Pause/resume while an evaluation is finishing retains one training loop.

## Browser checks

- Restored starter uses its continuous learner.
- Follow and relative target controls.
- Click the floor places a physical target.
- Pause and resume live physics.
- Covering eyes blacks out the actual retina.
- Continuous and ternary comparison select the matching live network.
- Save/export/restore retain progress and paused setting changes.
- Incompatible imports are rejected without replacing the family.
- Background learning advances while playground controls remain responsive.
- Desktop and phone layouts, actual network inspector, no overflow.

**Zero page errors.** No horizontal overflow at 1500 px desktop or 390 px phone width. The 3D arena, both actual eye feeds, score chart, tables and network inspector were visually inspected. Browser screenshots were used only for internal verification and are not included in the deliverable.

## Launch and platform limits

The Node launcher was exercised on Linux for first-launch body/eye verification, restoring the bundled starter, reusing the running instance, and graceful stop with a saved checkpoint. Mac shell wrappers pass `bash -n`; Windows wrappers use CRLF. Native macOS Finder/Gatekeeper and Windows launch behavior were not run here. Node.js 22+ must be installed on each computer.

See `starter/training-report.json` for per-trial measurements and full Metamorphosis history, and `SOURCE_PROVENANCE.md` for the preserved original modules.
