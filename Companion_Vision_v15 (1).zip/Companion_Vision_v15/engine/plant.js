import {sustainedGait} from './sustained_gait.mjs';
/* plant.js — port of Liquid_Foundry foundry/plant.py
 *
 * Nothing in this module is a searchable design factor. A controller gets 36
 * public sensors and emits eight direct joint torques -- or, with actuation
 * 'pd' (alias 'servo', v10.0.1), eight joint targets that a PD servo tracks,
 * recomputed every 4 ms physics step and capped at each motor's limit.
 * v10.0.2: friction is firm by default (elliptic cone, impratio 10); see
 * PLANT.frictionCone. The Foundry's soft friction let planted feet creep.
 * v10.1.0: actuation 'muscle' -- sixteen commands, a flexor and an extensor per
 * joint, so the brain sets each joint's stiffness as well as its angle (see
 * torquesFrom). Commands 0-7 drive the muscles that pull each joint toward
 * +25 % of its range, commands 8-15 the ones that pull toward -25 %.
 *
 * THE BODY IS GENERATED, NOT AUTHORED. build_mjcf renders MJCF from the frozen
 * PLANT dict, so the geometry, masses, joint ranges, damping, armature,
 * friction, hip springs and actuator limits all come from one place. Every id
 * is then resolved by name, and the standing pose is SOLVED by forward
 * kinematics rather than written down: drop the body from 1 m with hips at zero
 * and knees at kneeRangeMin + kneeRestOffset, find the lowest point of the
 * lowest foot, and place the torso so that point clears the floor by 3 mm.
 * That solved pose is what the injury ledger treats as the neutral, load-bearing
 * posture, which is why merely standing costs no health.
 *
 * Distance is whole-body centre-of-mass progress projected to the floor, made
 * eligible only after at least one foot has materially relocated, minus a
 * matched zero-action passive COM counterfactual under the exact same
 * disturbance.
 *
 * PORT NOTES
 *   - Trajectories will not match the Python bit-for-bit: numpy's Generator and
 *     this module's PRNG draw different numbers from the same distributions.
 *     The contract, the thresholds and the measurement semantics do match.
 *   - The Python decomposes contact forces per contact with mj_contactForce.
 *     This port does NOT read data.contact at all, and the reason matters:
 *     every accessor on it returns an embind ClassHandle, and embind handles are
 *     never garbage collected. One vector handle plus one handle per contact per
 *     control step leaked the WASM heap and produced "MuJoCo Error: Could not
 *     allocate memory" after roughly 90,000 control steps. Caching the vector is
 *     not safe either, because in MuJoCo 3 the contact array lives in the
 *     per-step arena and can move. Floor contact is instead computed in closed
 *     form: the floor is a plane at z = 0 and every collidable geom here is a
 *     sphere, a box or a capsule, so each lowest point is exact and costs no
 *     allocation. Load magnitudes still come from the measured per-body wrench.
 *   - The Foundry sets a torsional and rolling friction on the foot geoms but
 *     leaves the default condim at 3, which uses sliding friction only, so
 *     those two numbers are inert. Reproduced as written.
 */
import {AnatomicalHitPointState,strainGeometry,JOINT_NAMES,SURFACE_NAMES,
        DEFAULT_HIT_POINT_BUDGET} from './injury.js';
import {makeTargetPath,targetSensors,TargetProgress,TargetGoal,TARGET_VERSION,TARGET_DEFAULTS} from './target.mjs';
import {FootSlip,FOOT_SLIP_VERSION,FOOT_SLIP_DEFAULTS} from './foot_slip.mjs';
import {ContactHealth,CONTACT_HEALTH_VERSION} from './contact_health.mjs';

const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const num=(v,d=0)=>Number.isFinite(Number(v))?Number(v):d;
const f4=v=>Number(v).toFixed(4);
export const EARLY_EXIT_VERSION='nonfoot-early-exit-v1-charged-remainder';

export const N_SENSORS=36, N_ACTUATORS=8;
export const LEG_ORDER=['fl','fr','rl','rr'];
export const BODY_NAMES=['torso',...LEG_ORDER.flatMap(l=>[`${l}_thigh`,`${l}_shin`])];
export const MOTOR_NAMES=['FL hip','FL knee','FR hip','FR knee','RL hip','RL knee','RR hip','RR knee'];

/* Frozen plant contract. Visible in the dashboard and the checkpoint, but not
 * part of the searchable experiment grammar. Values are foundry/plant.py's. */
export const PLANT={
  gravity:9.81,
  dt:0.004,
  frameSkip:5,
  torsoLength:0.60,
  torsoWidth:0.28,
  torsoHeight:0.14,
  torsoMass:6.0,
  hipSpanX:0.48,
  hipSpanY:0.34,
  hipZOffset:-0.05,
  thighLength:0.24,
  shinLength:0.22,
  thighRadius:0.034,
  shinRadius:0.027,
  thighMass:0.70,
  shinMass:0.45,
  footMass:0.12,
  footRadius:0.045,
  frictionMu:1.10,
  footTorsionFriction:0.10,
  footRollFriction:0.05,
  /* v10.0.2 FIRM FRICTION. MuJoCo's default friction (pyramidal cone, impratio 1)
   * is soft: a planted, loaded foot creeps at 7-15 mm/s, far above the 2 mm/s the
   * slide meter forgives, so it spent about 2.5 cm of every trial's 6.25 cm slide
   * allowance before the walker did anything. An elliptic cone with impratio 10 is
   * MuJoCo's own remedy (friction made stiffer than contact, the coefficient
   * unchanged at 1.10): creep falls to 0.6-2.7 mm/s at no measurable cost in speed.
   * 'pyramidal' + 1 restores the Foundry contract exactly (friction: legacy). */
  frictionCone:'elliptic',
  impratio:10,
  jointDampingNms:0.60,
  jointArmature:0.03,
  torqueLimitHip:28.0,
  torqueLimitKnee:20.0,
  kneeRangeMin:0.35,
  kneeRangeMax:2.10,
  kneeRestOffset:0.06,
  hipRange:1.30,
  hipStiffness:22.0,
  hipSpringRef:0.0,
  startHeight:0.50,
  failureTiltRad:1.20,
  failureHeightM:0.18,
  distanceFootMoveM:0.015,
  // measurement thresholds, also frozen
  stepMinSwingTicks:2,
  stepMinHorizontalM:0.015,
  stepMinLiftM:0.008,
  segmentMinProgressM:0.005,
  nonfootContactThresholdBW:0.02,
};

/* Frozen perturbation recipe, from foundry/evaluation.py DEFAULT_RECIPE. */
export const DEFAULT_RECIPE={
  pert_mode:'mixed',kick_min:1,kick_max:3,kick_strength:0.35,
  int_lo:0.75,int_hi:1.25,pert_noise:0.035,pert_dropout:0.05,
  pert_lag:1,pert_mass:0.10,
};

// ------------------------------------------------------ the body ------------
/* Render MJCF from the contract. Direct port of build_mjcf(). */
export function buildMjcf(cfg){
  const c={...PLANT,...(cfg||{})};
  const g=num(c.gravity),dt=num(c.dt);
  const tl=num(c.torsoLength)/2,tw=num(c.torsoWidth)/2,th=num(c.torsoHeight)/2;
  const hipX=num(c.hipSpanX)/2,hipY=num(c.hipSpanY)/2,hipZ=num(c.hipZOffset);
  const thigh=num(c.thighLength),shin=num(c.shinLength);
  const tr=num(c.thighRadius),sr=num(c.shinRadius);
  const tm=num(c.thighMass),sm=num(c.shinMass),fm=num(c.footMass),fr=num(c.footRadius);
  const mu=num(c.frictionMu),hipT=num(c.torqueLimitHip),kneeT=num(c.torqueLimitKnee);
  const kneeMin=num(c.kneeRangeMin),kneeMax=num(c.kneeRangeMax),hipLim=num(c.hipRange);
  const legs=LEG_ORDER.map(leg=>{
    const sx=leg[0]==='f'?hipX:-hipX, sy=leg[1]==='l'?hipY:-hipY;
    return `<body name="${leg}_thigh" pos="${f4(sx)} ${f4(sy)} ${f4(hipZ)}">
          <joint name="${leg}_hip" type="hinge" axis="0 1 0" range="${f4(-hipLim)} ${f4(hipLim)}"
                 stiffness="${f4(c.hipStiffness)}" springref="${f4(c.hipSpringRef)}"/>
          <geom name="${leg}_thigh_geom" type="capsule" fromto="0 0 0 0 0 ${f4(-thigh)}" size="${f4(tr)}" mass="${f4(tm)}"/>
          <body name="${leg}_shin" pos="0 0 ${f4(-thigh)}">
            <joint name="${leg}_knee" type="hinge" axis="0 1 0" range="${f4(kneeMin)} ${f4(kneeMax)}"/>
            <geom name="${leg}_shin_geom" type="capsule" fromto="0 0 0 0 0 ${f4(-shin)}" size="${f4(sr)}" mass="${f4(sm)}"/>
            <geom name="${leg}_foot" type="sphere" pos="0 0 ${f4(-shin)}" size="${f4(fr)}" mass="${f4(fm)}"
                  friction="${f4(mu)} ${f4(c.footTorsionFriction)} ${f4(c.footRollFriction)}"/>
            <site name="${leg}_foot_site" pos="0 0 ${f4(-shin)}" size="0.01"/>
          </body>
        </body>`;
  }).join('');
  const motors=LEG_ORDER.flatMap(leg=>['hip','knee'].map(j=>{
    const lim=j==='hip'?hipT:kneeT;
    return `<motor name="m_${leg}_${j}" joint="${leg}_${j}" gear="1" ctrlrange="${(-lim).toFixed(2)} ${lim.toFixed(2)}"/>`;
  })).join('\n');
  return `<mujoco model="clean_liquid_walker">
      <compiler angle="radian"/>
      <option timestep="${dt}" gravity="0 0 ${-g}" integrator="implicitfast" cone="${c.frictionCone==='pyramidal'?'pyramidal':'elliptic'}" impratio="${Math.max(1,num(c.impratio,1))}"><flag energy="enable"/></option>
      <default>
        <joint damping="${num(c.jointDampingNms)}" armature="${num(c.jointArmature)}" limited="true" solreflimit="0.01 1"/>
        <geom condim="3" friction="${f4(mu)} 0.02 0.001" solref="0.01 1"/>
      </default>
      <worldbody>
        <geom name="floor" type="plane" size="80 80 1" friction="${f4(mu)} 0.02 0.001"/>
        <body name="torso" pos="0 0 ${f4(c.startHeight)}">
          <freejoint name="root"/>
          <geom name="torso_geom" type="box" size="${f4(tl)} ${f4(tw)} ${f4(th)}" mass="${f4(c.torsoMass)}"/>
          ${legs}
        </body>
      </worldbody>
      <actuator>${motors}</actuator>
    </mujoco>`;
}
export function rangesFromConfig(cfg){
  const c={...PLANT,...(cfg||{})};
  const hip=Math.max(0.10,num(c.hipRange,1.30));
  const lo=num(c.kneeRangeMin,0.35),hi=Math.max(lo+0.10,num(c.kneeRangeMax,2.10));
  return JOINT_NAMES.map(n=>n.endsWith('_hip')?[-hip,hip]:[lo,hi]);
}
export function neutralFromConfig(cfg){
  const c={...PLANT,...(cfg||{})};
  const lo=num(c.kneeRangeMin,0.35),off=Math.max(0,num(c.kneeRestOffset,0.06));
  const hi=Math.max(lo+0.10,num(c.kneeRangeMax,2.10));
  const knee=clamp(lo+off,lo,hi);
  return JOINT_NAMES.map(n=>n.endsWith('_hip')?0:knee);
}

// ---------------------------------------------------------------- RNG --------
function rng32(seed){return {s:seed>>>0}}
function nextRand(o){let a=o.s>>>0;a=(a+0x6D2B79F5)>>>0;o.s=a;let t=Math.imul(a^(a>>>15),1|a);t=(t+Math.imul(t^(t>>>7),61|t))^t;return ((t^(t>>>14))>>>0)/4294967296}
function randn(o){let u=0,v=0;while(!u)u=nextRand(o);while(!v)v=nextRand(o);return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v)}
function hash32(x){x=(x+0x9E3779B9)>>>0;x=Math.imul(x^(x>>>16),0x85EBCA6B)>>>0;x=Math.imul(x^(x>>>13),0xC2B2AE35)>>>0;return (x^(x>>>16))>>>0}

// ------------------------------------------------------- measurement ---------
export function horizontalFootRelocation(initialFeet,currentFeet){
  let m=0;
  for(let f=0;f<4;f++){
    const d=Math.hypot(currentFeet[3*f]-initialFeet[3*f],currentFeet[3*f+1]-initialFeet[3*f+1]);
    if(d>m)m=d;
  }
  return m;
}
export function footGatedComProgress(initialComX,currentComX,initialFeet,currentFeet,thresholdM){
  const moved=horizontalFootRelocation(initialFeet,currentFeet);
  const eligible=moved>=Math.max(0,num(thresholdM));
  return {signed:eligible?currentComX-initialComX:0,eligible,moved};
}

// ---------------------------------------------------------- scenario ---------
export function makeScenario(seed,difficulty=1.0,steps=875,recipe=DEFAULT_RECIPE){
  const r=rng32(hash32(seed)),diff=Math.max(0,num(difficulty,1));
  const mode=String(recipe.pert_mode||'impulse');
  const kickEnabled=['impulse','sustained','mixed'].includes(mode);
  let lo=Math.trunc(num(recipe.kick_min,1)),hi=Math.trunc(num(recipe.kick_max,3));
  if(hi<lo){const t=lo;lo=hi;hi=t}
  const count=kickEnabled&&hi>0?lo+Math.floor(nextRand(r)*(hi-lo+1)):0;
  const earliest=Math.max(8,Math.floor(steps/10));
  const latest=Math.max(10,steps-Math.floor(steps/8));
  const room=Math.max(0,latest-earliest);
  const chosen=new Set();
  for(let i=0;i<Math.min(count,room);i++){
    let s=earliest+Math.floor(nextRand(r)*room),guard=0;
    while(chosen.has(s)&&guard++<64)s=earliest+Math.floor(nextRand(r)*room);
    chosen.add(s);
  }
  const pushSteps=[...chosen].sort((a,b)=>a-b);
  const base=num(recipe.kick_strength,0.35)*diff;
  let iLo=num(recipe.int_lo,0.70),iHi=num(recipe.int_hi,1.30);
  if(iHi<iLo){const t=iLo;iLo=iHi;iHi=t}
  const pushVectors=pushSteps.map(()=>{
    const ang=(nextRand(r)*2-1)*Math.PI,inten=iLo+nextRand(r)*(iHi-iLo);
    return [Math.cos(ang)*base*inten,Math.sin(ang)*base*inten,((nextRand(r)*2-1)*0.08)*base*inten];
  });
  const noise=['sensor_noise','mixed'].includes(mode)?num(recipe.pert_noise,0.06)*diff:0;
  const dropout=['sensor_dropout','mixed'].includes(mode)?Math.min(0.95,num(recipe.pert_dropout,0.12)*diff):0;
  const lag=['actuator_lag','mixed'].includes(mode)?Math.min(20,Math.round(num(recipe.pert_lag,2)*diff)):0;
  const payload=['plant_shift','mixed'].includes(mode)?Math.max(0,num(recipe.pert_mass,0.10)*diff):0;
  return {mode,difficulty:diff,seed:seed>>>0,steps,pushSteps,pushVectors,
    noiseStd:noise,dropout,actuatorLag:lag,payloadFraction:payload,
    key:`${seed>>>0}:${diff}:${steps}:${mode}`};
}

// ------------------------------------------------------------- plant ---------
export class WalkerPlant{
  /* `mujoco` is the loaded WASM module. The model is built here from the
   * contract; nothing is fetched from disk. */
  constructor(mujoco,cfg){
    const mj=this.mj=mujoco;
    this.cfg={...PLANT,...(cfg||{})};
    // v15 extension point: keep the original named leg/muscle contract while
    // adding articulated shoulder steering, a neck and physical eye cameras.
    this.mjcf=this.cfg.modelXml||buildMjcf(this.cfg);
    this.model=mj.MjModel.from_xml_string(this.mjcf);
    if(!this.model)throw new Error('MuJoCo rejected the generated MJCF.');
    const m=this.model;
    this.dt=num(this.cfg.dt);
    this.frameSkip=Math.max(1,Math.trunc(num(this.cfg.frameSkip,5)));
    this.controlDt=this.dt*this.frameSkip;
    this.sustainedLen=Math.max(1,Math.round(0.16/this.controlDt));

    // every id by name, as the Python does
    // embind exposes mjtObj entries as objects carrying .value; fall back to the
    // documented numeric constants if this build shapes them differently, so a
    // binding quirk cannot silently turn every lookup into -1
    const OBJ_FALLBACK={mjOBJ_BODY:1,mjOBJ_JOINT:3,mjOBJ_GEOM:5,mjOBJ_SITE:6};
    const OBJ=t=>{
      const e=mj.mjtObj?.[t];
      const v=(e&&typeof e==='object'&&'value' in e)?e.value:e;
      return Number.isFinite(Number(v))?Number(v):OBJ_FALLBACK[t];
    };
    const id=(t,n)=>{
      const v=mj.mj_name2id(m,OBJ(t),n);
      if(!(v>=0))throw new Error(`Generated model has no ${t} named "${n}". `+
        `mj_name2id returned ${v}. The MJCF compiled but naming is not resolving, `+
        `so this MuJoCo build differs from the one this port was written against.`);
      return v;
    };
    this.torsoBid=id('mjOBJ_BODY','torso');
    this.torsoGid=id('mjOBJ_GEOM','torso_geom');
    this.floorGid=id('mjOBJ_GEOM','floor');
    this.bodyIds=BODY_NAMES.map(n=>id('mjOBJ_BODY',n));
    this.jointIds=JOINT_NAMES.map(n=>id('mjOBJ_JOINT',n));
    this.jointQpos=this.jointIds.map(j=>num(m.jnt_qposadr[j]));
    this.jointQvel=this.jointIds.map(j=>num(m.jnt_dofadr[j]));
    this.footGids=LEG_ORDER.map(l=>id('mjOBJ_GEOM',`${l}_foot`));
    this.footSids=LEG_ORDER.map(l=>id('mjOBJ_SITE',`${l}_foot_site`));
    this.footGidMap=new Map(this.footGids.map((g,i)=>[g,i]));
    // which shin body carries which foot, for the degraded load fallback
    this.footBodies=LEG_ORDER.map(l=>id('mjOBJ_BODY',`${l}_shin`));
    this.footRootBodies=this.footBodies.map(b=>m.body_rootid[b]);
    this.footContactMargins=Float64Array.from(this.footGids,g=>m.geom_margin[g]+m.geom_margin[this.floorGid]);
    this.surfaceGidMap=new Map([[this.torsoGid,'torso']]);
    this.surfaceBodyMap=new Map([[this.torsoBid,'torso']]);
    for(const l of LEG_ORDER)for(const seg of ['thigh','shin']){
      this.surfaceGidMap.set(id('mjOBJ_GEOM',`${l}_${seg}_geom`),`${l}_${seg}`);
      this.surfaceBodyMap.set(id('mjOBJ_BODY',`${l}_${seg}`),`${l}_${seg}`);
    }

    this.torqueLimits=Float64Array.from(
      Array.from({length:N_ACTUATORS},(_,i)=>i%2===0?num(this.cfg.torqueLimitHip):num(this.cfg.torqueLimitKnee)));
    this.jointLimits=rangesFromConfig(this.cfg);
    let mass=0;for(let b=0;b<m.nbody;b++)mass+=num(m.body_mass[b]);
    this.totalMass=mass;
    this.bodyWeight=Math.max(1e-9,mass*num(this.cfg.gravity));

    this.caps={cfrc:false,subtreeCom:false,xfrc:false};
    this.probeNotes={};   // why each capability came out the way it did
    /* Non-foot probes retain a conservative 1 mm safety buffer. Foot contact
     * uses the compiled collision margin plus roundoff only; proximity above
     * the floor is not evidence of contact or friction. */
    this.floorTolM=0.001;
    this.footRadius=num(this.cfg.footRadius);
    this.touchProbes=[{name:'torso',kind:'box',bid:this.torsoBid,
      hx:num(this.cfg.torsoLength)/2,hy:num(this.cfg.torsoWidth)/2,hz:num(this.cfg.torsoHeight)/2}];
    for(const l of LEG_ORDER){
      this.touchProbes.push({name:`${l}_thigh`,kind:'capsule',
        bid:id('mjOBJ_BODY',`${l}_thigh`),L:num(this.cfg.thighLength),r:num(this.cfg.thighRadius)});
      this.touchProbes.push({name:`${l}_shin`,kind:'capsule',
        bid:id('mjOBJ_BODY',`${l}_shin`),L:num(this.cfg.shinLength),r:num(this.cfg.shinRadius)});
    }
    this._passiveCache=new Map();
    this._scratch={
      feet:new Float64Array(12),initFeet:new Float64Array(12),prevFeet:new Float64Array(12),
      obs:new Float64Array(N_SENSORS),q:new Float64Array(8),qd:new Float64Array(8),
      tq:new Float64Array(8),tqn:new Float64Array(8),tqSum:new Float64Array(8),zero:new Float64Array(16),ptq:new Float64Array(8),
      footForce:new Float64Array(4),footShear:new Float64Array(4),footSlip:new Float64Array(4),
      contacts:new Float64Array(4),surface:{},footTouch:new Uint8Array(4),shinTouch:new Uint8Array(4),
      surfTouch:new Set(),
    };
    for(const n of SURFACE_NAMES)this._scratch.surface[n]=0;

    this.run={difficulty:1.0,actuation:'torque',kp:55,kd:5,tauCap:32,hpBudget:DEFAULT_HIT_POINT_BUDGET};
    this.startHeight=num(this.cfg.startHeight);
    this.restJointQ=Float64Array.from(neutralFromConfig(this.cfg));
    this.restQuat=Float64Array.from([1,0,0,0]);
    this.strain=strainGeometry(this.jointLimits,Array.from(this.restJointQ));
  }
  configure(run){Object.assign(this.run,run||{});return this}

  /* Solve the standing height instead of asserting it. Direct port of
   * _calibrate_standing(). */
  calibrateStanding(data){
    const mj=this.mj,m=this.model,d=data;
    mj.mj_resetData(m,d);
    d.qpos[3]=1;d.qpos[4]=0;d.qpos[5]=0;d.qpos[6]=0;
    d.qpos[2]=1.0;
    const neutral=neutralFromConfig(this.cfg);
    for(let i=0;i<8;i++)d.qpos[this.jointQpos[i]]=neutral[i];
    mj.mj_forward(m,d);
    let low=Infinity;
    for(const gid of this.footGids){
      const z=num(d.geom_xpos[3*gid+2])-num(m.geom_size[3*gid]);
      if(z<low)low=z;
    }
    d.qpos[2]=1.0-low+0.003;
    mj.mj_forward(m,d);
    this.startHeight=num(d.qpos[2]);
    this.restJointQ=Float64Array.from({length:8},(_,i)=>num(d.qpos[this.jointQpos[i]]));
    this.restQuat=Float64Array.from([num(d.qpos[3],1),num(d.qpos[4]),num(d.qpos[5]),num(d.qpos[6])]);
    this.strain=strainGeometry(this.jointLimits,Array.from(this.restJointQ));
    return {startHeight:this.startHeight,restJointQ:Array.from(this.restJointQ),
      lowestFootAtUnitHeight:low};
  }

  /* Probe which measurement paths this WASM build supports, so the dashboard
   * states what it is measuring rather than implying precision it lacks. */
  probe(data){
    const mj=this.mj,m=this.model;
    mj.mj_resetData(m,data);
    data.qpos[2]=this.startHeight;
    for(let i=0;i<8;i++)data.qpos[this.jointQpos[i]]=this.restJointQ[i];
    mj.mj_forward(m,data);
    for(let i=0;i<500;i++){for(let k=0;k<N_ACTUATORS;k++)data.ctrl[k]=0;mj.mj_step(m,data)}
    try{
      const v=data.subtree_com[3*this.torsoBid];
      this.caps.subtreeCom=Number.isFinite(v);
      this.probeNotes.subtreeCom=this.caps.subtreeCom
        ?`subtree_com[torso].x read back as ${v.toFixed(4)}`
        :`subtree_com[torso].x read back as ${v}`;
    }catch(e){this.caps.subtreeCom=false;this.probeNotes.subtreeCom=`reading subtree_com threw: ${e?.message||e}`}
    try{
      data.xfrc_applied[6*this.torsoBid]=0;this.caps.xfrc=true;
      this.probeNotes.xfrc='xfrc_applied is writable';
    }catch(e){this.caps.xfrc=false;this.probeNotes.xfrc=`writing xfrc_applied threw: ${e?.message||e}`}
    /* Measured contact wrench. Without this the load path falls back to a crude
     * kinematic proxy in which the nine limb-surface parts take no load at all,
     * so the injury ledger silently measures far less than it claims. After 500
     * settling steps the body is resting on its feet, so a working binding must
     * report a non-zero external wrench. */
    try{
      mj.mj_rnePostConstraint(m,data);
      let sum=0;
      for(let b=1;b<m.nbody;b++)for(let k=0;k<6;k++)sum+=Math.abs(num(data.cfrc_ext[6*b+k]));
      this.caps.cfrc=Number.isFinite(sum)&&sum>1e-6;
      this.probeNotes.cfrc=this.caps.cfrc
        ?`mj_rnePostConstraint ran and cfrc_ext summed to ${sum.toFixed(2)} N over ${m.nbody-1} bodies after 500 settling steps`
        :`mj_rnePostConstraint ran but cfrc_ext summed to ${sum} — the call exists yet writes nothing back`;
    }catch(e){
      this.caps.cfrc=false;
      this.probeNotes.cfrc=`mj_rnePostConstraint threw: ${e?.message||e}`;
    }
    return this.caps;
  }
  reset(d,o){
    const mj=this.mj,m=this.model;
    mj.mj_resetData(m,d);
    d.qpos[2]=this.startHeight+(o?randn(o)*0.004:0);
    if(o){
      const roll=randn(o)*0.020,pitch=randn(o)*0.020;
      const cr=Math.cos(roll/2),sr=Math.sin(roll/2),cp=Math.cos(pitch/2),sp=Math.sin(pitch/2);
      let q=[cr*cp,sr*cp,cr*sp,-sr*sp];
      const nq=Math.hypot(q[0],q[1],q[2],q[3])||1;
      for(let k=0;k<4;k++)d.qpos[3+k]=q[k]/nq;
      for(let i=0;i<8;i++){
        d.qpos[this.jointQpos[i]]=this.restJointQ[i]+randn(o)*0.025;
        d.qvel[this.jointQvel[i]]=randn(o)*0.02;
      }
      for(let k=0;k<6;k++)d.qvel[k]=randn(o)*0.012;
    }else{
      d.qpos[3]=this.restQuat[0];d.qpos[4]=this.restQuat[1];
      d.qpos[5]=this.restQuat[2];d.qpos[6]=this.restQuat[3];
      for(let i=0;i<8;i++)d.qpos[this.jointQpos[i]]=this.restJointQ[i];
    }
    if(this.caps.xfrc)for(let k=0;k<6;k++)d.xfrc_applied[6*this.torsoBid+k]=0;
    mj.mj_forward(m,d);
  }

  comX(d){
    return this.comXY(d)[0];
  }
  comXY(d){
    // xipos is refreshed by mj_kinematics; subtree_com otherwise lags mj_step.
    let x=0,y=0;
    for(let b=1;b<this.model.nbody;b++){const mass=this.model.body_mass[b];x+=mass*d.xipos[3*b];y+=mass*d.xipos[3*b+1]}
    return [x/this.totalMass,y/this.totalMass];
  }
  headPose(d){
    const b=9*this.torsoBid,p=3*this.torsoBid,R=d.xmat,offset=this.cfg.torsoLength/2;
    return {x:d.xpos[p]+offset*R[b],y:d.xpos[p+1]+offset*R[b+3],z:d.xpos[p+2]+offset*R[b+6],yaw:Math.atan2(R[b+3],R[b])};
  }
  scanNonfoot(d,parts){
    parts.clear();for(const p of this.touchProbes)if(this.lowestPoint(d,p)<=this.floorTolM)parts.add(p.name);
    // Both adjoining capsule ends belong to a knee, never an adapted foot.
    const radius=Math.max(this.cfg.thighRadius,this.cfg.shinRadius);
    return this.footBodies.some(b=>d.xpos[3*b+2]-radius<=this.floorTolM);
  }
  /* Feet are measured at their sites, as the Python does, not at geom centres. */
  feetInto(d,out){
    for(let f=0;f<4;f++){
      const j=3*this.footSids[f];
      out[3*f]=num(d.site_xpos[j]);out[3*f+1]=num(d.site_xpos[j+1]);out[3*f+2]=num(d.site_xpos[j+2]);
    }
    return out;
  }
  tilt(d){return Math.acos(clamp(num(d.xmat[9*this.torsoBid+8],1),-1,1))}
  /* Has the integrator blown up? 500 m/s or rad/s is far outside anything an
   * 11 kg body with 28 N.m actuators can reach, so it means divergence rather
   * than a fast gait. */
  diverged(d){
    for(let k=0;k<3;k++)if(!Number.isFinite(d.qpos[k]))return true;
    for(let k=0;k<6;k++){const v=d.qvel[k];if(!Number.isFinite(v)||Math.abs(v)>500)return true}
    for(let i=0;i<8;i++){
      if(!Number.isFinite(d.qpos[this.jointQpos[i]]))return true;
      const v=d.qvel[this.jointQvel[i]];
      if(!Number.isFinite(v)||Math.abs(v)>500)return true;
    }
    return false;
  }

  /* Lowest world-frame point of a probe geom. Exact for a box (the minimum
   * corner projection onto world z) and for a capsule (the lower of its two
   * endpoints, minus the radius). */
  lowestPoint(d,p){
    const o=9*p.bid,R=d.xmat,z=num(d.xpos[3*p.bid+2]);
    const r20=num(R[o+6]),r21=num(R[o+7]),r22=num(R[o+8]);
    if(p.kind==='box')
      return z-(Math.abs(r20)*p.hx+Math.abs(r21)*p.hy+Math.abs(r22)*p.hz);
    return Math.min(z,z-r22*p.L)-p.r;   // capsule along the body's local -z
  }

  /* Adapted-foot contacts and forces plus non-adapted surface loads, normalised
   * to bodyweight because the hit-point model is body-scale invariant.
   *
   * Contact is geometric and allocates nothing: reading data.contact leaked
   * embind handles until the WASM heap ran out. Magnitudes still come from the
   * measured per-body wrench. */
  contacts(d,S){
    const c=S.contacts,ff=S.footForce,fs=S.footShear,surf=S.surface;
    c.fill(0);ff.fill(0);fs.fill(0);S.footTouch.fill(0);S.shinTouch.fill(0);S.surfTouch.clear();
    for(const n of SURFACE_NAMES)surf[n]=0;
    const tol=this.floorTolM,bw=this.bodyWeight;

    // feet: a sphere against a plane, so this is exact
    for(let f=0;f<4;f++){
      if(num(d.site_xpos[3*this.footSids[f]+2])-this.footRadius<=this.footContactMargins[f]+FOOT_SLIP_DEFAULTS.contactEpsilonM){c[f]=1;S.footTouch[f]=1}
    }
    let torsoContact=false;
    for(const p of this.touchProbes){
      if(this.lowestPoint(d,p)>tol)continue;
      S.surfTouch.add(p.name);
      if(p.name==='torso')torsoContact=true;
      else if(p.name.endsWith('_shin')){
        const si=LEG_ORDER.indexOf(p.name.slice(0,2));
        if(si>=0)S.shinTouch[si]=1;
      }
    }

    if(this.caps.cfrc){
      // Per-body wrench. The foot sphere sits on the shin body, so a shin
      // body's wrench is split by which of its geoms is actually touching.
      this.mj.mj_rnePostConstraint(this.model,d);
      const w=d.cfrc_ext,xf=this.caps.xfrc?d.xfrc_applied:null;
      for(let f=0;f<4;f++){
        const b=6*this.footBodies[f];
        const fx=num(w[b+3]),fy=num(w[b+4]),fz=num(w[b+5]);
        const share=(S.footTouch[f]&&S.shinTouch[f])?0.5:1;
        if(S.footTouch[f]){ff[f]=Math.abs(fz)*share/bw;fs[f]=Math.hypot(fx,fy)*share/bw}
        if(S.shinTouch[f])surf[`${LEG_ORDER[f]}_shin`]=Math.hypot(fx,fy,fz)*share/bw;
      }
      for(const [bid,name] of this.surfaceBodyMap){
        if(name.endsWith('_shin'))continue;
        // A body that is not touching the floor is not carrying a contact load,
        // whatever its external wrench happens to say.
        if(!S.surfTouch.has(name)){surf[name]=0;continue}
        const b=6*bid;
        let fx=num(w[b+3]),fy=num(w[b+4]),fz=num(w[b+5]);
        if(xf&&bid===this.torsoBid){
          // cfrc_ext also carries the disturbance we applied ourselves. Charging
          // the injury ledger for our own payload and impulses would be scoring
          // the perturbation as an injury.
          fx-=num(xf[6*bid]);fy-=num(xf[6*bid+1]);fz-=num(xf[6*bid+2]);
        }
        surf[name]=Math.hypot(fx,fy,fz)/bw;
      }
    }else{
      let n=0;for(let f=0;f<4;f++)if(c[f])n++;
      for(let f=0;f<4;f++){ff[f]=c[f]&&n?1/n:0;fs[f]=c[f]&&n?0.35/n:0}
      surf.torso=torsoContact?1.1:0;
    }
    return torsoContact;
  }

  /* 36 public sensors: original 33 plus head-relative target range and bearing. Body-frame gravity rather than a raw quaternion,
   * body-frame linear velocity, and sin/cos of yaw so the network never sees a
   * wraparound discontinuity. */
  observation(d,contacts,out,target=null){
    const R=d.xmat,b=9*this.torsoBid,o=out;
    const r00=num(R[b]),r01=num(R[b+1]),r02=num(R[b+2]);
    const r10=num(R[b+3]),r11=num(R[b+4]),r12=num(R[b+5]);
    const r20=num(R[b+6]),r21=num(R[b+7]),r22=num(R[b+8]);
    o[0]=-r20;o[1]=-r21;o[2]=-r22;
    o[3]=num(d.qvel[3])/4;o[4]=num(d.qvel[4])/4;o[5]=num(d.qvel[5])/4;
    o[6]=(num(d.qpos[2])-this.startHeight)/0.30;
    const vx=num(d.qvel[0]),vy=num(d.qvel[1]),vz=num(d.qvel[2]);
    o[7]=(r00*vx+r10*vy+r20*vz)/1.5;
    o[8]=(r01*vx+r11*vy+r21*vz)/1.5;
    o[9]=(r02*vx+r12*vy+r22*vz)/1.5;
    const yaw=Math.atan2(r10,r00);
    o[10]=Math.sin(yaw);o[11]=Math.cos(yaw);
    for(let i=0;i<8;i++)o[12+i]=num(d.qpos[this.jointQpos[i]])/1.5;
    for(let i=0;i<8;i++)o[20+i]=num(d.qvel[this.jointQvel[i]])/5;
    for(let i=0;i<4;i++)o[28+i]=contacts[i];
    o[32]=num(d.qpos[1]);
    if(target){const head=this.headPose(d);targetSensors(head.x,head.y,head.yaw,target[0],target[1],o)}
    else{o[33]=0;o[34]=0;o[35]=0}
    for(let i=0;i<N_SENSORS;i++)o[i]=clamp(o[i],-3,3);
    return o;
  }

  /* v10.0.1: is the brain's command a joint target (a servo) rather than a torque?
   * v10.1.0: muscles too -- both are recomputed every physics step. */
  isServo(){return this.run.actuation==='pd'||this.run.actuation==='servo'||this.run.actuation==='muscle'}
  isMuscle(){return this.run.actuation==='muscle'}
  /* how many numbers the brain sends each 20 ms step: 16 for muscles, else 8 */
  commandSize(){return this.isMuscle()?16:8}
  torquesFrom(out,d,into){
    if(this.isMuscle()){
      /* v10.1.0 MUSCLES. Each joint has two muscles, each a spring pulling the
       * joint toward its own end: the "plus" muscle toward rest + 25 % of the
       * range, the "minus" muscle toward rest - 25 %. A command c in [-1, 1]
       * sets the muscle's activation a = (1 + c) / 2: -1 fully relaxed, 0 half
       * tone, +1 fully contracted. With activations a+ and a-:
       *   the joint settles at rest + span x (a+ - a-) / (a+ + a-)
       *   its stiffness is kp x (a+ + a-) and its damping kd x (a+ + a-)
       * so one pair sets both where the joint goes and how stiff it is. Two half
       * tones (zero commands) give exactly the v10.0.1 servo: the rest pose at
       * kp 55, kd 5. Contracting both stiffens the joint up to twice that;
       * relaxing both lets it go limp. Torque is capped at the same motor limits
       * (28 N.m hip, 20 N.m knee), and recomputed every 4 ms physics step. */
      const kp=num(this.run.kp,55),kd=num(this.run.kd,5),cap=num(this.run.tauCap,32);
      for(let i=0;i<8;i++){
        const [lo,hi]=this.jointLimits[i],span=(hi-lo)*0.25,lim=Math.min(cap,this.torqueLimits[i]);
        const ap=clamp(.5+.5*num(out[i]),0,1),am=clamp(.5+.5*num(out[8+i]),0,1),A=ap+am;
        if(A<1e-9){into[i]=0;continue}                 // both relaxed: a limp joint (passive damping and the hip spring only)
        const target=clamp(this.restJointQ[i]+span*(ap-am)/A,lo+0.02,hi-0.02);
        into[i]=clamp(kp*A*(target-num(d.qpos[this.jointQpos[i]]))-kd*A*num(d.qvel[this.jointQvel[i]]),-lim,lim);
      }
    }else if(this.isServo()){
      /* A PD servo toward rest + 25 % of the joint's range per unit of command,
       * capped at the joint's own motor limit (28 N.m hip, 20 N.m knee). The
       * rollout recomputes it every physics step (see rollout): held for a whole
       * 20 ms control step, kd 5 is unstable and the body skates and falls. */
      const kp=num(this.run.kp,55),kd=num(this.run.kd,5),cap=num(this.run.tauCap,32);
      for(let i=0;i<8;i++){
        const [lo,hi]=this.jointLimits[i],span=(hi-lo)*0.25,lim=Math.min(cap,this.torqueLimits[i]);
        const target=clamp(this.restJointQ[i]+span*num(out[i]),lo+0.02,hi-0.02);
        into[i]=clamp(kp*(target-num(d.qpos[this.jointQpos[i]]))-kd*num(d.qvel[this.jointQvel[i]]),-lim,lim);
      }
    }else{
      for(let i=0;i<8;i++)into[i]=clamp(num(out[i]),-1,1)*this.torqueLimits[i];
    }
    return into;
  }

  applyDisturbance(d,scenario,t,state){
    if(!this.caps.xfrc)return;
    const tb=6*this.torsoBid;
    for(let k=0;k<6;k++)d.xfrc_applied[tb+k]=0;
    d.xfrc_applied[tb+2]=-scenario.payloadFraction*this.bodyWeight;
    const idx=scenario.pushSteps.indexOf(t);
    if(idx>=0){
      state.push=scenario.pushVectors[idx];
      state.left=['sustained','mixed'].includes(scenario.mode)?this.sustainedLen:1;
    }
    if(state.left>0&&state.push){
      d.xfrc_applied[tb]+=state.push[0]*this.bodyWeight;
      d.xfrc_applied[tb+1]+=state.push[1]*this.bodyWeight;
      d.xfrc_applied[tb+2]+=state.push[2]*this.bodyWeight;
      state.left--;
    }
  }

  /* Matched zero-action whole-body COM traces. Passive COM is intentionally NOT
   * foot-gated: any disturbance-driven translation is subtracted from the active
   * foot-gated signal, so a controller cannot earn a shove merely by moving one
   * foot while a matched passive body would have translated anyway. */
  passiveProfile(scenario,steps,data){
    const key=`${scenario.key}:${steps}:${this.run.actuation}`;   // v10.0.1: a servo's do-nothing body differs from a torque one's
    const hit=this._passiveCache.get(key);
    if(hit)return hit;
    const mj=this.mj,m=this.model,o=rng32(hash32(scenario.seed));
    this.reset(data,o);

    const initComX=this.comX(data);
    const ratcheted=new Float64Array(steps),signed=new Float64Array(steps);
    let furthest=0;
    const st={push:null,left:0};
    for(let t=0;t<steps;t++){
      this.applyDisturbance(data,scenario,t,st);
      for(let i=0;i<N_ACTUATORS;i++)data.ctrl[i]=0;
      if(this.isServo())for(let k=0;k<this.frameSkip;k++){this.torquesFrom(this._scratch.zero,data,this._scratch.ptq);for(let i=0;i<N_ACTUATORS;i++)data.ctrl[i]=this._scratch.ptq[i];mj.mj_step(m,data)}
      else for(let k=0;k<this.frameSkip;k++)mj.mj_step(m,data);
      if(this.diverged(data)){
        // freeze the trace at its last good value rather than propagate NaN
        for(let u=t;u<steps;u++){ratcheted[u]=Math.max(0,furthest);signed[u]=signed[Math.max(0,t-1)]||0}
        try{mj.mj_resetData(m,data)}catch(e){}
        break;
      }
      mj.mj_kinematics(m,data);
      const s=this.comX(data)-initComX;
      if(s>furthest)furthest=s;
      ratcheted[t]=Math.max(0,furthest);signed[t]=s;
    }
    const profile={ratcheted,signed,measure:'whole_body_com_floor_projection',footGate:false};
    this._passiveCache.set(key,profile);
    while(this._passiveCache.size>128)this._passiveCache.delete(this._passiveCache.keys().next().value);
    return profile;
  }

  /* v7.0 EARLY EXIT (additive, default OFF). With `earlyExit:{nonfootSeconds,mode}`
   * a rollout stops once the body has been in non-foot floor contact for that
   * long — continuously (mode 'continuous', the default) or in total (mode
   * 'cumulative', which is what the ternary warm-up rungs use: a thrashing body
   * touches down intermittently and almost never stays down for a full second), and the unrun remainder of the episode is CHARGED
   * as non-foot contact (the worst case for contact health). Foot slide after
   * the stop cannot be known and is not integrated, so the guarantee is stated
   * where early exit is used: a stopped rollout never outranks its completed
   * self on either warm-up rung (tested). Survival is kept at 1, as it would have been:
   * a fall never ends an ordinary rollout. Used only for training ranks on the
   * warm-up rungs of ternary lanes; the reward of record, the yardstick,
   * certification and every KG panel run full length. With earlyExit null
   * this function is bit-identical to v6.18.3 (tests/reward_fence_test.mjs). */
  rollout({control,hidden=null,steps,scenario,data,passiveData,record=false,recordStride=8,onStep=null,earlyExit=null}){
    const mj=this.mj,m=this.model,S=this._scratch;
    const o=rng32(hash32(scenario.seed^0x5bf03635));
    this.reset(data,o);

    const taskMode=scenario.taskMode==='target'?'target':'walk';
    const targetRequirement=scenario.targetRequirement||'stop';
    const targetPath=makeTargetPath(scenario.seed,steps*this.frameSkip,this.dt,scenario.targetMode);
    const targetAt=k=>[targetPath.points[2*k],targetPath.points[2*k+1]];
    const progress=new TargetProgress(...this.comXY(data)),health=new ContactHealth(SURFACE_NAMES);
    const footSlip=new FootSlip(LEG_ORDER,this.footRadius,this.footContactMargins);
    footSlip.prime(data,this.footSids,this.footBodies,this.footRootBodies);
    const goal=new TargetGoal(this.headPose(data),this.comXY(data),targetAt(0),this.dt);
    const previousParts=new Set(),currentParts=new Set(),intervalParts=new Set(),frameParts=new Set(),frameSlidingFeet=new Set();
    let previousKnee=this.scanNonfoot(data,previousParts),physicsTicks=0,lastFrameTick=0;
    const targetNoise=rng32(hash32(scenario.seed^0x544e4f49));

    const hp=new AnatomicalHitPointState({budget:this.run.hpBudget,strain:this.strain});
    let torsoContact=this.contacts(data,S);
    const initComX=this.comX(data);
    let cleanWalkX=initComX,cleanWalkSignedM=0,blockedWalkProgressM=0,walkPathLengthM=0;
    this.feetInto(data,S.initFeet);
    S.prevFeet.set(S.initFeet);

    const passive=passiveData?this.passiveProfile(scenario,steps,passiveData)
                             :{ratcheted:new Float64Array(0),signed:new Float64Array(0)};

    let furthest=0,useful=0,activeSigned=0,passiveSigned=0,passiveFurthest=0;
    let ungatedSigned=0,ungatedFurthest=0,footGateOpen=false,maxFootRelocation=0;
    let failure=null,tilt=0,noninjury=1;
    const prevContacts=new Float64Array(4);prevContacts.set(S.contacts);
    const inSwing=[false,false,false,false];
    const swingStart=new Float64Array(12);swingStart.set(S.prevFeet);
    const swingPeakLift=new Float64Array(4),swingTicks=new Int32Array(4),stepCounts=new Int32Array(4);
    let torsoContactSteps=0,nonfootContactSteps=0,nonfootGeomContactSteps=0,peakNonfootBW=0;
    let footDragExcessSum=0,footDragContactTicks=0;
    let segmentStart=0,positiveSegments=0,midpointAutonomous=null;
    const autonomousSegmentProgress=[];
    const boundaries=new Set([1,2,3,4].map(q=>Math.max(1,Math.round(steps*q/4))-1));
    const lagBuf=[];for(let i=0;i<=scenario.actuatorLag;i++)lagBuf.push(new Float64Array(this.commandSize()));
    const st={push:null,left:0};
    const frames=[];
    let t=-1,aliveSteps=0;
    const exitTicks=earlyExit&&num(earlyExit.nonfootSeconds,0)>0?Math.max(1,Math.round(num(earlyExit.nonfootSeconds)/this.dt)):0;
    const exitCumulative=earlyExit?.mode==='cumulative';   // default: continuous contact
    let earlyExitAt=null,exitNow=false;

    for(t=0;t<steps;t++){
      const obs=this.observation(data,S.contacts,S.obs,taskMode==='target'?targetAt(physicsTicks):null);
      const noisySensors=taskMode==='target'?N_SENSORS:33;
      if(scenario.noiseStd>0)for(let i=0;i<noisySensors;i++)obs[i]=clamp(obs[i]+randn(i<33?o:targetNoise)*scenario.noiseStd,-3,3);
      if(scenario.dropout>0)for(let i=0;i<noisySensors;i++)if(nextRand(i<33?o:targetNoise)<scenario.dropout)obs[i]=0;
      if(taskMode==='walk'){obs[33]=0;obs[34]=0;obs[35]=0}

      const cmd=control(obs,this.controlDt);
      const servo=this.isServo();let held=cmd,subSteps=0;
      if(servo){
        /* v10.0.1: actuator lag delays the servo's COMMAND; its torque is then
         * recomputed from the joint state before every physics step below. */
        if(scenario.actuatorLag>0){lagBuf.push(Float64Array.from(cmd));held=lagBuf.shift()}
        S.tqSum.fill(0);
      }else{
      this.torquesFrom(cmd,data,S.tq);
      if(scenario.actuatorLag>0){
        lagBuf.push(new Float64Array(S.tq));
        S.tq.set(lagBuf.shift());
      }
      }
      this.applyDisturbance(data,scenario,t,st);
      if(!servo)for(let i=0;i<N_ACTUATORS;i++)data.ctrl[i]=S.tq[i];
      for(let k=0;k<this.frameSkip;k++){
        if(servo){this.torquesFrom(held,data,S.tq);for(let i=0;i<N_ACTUATORS;i++){data.ctrl[i]=S.tq[i];S.tqSum[i]+=S.tq[i]}subSteps++}
        mj.mj_step(m,data);physicsTicks++;
        if(this.diverged(data))break;
        // mj_step ends with integration; derived transforms still describe the
        // preceding state until kinematics is explicitly refreshed.
        mj.mj_kinematics(m,data);
        // Refresh the velocity's COM frame and joint motion axes as well as
        // the poses. This is observation only; do not repeat dynamics/forces.
        mj.mj_comPos(m,data);mj.mj_comVel(m,data);
        const knee=this.scanNonfoot(data,currentParts);
        intervalParts.clear();for(const n of previousParts)intervalParts.add(n);for(const n of currentParts)intervalParts.add(n);
        const bad=health.step(intervalParts,previousKnee||knee);
        if(exitTicks&&(exitCumulative?health.badTicks:health.consecutive)>=exitTicks)exitNow=true;
        if(record)for(const n of intervalParts)frameParts.add(n);
        const [cx,cy]=this.comXY(data),target=targetAt(physicsTicks-1);
        progress.step(cx,cy,target[0],target[1],bad);
        const walkDx=cx-cleanWalkX;walkPathLengthM+=Math.abs(walkDx);
        if(bad&&walkDx>0)blockedWalkProgressM+=walkDx;else cleanWalkSignedM+=walkDx;cleanWalkX=cx;
        const sliding=footSlip.step(data,this.footSids,this.footBodies,this.footRootBodies,this.dt);
        if(record&&sliding)for(let f=0;f<4;f++)if(footSlip.intervalSlidingFeet[f])frameSlidingFeet.add(LEG_ORDER[f]);
        goal.step(this.headPose(data),[cx,cy],targetAt(physicsTicks),bad||sliding);
        previousParts.clear();for(const n of currentParts)previousParts.add(n);previousKnee=knee;
      }
      aliveSteps++;
      if(servo&&subSteps)for(let i=0;i<N_ACTUATORS;i++)S.tq[i]=S.tqSum[i]/subSteps;

      // A diverged integrator leaves non-finite or absurd state behind. Asking
      // MuJoCo to keep stepping from there can abort inside the WASM module and
      // take the whole process down, so the episode ends here instead and the
      // body is reset before anything else touches it.
      if(this.diverged(data)){
        failure='diverged';hp.fatal();noninjury=0;
        try{mj.mj_resetData(m,data)}catch(e){/* nothing further to salvage */}
        break;
      }

      torsoContact=this.contacts(data,S);
      this.feetInto(data,S.feet);
      for(let f=0;f<4;f++){
        S.footSlip[f]=Math.hypot(S.feet[3*f]-S.prevFeet[3*f],S.feet[3*f+1]-S.prevFeet[3*f+1])/this.controlDt;
      }
      for(let i=0;i<8;i++){
        S.q[i]=num(data.qpos[this.jointQpos[i]]);
        S.qd[i]=num(data.qvel[this.jointQvel[i]]);
        S.tqn[i]=Math.abs(S.tq[i])/Math.max(1e-9,this.torqueLimits[i]);
      }
      tilt=this.tilt(data);
      hp.step({jointAngles:S.q,jointVelocities:S.qd,normalizedTorques:S.tqn,
        footForceBW:S.footForce,footShearBW:S.footShear,footSlipSpeed:S.footSlip,
        nonfootSurfaceForceBW:S.surface,tiltRadians:tilt,dt:this.controlDt});

      const comX=this.comX(data);
      ungatedSigned=comX-initComX;
      if(ungatedSigned>ungatedFurthest)ungatedFurthest=ungatedSigned;
      const gate=footGatedComProgress(initComX,comX,S.initFeet,S.feet,num(this.cfg.distanceFootMoveM));
      footGateOpen=footGateOpen||gate.eligible;
      if(gate.moved>maxFootRelocation)maxFootRelocation=gate.moved;
      // Once a foot has relocated, current and future COM positions are eligible.
      if(footGateOpen){activeSigned=ungatedSigned;if(activeSigned>furthest)furthest=activeSigned}
      else activeSigned=0;
      passiveFurthest=passive.ratcheted.length?passive.ratcheted[Math.min(t,passive.ratcheted.length-1)]:0;
      passiveSigned=passive.signed.length?passive.signed[Math.min(t,passive.signed.length-1)]:0;
      useful=Math.max(0,furthest-passiveFurthest);

      if(torsoContact)torsoContactSteps++;
      if(S.surfTouch.size>0)nonfootGeomContactSteps++;
      const dragFree=Math.max(0,num(this.cfg.footDragFreeMps,.02));
      for(let f=0;f<4;f++)if(S.contacts[f]>=0.5){footDragExcessSum+=Math.max(0,S.footSlip[f]-dragFree);footDragContactTicks++;}
      let localNonfoot=0;
      for(const n of SURFACE_NAMES)if(S.surface[n]>localNonfoot)localNonfoot=S.surface[n];
      if(localNonfoot>num(this.cfg.nonfootContactThresholdBW))nonfootContactSteps++;
      if(localNonfoot>peakNonfootBW)peakNonfootBW=localNonfoot;

      for(let f=0;f<4;f++){
        const wasDown=prevContacts[f]>=0.5,isDown=S.contacts[f]>=0.5;
        if(wasDown&&!isDown){
          inSwing[f]=true;
          swingStart[3*f]=S.prevFeet[3*f];swingStart[3*f+1]=S.prevFeet[3*f+1];swingStart[3*f+2]=S.prevFeet[3*f+2];
          swingPeakLift[f]=0;swingTicks[f]=0;
        }else if(inSwing[f]&&!isDown){
          swingTicks[f]++;
          const lift=S.feet[3*f+2]-swingStart[3*f+2];
          if(lift>swingPeakLift[f])swingPeakLift[f]=lift;
        }else if(inSwing[f]&&isDown){
          const horiz=Math.hypot(S.feet[3*f]-swingStart[3*f],S.feet[3*f+1]-swingStart[3*f+1]);
          if(swingTicks[f]>=num(this.cfg.stepMinSwingTicks)&&horiz>=num(this.cfg.stepMinHorizontalM)
             &&swingPeakLift[f]>=num(this.cfg.stepMinLiftM))stepCounts[f]++;
          inSwing[f]=false;
        }
      }
      prevContacts.set(S.contacts);
      S.prevFeet.set(S.feet);

      const autonomousNow=activeSigned-passiveSigned;
      if(t===Math.max(1,Math.round(steps/2))-1)midpointAutonomous=autonomousNow;
      if(boundaries.has(t)){
        autonomousSegmentProgress.push(autonomousNow-segmentStart);
        if(autonomousNow-segmentStart>=num(this.cfg.segmentMinProgressM))positiveSegments++;
        segmentStart=autonomousNow;
      }

      // v6.6 SIMPLE GAIT deliberately does not terminate ordinary falls or tilt.
      // A collapsed animal remains in MuJoCo and keeps accumulating geometric
      // non-foot ground contact. Only numerical divergence aborts the rollout.
      // Anatomical HP is telemetry only and cannot terminate or grade an episode.
      noninjury=clamp(hp.remainingFraction(),0,1);

      if(record&&(t%Math.max(1,recordStride)===0||failure||t===steps-1)){
        frames.push(this.frame(data,S,hp.snapshot(),useful,noninjury,t,
          {footGateOpen,maxFootRelocation,rawDistance:furthest,passiveDistance:passiveFurthest,
           ungatedDistance:Math.max(0,ungatedFurthest),forwardSpeedMps:Math.max(0,ungatedSigned)/Math.max(this.controlDt,(t+1)*this.controlDt),
           nonfootGroundContact:currentParts.size>0,nonfootParts:[...currentParts],contactHealth:health.snapshot(this.dt),footSlip:footSlip.snapshot(),
           contactInterval:{seconds:(physicsTicks-lastFrameTick)*this.dt,bodyParts:[...frameParts],slidingFeet:[...frameSlidingFeet]},
           taskMode,walking:{cleanForwardM:Math.max(0,cleanWalkSignedM),signedForwardM:cleanWalkSignedM,blockedForwardM:blockedWalkProgressM,pathLengthM:walkPathLengthM},
           target:{position:targetAt(physicsTicks),head:this.headPose(data),...progress.snapshot(),goal:goal.snapshot(progress.snapshot(),targetRequirement)},
           footDragMps:footDragContactTicks?footDragExcessSum/footDragContactTicks:0,tilt,
           brainState:hidden?Array.from(hidden()):null}));
        frameParts.clear();frameSlidingFeet.clear();lastFrameTick=physicsTicks;
      }
      if(onStep)onStep({t,useful,noninjury,tilt,failure});
      if(failure)break;
      if(exitNow&&t<steps-1){earlyExitAt=t;break}
    }
    let earlyExitReport=null;
    if(earlyExitAt!==null){
      const remaining=Math.max(0,steps*this.frameSkip-physicsTicks);
      health.chargeRemainder(remaining,currentParts);
      earlyExitReport={version:EARLY_EXIT_VERSION,atStep:earlyExitAt,atSeconds:(earlyExitAt+1)*this.controlDt,
        chargedTicks:remaining,chargedSeconds:remaining*this.dt,nonfootSeconds:exitTicks*this.dt,mode:exitCumulative?'cumulative':'continuous',
        rule:`${exitCumulative?'cumulative':'continuous'} non-foot contact reached the limit; the unrun remainder is charged as non-foot contact and survival is kept`};
    }

    const snap=hp.snapshot();
    const steppingFeet=stepCounts.reduce((n,c)=>n+(c>0?1:0),0);
    const genuineSteps=stepCounts.reduce((s,c)=>s+c,0);
    const done=Math.max(1,aliveSteps),survived=earlyExitAt!==null?steps:done;
    const fullEpisodeSeconds=Math.max(this.controlDt,steps*this.controlDt);
    const forwardDistanceM=failure==='diverged'?0:Math.max(0,ungatedSigned);
    const forwardSpeedMps=forwardDistanceM/fullEpisodeSeconds;
    const contactHealth=health.snapshot(this.dt),footSlipResult=footSlip.snapshot(),target=progress.snapshot();target.goal=goal.snapshot(target,targetRequirement);
    const nonfootGroundContactFraction=failure==='diverged'?1:contactHealth.contactFraction;
    if(failure==='diverged'){contactHealth.health=0;contactHealth.contactFraction=1;contactHealth.contactFree=false;target.effectiveDistanceM=0;target.goal.goalScore=0;target.goal.success=false;cleanWalkSignedM=0}
    const cleanWalkDistanceM=Math.max(0,cleanWalkSignedM),cleanWalkSpeedMps=cleanWalkDistanceM/fullEpisodeSeconds;
    const legacyFootDragMps=footDragContactTicks?footDragExcessSum/footDragContactTicks:0;
    const footDragMps=footSlipResult.maxSlipM/fullEpisodeSeconds;
    const footDragIndex=footSlipResult.maxSlipM/FOOT_SLIP_DEFAULTS.scaleM;
    const groundHealth=contactHealth.health*footSlipResult.health;
    const sustained=sustainedGait({genuineSteps,steppingFeet,positiveProgressSegments:positiveSegments,signedAutonomousDistanceM:activeSigned-passiveSigned,lateAutonomousDistanceM:midpointAutonomous===null?0:activeSigned-passiveSigned-midpointAutonomous,survival:survived/steps});
    return {
      distance:useful,noninjury,
      taskMode,targetSkillStage:scenario.targetSkillStage??null,targetSkillId:scenario.targetSkillId??null,targetRequirement,
      sustainedGait:sustained,score:(taskMode==='target'?target.goal.goalScore:cleanWalkSpeedMps*sustained.factor)*groundHealth,forwardDistanceM,forwardSpeedMps,nonfootGroundContactFraction,footDragMps,footDragIndex,legacyFootDragMps,fullEpisodeSeconds,
      cleanWalkDistanceM,cleanWalkSpeedMps,blockedWalkProgressM,walkPathLengthM,
      targetGoalScore:target.goal.goalScore,targetDistanceM:target.effectiveDistanceM,target,contactHealth,footSlip:footSlipResult,groundHealth,
      targetPath:{version:targetPath.version,mode:targetPath.mode,seed:targetPath.seed,side:targetPath.side,phase:targetPath.phase,period:targetPath.period,moveStart:targetPath.moveStart,moveEnd:targetPath.moveEnd,defaults:TARGET_DEFAULTS},
      rawDistance:furthest,passiveDistance:passiveFurthest,
      ungatedDistance:Math.max(0,ungatedFurthest),
      signedAutonomousDistanceM:activeSigned-passiveSigned,
      lateAutonomousDistanceM:midpointAutonomous===null?0:activeSigned-passiveSigned-midpointAutonomous,
      survival:survived/steps,failure,fall:failure==='fall',diverged:failure==='diverged',
      weakestPart:snap.weakestPart,hpRemaining:snap.remaining,
      damageByPart:snap.damageByPart,damageByCause:snap.damageByCause,
      totalDamageByCause:snap.totalDamageByCause,depleted:snap.depleted,
      tilt,physicsSteps:physicsTicks,
      gait:{
        footDistanceGateOpen:footGateOpen,maxFootRelocationM:maxFootRelocation,
        signedAutonomousDistanceM:activeSigned-passiveSigned,
        genuineSteps,steppingFeet,stepsPerFoot:Array.from(stepCounts),
        positiveProgressSegments:positiveSegments,
        autonomousSegmentProgress,
        lateAutonomousDistanceM:midpointAutonomous===null?0:activeSigned-passiveSigned-midpointAutonomous,
        torsoContactFraction:torsoContactSteps/done,
        nonfootContactFraction:nonfootContactSteps/done,
        nonfootGeometricContactFraction:nonfootGroundContactFraction,
        footDragMps,footDragIndex,
        peakNonfootForceBW:peakNonfootBW,
        catastrophic:failure==='fall'||failure==='diverged',
      },
      frames,
      ...(earlyExitReport?{earlyExit:earlyExitReport}:{}),
    };
  }

  frame(d,S,snap,distance,noninjury,t,extra){
    const bodies=[];
    for(const b of this.bodyIds){
      bodies.push([num(d.xpos[3*b]),num(d.xpos[3*b+1]),num(d.xpos[3*b+2]),
        num(d.xquat[4*b],1),num(d.xquat[4*b+1]),num(d.xquat[4*b+2]),num(d.xquat[4*b+3])]);
    }
    return {t,time:(t+1)*this.controlDt,bodies,
      x:num(d.qpos[0]),distance,noninjury,
      sensors:Array.from(S.obs),torques:Array.from(S.tq),
      jointAngles:Array.from(S.q),jointVelocities:Array.from(S.qd),
      contacts:Array.from(S.contacts),footForceBW:Array.from(S.footForce),
      footSlip:Array.from(S.footSlip),surface:{...S.surface},
      weakestPart:snap.weakestPart,injuryByPart:snap.damageByPart,
      chronicCrouchFatigue:snap.chronicCrouchFatigue,chronicCrouchStress:snap.chronicCrouchStress,...extra};
  }

  /* The renderer builds from this, and every number comes from the same
   * contract the physics was generated from. */
  geometryReport(){
    const c=this.cfg;
    return {
      torsoLength:num(c.torsoLength),torsoWidth:num(c.torsoWidth),torsoHeight:num(c.torsoHeight),
      thighLength:num(c.thighLength),thighRadius:num(c.thighRadius),
      shinLength:num(c.shinLength),shinRadius:num(c.shinRadius),
      footRadius:num(c.footRadius),
      hipSpanX:num(c.hipSpanX),hipSpanY:num(c.hipSpanY),hipZOffset:num(c.hipZOffset),
      startHeight:this.startHeight,
      bodyOrder:BODY_NAMES,nbody:this.model.nbody,ngeom:this.model.ngeom,nsite:this.model.nsite,
    };
  }

  physicsReport(){
    return {
      body:'generated by buildMjcf() from the frozen contract (foundry/plant.py build_mjcf)',
      model:'clean_liquid_walker',
      integrator:'implicitfast',
      timestep:this.dt,frameSkip:this.frameSkip,controlInterval:this.controlDt,
      totalMass:this.totalMass,bodyWeightN:this.bodyWeight,
      standingPose:{
        method:'solved by forward kinematics, not asserted',
        startHeightM:this.startHeight,
        restJointQ:Array.from(this.restJointQ),
        note:'hips neutral at 0, knees at kneeRangeMin + kneeRestOffset, lowest foot 3 mm clear of the floor',
      },
      joints:{hipRangeRad:[-num(this.cfg.hipRange),num(this.cfg.hipRange)],
        kneeRangeRad:[num(this.cfg.kneeRangeMin),num(this.cfg.kneeRangeMax)],
        dampingNms:num(this.cfg.jointDampingNms),armature:num(this.cfg.jointArmature),
        hipStiffness:num(this.cfg.hipStiffness),hipSpringRef:num(this.cfg.hipSpringRef),
        note:'the hips carry a passive spring toward neutral, so the standing prior is in the body rather than in the controller'},
      sensors:N_SENSORS,actuators:N_ACTUATORS,
      actuation:this.run.actuation==='muscle'
        ?`two muscles per joint (springs toward rest ± 25 % of the range; stiffness kp × total activation, kp ${this.run.kp}, kd ${this.run.kd}), capped at the motor limits`
        :this.run.actuation==='pd'
        ?`PD around the solved standing pose, cap ${this.run.tauCap} N·m (v1 wrapper)`
        :`direct joint torque, hip ${this.cfg.torqueLimitHip} / knee ${this.cfg.torqueLimitKnee} N·m (Foundry)`,
      friction:{mu:num(this.cfg.frictionMu),
        footTorsion:num(this.cfg.footTorsionFriction),footRoll:num(this.cfg.footRollFriction),
        cone:this.cfg.frictionCone==='pyramidal'?'pyramidal':'elliptic',impratio:Math.max(1,num(this.cfg.impratio,1)),
        note:'condim is 3, so the torsional and rolling coefficients are inert; reproduced as the Foundry writes them. v10.0.2: an elliptic cone with impratio 10 (firm) stops a planted foot creeping; pyramidal with impratio 1 is the Foundry contract (legacy)'},
      fitnessHealth:{version:CONTACT_HEALTH_VERSION,definition:'1 - fraction of physics intervals with non-foot floor contact; any knee contact violates health',sampleDt:this.dt,positiveContactProgressBlocked:true},
      fitnessFootSlip:{version:FOOT_SLIP_VERSION,...FOOT_SLIP_DEFAULTS,sampleDt:this.dt,contactMarginsM:Array.from(this.footContactMargins),definition:'ground-relative tangential rigid-body velocity at the sphere-plane contact point; soft-contact midpoint, grounded-time integration, no airborne endpoint velocity; worst individual accumulated slide reduces fitness'},
      target:{version:TARGET_VERSION,...TARGET_DEFAULTS,sensors:'head-to-target distance / (distance + 2m), sin bearing, cos bearing',path:'stationary main task; precomputed smooth target movement in observational tests'},
      fitnessGoal:{name:'reach_and_stop',definition:'terminal approach × (0.70 + 0.10 × straightness + 0.20 × final continuous hold); moving trials use target-relative speed during tracking'},
      fitnessDistance:{name:'target_effective_distance',role:'progress telemetry and morphology/plateau evidence; reproductive fitness uses goal score',definition:'signed COM approach (positive contact travel blocked) × approach/path-length straightness; target motion alone earns zero'},
      distance:{
        name:'autonomous_distance',
        definition:'whole-body COM floor projection; ratcheted active progress eligible only after any foot relocates by the threshold; matched passive COM fully subtracted',
        foot_relocation_threshold_m:num(this.cfg.distanceFootMoveM),
        role:'legacy diagnostic only; excluded from target fitness',com_source:'mass-weighted body inertial positions (xipos), refreshed after integration',
        foot_source:'foot sites (site_xpos)',
      },
      noninjury:{name:'weakest_part_noninjury',
        definition:'minimum remaining public anatomical hit-point fraction over all vulnerable parts; includes acute strain/shock/load plus recoverable chronic loaded-knee-flexion fatigue that damages only after sustained crouching'},
      contact_source:`closed-form lowest-point test against the floor plane; non-foot safety buffer ${this.floorTolM*1000} mm; feet use compiled contact margins plus ${FOOT_SLIP_DEFAULTS.contactEpsilonM} m roundoff only; allocation-free`,
      contact_note:'data.contact is deliberately never read: its accessors return embind ClassHandles, which are never garbage collected and exhausted the WASM heap',
      load_source:this.caps.cfrc
        ?'mj_rnePostConstraint + cfrc_ext per body, foot/shin split by which geom is touching'
        :'kinematic contact proxy (cfrc_ext unavailable)',
      failure:{height_m:num(this.cfg.failureHeightM),tilt_rad:num(this.cfg.failureTiltRad)},
      perturbation:{...DEFAULT_RECIPE,difficulty:this.run.difficulty,
        sustained_len_control_steps:this.sustainedLen},
      capabilities:{...this.caps},
      capability_evidence:{...this.probeNotes},
    };
  }
}
