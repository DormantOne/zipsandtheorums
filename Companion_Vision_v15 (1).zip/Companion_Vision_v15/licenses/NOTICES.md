# Included runtime software

- MuJoCo and `@mujoco/mujoco` 3.12.0: Apache License 2.0. Upstream: https://github.com/google-deepmind/mujoco and https://www.npmjs.com/package/@mujoco/mujoco. The WASM physics binary is distributed with its JavaScript binding. See `MuJoCo-Apache-2.0.txt`.
- Three.js 0.185.0: MIT License. Upstream: https://github.com/mrdoob/three.js. See `Three-MIT.txt`.

The download includes the runtime files used by this application. Unused examples, source maps and multithreaded builds are omitted. `npm ci` restores the complete pinned npm distributions if needed for development.

The application adapts the user's supplied Walker Neural Gait v13, QuadMind v4.0 Active Neck Gaze, and Walker Metamorphosis v14 projects. Their original ZIP archives are separate and unmodified. The original spinal-cord and Metamorphosis hybrid modules are retained unchanged; the visual task, body extension, server and interface are in the accompanying source.
