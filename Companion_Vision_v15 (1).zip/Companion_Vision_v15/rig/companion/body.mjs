import {WalkerPlant,PLANT,LEG_ORDER,buildMjcf} from '../../engine/plant.js';

export const BODY_VERSION='companion-physical-body-v15.2';
export const STEER_LIMIT=.42;
export const NECK_LIMITS=[1.0,.50];
export const BODY_CONFIG={thighLength:PLANT.thighLength*.72,shinLength:PLANT.shinLength*.72};
const names=['torso',...LEG_ORDER.flatMap(l=>[`${l}_shoulder`,`${l}_thigh`,`${l}_shin`]),'neck_yaw','neck_pitch'];
export function companionXml(){
  let xml=buildMjcf(BODY_CONFIG);
  // Rotate the plane of each leg's stroke by at most 24 degrees. The original
  // hip and knee, their springs, lengths, opposing muscles and limits remain.
  for(const l of LEG_ORDER){
    const x=l[0]==='f'?.24:-.24,y=l[1]==='l'?.17:-.17;
    xml=xml.replace(new RegExp(`<body name="${l}_thigh" pos="[^"]+">`),
      `<body name="${l}_shoulder" pos="${x} ${y} -.05">
       <joint name="${l}_steer" type="hinge" axis="0 0 1" range="-${STEER_LIMIT} ${STEER_LIMIT}" stiffness="1.0" damping=".35" armature=".004"/>
       <geom name="${l}_shoulder_geom" type="sphere" size=".042" mass=".06" rgba=".72 .52 .30 1"/>
       <body name="${l}_thigh" pos="0 0 0">`);
    const start=xml.indexOf(`<body name="${l}_shoulder"`),end=xml.indexOf('</body>\n        </body>',start);
    if(end<0)throw Error('Original leg layout changed');
    const at=end+'</body>\n        </body>'.length;
    xml=xml.slice(0,at)+'</body>'+xml.slice(at);
  }
  const neck=`
    <body name="neck_yaw" pos=".355 0 .125">
      <joint name="neck_yaw_joint" axis="0 0 1" range="-1 1" damping=".20" armature=".006"/>
      <geom name="neck_base" type="capsule" fromto="0 0 0 .067 0 .015" size=".043" mass=".17" rgba=".69 .47 .25 1"/>
      <body name="neck_pitch" pos=".067 0 .015">
        <joint name="neck_pitch_joint" axis="0 1 0" range="-.50 .50" damping=".20" armature=".006"/>
        <geom name="head_shell" type="box" pos=".045 0 .023" size=".095 .10 .067" mass=".30" rgba=".78 .58 .34 1"/>
        <geom name="muzzle" type="ellipsoid" pos=".132 0 -.008" size=".065 .065 .038" mass=".035" rgba=".89 .76 .57 1"/>
        <geom name="nose" type="ellipsoid" pos=".191 0 .0" size=".018 .030 .018" mass=".005" rgba=".13 .18 .19 1"/>
        <geom name="ear_left" type="ellipsoid" pos=".006 .105 .047" size=".040 .022 .072" mass=".012" rgba=".37 .26 .17 1"/>
        <geom name="ear_right" type="ellipsoid" pos=".006 -.105 .047" size=".040 .022 .072" mass=".012" rgba=".37 .26 .17 1"/>
        <geom name="eye_left_glass" type="sphere" pos=".142 .067 .073" size=".022" mass=".003" rgba=".11 .26 .29 1"/>
        <geom name="eye_right_glass" type="sphere" pos=".142 -.067 .073" size=".022" mass=".003" rgba=".11 .26 .29 1"/>
        <camera name="eye_left" pos=".165 .067 .073" xyaxes="0 -1 0 0 0 1" fovy="90"/>
        <camera name="eye_right" pos=".165 -.067 .073" xyaxes="0 -1 0 0 0 1" fovy="90"/>
      </body>
    </body>
    <geom name="tail" type="capsule" fromto="-.29 0 .035 -.45 0 .13" size=".023" mass=".035" rgba=".62 .42 .22 1"/>`;
  xml=xml.replace('</worldbody>',`<body name="beacon" mocap="true" pos="1.8 0 .38"><geom name="target_ball" type="sphere" size=".105" mass=".001" contype="0" conaffinity="0" rgba=".94 .13 .19 1"/></body>
    <body name="screen" mocap="true" pos="0 0 -5"><geom name="vision_screen" type="box" size=".035 .38 .40" contype="0" conaffinity="0" rgba=".28 .40 .40 1"/></body></worldbody>`);
  // Insert before the torso's close, rather than attaching to a leg.
  xml=xml.replace('        </body>\n      </worldbody>',`        </body>\n      </worldbody>`); // explicit layout below uses the worldbody boundary
  const wb=xml.indexOf('<body name="beacon"'),torsoEnd=xml.lastIndexOf('</body>',wb);
  xml=xml.slice(0,torsoEnd)+neck+from(xml,torsoEnd);
  const extra=LEG_ORDER.map(l=>`<motor name="m_${l}_steer" joint="${l}_steer" gear="1" ctrllimited="true" ctrlrange="-5 5"/>`).join('')+
    ['yaw','pitch'].map(a=>`<motor name="m_neck_${a}" joint="neck_${a}_joint" gear="1" ctrllimited="true" ctrlrange="-5 5"/>`).join('');
  // In v13 each thigh was a direct child of the torso, so MuJoCo excluded
  // their intentionally overlapping joint surfaces. The new shoulder body
  // changes that ancestry: retain those four original neighbour exclusions.
  const contact='<contact>'+LEG_ORDER.map(l=>`<exclude body1="torso" body2="${l}_thigh"/>`).join('')+'</contact>';
  return xml.replace('<actuator>',contact+'<actuator>').replace('</actuator>',extra+'</actuator>').replace('model="clean_liquid_walker"','model="Companion_vision_v15"');
}
const from=(s,i)=>s.slice(i);
export function makeCompanionBody(mj){
  const p=new WalkerPlant(mj,{...BODY_CONFIG,modelXml:companionXml()});
  const data=new mj.MjData(p.model);
  p.calibrateStanding(data);p.probe(data);p.configure({actuation:'muscle',hpBudget:800});
  const id=(type,name)=>{const i=mj.mj_name2id(p.model,type,name);if(i<0)throw Error('Missing '+name);return i;};
  const steer=LEG_ORDER.map(l=>id(3,l+'_steer')),neck=['yaw','pitch'].map(a=>id(3,'neck_'+a+'_joint'));
  const extra=[...steer,...neck].map(j=>({q:p.model.jnt_qposadr[j],v:p.model.jnt_dofadr[j]}));
  const camera=['eye_left','eye_right'].map(n=>id(7,n));
  const beacon=id(1,'beacon'),screen=id(1,'screen');
  const mocap=p.model.body_mocapid[beacon],screenMocap=p.model.body_mocapid[screen];
  const bodyIds=names.map(n=>id(1,n));
  // A mocap beacon is a visual stimulus, not part of the animal's mass.
  p.totalMass=bodyIds.reduce((s,i)=>s+p.model.body_mass[i],0);p.bodyWeight=p.totalMass*PLANT.gravity;
  p.comXY=d=>{let x=0,y=0;for(const i of bodyIds){const mass=p.model.body_mass[i];x+=mass*d.xipos[3*i];y+=mass*d.xipos[3*i+1];}return [x/p.totalMass,y/p.totalMass];};
  return {plant:p,data,extra,camera,mocap,screenMocap,bodyIds,names,
    dispose(){data.delete();p.model.delete();}};
}

export function describeModel(body){
  const p=body.plant,m=p.model,mj=p.mj;
  return {version:BODY_VERSION,bodies:body.names.map((name,i)=>({name,id:body.bodyIds[i]})),
    geoms:Array.from({length:m.ngeom},(_,g)=>({name:mj.mj_id2name(m,5,g),body:m.geom_bodyid[g],type:m.geom_type[g],
      size:Array.from(m.geom_size.slice(3*g,3*g+3)),pos:Array.from(m.geom_pos.slice(3*g,3*g+3)),
      quat:Array.from(m.geom_quat.slice(4*g,4*g+4)),rgba:Array.from(m.geom_rgba.slice(4*g,4*g+4))})),
    dt:p.dt,controlDt:p.controlDt,steerLimit:STEER_LIMIT,neckLimits:NECK_LIMITS};
}
