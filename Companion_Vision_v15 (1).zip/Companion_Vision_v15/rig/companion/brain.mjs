/* The Metamorphosis genome and frozen-topology inheritance are used intact.
 * This adapter replaces its walker-specific sensor encoder and muscle decoder
 * with retinal/proprioceptive inputs and six descending commands to the fixed
 * spinal cord. There are no privileged target inputs.
 */
import {packRig,unpackRig,rigAudit,KIND,ROLE,rigDistance} from '../brain.mjs';
export const SENSORS=['left: horizontal','right: horizontal','left: area','right: area','left: visible','right: visible','binocular disparity','mean red area','left: vertical','right: vertical','neck yaw','neck pitch','neck yaw speed','neck pitch speed','body pitch','body roll','body turn rate','forward speed','far / near retinal size','either eye visible','time without target','last turn command','constant','last speed command'];
export const OUTPUTS=['forward drive','body turn','look left / right','look down / up','muscle tone','step rhythm'];
export const SENSOR_COUNT=SENSORS.length;
export function makeFounder(rng,{N=48,variant=0}={}){
  const S=SENSOR_COUNT,A=OUTPUTS.length,V=3,K=2,role=new Int8Array(N),src=new Int32Array(3*N),w=new Int8Array(3*N),dec=new Int8Array(A*N);
  const bias=new Float64Array(N),gain=new Float64Array(N).fill(1),fb=new Float64Array(3*N);
  for(let i=0;i<N;i++)for(let k=0;k<3;k++){src[3*i+k]=rng.int(S+N);w[3*i+k]=rng.next()<.30?0:rng.next()<.5?-1:1;}
  // A transparent visual-reflex prior. The initial chase isn't evidence of
  // learning. Its connections, like every other founder's, can subsequently
  // mutate; full-precision descendants learn between evolution windows.
  const cell=(i,inputs,weights)=>{for(let k=0;k<3;k++){src[3*i+k]=inputs[k]??22;w[3*i+k]=weights[k]??0;}};
  for(let a=0;a<A;a++)for(let j=0;j<V;j++){
    const i=a*V+j;dec[a*N+i]=1;
    if(a===0)cell(i,[18,18,18],[1,1,0]);
    if(a===1)cell(i,[10,0,1],[1,1,j===2?0:1]);
    if(a===2)cell(i,[0,1,12],[1,1,-1]);
    if(a===3)cell(i,[8,9,13],[1,1,-1]);
    if(a===4)cell(i,[14,15,22],[0,0,0]);
    if(a===5)cell(i,[18,17,22],[1,0,0]);
  }
  // Remaining recurrent cells are available for evolution without changing the
  // seed's motor votes. Some are internal; tonic cells keep strict rules.
  for(let i=A*V;i<N;i++)if(i%5===0){role[i]=ROLE.INTERNAL;for(let k=0;k<3;k++)src[3*i+k]=S+rng.int(N);}
  const g=packRig({N,S,A,V,K,kind:KIND.STRICT_FIXED,role,src,w,dec,bias,gain,fb});
  return variant?mutateVision(g,rng,{count:variant}):g;
}
export function makeVisualNetwork(g){
  validateGenome(g);const b=unpackRig(g),{N,S,A,K,src,w,role,dec}=b,continuous=b.kind===KIND.HEIR;
  const h=new Float64Array(N),next=new Float64Array(N),out=new Float64Array(A),acc=new Float64Array(A);
  const voters=Array.from({length:A},(_,a)=>Array.from({length:N},(_,i)=>i).filter(i=>dec[a*N+i]!==0));
  return {control(obs){
    if(obs.length!==S)throw Error('Visual network received the wrong input contract');acc.fill(0);
    for(let tick=0;tick<K;tick++){
      for(let i=0;i<N;i++){
        if(role[i]===ROLE.TONIC){next[i]=1;continue;}
        let z=b.bias[i];for(let k=0;k<3;k++){const j=3*i+k,s=src[j];z+=w[j]*(s<S?obs[s]:h[s-S]);}
        next[i]=continuous?Math.tanh(2.4*z):Math.abs(z)<.06?0:Math.sign(z);
      }
      h.set(next);for(let a=0;a<A;a++){let v=0;for(const i of voters[a])v+=dec[a*N+i]*h[i];acc[a]+=v;}
    }
    for(let a=0;a<A;a++)out[a]=continuous?Math.tanh(acc[a]/K/Math.max(3,b.V*.55)):Math.tanh(acc[a]/K/Math.max(3,b.V*.55));
    return out;
  },activity:()=>Array.from(h),reset(){h.fill(0);next.fill(0);out.fill(0);},genome:g};
}
export function validateGenome(g){
  if(!(g instanceof Float64Array)||g[0]!==9.0625||!Number.isInteger(g[1])||g[1]<18||g[1]>256||g[2]!==SENSOR_COUNT||g[3]!==OUTPUTS.length||!Number.isInteger(g[4])||![4,6].includes(g[6])||!Number.isInteger(g[5])||g[5]<1||g[5]>8||g.length!==8+(12+OUTPUTS.length)*g[1])throw Error('Not a v15 visual controller');
  if(!Array.from(g).every(Number.isFinite))throw Error('Nonfinite controller');
  const a=rigAudit(g);if(!a.ok)throw Error('Controller audit: '+a.text);return a;
}
export function mutateVision(g,rng,{count=2}={}){
  const b=unpackRig(g);if(b.kind!==KIND.STRICT_FIXED)throw Error('Evolution accepts only strict ternary controllers');
  for(let k=0;k<count;k++){
    const i=rng.int(b.N),j=3*i+rng.int(3),r=rng.next();
    if(r<.4)b.src[j]=b.role[i]===ROLE.INTERNAL?b.S+rng.int(b.N):rng.int(b.S+b.N);
    else if(r<.8)b.w[j]=[-1,0,1][rng.int(3)];
    else {const a=rng.int(b.A),old=Array.from({length:b.N},(_,v)=>v).filter(v=>b.dec[a*b.N+v]!==0),free=Array.from({length:b.N},(_,v)=>v).filter(v=>b.role[v]!==ROLE.INTERNAL&&b.dec[a*b.N+v]===0);
      if(free.length){b.dec[a*b.N+old[rng.int(old.length)]]=0;b.dec[a*b.N+free[rng.int(free.length)]]=rng.next()<.5?1:-1;}}
  }
  const out=packRig(b);validateGenome(out);return out;
}
export {rigDistance};
