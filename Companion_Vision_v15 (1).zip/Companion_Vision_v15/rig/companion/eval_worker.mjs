import {parentPort} from 'node:worker_threads';
import {loadMujoco} from '../gait/mujoco_loader.mjs';
import {CompanionSim} from './sim.mjs';
import {runEpisode} from './evaluate.mjs';
const mj=await loadMujoco();let sim=null;
parentPort.on('message',m=>{
  try{
    if(m.cmd==='evaluate'){
      const rows=m.genomes.map(a=>{const g=Float64Array.from(a);sim??=new CompanionSim(mj,{genome:g,settings:{autoRecover:false}});return m.suite.map(s=>runEpisode(sim,g,s,m.settings));});
      parentPort.postMessage({id:m.id,rows});
    }
  }catch(e){parentPort.postMessage({id:m.id,error:e.stack||e.message});}
});
parentPort.postMessage({ready:true});
