import {Rng,seedFor} from '../core/rng.mjs';
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
export const EVAL_VERSION='vision-follow-evaluation-v15.1';
export function makeSuite(seed,role='train',epoch=0,{count=2,seconds=8}={}){
  const rng=new Rng(seedFor(seed,'companion-'+role,epoch));
  return Array.from({length:count},(_,i)=>{
    const angle=(rng.next()*2-1)*(role==='hold'?.65:.45),range=1.25+rng.next()*.50;
    return {id:`${role}:${epoch}:${i}`,seed:rng.int(0xffffffff),seconds,
      target:[Math.cos(angle)*range,Math.sin(angle)*range,.32+rng.next()*.10],yaw:(rng.next()-.5)*.10,
      targetMode:i%3===0?'sway':i%3===1?'still':'lead'};
  });
}
export function runEpisode(sim,genome,scenario,settings={}){
  sim.settings={...sim.settings,...settings,mode:'learned',targetMode:scenario.targetMode||'still',eyeBlackout:!!scenario.blackout,occluder:scenario.occluder||null};
  sim.setGenome(genome);sim.setTarget(scenario.target);sim.seed=scenario.seed;sim.reset({yaw:scenario.yaw||0,random:!!scenario.random});
  let fell=false;const steps=Math.round(scenario.seconds/.02),positions=[];
  for(let i=0;i<steps;i++){
    const row=sim.step();if(i%50===0)positions.push([...sim.body.data.qpos.slice(0,2)]);
    if(row.fallen){fell=true;break;}
  }
  const M=sim.metrics,n=Math.max(1,M.steps),completed=M.steps/steps,visible=M.visible/steps,center=M.center/steps,aligned=M.bodyAligned/steps,close=M.close/steps;
  const needed=Math.max(.15,M.initialGap-sim.settings.followGap),progress=clamp((M.initialGap-M.gap)/needed,0,1),hp=sim.hp.snapshot().remainingFraction,nonfoot=sim.health.snapshot(.004).contactFraction;
  const slip=sim.slip.snapshot().maxSlipM,safe=(fell?.05:1)*clamp(1-nonfoot,0,1)*clamp(hp,0,1)**2;
  // Real range is permitted for reward/evaluation only. It is never returned by
  // makeInputs() and never substituted for rendered eye features.
  const pursuit=safe*(.48*progress+.26*close+.16*visible+.10*aligned);
  const gaze=safe*(.35*visible+.30*center+.25*progress+.10*close);
  const follow=safe*(.35*progress+.35*close+.15*center+.15*aligned);
  return {quality:pursuit,pursuit,gaze,follow,progress,close,visible,center,aligned,hp,slip,nonfoot,fell,completed,
    initialGap:M.initialGap,gap:M.gap,path:M.path,energy:M.work,seconds:sim.t,positions,
    desc:{duty:close,coordination:aligned,cadence:visible},id:scenario.id};
}
export function summarize(rows,{cfg={}}={}){
  if(!rows.length)throw Error('Empty evaluation suite');
  const mean=k=>rows.reduce((s,r)=>s+r[k],0)/rows.length;
  const quality=.7*mean('quality')+.3*Math.min(...rows.map(r=>r.quality));
  const lens=cfg.rung==='posture'?'gaze':cfg.rung==='footfalls'?'follow':'pursuit';
  const selection=.7*mean(lens)+.3*Math.min(...rows.map(r=>r[lens]));
  return {quality,selection,record:quality,guard:mean('hp'),meanQ:mean('quality'),progress:mean('progress'),visible:mean('visible'),close:mean('close'),gap:mean('gap'),hp:mean('hp'),slip:mean('slip'),falls:rows.filter(r=>r.fell).length,
    desc:{duty:mean('close'),coordination:mean('aligned'),cadence:mean('visible')},rows};
}
