import {parentPort,workerData} from 'node:worker_threads';
import {loadMujoco} from '../gait/mujoco_loader.mjs';
import {CompanionSim} from './sim.mjs';
import {describeModel} from './body.mjs';
const mj=await loadMujoco();
const sim=new CompanionSim(mj,{genome:Float64Array.from(workerData.genome),settings:{...workerData.settings,mode:'rest'}});
let running=true,rate=1,clock=0,last=performance.now(),lastFrame=0;
const frame=()=>parentPort.postMessage({frame:{...sim.snapshot({network:true}),running,rate}});
parentPort.on('message',m=>{try{
  if(m.cmd==='genome')sim.setGenome(Float64Array.from(m.genome));
  if(m.cmd==='settings')Object.assign(sim.settings,m.settings);
  if(m.cmd==='target'){sim.setTarget(m.xyz);sim.settings.targetMode='still';}
  if(m.cmd==='reset'){sim.setTarget([1.8,.1,.38]);sim.reset();}
  if(m.cmd==='run'){running=!!m.on;clock=0;}
  if(m.cmd==='rate')rate=m.rate;
  if(m.cmd==='manual'){sim.settings.mode='manual';Object.assign(sim.manual,m.values);}
  if(m.cmd==='push')sim.push={x:m.x,y:m.y,left:8};
  frame();
}catch(e){parentPort.postMessage({error:e.message});}});
parentPort.postMessage({ready:true,describe:describeModel(sim.body)});frame();
setInterval(()=>{
  const now=performance.now(),elapsed=Math.min(100,now-last);last=now;
  if(running)clock+=elapsed*rate;
  try{
    let n=0;while(clock>=20&&n++<8){const r=sim.step();clock-=20;if(r.fallen&&sim.settings.autoRecover){parentPort.postMessage({event:'The companion lost its footing and has been helped upright.'});sim.reset();clock=0;}}
    if(now-lastFrame>95){lastFrame=now;frame();}
  }catch(e){running=false;parentPort.postMessage({error:e.message});}
},10);
