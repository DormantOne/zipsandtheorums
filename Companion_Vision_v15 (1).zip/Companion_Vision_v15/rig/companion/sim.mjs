import fs from 'node:fs';
import {makeCompanionBody,STEER_LIMIT} from './body.mjs';
import {readEyes} from './vision.mjs';
import {makeVisualNetwork} from './brain.mjs';
import {makeSpinalCord} from '../gait/spinal_cord.mjs';
import {FootSlip} from '../../engine/foot_slip.mjs';
import {ContactHealth} from '../../engine/contact_health.mjs';
import {AnatomicalHitPointState,SURFACE_NAMES} from '../../engine/injury.js';
import {LEG_ORDER} from '../../engine/plant.js';
const tuned=JSON.parse(fs.readFileSync(new URL('../gait/tuned.json',import.meta.url))).params;
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
export const SIM_VERSION='companion-simulation-v15.3';
export const DEFAULT_SETTINGS={maxSpeed:.18,turnGain:.30,followGap:.85,gait:'trot',mode:'learned',targetMode:'still',eyeBlackout:false,autoRecover:true,steering:true};
export class CompanionSim{
  constructor(mj,{genome,settings={},seed=7}={}){
    this.mj=mj;this.body=makeCompanionBody(mj);this.settings={...DEFAULT_SETTINGS,...settings};this.seed=seed;
    this.cord=makeSpinalCord({params:{...tuned,...(settings.spineParams||{}),turnGait:0,turnArm:.17},descending:{speed:0,turn:0,gait:'trot',stop:true,headingHold:false}});
    this.genome=genome;this.net=genome?makeVisualNetwork(genome):null;this.manual={speed:0,turn:0,headYaw:0,headPitch:0};
    this.setTarget([1.8,.1,.38]);this.reset();
  }
  setGenome(g){this.net=makeVisualNetwork(g);this.genome=g;this.lastCommand=[0,0,0,0,0,0];}
  setTarget(xyz){if(!Array.isArray(xyz)||xyz.length<2||!xyz.every(Number.isFinite))throw Error('Target needs finite coordinates');
    this.targetBase=[clamp(xyz[0],-15,15),clamp(xyz[1],-15,15),clamp(xyz[2]??.38,.15,1.3)];this.target=[...this.targetBase];this.targetStart=this.t||0;}
  reset({yaw=0,random=false,target=null}={}){
    const {plant:p,data:d}=this.body;
    p.reset(d,random?{s:this.seed>>>0}:null);
    d.qpos[3]=Math.cos(yaw/2);d.qpos[4]=0;d.qpos[5]=0;d.qpos[6]=Math.sin(yaw/2);
    this.mj.mj_forward(p.model,d);this.cord.reset();this.net?.reset();this.t=0;this.steps=0;this.lost=0;this.headTarget=[0,0];this.lastCommand=[0,0,0,0,0,0];this.inputs=Array(24).fill(0);
    this.fallTime=0;this.falls=0;this.trail=[];this.targetStart=0;this.push=null;this.searchSign=1;
    if(target)this.setTarget(target);else this.target=[...this.targetBase];
    this.metrics={steps:0,visible:0,center:0,bodyAligned:0,progress:0,close:0,work:0,path:0,lastXY:[0,0],initialGap:null,minGap:Infinity,gap:0,fallTicks:0};
    this.slip=new FootSlip(LEG_ORDER,p.footRadius,p.footContactMargins);this.slip.prime(d,p.footSids,p.footBodies,p.footRootBodies);
    this.hp=new AnatomicalHitPointState({budget:p.run.hpBudget,strain:p.strain});this.health=new ContactHealth(SURFACE_NAMES);
    this.prevParts=new Set();this.curParts=new Set();this.intervalParts=new Set();this.prevFeet=new Float64Array(12);p.feetInto(d,this.prevFeet);
    this.updateWorld();p.contacts(d,p._scratch);this.retina=readEyes(this.body,{blackout:this.settings.eyeBlackout});
    this.initialHead=this.headPosition();this.metrics.initialGap=this.gap();this.metrics.gap=this.metrics.initialGap;
  }
  updateWorld(){
    const {data:d,plant:p,mocap,screenMocap}=this.body,s=this.settings,t=this.t-this.targetStart;
    const q=[...this.targetBase];
    if(s.targetMode==='sway'){q[1]+=.50*Math.sin(t*.15);q[0]+=.12*Math.sin(t*.09);}
    if(s.targetMode==='lead'){q[0]+=.055*t;q[1]+=.42*Math.sin(t*.22);}
    if(s.targetMode==='circle'){q[0]+=.55*(Math.cos(t*.15)-1);q[1]+=.75*Math.sin(t*.15);}
    this.target=q;d.mocap_pos.set(q,3*mocap);
    d.mocap_pos.set(s.occluder||[0,0,-5],3*screenMocap);
    this.mj.mj_kinematics(p.model,d);this.mj.mj_comPos(p.model,d);this.mj.mj_comVel(p.model,d);
  }
  headPosition(){const d=this.body.data,c=this.body.camera;return [0,1,2].map(k=>(d.cam_xpos[3*c[0]+k]+d.cam_xpos[3*c[1]+k])/2);}
  gap(){const d=this.body.data;return Math.hypot(this.target[0]-d.qpos[0],this.target[1]-d.qpos[1]);}
  makeInputs(){
    const {extra:e,data:d,plant:p}=this.body,f=this.retina.features,vis=f[4]||f[5],ny=d.qpos[e[4].q],np=d.qpos[e[5].q];
    const o=p.observation(d,p._scratch.contacts,p._scratch.obs,null);o[32]=0;o[33]=o[34]=o[35]=0;
    // The desired angular size is a task setting and pinhole-camera calibration,
    // not a range measurement. Area itself is counted from the RGB pixels.
    const opticalGap=Math.max(.30,this.settings.followGap-.45),desiredArea=clamp(Math.PI*.105**2/(4*opticalGap**2)*12,.04,.8);
    this.desiredArea=desiredArea;
    return this.inputs=[-f[0],-f[1],f[2],f[3],f[4],f[5],f[6],f[7],f[8],f[9],ny,np/.5,d.qvel[e[4].v]/4,d.qvel[e[5].v]/4,
      -Math.atan2(o[0],-o[2])/.3,Math.atan2(o[1],-o[2])/.3,o[5]*4/.5,o[7]*1.5/.25,
      clamp((desiredArea-f[7])/desiredArea,-1,1),vis?1:0,Math.min(1,this.lost/6),this.lastCommand[1]||0,1,this.lastCommand[0]||0].map(v=>clamp(Number.isFinite(v)?v:0,-1,1));
  }
  decide(){
    const s=this.settings,f=this.retina.features,vis=f[4]||f[5],dt=.02,e=this.body.extra,d=this.body.data;
    this.lost=vis?0:this.lost+dt;const inputs=this.makeInputs();let u=this.net?.control(inputs)||[0,0,0,0,0,0];
    if(s.mode==='reflex')u=[clamp(inputs[18]*2,-.76,.76),clamp(inputs[10]*1.5+inputs[0]+inputs[1],-.76,.76),clamp(inputs[0]+inputs[1]-.3*inputs[12],-.76,.76),clamp(inputs[8]+inputs[9]-.3*inputs[13],-.76,.76),0,0];
    let speed=clamp(u[0]/.762,0,1)*s.maxSpeed,turn=clamp(u[1]/.762,-1,1)*s.turnGain;
    this.headTarget[0]=clamp(this.headTarget[0]+u[2]*dt*1.7,-1,1);
    this.headTarget[1]=clamp(this.headTarget[1]+u[3]*dt*1.2,-.5,.5);
    if(!vis){
      // Explicit, built-in visual search reflex: scan and step in an arc. It
      // knows only that the retina lost red pixels; it never knows where red is.
      if(this.lost<dt*1.5)this.searchSign=Math.sign(this.lastCommand[1]||d.qpos[e[4].q]||1);
      const phase=this.lost*.9;this.headTarget[0]=.70*Math.sin(phase);this.headTarget[1]=.22;
      turn=this.lost>1.0?.30*this.searchSign:0;speed=0;
    }
    if(s.mode==='manual'){speed=this.manual.speed;turn=this.manual.turn;this.headTarget=[this.manual.headYaw,this.manual.headPitch];}
    if(s.mode==='rest'){speed=0;turn=0;this.headTarget=this.headTarget.map(v=>v*.98);}
    const moving=Math.abs(speed)>.008||Math.abs(turn)>.03;
    // The original spinal turning pattern is useful when stopped beside the
    // ball: merely changing the stroke planes then cannot rotate the body.
    // Recruit it from descending intent alone, with no world-target sensor.
    const spin=moving&&Math.abs(speed)<.065&&Math.abs(turn)>.08;
    this.cord.P.turnGait=spin?1:0;
    const spinalTurn=spin?Math.sign(turn)*clamp(.35+Math.abs(turn),.35,.65):turn;
    this.cord.set({speed,turn:spinalTurn,gait:s.gait,stop:!moving,headingHold:false,stiffness:clamp(u[4]*.10,-.1,.1),freq:clamp(u[5]*.06,-.06,.06)});
    const obs=this.body.plant._scratch.obs,muscles=this.cord.control(obs,dt);
    this.lastCommand=Array.from(u);this.descending={speed,turn,headYaw:this.headTarget[0],headPitch:this.headTarget[1]};
    // Ackermann-like orientation of each leg's stroke plane. Left/right stride
    // differential remains the spinal cord's job. Rotations are real joints,
    // driven by bounded torques, never edits to the body's world pose.
    this.steerTarget=[.24,.24,-.24,-.24].map((x,i)=>s.steering?clamp(Math.atan2(turn*x,Math.max(.055,Math.abs(speed))-turn*(i%2?-.17:.17)),-STEER_LIMIT+.015,STEER_LIMIT-.015):0);
    return muscles;
  }
  step(){
    this.updateWorld();const b=this.body,p=b.plant,d=b.data,mj=this.mj,S=p._scratch,dt=.02;
    if(this.steps%4===0)this.retina=readEyes(b,{blackout:this.settings.eyeBlackout});
    const cmd=this.decide(),M=this.metrics,tb=6*p.torsoBid;
    d.xfrc_applied.fill(0);if(this.push?.left>0){d.xfrc_applied[tb]=this.push.x*p.bodyWeight;d.xfrc_applied[tb+1]=this.push.y*p.bodyWeight;this.push.left--;}
    for(let k=0;k<p.frameSkip;k++){
      p.torquesFrom(cmd,d,S.tq);for(let j=0;j<8;j++)d.ctrl[j]=S.tq[j];
      for(let j=0;j<6;j++){const e=b.extra[j],isHead=j>=4,target=isHead?this.headTarget[j-4]:this.steerTarget[j];
        const torque=clamp((isHead?11:25)*(target-d.qpos[e.q])-(isHead?.85:1.1)*d.qvel[e.v],-5,5);d.ctrl[8+j]=torque;M.work+=Math.abs(torque*d.qvel[e.v])*p.dt;}
      mj.mj_step(p.model,d);mj.mj_kinematics(p.model,d);mj.mj_comPos(p.model,d);mj.mj_comVel(p.model,d);
      if(p.diverged(d))throw Error('Physics diverged');
      for(let j=0;j<8;j++)M.work+=Math.abs(S.tq[j]*d.qvel[p.jointQvel[j]])*p.dt;
      p.scanNonfoot(d,this.curParts);this.intervalParts.clear();for(const v of this.prevParts)this.intervalParts.add(v);for(const v of this.curParts)this.intervalParts.add(v);
      this.health.step(this.intervalParts,false);this.prevParts=new Set(this.curParts);this.slip.step(d,p.footSids,p.footBodies,p.footRootBodies,p.dt);
    }
    p.contacts(d,S);p.feetInto(d,S.feet);
    for(let f=0;f<4;f++)S.footSlip[f]=Math.hypot(S.feet[3*f]-this.prevFeet[3*f],S.feet[3*f+1]-this.prevFeet[3*f+1])/dt;this.prevFeet.set(S.feet);
    for(let j=0;j<8;j++){S.q[j]=d.qpos[p.jointQpos[j]];S.qd[j]=d.qvel[p.jointQvel[j]];S.tqn[j]=Math.abs(S.tq[j])/p.torqueLimits[j];}
    const tilt=p.tilt(d);this.hp.step({jointAngles:S.q,jointVelocities:S.qd,normalizedTorques:S.tqn,footForceBW:S.footForce,footShearBW:S.footShear,footSlipSpeed:S.footSlip,nonfootSurfaceForceBW:S.surface,tiltRadians:tilt,dt});
    const f=this.retina.features,vis=f[4]||f[5],cx=(f[0]*f[4]+f[1]*f[5])/Math.max(1,f[4]+f[5]);
    const R=d.xmat,off=9*p.torsoBid,yaw=Math.atan2(R[off+3],R[off]),bearing=Math.atan2(this.target[1]-d.qpos[1],this.target[0]-d.qpos[0]);
    const gap=this.gap(),close=Math.abs(gap-this.settings.followGap)<.28;
    M.steps++;M.visible+=vis?1:0;M.center+=vis?Math.max(0,1-Math.abs(cx)):0;M.bodyAligned+=Math.max(0,Math.cos(bearing-yaw));M.close+=close?1:0;
    M.gap=gap;M.minGap=Math.min(M.minGap,gap);M.progress+=clamp((M.lastGap??gap)-gap,-.01,.01);M.lastGap=gap;
    M.path+=Math.hypot(d.qpos[0]-M.lastXY[0],d.qpos[1]-M.lastXY[1]);M.lastXY=[d.qpos[0],d.qpos[1]];
    const fallen=tilt>1||d.qpos[2]<.24;if(fallen){M.fallTicks++;this.fallTime+=dt;}else this.fallTime=0;
    this.t+=dt;this.steps++;
    if(this.steps%5===0){this.trail.push([d.qpos[0],d.qpos[1]]);if(this.trail.length>300)this.trail.shift();}
    return {fallen:fallen&&this.fallTime>.5,gap,visible:!!vis};
  }
  snapshot({images=true,network=false}={}){
    const b=this.body,p=b.plant,d=b.data,R=d.xmat,off=9*p.torsoBid,counts=Math.max(1,this.metrics.steps),hp=this.hp.snapshot();
    return {type:'frame',t:this.t,version:SIM_VERSION,bodies:b.bodyIds.map(id=>({id,pos:Array.from(d.xpos.slice(3*id,3*id+3)),quat:Array.from(d.xquat.slice(4*id,4*id+4))})),
      target:this.target,targetBase:this.targetBase,screen:this.settings.occluder||[0,0,-5],xy:[d.qpos[0],d.qpos[1]],yaw:Math.atan2(R[off+3],R[off]),yawRate:d.qvel[5],speed:d.qvel[0]*R[off]+d.qvel[1]*R[off+3],
      head:b.extra.slice(4).map(e=>d.qpos[e.q]),steer:b.extra.slice(0,4).map(e=>d.qpos[e.q]),contacts:Array.from(p._scratch.contacts),
      ph:Array.from(this.cord.ph),stance:Array.from(this.cord.stance),trail:this.trail,commands:this.descending,inputs:this.inputs,
      vision:{features:this.retina.features,desiredArea:this.desiredArea,width:this.retina.width,height:this.retina.height,rgb:images?this.retina.rgb.map(a=>Buffer.from(a).toString('base64')):undefined,source:'RGB raycast at physical MuJoCo cameras'},
      metrics:{gap:this.metrics.gap,initialGap:this.metrics.initialGap,visible:this.metrics.visible/counts,close:this.metrics.close/counts,center:this.metrics.center/counts,progress:this.metrics.progress,path:this.metrics.path,
        hp:hp.remainingFraction,weakest:hp.weakestPart,slip:this.slip.snapshot().maxSlipM,nonfoot:this.health.snapshot(p.dt).contactFraction,falls:this.metrics.fallTicks,energy:this.metrics.work},
      mode:this.settings.mode,network:network?{brain:this.net?.activity(),spine:Array.from(this.cord.activity())}:undefined};
  }
  dispose(){this.body.dispose();}
}
