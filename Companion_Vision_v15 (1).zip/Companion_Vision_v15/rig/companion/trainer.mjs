import {Worker} from 'node:worker_threads';
import {HybridLearning,toHeir,isHeir,strictGenomeKey,assertFrozen} from '../core/hybrid.mjs';
import {rigAudit} from '../brain.mjs';
import {makeFounder,mutateVision,rigDistance,validateGenome} from './brain.mjs';
import {Rng,hash32} from '../core/rng.mjs';
import {makeSuite,summarize,EVAL_VERSION} from './evaluate.mjs';
import {BODY_VERSION} from './body.mjs';
import {SIM_VERSION} from './sim.mjs';
import {VISION_VERSION} from './vision.mjs';
export const TRAIN_DEFAULTS={N:48,seed:47017,hybridTracks:3,hybridEvoGens:8,hybridLearnSteps:180,hybridCases:2,hybridValEvery:6,hybridRotate:8,hybridSigma:.12,hybridRate:.07,hybridNurseryCap:15,hybridNurseryTrials:24,hybridLineageCap:16,trainSeconds:6,valSeconds:16,valCases:4,holdCases:8,lambda:3,hybridBias:false,joints:'muscles',friction:'firm',brainKind:4,poolMinDiff:4};
const CHECKS={body:BODY_VERSION,sim:SIM_VERSION,vision:VISION_VERSION,evaluation:EVAL_VERSION};
const CONFIG_LIMITS={N:[18,256],seed:[0,4294967295],hybridTracks:[1,6],hybridEvoGens:[1,100],hybridLearnSteps:[12,10000],hybridCases:[1,4],hybridValEvery:[1,100],hybridRotate:[1,100],hybridSigma:[.005,.8],hybridRate:[.001,.5],hybridNurseryCap:[3,48],hybridNurseryTrials:[2,200],hybridLineageCap:[8,32],trainSeconds:[2,20],valSeconds:[4,40],valCases:[2,24],holdCases:[2,24],lambda:[1,16],poolMinDiff:[0,200]};
function validateConfig(cfg){for(const [k,[lo,hi]] of Object.entries(CONFIG_LIMITS)){if(!Number.isFinite(cfg[k])||cfg[k]<lo||cfg[k]>hi)throw Error('Invalid checkpoint setting: '+k);if(!['hybridSigma','hybridRate','trainSeconds','valSeconds'].includes(k)&&!Number.isInteger(cfg[k]))throw Error('Noninteger checkpoint setting: '+k);}}
export class EvalClient{
  constructor(){this.serial=0;this.pending=new Map();this.worker=new Worker(new URL('./eval_worker.mjs',import.meta.url));
    this.ready=new Promise((resolve,reject)=>{this.worker.once('error',reject);this.resolveReady=resolve;});
    this.worker.on('message',m=>{if(m.ready){this.resolveReady();return;}const q=this.pending.get(m.id);if(!q)return;this.pending.delete(m.id);m.error?q.reject(Error(m.error)):q.resolve(m.rows);});
    this.worker.on('error',e=>{for(const q of this.pending.values())q.reject(e);this.pending.clear();});}
  async evaluate(genomes,suite,settings){await this.ready;const id=++this.serial;return new Promise((resolve,reject)=>{this.pending.set(id,{resolve,reject});this.worker.postMessage({cmd:'evaluate',id,genomes:genomes.map(g=>Array.from(g)),suite,settings});});}
  async close(){for(const q of this.pending.values())q.reject(Error('Evaluation stopped'));this.pending.clear();await this.worker.terminate();}
}
class VisualArchive{
  constructor(){this.entries=[];this.serial=0;}
  ranked(){return [...this.entries].sort((a,b)=>b.quality-a.quality);}
  best(){return this.ranked()[0]||null;}
  derivePool(){}
  tryAdd(e){
    validateGenome(e.genome);if(isHeir(e.genome))throw Error('Continuous genome cannot enter strict archive');
    const key=strictGenomeKey(e.genome);const same=this.entries.find(x=>strictGenomeKey(x.genome)===key);
    if(same){if(e.quality>same.quality){Object.assign(same,e,{id:same.id});return true;}return false;}
    // Retain actual behavioural variety, then quality, under a bounded budget.
    const cell=d=>[Math.min(3,Math.floor((d?.duty||0)*4)),Math.min(3,Math.floor((d?.coordination||0)*4)),Math.min(3,Math.floor((d?.cadence||0)*4))].join(':');
    const candidates=this.entries.filter(x=>cell(x.desc)===cell(e.desc));
    if(candidates.length>=3){const worst=candidates.sort((a,b)=>a.quality-b.quality)[0];if(worst.quality>=e.quality)return false;this.entries.splice(this.entries.indexOf(worst),1);}
    this.entries.push({...e,genome:e.genome.slice(),id:++this.serial});
    if(this.entries.length>32){const worst=this.entries.reduce((a,b)=>a.quality<b.quality?a:b);this.entries.splice(this.entries.indexOf(worst),1);}
    return true;
  }
}
export class TrainingLab{
  constructor({cfg={},settings={},onUpdate=()=>{},onBest=()=>{},evaluator=null}={}){
    this.cfg={...TRAIN_DEFAULTS,...cfg};this.seed=this.cfg.seed;this.rng=new Rng(this.seed);this.settings={...settings};this.onUpdate=onUpdate;this.onBest=onBest;
    this.evaluator=evaluator||new EvalClient();this.archive=new VisualArchive();this.generation=0;this.physicsSteps=0;this.running=false;this.busy=false;this.note='Ready to learn';this.history=[];this.logs=[];this.initialized=false;this.best=null;this.testing=false;this.holdout=null;this.stageRequest=null;this.job=null;
    this.suites={val:makeSuite(this.seed,'val',0,{count:this.cfg.valCases,seconds:this.cfg.valSeconds}),hold:makeSuite(this.seed,'hold',0,{count:this.cfg.holdCases,seconds:24})};
    this.plant={distance:rigDistance,mutate:(g,rng,o)=>mutateVision(g,rng,{count:o.count||2}),summarize,
      trainingSuite:(seed,epoch,cfg)=>makeSuite(seed,'train',epoch,{count:cfg.trainCases||2,seconds:cfg.trainSeconds||6}),
      evaluate:async(genomes,suite)=>this.evaluator.evaluate(genomes,suite,this.settings)};
    this.hybrid=new HybridLearning(this,{seed:this.seed,config:this.cfg});
  }
  log(text){this.logs.push({at:new Date().toISOString(),text});if(this.logs.length>80)this.logs.shift();this.note=text;}
  charge(rows){for(const suite of rows)for(const r of suite)this.physicsSteps+=Math.round(r.seconds/.004);}
  async score(genomes,suite){const rows=await this.plant.evaluate(genomes,suite);this.charge(rows);return rows.map(r=>summarize(r,{cfg:this.cfg}));}
  follower(){const t=[...this.hybrid.lineages].sort((a,b)=>b.bestVal.quality-a.bestVal.quality)[0];return t?{genome:t.best,score:t.bestVal,origin:'continuous learning',lineageId:t.lineageId}:null;}
  offerBest(genome,score,origin){if(!this.best||score.quality>this.best.score.quality+1e-10){this.best={genome:genome.slice(),score,origin,generation:this.generation,updates:this.hybrid.stepCount};this.onBest(this.best);return true;}return false;}
  async initialize(){
    if(this.initialized)return;
    this.note='Measuring the visual-reflex founders in MuJoCo';this.onUpdate(this.status());
    const founders=Array.from({length:4},(_,i)=>makeFounder(this.rng,{N:this.cfg.N,variant:i}));
    const scores=await this.score(founders,this.suites.val);
    for(let i=0;i<founders.length;i++){this.archive.tryAdd({genome:founders[i],quality:scores[i].quality,desc:scores[i].desc,stats:scores[i],generation:0,source:'visual-reflex seed'});this.offerBest(founders[i],scores[i],'seeded visual reflex');}
    // The same controller is then measured in full precision; conversions do
    // not count as learned improvements.
    const g=toHeir(this.archive.best().genome),[v]=await this.score([g],this.suites.val);this.offerBest(g,v,'untrained continuous seed');
    this.baseline={strict:scores[0],continuous:v};this.initialized=true;this.log('Founders measured. Starting persistent continuous learning.');
    await this.hybrid.enter({count:this.cfg.hybridTracks});this.record();
  }
  async evolve(){
    const ranked=this.archive.ranked(),genomes=[];
    for(let i=0;i<this.cfg.lambda;i++){const parent=ranked[this.rng.int(Math.min(6,ranked.length))];genomes.push(mutateVision(parent.genome,this.rng,{count:1+this.rng.int(4)}));}
    const train=makeSuite(this.seed,'train',Math.floor(this.generation/4),{count:this.cfg.hybridCases,seconds:this.cfg.trainSeconds});
    const scores=await this.score(genomes,train),order=scores.map((s,i)=>({s,i})).sort((a,b)=>b.s.quality-a.s.quality),winner=genomes[order[0].i];
    const [v]=await this.score([winner],this.suites.val);
    this.archive.tryAdd({genome:winner,quality:v.quality,desc:v.desc,stats:v,generation:this.generation,source:'evolution'});this.offerBest(winner,v,'ternary evolution');
    await this.hybrid.evolveNursery();this.generation++;
    if(this.generation-this.hybrid.startedAtGen>=this.cfg.hybridEvoGens)await this.hybrid.enter({count:this.cfg.hybridTracks});
  }
  async step(){
    if(this.hybrid.stage==='learning'){
      await this.hybrid.step();for(const t of this.hybrid.tracks)this.offerBest(t.best,t.bestVal,'continuous learning');
      if(this.hybrid.stepCount-this.hybrid.stageStart>=this.cfg.hybridLearnSteps){this.note='Projecting offspring and checking the reserved suite';this.onUpdate(this.status());await this.hybrid.leave();this.hybrid.startedAtGen=this.generation;this.log('New ternary offspring are in the nursery. Continuous parents remain alive.');}
    }else await this.evolve();
    if(this.stageRequest){const r=this.stageRequest;this.stageRequest=null;if(r==='learning'&&this.hybrid.stage!=='learning')await this.hybrid.enter({count:this.cfg.hybridTracks});if(r==='evolution'&&this.hybrid.stage==='learning'){await this.hybrid.leave();this.hybrid.startedAtGen=this.generation;}}
    this.record();this.onUpdate(this.status());
  }
  record(){const elite=this.archive.best();if(elite?.stats)this.offerBest(elite.genome,elite.stats,'ternary evolution');this.history.push({step:this.hybrid.stepCount,generation:this.generation,stage:this.hybrid.stage,best:this.best?.score.quality??0,strict:elite?.quality??0,learned:Math.max(0,...this.hybrid.lineages.map(t=>t.bestVal.quality)),born:this.hybrid.nurserySerial,promoted:this.hybrid.nurseryPromoted});if(this.history.length>1000)this.history.shift();}
  start(){
    if(this.running)return;if(this.testing)throw Error('Reserved evaluation is running');
    if(this.busy){this.running=true;return;}this.running=true;
    this.job=(async()=>{this.busy=true;try{await this.initialize();while(this.running){await this.step();await new Promise(r=>setImmediate(r));}}catch(e){this.running=false;this.log('Training stopped: '+e.message);this.error=e.stack||e.message;}finally{this.busy=false;if(!this.running&&!this.error)this.note='Learning paused';this.onUpdate(this.status());}})();
  }
  pause(){this.running=false;this.note=this.busy?'Finishing the current evaluation, then pausing':'Learning paused';}
  async test({which='learned'}={}){
    if(this.busy||this.testing)throw Error('Pause learning and let the current evaluation finish before testing');if(!this.best)throw Error('No measured controller yet');
    const e=this.archive.best(),chosen=which==='strict'&&e?{genome:e.genome}:this.follower()||this.best;
    this.testing=true;try{const [r]=await this.score([chosen.genome],this.suites.hold);this.holdout={...r,kind:which==='strict'?'ternary':'continuous',at:new Date().toISOString(),selected:false,suite:'reserved, never used for selection'};this.log('Reserved evaluation finished');return this.holdout;}finally{this.testing=false;this.onUpdate(this.status());}
  }
  status(){const f=this.follower();return {running:this.running,busy:this.busy,testing:this.testing,initialized:this.initialized,note:this.note,error:this.error||null,generation:this.generation,physicsSteps:this.physicsSteps,cfg:this.cfg,
    follower:f?{origin:f.origin,lineageId:f.lineageId,score:{...f.score,rows:undefined}}:null,
    best:this.best?{...this.best,genome:undefined,score:{...this.best.score,rows:undefined}}:null,hybrid:{...this.hybrid.status(),stageProgress:this.hybrid.stepCount-this.hybrid.stageStart},history:this.history.slice(-300),holdout:this.holdout,baseline:this.baseline?{strict:this.baseline.strict.quality,continuous:this.baseline.continuous.quality}:null,
    archive:this.archive.ranked().slice(0,12).map(e=>({id:e.id,quality:e.quality,source:e.source,desc:e.desc})),logs:this.logs.slice(-15)};}
  serialize(){return {format:'COMPANION_VISION_CHECKPOINT',version:1,checks:CHECKS,cfg:this.cfg,settings:this.settings,seed:this.seed,rng:this.rng.rngState,generation:this.generation,physicsSteps:this.physicsSteps,initialized:this.initialized,
    archive:{serial:this.archive.serial,entries:this.archive.entries.map(e=>({...e,genome:Array.from(e.genome)}))},best:this.best?{...this.best,genome:Array.from(this.best.genome)}:null,hybrid:this.hybrid.serialize(),pendingStage:this.stageRequest,history:this.history,logs:this.logs,baseline:this.baseline,holdout:this.holdout};}
  restore(x){
    if(this.busy||this.testing)throw Error('Pause and finish the current evaluation before loading a checkpoint');
    if(x?.format!=='COMPANION_VISION_CHECKPOINT'||x.version!==1||JSON.stringify(x.checks)!==JSON.stringify(CHECKS))throw Error('This checkpoint is not for this body and vision contract. Old v13/v14 whole-muscle brains cannot be attached to six spinal commands.');
    const cfg={...TRAIN_DEFAULTS,...x.cfg};validateConfig(cfg);
    if(cfg.joints!=='muscles'||cfg.friction!=='firm'||cfg.brainKind!==4)throw Error('Checkpoint uses another physical controller contract');
    if(!Number.isInteger(x.rng)||x.rng<0||x.rng>4294967295)throw Error('Invalid random-generator state');
    if(!Array.isArray(x.hybrid?.lineages)||x.hybrid.lineages.length>32||!Array.isArray(x.hybrid?.nursery)||x.hybrid.nursery.length>48)throw Error('Invalid checkpoint family size');
    const inputSettings=x.settings||{};
    for(const [k,v] of Object.entries(inputSettings)){
      const limits={maxSpeed:[.04,.24],turnGain:[.05,.6],followGap:[.72,1.5]};
      if(!limits[k]||!Number.isFinite(v)||v<limits[k][0]||v>limits[k][1])throw Error('Unsupported training task setting: '+k);
    }
    const entries=(x.archive?.entries||[]).map(e=>({...e,genome:Float64Array.from(e.genome)}));if(entries.length>32)throw Error('Checkpoint archive too large');
    for(const e of entries){validateGenome(e.genome);if(isHeir(e.genome)||!Number.isFinite(e.quality))throw Error('Invalid strict archive');}
    const best=x.best?{...x.best,genome:Float64Array.from(x.best.genome)}:null;if(best){validateGenome(best.genome);if(!Number.isFinite(best.score?.quality))throw Error('Invalid checkpoint score');}
    // Validate the full hybrid state in a temporary run before any mutation.
    const tempRun={cfg,seed:x.seed},temp=new HybridLearning(tempRun,{seed:x.seed,config:cfg});temp.restore(x.hybrid);
    for(const t of temp.lineages){validateGenome(t.source);validateGenome(t.best);validateGenome(t.genome);if(!assertFrozen(t.source,t.best))throw Error('Invalid lineage');}
    this.cfg=cfg;this.seed=x.seed;this.rng=new Rng(x.rng);this.rng.rngState=x.rng>>>0;this.generation=x.generation||0;this.physicsSteps=x.physicsSteps||0;this.initialized=!!x.initialized;this.stageRequest=['learning','evolution'].includes(x.pendingStage)?x.pendingStage:null;
    this.settings={...this.settings,...x.settings};this.archive.entries=entries;this.archive.serial=x.archive.serial;this.best=best;this.hybrid=new HybridLearning(this,{seed:this.seed,config:this.cfg});this.hybrid.restore(x.hybrid);
    this.history=x.history||[];this.logs=x.logs||[];this.baseline=x.baseline;this.holdout=x.holdout;
    this.suites={val:makeSuite(this.seed,'val',0,{count:cfg.valCases,seconds:cfg.valSeconds}),hold:makeSuite(this.seed,'hold',0,{count:cfg.holdCases,seconds:24})};
    if(best)this.onBest(best);this.log('Learning checkpoint restored');this.onUpdate(this.status());
  }
  async close(){this.pause();await this.job;await this.evaluator.close();}
}
