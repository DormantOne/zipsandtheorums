/* Portable RGB retina. Rays start at MuJoCo's actual articulated eye cameras
 * and intersect the compiled MuJoCo geoms. No target coordinate, geom id or
 * geometric bearing is returned to the controller: only these pixels and
 * QuadMind's deterministic red-pixel features. Occluders win the depth test.
 * This is a CPU renderer, not an OpenGL/MuJoCo framebuffer. It is deliberately
 * identical in headless training and the live viewer (no GPU dependency).
 */
export const WIDTH=64,HEIGHT=48,VISION_VERSION='physical-binocular-rgb-v15.1';
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const dirs=Array.from({length:WIDTH*HEIGHT},(_,i)=>[(2*(i%WIDTH+.5)/WIDTH-1)*WIDTH/HEIGHT,1-2*(Math.floor(i/WIDTH)+.5)/HEIGHT,-1]);
const INF=1e10;
function sphere(ox,oy,oz,dx,dy,dz,r){
  const a=dx*dx+dy*dy+dz*dz,b=ox*dx+oy*dy+oz*dz,c=ox*ox+oy*oy+oz*oz-r*r,h=b*b-a*c;
  if(h<0)return INF;const s=Math.sqrt(h),t=(-b-s)/a;return t>.002?t:(-b+s)/a>.002?(-b+s)/a:INF;
}
function intersect(g,dx,dy,dz){
  const [ox,oy,oz]=g.o,s=g.s;
  if(g.type===2)return sphere(ox,oy,oz,dx,dy,dz,s[0]);
  if(g.type===4)return sphere(ox/s[0],oy/s[1],oz/s[2],dx/s[0],dy/s[1],dz/s[2],1);
  if(g.type===6){
    let lo=-INF,hi=INF;
    for(let i=0;i<3;i++){const o=g.o[i],d=i===0?dx:i===1?dy:dz;if(Math.abs(d)<1e-10){if(Math.abs(o)>s[i])return INF;continue}
      let a=(-s[i]-o)/d,b=(s[i]-o)/d;if(a>b)[a,b]=[b,a];lo=Math.max(lo,a);hi=Math.min(hi,b);if(lo>hi)return INF;}
    return lo>.002?lo:hi>.002?hi:INF;
  }
  if(g.type===3||g.type===5){
    const a=dx*dx+dy*dy,b=ox*dx+oy*dy,c=ox*ox+oy*oy-s[0]*s[0],h=b*b-a*c;let t=INF;
    if(a>1e-12&&h>=0){for(const v of [(-b-Math.sqrt(h))/a,(-b+Math.sqrt(h))/a])if(v>.002&&Math.abs(oz+v*dz)<=s[1])t=Math.min(t,v);}
    if(g.type===3)t=Math.min(t,sphere(ox,oy,oz-s[1],dx,dy,dz,s[0]),sphere(ox,oy,oz+s[1],dx,dy,dz,s[0]));
    else if(Math.abs(dz)>1e-10)for(const z of [-s[1],s[1]]){const v=(z-oz)/dz;if(v>.002&&(ox+dx*v)**2+(oy+dy*v)**2<=s[0]**2)t=Math.min(t,v);}
    return t;
  }
  return INF;
}
export function renderEye(body,cam,{blackout=false}={}){
  const out=new Uint8Array(WIDTH*HEIGHT*3);if(blackout)return out;
  const {plant:p,data:d}=body,m=p.model,cp=Array.from(d.cam_xpos.slice(3*cam,3*cam+3)),C=d.cam_xmat.slice(9*cam,9*cam+9),geoms=[];
  for(let g=0;g<m.ngeom;g++){
    const type=m.geom_type[g];if(type===0)continue;
    const G=d.geom_xmat.slice(9*g,9*g+9),off=[cp[0]-d.geom_xpos[3*g],cp[1]-d.geom_xpos[3*g+1],cp[2]-d.geom_xpos[3*g+2]];
    const o=[0,1,2].map(i=>G[i]*off[0]+G[i+3]*off[1]+G[i+6]*off[2]),R=[];
    for(let a=0;a<3;a++)for(let b=0;b<3;b++)R.push(G[a]*C[b]+G[a+3]*C[b+3]+G[a+6]*C[b+6]);
    // Geoms entirely behind the camera cannot intersect a forward ray.
    const dist=Math.hypot(...off),bound=Math.hypot(...m.geom_size.slice(3*g,3*g+3));
    const forward=-(off[0]*C[2]+off[1]*C[5]+off[2]*C[8]);
    if(forward>bound+.003)continue;
    geoms.push({type,o,R,s:m.geom_size.slice(3*g,3*g+3),color:m.geom_rgba.slice(4*g,4*g+3),dist});
  }
  for(let i=0;i<dirs.length;i++){
    const [x,y,z]=dirs[i],dx=C[0]*x+C[1]*y+C[2]*z,dy=C[3]*x+C[4]*y+C[5]*z,dz=C[6]*x+C[7]*y+C[8]*z;
    let best=INF,r=139,g=178,b=186;
    if(dz<-.00001){const t=-cp[2]/dz;if(t>.002){best=t;const wx=cp[0]+dx*t,wy=cp[1]+dy*t;
      const grid=(Math.abs(wx-Math.round(wx))<.012||Math.abs(wy-Math.round(wy))<.012),checker=(Math.floor(wx)+Math.floor(wy))%2===0;
      r=grid?139:checker?198:192;g=grid?153:checker?207:201;b=grid?139:checker?178:174;}}
    for(const geom of geoms){const R=geom.R,t=intersect(geom,R[0]*x+R[1]*y+R[2]*z,R[3]*x+R[4]*y+R[5]*z,R[6]*x+R[7]*y+R[8]*z);
      if(t<best){best=t;const shade=.84+.16/(1+.08*t);r=255*geom.color[0]*shade;g=255*geom.color[1]*shade;b=255*geom.color[2]*shade;}}
    out[3*i]=r;out[3*i+1]=g;out[3*i+2]=b;
  }
  return out;
}
export function extract(rgb){
  if(rgb.length!==WIDTH*HEIGHT*3)throw Error('Retina RGB dimensions mismatch');
  let n=0,x=0,y=0;
  for(let i=0;i<WIDTH*HEIGHT;i++){const r=rgb[3*i];if(r>125&&r>1.7*rgb[3*i+1]&&r>1.7*rgb[3*i+2]){n++;x+=i%WIDTH;y+=Math.floor(i/WIDTH);}}
  return n?[clamp((x/n-(WIDTH-1)/2)/((WIDTH-1)/2),-1,1),clamp(n/(WIDTH*HEIGHT)*12,0,1),1,clamp((y/n-(HEIGHT-1)/2)/((HEIGHT-1)/2),-1,1)]:[0,0,0,0];
}
export function readEyes(body,options={}){
  body.plant.mj.mj_camlight(body.plant.model,body.data);
  const rgb=body.camera.map(c=>renderEye(body,c,options)),a=extract(rgb[0]),b=extract(rgb[1]);
  const features=[a[0],b[0],a[1],b[1],a[2],b[2],a[2]&&b[2]?clamp(a[0]-b[0],-1,1):0,(a[1]+b[1])/2,a[3],b[3]];
  return {rgb,features,width:WIDTH,height:HEIGHT};
}
