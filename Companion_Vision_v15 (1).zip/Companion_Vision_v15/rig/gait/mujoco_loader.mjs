/* rig/gait/mujoco_loader.mjs — MuJoCo WASM loading, as rig/plants/walker_worker.mjs
 * does it (the vendored engine/vendor/mujoco.wasm first), without that module's
 * worker message handler, so gait threads can load the same physics. */
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..','..');
let mujoco=null;
export async function loadMujoco(){
  if(mujoco)return mujoco;
  const mod=await import('@mujoco/mujoco'),load=mod.default||mod,require=createRequire(import.meta.url);
  let opts={};
  try{const entry=require.resolve('@mujoco/mujoco'),dir=path.dirname(entry),localWasm=path.join(ROOT,'engine','vendor','mujoco.wasm');
    opts={locateFile:p=>(String(p).endsWith('.wasm')&&fs.existsSync(localWasm))?localWasm:path.join(dir,p)}}catch{}
  try{mujoco=await load(opts)}catch(e){mujoco=await load()}
  return mujoco;
}
