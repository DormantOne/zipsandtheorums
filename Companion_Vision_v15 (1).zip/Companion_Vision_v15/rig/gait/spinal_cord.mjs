/* rig/gait/spinal_cord.mjs — a hand-made spinal locomotor network for the MuJoCo walker.
 *
 * The body, its muscles and its sensors are engine/plant.js, untouched. This
 * controller is a function from the plant's 36 public sensors to its 16 muscle
 * commands, called every 20 ms control step, exactly like every evolved brain.
 * It never reads MuJoCo state, never writes forces, and never touches the
 * plant's measurement. Everything below is fixed wiring; the only way to change
 * what it does is through its DESCENDING inputs and MODULATION ports (the
 * "higher brain" interface), which is what a cortex, a brainstem or an evolved
 * network would drive.
 *
 * LAYERS (biological names; see the connectome in describe()):
 *   descending   MLR speed drive, reticulospinal turn L/R, vestibulospinal height,
 *                gait selectors (walk, trot, pace, bound, pronk), stop, heading hold
 *   rhythm       one phase oscillator per limb (the phase-reduced form of a
 *                flexor/extensor half-centre pair), Kuramoto-coupled
 *   coupling     commissural (V0 alternation / V3 synchrony) and long propriospinal
 *                interneurons: the gait's inter-limb phase relationships
 *   pattern      per limb: foot path in a gravity-levelled hip frame — velocity-
 *                matched stance, retracting swing, then leg inverse kinematics
 *   reflexes     touchdown ends swing (load afferent), support gates lift-off,
 *                vestibulospinal pitch/roll correction, Raibert foot placement
 *   motor        motoneuron pools: an exact inversion of the plant's muscle model
 *                (target angle + co-contraction -> flexor/extensor commands), with
 *                feedforward lead for the muscle's damping lag and the hip spring.
 */
import {PLANT,neutralFromConfig,rangesFromConfig} from '../../engine/plant.js';

export const SPINAL_VERSION='spinal-cord-v1';
const TAU=2*Math.PI;
const clamp=(x,a,b)=>x<a?a:x>b?b:x;
const num=(v,d=0)=>Number.isFinite(Number(v))?Number(v):d;
export const LEGS=['FL','FR','RL','RR'];
const LEG_SCALE=.72;   // rig/plants/walker.mjs WALKER_PHYSICS.legScale

/* The body as the plant builds it (rig scale), so the network's internal model
 * of its own legs is the real one. */
export function bodyModel(cfg={}){
  const c={...PLANT,thighLength:PLANT.thighLength*LEG_SCALE,shinLength:PLANT.shinLength*LEG_SCALE,...cfg};
  const rest=neutralFromConfig(c),R=rangesFromConfig(c);
  return Object.freeze({L1:c.thighLength,L2:c.shinLength,hipX:c.hipSpanX/2,hipY:c.hipSpanY/2,hipZ:c.hipZOffset,footR:c.footRadius,
    restHip:rest[0],restKnee:rest[1],hipLo:R[0][0],hipHi:R[0][1],kneeLo:R[1][0],kneeHi:R[1][1],
    hipSpan:(R[0][1]-R[0][0])*.25,kneeSpan:(R[1][1]-R[1][0])*.25,kp:55,kd:5,hipSpring:c.hipStiffness,hipSpringRef:c.hipSpringRef});
}
export const BODY=bodyModel();
const HX=[BODY.hipX,BODY.hipX,-BODY.hipX,-BODY.hipX],HY=[BODY.hipY,-BODY.hipY,BODY.hipY,-BODY.hipY];
const RIGHT=[-1,1,-1,1];   // +1 for right legs: a left turn speeds the right side

/* Gaits as an animal's gait diagram: per-limb phase lag (cycles, FL = 0), duty
 * factor, base step frequency and its rise with speed. Offsets are written so
 * that blending neighbours linearly passes through sensible intermediates
 * (trot -> walk -> pace; the lateral-sequence walk sits exactly between them). */
export const GAITS=Object.freeze({
  walk: {label:'walk (lateral sequence)',off:[0,.5,.75,.25],duty:.72,f0:.95,fv:1.2,lift:1,support:3},
  trot: {label:'trot',off:[0,.5,.5,0],duty:.56,f0:1.35,fv:1.6,lift:1,support:2},
  pace: {label:'pace',off:[0,.5,1,.5],duty:.56,f0:1.35,fv:1.6,lift:1,support:2},
  bound:{label:'bound',off:[0,0,.5,.5],duty:.5,f0:1.6,fv:1.4,lift:1,support:2},
  pronk:{label:'pronk',off:[0,0,0,0],duty:.55,f0:1.6,fv:1,lift:.8,support:0},
});
export const GAIT_NAMES=Object.keys(GAITS);
/* The turning pattern. Not a gait you select: the reticulospinal turn neurons
 * recruit it as the turn command rises from turnOn to turnFull (a smooth step),
 * reconfiguring the commissural coupling, duty and rhythm; a right turn uses its
 * mirror image. This body has no hip abduction, so it can turn only by skidding:
 * a trot or pace barely yaws however hard its sides push, and a half-recruited
 * pattern is neither gait. So the recruitment is steep, and while turning the
 * forward speed is held to turnVmax, as animals slow to turn sharply.
 * Calibrated separately (rig/gait/tuned.json "spin"). */
export const SPIN=Object.freeze({label:'turning pattern',off:[0,.5,1,.5],duty:.5,f0:1.6,fv:0,lift:1,support:2});

export const DEFAULT_PARAMS=Object.freeze({
  standHeight:.321,     // hip-to-foot-centre height in the levelled frame (m)
  crouchDrop:.022,      // height lost at full crouch (m): the muscles' knee span allows ~2.4 cm
  x0:-.004,             // neutral foot position fore-aft of the hip (m)
  lift:.022,            // swing clearance asked of the pattern (m)
  liftSkew:.75,         // <1 lifts early, lands gently
  stepMax:.11,          // longest step (m)
  Kc:4,                 // inter-limb coupling (1/s)
  leadT:.085,           // feedforward lead, the muscle's kd/kp damping lag (s)
  springComp:1,         // cancel the hip's passive spring (fraction)
  Ast:1.35,Asw:1,Aland:1.25,   // co-contraction: stance, swing, pre-landing
  pitchKp:0,pitchKd:0,rollKp:0,rollKd:0,  // vestibulospinal gains (geometric units, s)
  postureMax:.018,      // largest vestibulospinal leg-length correction (m)
  raibertK:0,         // foot placement per m/s of speed error (s)
  turnArm:.24,          // m of differential stance speed per rad/s of turn
  tdReset:.55,          // swing progress after which ground contact ends the swing
  holdMax:.12,          // longest lift-off delay while support is missing (s)
  headingK:1.5,         // heading hold (rad/s per rad)
  spread:0,             // fore feet forward and hind feet back by this much (m): a wider, lower base
  turnGait:0,           // 1: a hard turn recruits the turning pattern; 0: never (stride differential only)
  turnOn:.1,            // the turn command where recruitment starts
  turnFull:.35,         // ... and where it is complete
  turnVmax:.06,         // forward speed allowed while turning with the full pattern (m/s)
  turnMin:.45,          // with the turning pattern, the turn effort starts here (the feet's friction breakaway) ...
  turnSat:.6,           // ... and saturates here (harder pushing only skids and stumbles)
  crouchVmax:.1,        // speed allowed from half crouch down (m/s): a crouched animal stalks
  kneeSlew:0,           // knee target slew limit (rad/s; 0 = off)
  cr:null,              // constants' shift at full crouch, e.g. {"flexEnd":.1,"f0":-.2,"duty":.05}
  spin:null,            // calibrated turning pattern: {off,duty,f0,fv,lift,support,p:{constant overrides}}
  cmdTau:.35,           // descending command smoothing (s)
  gaitTau:.6,           // gait-selector smoothing (s)
  ampTau:.25,           // rhythm amplitude onset/offset (s)
  levelFrame:0,         // 1 = foot paths in the gravity-levelled frame (needs clean tilt sensing)
  sagComp:0,            // stance knee pre-extension against load sag (rad)
  preSwing:0,           // fraction of stance at its end where the knee burst begins
  retract:1,            // swing-leg retraction at lift-off and touchdown (1 = ground-speed matched)
  flexEnd:.5,           // swing progress where the knee burst ends
  flexOver:0,           // extra knee flexion asked beyond the lift (rad)
  kneeOver:.1,          // knee extension overdrive for landing (rad)
  kneeTau:.1,           // the knee's response time in the efference copy (s)
  pitchBias:0,          // standing nose-up attitude (rad): front legs longer, more front clearance
});

// ── leg geometry ─────────────────────────────────────────────────────────────
const L1=BODY.L1,L2=BODY.L2;
export function legFK(h,k){return [-L1*Math.sin(h)-L2*Math.sin(h+k),-L1*Math.cos(h)-L2*Math.cos(h+k)]}
const KNEE_REACH_MAX=BODY.restKnee+BODY.kneeSpan;   // furthest flexion a muscle target can ask for
/* inverse kinematics in the body frame, foot centre relative to the hip.
 * The knee is clamped to what the muscles can reach and the hip keeps the
 * leg's angle, so a foot that cannot be lifted further stays at the right x. */
export function legIK(x,z,out,o=0){
  const d=Math.min(Math.hypot(x,z),L1+L2-1e-5);
  const ck=clamp((d*d-L1*L1-L2*L2)/(2*L1*L2),-1,1);let k=Math.acos(ck);
  k=clamp(k,BODY.kneeLo+.01,KNEE_REACH_MAX+.02);
  const a=Math.atan2(-x,-z),b=Math.atan2(L2*Math.sin(k),L1+L2*Math.cos(k));
  out[o]=a-b;out[o+1]=k;return out;
}
/* the hip angle that puts the foot at x (fore-aft of the hip) with the knee at k */
export function hipFor(x,k){const d=Math.sqrt(L1*L1+L2*L2+2*L1*L2*Math.cos(k)),a=Math.asin(clamp(-x/d,-.95,.95)),b=Math.atan2(L2*Math.sin(k),L1+L2*Math.cos(k));return a-b}
/* the plant's muscle model, inverted: a joint target and a co-contraction level
 * A (0..2, 1 = both muscles at half tone) -> the plus and minus commands */
export function muscleCommands(q,j,A,out){
  const knee=j&1,rest=knee?BODY.restKnee:BODY.restHip,span=knee?BODY.kneeSpan:BODY.hipSpan;
  const lo=(knee?BODY.kneeLo:BODY.hipLo)+.02,hi=(knee?BODY.kneeHi:BODY.hipHi)-.02;
  const u=clamp((clamp(q,lo,hi)-rest)/span,-1,1),a=clamp(A,0,2/(1+Math.abs(u)));
  out[j]=a*(1+u)-1;out[8+j]=a*(1-u)-1;return out;
}
const hermite=(s,a,b,m0,m1)=>{const s2=s*s,s3=s2*s;return (2*s3-3*s2+1)*a+(s3-2*s2+s)*m0+(-2*s3+3*s2)*b+(s3-s2)*m1};
const hermiteD=(s,a,b,m0,m1)=>{const s2=s*s;return (6*s2-6*s)*a+(3*s2-4*s+1)*m0+(-6*s2+6*s)*b+(3*s2-2*s)*m1};


// ── the connectome: every node is a signal in control(), every edge a real pathway ──
const GROUPS=Object.freeze({desc:'descending (brainstem / higher-brain input)',sense:'sensory afferents',rg:'rhythm generator half-centres',cin:'commissural & propriospinal interneurons',
  pf:'pattern formation (synergies)',mn:'motoneuron pools (the 16 muscles)',eff:'efference copy (internal model)',rfx:'reflex interneurons'});
const MODULE_XY=[[.215,.345],[.785,.345],[.215,.735],[.785,.735]];   // FL FR RL RR, seen from above, head up
const MOD_W=.33,MOD_H=.31;
export function buildNetwork(){
  const nodes=[],edges=[],ix=new Map();
  const node=(id,label,group,x,y,extra={})=>{ix.set(id,nodes.length);nodes.push({id,label,group,x,y,...extra})};
  const edge=(a,b,w,kind,label)=>edges.push({from:a,to:b,w,kind,label});
  // descending row
  const D=[['gait:walk','walk','walk selector'],['gait:trot','trot','trot selector'],['gait:pace','pace','pace selector'],['gait:bound','bound','bound selector'],['gait:pronk','pronk','pronk selector'],
    ['mlr','MLR speed','MLR locomotor drive (speed)'],['stop','stop','stop / stand'],['turnL','turn L','reticulospinal turn left'],['turnR','turn R','reticulospinal turn right'],
    ['crouch','crouch','vestibulospinal height (crouch)'],['tone','tone','tone (co-contraction)'],['head','heading','heading hold']];
  D.forEach(([id,short,l],k)=>node(id,l,'desc',.05+k*(.90/(D.length-1)),.07,{port:true,short}));
  // global senses and reflexes (centre column)
  node('s:pitch','vestibular pitch','sense',.455,.20,{short:'pitch'});node('s:roll','vestibular roll','sense',.545,.20,{short:'roll'});
  node('r:vsr','vestibulospinal reflex','rfx',.5,.265,{short:'VSR'});
  node('s:flow','forward velocity','sense',.455,.885,{short:'velocity'});node('s:yaw','heading (yaw)','sense',.545,.885,{short:'yaw'});
  node('r:place','foot placement (Raibert)','rfx',.5,.82,{short:'placement'});
  // limb modules ("superneurons": few inputs, few outputs, internal computation)
  LEGS.forEach((L,i)=>{const [cx,cy]=MODULE_XY[i],sx=i%2?1:-1,sy=i<2?-1:1;
    const at=(dx,dy)=>[cx+dx*sx,cy+dy*sy];
    const put=(id,label,group,dx,dy,extra={})=>{const [x,y]=at(dx,dy);node(id,label,group,x,y,{limb:i,...extra})};
    put('rg:F:'+L,`${L} flexor half-centre`,'rg',-.032,0,{short:'F'});put('rg:E:'+L,`${L} extensor half-centre`,'rg',.032,0,{short:'E'});
    put('pf:lift:'+L,`${L} knee flexion burst`,'pf',-.07,-.07,{short:'lift'});put('pf:prot:'+L,`${L} hip protraction`,'pf',-.08,.06,{short:'protract'});
    put('pf:push:'+L,`${L} hip retraction (push)`,'pf',.08,.06,{short:'push'});put('pf:sup:'+L,`${L} knee support`,'pf',.07,-.07,{short:'support'});
    put('mn:k+:'+L,`${L} knee flexor muscle`,'mn',-.13,-.10,{muscle:2*i+1,short:'knee flex'});put('mn:h-:'+L,`${L} hip protractor muscle`,'mn',-.135,.085,{muscle:8+2*i,short:'hip flex'});
    put('mn:h+:'+L,`${L} hip retractor muscle`,'mn',.135,.085,{muscle:2*i,short:'hip ext'});put('mn:k-:'+L,`${L} knee extensor muscle`,'mn',.13,-.10,{muscle:8+2*i+1,short:'knee ext'});
    put('eff:'+L,`${L} knee efference copy`,'eff',-.035,.115,{short:'eff. copy'});
    put('r:td:'+L,`${L} touchdown interneuron`,'rfx',.035,.115,{short:'touchdown'});put('r:gate:'+L,`${L} lift-off gate (support)`,'rfx',0,-.075,{short:'gate'});
    put('s:load:'+L,`${L} load afferent (foot contact)`,'sense',.0,.14,{short:'load'});
  });
  // commissural (left-right), long propriospinal (fore-hind) and diagonal interneurons
  const PAIRS=[[0,1,'V0/V3 fore commissural','fore CIN'],[2,3,'V0/V3 hind commissural','hind CIN'],[0,2,'LPN left fore-hind','left LPN'],[1,3,'LPN right fore-hind','right LPN'],[0,3,'diagonal LPN FL-RR','FL-RR'],[1,2,'diagonal LPN FR-RL','FR-RL']];
  const PXY=[[.5,.345],[.5,.735],[.215,.54],[.785,.54],[.465,.54],[.535,.54]];
  PAIRS.forEach(([a,b,l,short],k)=>{const id=`cin:${LEGS[a]}${LEGS[b]}`;node(id,l,'cin',PXY[k][0],PXY[k][1],{pair:[a,b],short});
    edge('rg:F:'+LEGS[a],id,1,'phase');edge(id,'rg:F:'+LEGS[b],1,'phase');edge('rg:F:'+LEGS[b],id,1,'phase');edge(id,'rg:F:'+LEGS[a],1,'phase');
    for(const g of GAIT_NAMES)edge('gait:'+g,id,.4,'mod','gates phase bias')});
  // wiring per limb
  LEGS.forEach((L,i)=>{const right=RIGHT[i]>0;
    edge('mlr','rg:F:'+L,.6,'mod','frequency');edge('mlr','rg:E:'+L,.6,'mod','frequency');edge('mlr','pf:push:'+L,.8,'exc','stride');edge('mlr','pf:prot:'+L,.6,'exc','stride');
    edge('stop','rg:F:'+L,-.8,'inh','rhythm amplitude');
    edge('turnL','pf:push:'+L,right?.7:-.7,right?'exc':'inh','differential stride');edge('turnR','pf:push:'+L,right?-.7:.7,right?'inh':'exc','differential stride');
    edge('crouch','pf:sup:'+L,-.7,'inh','leg length');edge('tone','mn:k-:'+L,.4,'mod');edge('tone','mn:h+:'+L,.4,'mod');
    edge('rg:F:'+L,'rg:E:'+L,-1,'inh','half-centre inhibition');edge('rg:E:'+L,'rg:F:'+L,-1,'inh','half-centre inhibition');
    edge('rg:F:'+L,'pf:lift:'+L,1,'exc');edge('rg:F:'+L,'pf:prot:'+L,1,'exc');edge('rg:E:'+L,'pf:push:'+L,1,'exc');edge('rg:E:'+L,'pf:sup:'+L,1,'exc');
    edge('pf:lift:'+L,'mn:k+:'+L,1,'exc');edge('pf:lift:'+L,'mn:k-:'+L,-.8,'inh');edge('pf:sup:'+L,'mn:k-:'+L,1,'exc');edge('pf:sup:'+L,'mn:k+:'+L,-.5,'inh');
    edge('pf:prot:'+L,'mn:h-:'+L,1,'exc');edge('pf:prot:'+L,'mn:h+:'+L,-.6,'inh');edge('pf:push:'+L,'mn:h+:'+L,1,'exc');edge('pf:push:'+L,'mn:h-:'+L,-.6,'inh');
    edge('mn:k+:'+L,'eff:'+L,.8,'exc','efference copy');edge('mn:k-:'+L,'eff:'+L,-.8,'inh','efference copy');edge('eff:'+L,'pf:prot:'+L,.6,'mod','hip keeps the foot on its path');
    edge('s:load:'+L,'r:td:'+L,1,'exc','touchdown');edge('r:td:'+L,'rg:E:'+L,1,'exc','ends swing');edge('r:td:'+L,'rg:F:'+L,-1,'inh','ends swing');
    LEGS.forEach((M,j)=>{if(j!==i)edge('s:load:'+M,'r:gate:'+L,-.5,'inh','support present')});edge('r:gate:'+L,'rg:F:'+L,-1,'inh','delays lift-off');
    edge('r:vsr','pf:sup:'+L,.6,'mod','posture');edge('r:place','pf:prot:'+L,.5,'mod','touchdown placement');
  });
  edge('s:pitch','r:vsr',1,'exc');edge('s:roll','r:vsr',1,'exc');edge('s:flow','r:place',1,'exc');edge('s:yaw','head',1,'exc');edge('head','turnL',.6,'exc','heading error');edge('head','turnR',.6,'exc','heading error');
  return {nodes,edges,ix,groups:GROUPS,modules:LEGS.map((L,i)=>({id:L,label:`${L} limb module`,x:MODULE_XY[i][0],y:MODULE_XY[i][1],w:MOD_W,h:MOD_H}))};
}
export const NETWORK=buildNetwork();
const CIN_OF=[0,1,2,3].map(i=>[0,1,2,3].map(j=>{const a=Math.min(i,j),b=Math.max(i,j);return `cin:${LEGS[a]}${LEGS[b]}`}));

// ── the network ──────────────────────────────────────────────────────────────
export function makeSpinalCord({params={},descending={}}={}){
  const P={...DEFAULT_PARAMS,...params};
  // descending inputs (what a higher brain sets) and their smoothed versions
  const D={speed:0,turn:0,crouch:0,gait:'trot',pitch:0,stop:false,headingHold:true,stiffness:0,stepHeight:0,freq:0,autoGait:false,...descending};
  const Ds={speed:0,turn:0,crouch:0,pitch:0,stiffness:0,stepHeight:0,freq:0};
  const gw=Object.fromEntries(GAIT_NAMES.map(g=>[g,g===D.gait?1:0]));   // gait-selector activities
  const inj=new Map();   // modulation ports: node id -> additive input
  // limb state
  const ph=new Float64Array(4),stance=new Uint8Array(4),air=new Uint8Array(4),hold=new Float64Array(4);
  const fx=new Float64Array(4),xLift=new Float64Array(4),xLand=new Float64Array(4),xTD=new Float64Array(4);
  const lastKt=new Float64Array(4).fill(NaN),vLeg=new Float64Array(4),lenLeg=new Float64Array(4),hLift=new Float64Array(4),kEst=new Float64Array(4).fill(BODY.restKnee),lastC=new Uint8Array(4),tdq=new Float64Array(8),liftq=new Float64Array(8);
  const q=new Float64Array(8),qn=new Float64Array(8),qt=new Float64Array(8),A=new Float64Array(8),out=new Float64Array(16);
  // filtered senses
  const F={pitch:0,roll:0,pitchRate:0,rollRate:0,yaw:0,yawRef:null,v:0,ok:false,yawRate:0,pitchI:0,rollI:0,vI:0,yawI:0};
  let amp=0,ampV=0,t=0,events=[];
  const act={};   // summary signals
  const NI=NETWORK.ix,actv=new Float32Array(NETWORK.nodes.length),tdPulse=new Float64Array(4),hcorr={v:0};
  const setA=(id,v)=>{const k=NI.get(id);if(k!==undefined)actv[k]=Number.isFinite(v)?clamp(v,-1,1):0};
  const GT=Object.fromEntries(GAIT_NAMES.map(g=>{const o=P.gaits?.[g]||{};return [g,{...GAITS[g],...o,p:{...(GAITS[g].p||{}),...(o.p||{})},pv:{...(GAITS[g].pv||{}),...(o.pv||{})}}]}));
  const SP={...SPIN,...(P.spin||{}),p:{...(P.spin?.p||{})}};
  /* turning right is the mirror image of turning left: the commissural pattern swaps sides (FL<->FR, HL<->HR) */
  const SPR=(()=>{const o=SP.off,m=[o[1],o[0],o[3],o[2]];return m.map(x=>x-m[0])})();
  /* speed calibration: each gait may carry a measured table [[body speed, stride speed], ...]
   * so that the speed asked of the cord is the speed the body actually makes */
  const interp=(tab,u)=>{if(!tab||tab.length<2)return u;const sg=Math.sign(u)||1,a=Math.abs(u);if(a<=tab[0][0])return sg*a*tab[0][1]/Math.max(1e-6,tab[0][0]);
    for(let k=1;k<tab.length;k++)if(a<=tab[k][0]){const [x0,y0]=tab[k-1],[x1,y1]=tab[k];return sg*(y0+(y1-y0)*(a-x0)/Math.max(1e-9,x1-x0))}const [x0,y0]=tab[tab.length-2],[x1,y1]=tab[tab.length-1];return sg*(y1+(y1-y0)*(a-x1)/Math.max(1e-9,x1-x0))};
  const strideFor=(w,u)=>{let v=0,ws=0;for(const g of GAIT_NAMES){const x=w[g];if(!x)continue;v+=x*interp(u<0?GT[g].vcalBack||GT[g].vcal:GT[g].vcal,u);ws+=x}return ws?v/ws:u};
  const blend=(spinW=0,crouch=0,speed=0,dir=1)=>{let s=0;for(const g of GAIT_NAMES)s+=gw[g];const w={};for(const g of GAIT_NAMES)w[g]=gw[g]/(s||1);
    const o=[0,0,0,0];let duty=0,f0=0,fv=0,lift=0,sup=0;
    for(const g of GAIT_NAMES){const G=GT[g],k=w[g];if(!k)continue;for(let i=0;i<4;i++)o[i]+=k*G.off[i];duty+=k*(G.duty+(G.dutyV||0)*speed);f0+=k*G.f0;fv+=k*G.fv;lift+=k*G.lift;sup+=k*G.support}
    if(spinW>0){const a=1-spinW,so=dir<0?SPR:SP.off;for(let i=0;i<4;i++)o[i]=a*o[i]+spinW*so[i];duty=a*duty+spinW*SP.duty;f0=a*f0+spinW*SP.f0;fv=a*fv+spinW*SP.fv;lift=a*lift+spinW*SP.lift;sup=a*sup+spinW*SP.support}
    if(crouch>0&&P.cr){duty+=crouch*(P.cr.duty||0);f0+=crouch*(P.cr.f0||0)}
    return {w,off:o,duty,f0,fv,lift,support:sup,spinW}};
  /* per-gait constants: a gait may override any constant (GAITS[g].p) and give it a
   * slope with speed (GAITS[g].pv); the gait selectors blend them like everything else */
  const CRK=P.cr?Object.keys(P.cr).filter(k=>k!=='duty'&&k!=='f0'&&k in P):[];
  const OVR=[...new Set([...GAIT_NAMES.flatMap(g=>[...Object.keys(GT[g].p||{}),...Object.keys(GT[g].pv||{})]),...Object.keys(SP.p),...CRK])];
  const Qb={...P};
  function blendParams(w,speed,spinW=0,crouch=0){if(!OVR.length)return P;for(const k of OVR){let v=0;for(const g of GAIT_NAMES){const G=GT[g],x=w[g];if(!x)continue;v+=x*((G.p&&k in G.p?G.p[k]:P[k])+(G.pv&&k in G.pv?G.pv[k]*speed:0))}
      if(spinW>0&&k in SP.p)v=(1-spinW)*v+spinW*SP.p[k];if(crouch>0&&P.cr&&k in P.cr)v+=crouch*P.cr[k];Qb[k]=v}return Qb}
  function reset(){
    const B=blend();for(let i=0;i<4;i++){kEst[i]=BODY.restKnee;ph[i]=((1-B.off[i])%1+1)%1;stance[i]=ph[i]>=1-B.duty?1:0;air[i]=0;hold[i]=0;fx[i]=P.x0;xLift[i]=P.x0;xLand[i]=P.x0;xTD[i]=P.x0;lastC[i]=1}
    amp=0;ampV=0;t=0;F.ok=false;F.yawRef=null;lastKt.fill(NaN);for(const k of Object.keys(Ds))Ds[k]=0;
  }
  reset();
  const read=(obs,i,prev)=>{const v=obs[i];return v===0||!Number.isFinite(v)?prev:v};   // a dropped sensor reads exactly 0
  function senses(obs,dt){
    const g0=obs[0],g1=obs[1],g2=obs[2],n=g0*g0+g1*g1+g2*g2;
    if(n>.7&&n<1.3&&g2<-.5){const p=Math.atan2(g0,-g2),r=Math.atan2(-g1,-g2);const k=F.ok?.35:1;F.pitch+=k*(p-F.pitch);F.roll+=k*(r-F.roll)}
    const pr=read(obs,4,F.pitchRate/4)*4,rr=read(obs,3,F.rollRate/4)*4,yr=read(obs,5,F.yawRate/4)*4;
    F.pitchRate+=.5*(pr-F.pitchRate);F.rollRate+=.5*(rr-F.rollRate);F.yawRate+=.5*(yr-F.yawRate);
    const v=read(obs,7,F.v/1.5)*1.5;F.v+=(F.ok?.25:1)*(v-F.v);
    const s=obs[10],c=obs[11];if(!(s===0||c===0)&&Math.abs(s*s+c*c-1)<.4)F.yaw=Math.atan2(s,c);
    F.ok=true;
  }
  function control(obs,dt=.02){
    senses(obs,dt);
    {const inj0=k=>num(inj.get(k),0);F.pitchI=F.pitch+.1*inj0('s:pitch');F.rollI=F.roll+.1*inj0('s:roll');F.vI=F.v+.3*inj0('s:flow');F.yawI=F.yaw-.3*inj0('s:yaw')}
    // ── descending layer ───────────────────────────────────────────────
    const ki=1-Math.exp(-dt/P.cmdTau),inj0=k=>num(inj.get(k),0);
    const want={speed:D.stop?0:num(D.speed)+.3*inj0('mlr'),turn:D.stop?0:num(D.turn)+.6*inj0('turnL')-.6*inj0('turnR'),crouch:clamp(num(D.crouch)+inj0('crouch'),0,1),pitch:num(D.pitch),stiffness:num(D.stiffness)+.5*inj0('tone'),stepHeight:num(D.stepHeight),freq:num(D.freq)};
    for(const k of Object.keys(Ds))Ds[k]+=ki*(want[k]-Ds[k]);
    let gait=D.gait in GAITS?D.gait:'trot';
    if(D.autoGait){const v=Math.abs(Ds.speed);gait=v<.09?'walk':'trot'}
    const kg=1-Math.exp(-dt/P.gaitTau);for(const g of GAIT_NAMES)gw[g]+=kg*((g===gait?1:0)+inj0('gait:'+g)-gw[g]),gw[g]=clamp(gw[g],0,1.5);
    const tx=P.turnGait>0?clamp((Math.abs(Ds.turn)-P.turnOn)/Math.max(.01,P.turnFull-P.turnOn),0,1):0,spinW=tx*tx*(3-2*tx);
    // a crouched animal stalks: from half crouch down the speed is held to crouchVmax
    const cx=clamp(Ds.crouch/.5,0,1),vCr=.45+cx*cx*(3-2*cx)*(P.crouchVmax-.45);
    // turning slows the animal: with the full turning pattern the forward speed is held to turnVmax
    const vCmd=clamp(Ds.speed,-Math.min(.2,vCr),vCr),vBody=vCmd+spinW*(clamp(vCmd,-P.turnVmax,P.turnVmax)-vCmd);
    const B=blend(spinW,Ds.crouch,Math.abs(vBody),Ds.turn<0?-1:1);
    const Q=blendParams(B.w,Math.abs(vBody),spinW,Ds.crouch);
    /* once the turning pattern is recruited, the turn neurons set the sides' push difference past the feet's
     * friction breakaway (a weaker difference only scrubs the feet, it doesn't yaw the body) and saturate where
     * harder pushing would only skid and stumble: the command's range |turn| = turnFull..1 maps to turnMin..turnSat */
    let turn=Ds.turn;
    if(spinW>0){const a=Math.abs(Ds.turn),m=clamp((a-P.turnFull)/Math.max(.01,1-P.turnFull),0,1),e=P.turnMin+(P.turnSat-P.turnMin)*m;
      turn=Math.sign(Ds.turn)*((1-spinW)*Math.min(a,P.turnSat)+spinW*e)}
    // heading hold: a slow loop through the turn channel, released while turning
    hcorr.v=0;if(D.headingHold&&Math.abs(D.turn)<.02&&Math.abs(Ds.turn)<.05&&amp>.5){if(F.yawRef===null)F.yawRef=F.yaw;let e=F.yawRef-F.yawI;e=Math.atan2(Math.sin(e),Math.cos(e));hcorr.v=clamp(Q.headingK*e,-.4,.4);turn+=hcorr.v}
    else F.yawRef=null;
    turn+=.4*inj0('head');
    const stopNow=D.stop||inj0('stop')>.5,v=clamp(strideFor(B.w,vBody),-.25,.5),moving=!stopNow&&(Math.abs(vBody)>.01||Math.abs(turn)>.03);
    // rhythm amplitude: a Hopf-like onset, so the animal starts and stops stepping smoothly
    const target=moving?1:0;amp=clamp(amp+(dt/Q.ampTau)*(target-amp),0,1);
    const f=clamp(B.f0+B.fv*Math.abs(v)+Ds.freq,.4,3.2),D_=clamp(B.duty,.3,.9),sw=1-D_,Tst=D_/f,Tsw=sw/f;
    const height=Q.standHeight-Q.crouchDrop*Ds.crouch,lift=Math.max(0,(Q.lift+Ds.stepHeight)*B.lift*(1-.5*Ds.crouch))*amp;
    // ── rhythm generator: Kuramoto-coupled limb oscillators ────────────
    const raw=new Uint8Array(4),sup=new Uint8Array(4);for(let i=0;i<4;i++){raw[i]=obs[28+i]+inj0('s:load:'+LEGS[i])>.5?1:0;sup[i]=raw[i]||lastC[i]}
    for(let i=0;i<4;i++){
      let c=0;for(let j=0;j<4;j++)if(j!==i)c+=Math.max(0,1+inj0(CIN_OF[i][j]))*Math.sin(TAU*((ph[j]+B.off[j])-(ph[i]+B.off[i])));
      // a stimulated flexor half-centre ends stance sooner and prolongs swing; the extensor the reverse
      const hc=inj0('rg:F:'+LEGS[i])-inj0('rg:E:'+LEGS[i]);
      let rate=f*(1+(stance[i]?hc:-hc))+Q.Kc*c/TAU;
      // support gates lift-off: a loaded stance leg about to lift waits for the others to land
      if(stance[i]&&(ph[i]-sw)/D_>.92&&amp>.3&&B.support>=1.5){let others=0;for(let j=0;j<4;j++)if(j!==i&&sup[j])others++;
        if((others<Math.round(Math.min(B.support,3))||inj0('r:gate:'+LEGS[i])>.5)&&hold[i]<Q.holdMax*(1+Math.max(0,inj0('r:gate:'+LEGS[i]))*3)){rate*=.15;hold[i]+=dt}}
      ph[i]+=Math.max(0,rate)*dt;
      if(ph[i]>=1){ph[i]-=1;stance[i]=0;air[i]=0;hold[i]=0;xLift[i]=fx[i];events.push({t,leg:i,e:'liftoff'})}
      else if(!stance[i]&&ph[i]>=sw){stance[i]=1;xLand[i]=fx[i];tdPulse[i]=.6;events.push({t,leg:i,e:'touchdown'})}
      // touchdown reflex: ground contact late in swing ends the swing now
      if(!stance[i]){if(!raw[i])air[i]=1;
        if(air[i]&&raw[i]&&ph[i]/sw>Q.tdReset){ph[i]=sw;stance[i]=1;xLand[i]=fx[i];tdPulse[i]=1;events.push({t,leg:i,e:'touchdown-reflex'})}}
      lastC[i]=raw[i];
    }
    // ── pattern formation: levelled foot paths ─────────────────────────
    const vErr=F.vI-vBody,kPlace=Q.raibertK*(1+inj0('r:place')),kVsr=1+inj0('r:vsr');
    for(let i=0;i<4;i++){const L=LEGS[i];
      vLeg[i]=(v+RIGHT[i]*turn*Q.turnArm)*amp+.1*inj0('pf:push:'+L);
      const S=clamp(vLeg[i]*Tst,-Q.stepMax,Q.stepMax);
      xTD[i]=Q.x0+HX[i]/BODY.hipX*Q.spread+S/2+clamp(kPlace*vErr,-.04,.04)*amp+.03*inj0('pf:prot:'+L);
      // vestibulospinal posture: lengthen the low side, both pitch and roll
      const pc=kVsr*(HX[i]*(Q.pitchKp*(F.pitchI-Ds.pitch)+Q.pitchKd*F.pitchRate)-HY[i]*(Q.rollKp*F.rollI+Q.rollKd*F.rollRate));
      lenLeg[i]=height+HX[i]*Q.pitchBias+clamp(pc,-Q.postureMax,Q.postureMax)+.012*inj0('pf:sup:'+L);
    }
    const tone=clamp(1+Ds.stiffness,0,1.6);
    for(let i=0;i<4;i++){
      const j=2*i,lean=Q.levelFrame?F.pitch:0,cL=Math.cos(lean),sL=Math.sin(lean);
      const toBody=(x,z,o)=>legIK(cL*x-sL*z,sL*x+cL*z,o,j);
      let a;
      if(stance[i]){
        // stance: the foot sweeps back at the leg's own ground speed, at constant levelled height
        fx[i]=clamp(fx[i]-vLeg[i]*dt,Q.x0+HX[i]/BODY.hipX*Q.spread-.13,Q.x0+HX[i]/BODY.hipX*Q.spread+.13);
        toBody(fx[i],-lenLeg[i],q);toBody(fx[i]-vLeg[i]*dt,-lenLeg[i],qn);
        const p=(ph[i]-sw)/D_;
        a=tone*Q.Ast;
        const dh=(qn[j]-q[j])/dt,dk=(qn[j+1]-q[j+1])/dt;
        qt[j]=q[j]+Q.leadT*dh;qt[j+1]=q[j+1]+Q.leadT*dk-Q.sagComp;
        // pre-swing: the knee starts its flexion burst just before lift-off
        if(Q.preSwing>0&&p>1-Q.preSwing&&amp>.2){const r=(p-(1-Q.preSwing))/Q.preSwing;qt[j+1]+=r*(KNEE_REACH_MAX-qt[j+1])*amp}
        hLift[i]=q[j];
      }else{
        // swing: a knee flexion burst (as fast as the muscles allow) and a hip that keeps the foot on its
        // path for wherever the knee really is, from an efference copy of the knee's own command
        const s=clamp(ph[i]/sw,0,1),lookS=clamp((ph[i]+f*Q.leadT)/sw,0,1);
        toBody(xTD[i],-lenLeg[i],tdq);const kTD=tdq[j+1];
        toBody(xTD[i]*.5,-(lenLeg[i]-lift),liftq);const kUp=Math.max(kTD,liftq[j+1]);
        const mx=-vLeg[i]*Tsw*Q.retract;
        const kneeCmd=ss=>ss<Q.flexEnd?kTD+(kUp-kTD+Q.flexOver)*amp:kTD-Q.kneeOver*amp*(1-(ss-Q.flexEnd)/(1-Q.flexEnd));
        qt[j+1]=kneeCmd(s)+.15*inj0('pf:lift:'+LEGS[i]);
        // the knee Q.leadT from now, by the first-order muscle model, and the foot's path point then
        const kc=clamp(qt[j+1],BODY.kneeLo+.02,KNEE_REACH_MAX),kE=kEst[i]+.1*inj0('eff:'+LEGS[i]),kAhead=kc+(kE-kc)*Math.exp(-Q.leadT/Q.kneeTau);
        const xs=hermite(s,xLift[i],xTD[i],mx,mx),xa=hermite(lookS,xLift[i],xTD[i],mx,mx);
        qt[j]=hipFor(xa,kAhead);q[j]=hipFor(xs,kE);q[j+1]=kE;
        a=tone*(s>.75?Q.Aland:Q.Asw);
        fx[i]=xs;
      }
      // the hip's passive spring, cancelled by the muscle that works against it
      qt[j]+=Q.springComp*BODY.hipSpring*(q[j]-BODY.hipSpringRef)/(BODY.kp*a);
      {const L=LEGS[i];qt[j]+=.3*(inj0('mn:h+:'+L)-inj0('mn:h-:'+L))+inj0('hip:'+L);qt[j+1]+=.25*(inj0('mn:k+:'+L)-inj0('mn:k-:'+L))+inj0('knee:'+L)}
      // standing: never lock a loaded knee against its extension stop (it strains the joint); as the rhythm
      // fades the knee's floor rises from just off the stop to the plant's own standing angle
      {const kf=BODY.kneeLo+.02+(1-amp)*Math.max(0,BODY.restKnee-BODY.kneeLo-.02);if(qt[j+1]<kf)qt[j+1]=kf}
      // knee slew limit (rad/s): a softer knee burst costs the joint less shock (0 = off)
      if(Q.kneeSlew>0){const lim=Q.kneeSlew*dt;if(Number.isFinite(lastKt[i]))qt[j+1]=clamp(qt[j+1],lastKt[i]-lim,lastKt[i]+lim)}lastKt[i]=qt[j+1];
      for(let k=0;k<2;k++){const jj=j+k;A[jj]=a;muscleCommands(qt[jj],jj,a,out)}
      // efference copy: where the knee will be next step, under the plant's first-order muscle response
      const kc=clamp(qt[j+1],BODY.kneeLo+.02,KNEE_REACH_MAX);kEst[i]=kc+(kEst[i]-kc)*Math.exp(-dt/Q.kneeTau);
    }
    // activities for the connectome (each in -1..1)
    act.f=f;act.duty=D_;act.amp=amp;act.turn=turn;act.v=v;act.height=height;act.lift=lift;act.off=B.off;act.support=B.support;act.spinW=spinW;act.vBody=vBody;
    for(const g of GAIT_NAMES)setA('gait:'+g,gw[g]);
    setA('mlr',Ds.speed/.3);setA('stop',1-amp);setA('turnL',Math.max(0,turn)/.6);setA('turnR',Math.max(0,-turn)/.6);setA('crouch',Ds.crouch);setA('tone',Ds.stiffness);setA('head',hcorr.v/.4);
    setA('s:pitch',F.pitchI/.08);setA('s:roll',F.rollI/.08);setA('s:flow',F.vI/.3);setA('s:yaw',F.yawRef===null?F.yawRate/1.5:Math.atan2(Math.sin(F.yawRef-F.yaw),Math.cos(F.yawRef-F.yaw))/.3);
    setA('r:vsr',(Math.abs(Q.pitchKp*F.pitch)+Math.abs(Q.rollKp*F.roll))*.24/Math.max(1e-6,Q.postureMax));setA('r:place',Q.raibertK*vErr/.04);
    for(let i=0;i<4;i++){const L=LEGS[i],sp=stance[i],s=sp?0:clamp(ph[i]/sw,0,1),p=sp?clamp((ph[i]-sw)/D_,0,1):0;
      setA('rg:F:'+L,sp?0:amp*Math.sin(Math.PI*s));setA('rg:E:'+L,sp?amp*Math.sin(Math.PI*p)+(1-amp)*.5:0);
      setA('pf:lift:'+L,sp?0:(s<Q.flexEnd?amp:-amp*.6));setA('pf:prot:'+L,sp?0:amp*Math.sin(Math.PI*s));setA('pf:push:'+L,sp?amp*vLeg[i]/.25:0);setA('pf:sup:'+L,sp?.4+.6*raw[i]:0);
      setA('mn:h+:'+L,(1+out[2*i])/2);setA('mn:h-:'+L,(1+out[8+2*i])/2);setA('mn:k+:'+L,(1+out[2*i+1])/2);setA('mn:k-:'+L,(1+out[8+2*i+1])/2);
      setA('eff:'+L,(kEst[i]-BODY.restKnee)/BODY.kneeSpan);setA('s:load:'+L,raw[i]);setA('r:td:'+L,tdPulse[i]);setA('r:gate:'+L,hold[i]>0&&sp&&p>.9?1:0);tdPulse[i]*=Math.exp(-dt/.08)}
    for(const n of NETWORK.nodes)if(n.group==='cin'){const [a,b]=n.pair;setA(n.id,Math.cos(TAU*(B.off[b]-B.off[a])))}
    for(const [id,v] of inj){const k=NI.get(id);if(k!==undefined)actv[k]=clamp(actv[k]+v,-1,1)}
    if(events.length>64)events.splice(0,events.length-64);
    t++;return out;
  }
  return {control,reset,P,D,Ds,gw,inj,ph,stance,F,
    set(d){Object.assign(D,d||{});return D},
    inject(id,v){if(v===null||v===undefined||v===0)inj.delete(id);else inj.set(id,num(v));return this},
    state(){return {t,ph:Array.from(ph),stance:Array.from(stance),fx:Array.from(fx),q:Array.from(q),qt:Array.from(qt),A:Array.from(A),kEst:Array.from(kEst),amp,act:{...act},F:{...F},events:events.splice(0)}},
    activity(){return actv.slice()},
    N:NETWORK.nodes.length};
}
