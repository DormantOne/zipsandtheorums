import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawn,spawnSync} from 'node:child_process';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),port=Number(process.env.COMPANION_PORT||8797),url=`http://127.0.0.1:${port}`,data=path.resolve(process.env.COMPANION_DATA_DIR||path.join(root,'data_companion'));
if(Number(process.versions.node.split('.')[0])<22)throw Error('Please install Node.js 22 or newer from https://nodejs.org, then open START again.');
fs.mkdirSync(data,{recursive:true});
const status=async()=>{try{const r=await fetch(url+'/api/status',{signal:AbortSignal.timeout(1200)});return await r.json();}catch{return null;}};
const open=()=>{if(process.env.COMPANION_NO_OPEN)return;const p=process.platform==='darwin'?spawn('open',[url],{stdio:'ignore'}):process.platform==='win32'?spawn('cmd',['/c','start','',url],{stdio:'ignore'}):spawn('xdg-open',[url],{stdio:'ignore'});p.on('error',()=>console.log('Open this address in your browser: '+url));p.unref();};
let current=await status();
if(process.argv.includes('--stop')){
  if(current?.app==='Companion Vision v15'){await fetch(url+'/api/cmd',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({cmd:'shutdown'})});console.log('Companion stopped. Your last completed learning update is saved.');}
  else console.log('Companion is not running on port '+port+'.');
}else if(current?.app==='Companion Vision v15'){console.log('Companion is already running. Opening '+url);open();}
else{
  if(current)throw Error(`Port ${port} is occupied by another app. Choose another COMPANION_PORT or stop that app.`);
  const modules=['node_modules/@mujoco/mujoco/mujoco.js','node_modules/three/build/three.module.js'];
  if(!modules.every(n=>fs.existsSync(path.join(root,n)))){
    console.log('Installing the local physics and viewer dependencies…');
    const r=spawnSync(process.platform==='win32'?'npm.cmd':'npm',['ci','--no-audit','--no-fund'],{cwd:root,stdio:'inherit',shell:process.platform==='win32'});if(r.status!==0)throw Error('Dependency installation failed. Keep this window open for the error above.');
  }
  const marker=path.join(data,'.verified_body_v15_2');
  if(!fs.existsSync(marker)){
    console.log('Checking the physical body and binocular eyes (first launch)…');
    const r=spawnSync(process.execPath,['tests/launch_check.mjs'],{cwd:root,stdio:'inherit'});if(r.status!==0)throw Error('The body check failed. Companion was not started.');fs.writeFileSync(marker,new Date().toISOString());
  }
  const log=fs.openSync(path.join(data,'server.log'),'a'),child=spawn(process.execPath,['server.mjs'],{cwd:root,env:{...process.env,COMPANION_PORT:String(port),COMPANION_DATA_DIR:data},detached:true,stdio:['ignore',log,log]});
  child.unref();fs.closeSync(log);
  for(let i=0;i<100;i++){current=await status();if(current?.liveReady)break;await new Promise(r=>setTimeout(r,150));}
  if(!current?.liveReady)throw Error('The server did not become ready. Details are in data_companion/server.log.');
  console.log('\nCompanion is ready: '+url+'\nPress Follow target. Click the ground to move the ball.\nLearning is optional; use Start learning when you are ready.\nSTOP closes Companion and saves the last completed update.');open();
}
