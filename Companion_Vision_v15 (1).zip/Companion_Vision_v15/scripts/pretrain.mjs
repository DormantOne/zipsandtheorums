import fs from 'node:fs';
import {TrainingLab,TRAIN_DEFAULTS} from '../rig/companion/trainer.mjs';
const updates=Math.max(1,Number(process.argv[2]||48)),lab=new TrainingLab({cfg:{hybridTracks:2,hybridLearnSteps:10000,hybridValEvery:3}});
const log=()=>console.log(JSON.stringify({updates:lab.hybrid.stepCount,stage:lab.hybrid.stage,best:lab.best?.score.quality,strict:lab.archive.best()?.quality,accepted:lab.hybrid.accepted}));
try{
 await lab.initialize();log();
 for(let i=0;i<updates;i++){await lab.step();if(i%3===2){log();fs.writeFileSync('starter/training-in-progress.json',JSON.stringify(lab.serialize()));}}
 await lab.hybrid.leave();log();
 for(let i=0;i<3;i++){await lab.evolve();log();}
 await lab.hybrid.enter({count:3});
 for(let i=0;i<6;i++)await lab.step();
 const evaluation=await lab.test();
 lab.cfg.hybridLearnSteps=TRAIN_DEFAULTS.hybridLearnSteps;lab.cfg.hybridTracks=TRAIN_DEFAULTS.hybridTracks;lab.cfg.hybridValEvery=TRAIN_DEFAULTS.hybridValEvery;lab.hybrid.config=lab.cfg;
 fs.writeFileSync('starter/ready-to-follow.json',JSON.stringify(lab.serialize()));
 fs.writeFileSync('starter/training-report.json',JSON.stringify({updates:lab.hybrid.stepCount,baseline:lab.baseline,best:lab.best.score,following:lab.follower().score,holdout:evaluation,metamorphosis:lab.hybrid.status(),checks:lab.serialize().checks},null,2));
 fs.rmSync('starter/training-in-progress.json',{force:true});log();
}finally{await lab.close();}
