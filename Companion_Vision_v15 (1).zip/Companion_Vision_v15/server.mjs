import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {Worker} from 'node:worker_threads';
import {TrainingLab} from './rig/companion/trainer.mjs';
import {makeFounder,SENSORS,OUTPUTS} from './rig/companion/brain.mjs';
import {toHeir} from './rig/core/hybrid.mjs';
import {rigView} from './rig/brain.mjs';
import {Rng} from './rig/core/rng.mjs';
import {NETWORK} from './rig/gait/spinal_cord.mjs';
const ROOT=path.dirname(fileURLToPath(import.meta.url)),PORT=Number(process.env.COMPANION_PORT||8797),DATA=path.resolve(process.env.COMPANION_DATA_DIR||path.join(ROOT,'data_companion'));
fs.mkdirSync(DATA,{recursive:true});const clients=new Set();let frame=null,describe=null,liveReady=false,note='Starting the physical body and eyes…',latestCheckpoint=null,saveAt=0;
const broadcast=o=>{const data=`data: ${JSON.stringify(o)}\n\n`;for(const r of clients){if(!r.write(data)&&r.writableLength>2e6){r.end();clients.delete(r);}}};
const strictSeed=makeFounder(new Rng(47017)),seedGenome=toHeir(strictSeed);let followerKind='learned',deployed=null;
const live=new Worker(new URL('./rig/companion/live_worker.mjs',import.meta.url),{workerData:{genome:Array.from(seedGenome)}});
const lab=new TrainingLab({onBest:()=>deployFollower(),onUpdate:s=>{
  deployFollower();
  broadcast({type:'training',state:s});if(s.initialized&&!s.error){latestCheckpoint=lab.serialize();if(Date.now()-saveAt>20000){saveCheckpoint();saveAt=Date.now();}}
}});
function deployment(){const strict=lab.archive.best();return followerKind==='strict'?{genome:strict?.genome||strictSeed,score:strict?.stats||null}:lab.follower()||{genome:seedGenome,score:null};}
function deployFollower(){const d=deployment();if(deployed?.genome===d.genome)return;deployed=d;live.postMessage({cmd:'genome',genome:Array.from(d.genome)});}
function saveCheckpoint(){if(!latestCheckpoint)return false;const f=path.join(DATA,'checkpoint.json'),tmp=f+'.tmp';fs.writeFileSync(tmp,JSON.stringify(latestCheckpoint));fs.renameSync(tmp,f);return true;}
const saved=path.join(DATA,'checkpoint.json'),starter=path.join(ROOT,'starter','ready-to-follow.json');
try{if(fs.existsSync(saved)){lab.restore(JSON.parse(fs.readFileSync(saved)));note='Your saved learning is restored.';}else if(fs.existsSync(starter)){lab.restore(JSON.parse(fs.readFileSync(starter)));note='The starter companion is ready.';}}catch(e){note='Checkpoint was left untouched: '+e.message;console.error(note);}
live.on('message',m=>{if(m.ready){liveReady=true;describe=m.describe;note=lab.initialized?'Ready. Press Follow target.':'Ready. A visual-reflex seed is loaded.';}if(m.frame){frame=m.frame;broadcast(frame);}if(m.error){note=m.error;broadcast({type:'event',text:m.error});}if(m.event)broadcast({type:'event',text:m.event});});
live.on('error',e=>{liveReady=false;note=e.message;console.error(e);broadcast({type:'event',text:'Live physics stopped: '+e.message});});
function status(){return {app:'Companion Vision v15',version:'15.1.0',liveReady,note,saved:fs.existsSync(saved),training:lab.status(),frame:frame?{mode:frame.mode,running:frame.running,metrics:frame.metrics}:null};}
const json=(res,obj,status=200)=>{res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(obj));};
async function readBody(req){let text='';for await(const c of req){text+=c;if(Buffer.byteLength(text)>12e6)throw Error('Request too large');}return text?JSON.parse(text):{};}
const finite=(v,a,b)=>{if(!Number.isFinite(v)||v<a||v>b)throw Error(`Value must be between ${a} and ${b}`);return v;};
function setSettings(args){
  const next={};for(const [key,v] of Object.entries(args)){
    if(key==='maxSpeed')next[key]=finite(v,.04,.24);else if(key==='turnGain')next[key]=finite(v,.05,.6);else if(key==='followGap')next[key]=finite(v,.72,1.5);
    else if(key==='gait'){if(!['walk','trot'].includes(v))throw Error('Choose walk or trot');next[key]=v;}
    else if(key==='targetMode'){if(!['still','sway','lead','circle'].includes(v))throw Error('Unknown target path');next[key]=v;}
    else if(['eyeBlackout','steering','autoRecover'].includes(key))next[key]=!!v;
    else if(key==='mode'){if(!['learned','strict','reflex','manual','rest'].includes(v))throw Error('Unknown controller');next[key]=v;if(['learned','strict'].includes(v)){followerKind=v;deployFollower();}}
    else throw Error('Unknown setting: '+key);
  }
  live.postMessage({cmd:'settings',settings:next});
  // Evaluation settings are fixed for a training run. Viewer speed, target and
  // blindness experiments cannot silently change the comparison yardstick.
}
async function command(cmd,args){
  if(cmd==='settings'){setSettings(args);return {};}
  if(cmd==='target'){if(!Array.isArray(args.xyz)||args.xyz.length!==3)throw Error('Target requires three coordinates');args.xyz.forEach((v,i)=>finite(v,i===2?.15:-15,i===2?1.3:15));live.postMessage({cmd,xyz:args.xyz});return {};}
  if(cmd==='reset'){live.postMessage({cmd});return {};}
  if(cmd==='run'){live.postMessage({cmd,on:!!args.on});return {};}
  if(cmd==='rate'){live.postMessage({cmd,rate:finite(args.rate,.25,2)});return {};}
  if(cmd==='manual'){const values={};for(const [k,v] of Object.entries(args)){const ranges={speed:[-.1,.24],turn:[-.5,.5],headYaw:[-1,1],headPitch:[-.5,.5]};if(!ranges[k])throw Error('Unknown drive control');values[k]=finite(v,...ranges[k]);}live.postMessage({cmd,values});return {};}
  if(cmd==='train'){if(lab.testing)throw Error('Reserved evaluation is still running');lab.start();return {};}
  if(cmd==='pauseTraining'){lab.pause();return {};}
  if(cmd==='stage'){if(!['learning','evolution'].includes(args.stage))throw Error('Unknown stage');lab.stageRequest=args.stage;return {};}
  if(cmd==='trainSettings'){
    const ranges={hybridLearnSteps:[12,5000],hybridEvoGens:[1,100],hybridSigma:[.01,.6],hybridRate:[.002,.3],hybridValEvery:[1,50],hybridTracks:[1,6]};
    for(const [k,v] of Object.entries(args)){if(!ranges[k])throw Error('Unknown training setting');finite(v,...ranges[k]);if(!['hybridRate','hybridSigma'].includes(k)&&!Number.isInteger(v))throw Error('Use an integer');lab.cfg[k]=v;}
    lab.hybrid.config=lab.cfg;if(lab.initialized&&!lab.busy)latestCheckpoint=lab.serialize();return {};
  }
  if(cmd==='save'){if(lab.initialized&&!lab.busy)latestCheckpoint=lab.serialize();if(!saveCheckpoint())throw Error('Start learning before saving a checkpoint');return {message:'Checkpoint saved'};}
  if(cmd==='test'){lab.test({which:followerKind}).catch(e=>{lab.log(e.message);broadcast({type:'event',text:e.message});});return {};}
  if(cmd==='shutdown'){setTimeout(stop,100).unref();return {ok:true};}
  throw Error('Unknown command');
}
const server=http.createServer(async(req,res)=>{
  try{
    const host=(req.headers.host||'').split(':')[0];if(!['127.0.0.1','localhost','['].includes(host)){res.writeHead(403);res.end('Local connections only');return;}
    const origin=req.headers.origin;if(origin){const u=new URL(origin);if(!['127.0.0.1','localhost'].includes(u.hostname)||u.port!==String(PORT))throw Error('Unexpected request origin');}
    const u=new URL(req.url,'http://127.0.0.1');
    if(u.pathname==='/api/status')return json(res,status());
    if(u.pathname==='/api/brain')return json(res,rigView(deployment().genome));
    if(u.pathname==='/api/describe')return json(res,{...describe,ready:liveReady,sensors:SENSORS,outputs:OUTPUTS,spine:NETWORK});
    if(u.pathname==='/api/stream'){
      res.writeHead(200,{'Content-Type':'text/event-stream','Cache-Control':'no-cache','Connection':'keep-alive'});res.write('retry: 1500\n\n');clients.add(res);if(frame)res.write(`data: ${JSON.stringify(frame)}\n\n`);req.on('close',()=>clients.delete(res));return;
    }
    if(u.pathname==='/api/cmd'&&req.method==='POST'){const b=await readBody(req);return json(res,await command(b.cmd,b.args||{}));}
    if(u.pathname==='/api/checkpoint'&&req.method==='POST'){const b=await readBody(req);lab.restore(b);latestCheckpoint=lab.serialize();saveCheckpoint();return json(res,{ok:true});}
    if(u.pathname==='/api/checkpoint'){
      if(lab.initialized&&!lab.busy)latestCheckpoint=lab.serialize();if(!latestCheckpoint)return json(res,{error:'No learning checkpoint yet'},404);
      res.writeHead(200,{'Content-Type':'application/json','Content-Disposition':'attachment; filename="companion-learning-checkpoint.json"','Cache-Control':'no-store'});res.end(JSON.stringify(latestCheckpoint,null,2));return;
    }
    if(req.method!=='GET')return json(res,{error:'Method not allowed'},405);
    const routes={'/':'web/index.html','/app.js':'web/app.js','/style.css':'web/style.css','/arena.js':'web/arena.js','/vendor/three.module.js':'node_modules/three/build/three.module.js','/vendor/three.core.js':'node_modules/three/build/three.core.js','/vendor/OrbitControls.js':'node_modules/three/examples/jsm/controls/OrbitControls.js'};
    const file=routes[u.pathname];if(!file){res.writeHead(404);res.end('Not found');return;}
    const type=file.endsWith('.html')?'text/html':file.endsWith('.css')?'text/css':'text/javascript';res.writeHead(200,{'Content-Type':type,'Cache-Control':'no-cache'});fs.createReadStream(path.join(ROOT,file)).pipe(res);
  }catch(e){json(res,{error:e.message},400);}
});
server.on('error',e=>{console.error(e.code==='EADDRINUSE'?`Port ${PORT} is busy. Stop the other Companion window or use COMPANION_PORT.`:e);process.exitCode=1;live.terminate();lab.evaluator.close();});
server.listen(PORT,'127.0.0.1',()=>{fs.writeFileSync(path.join(DATA,'server.pid'),String(process.pid));console.log(`Companion Vision v15 · http://127.0.0.1:${PORT}`);});
const keepalive=setInterval(()=>{for(const r of clients)r.write(': keepalive\n\n');},15000);
async function stop(){clearInterval(keepalive);saveCheckpoint();for(const r of clients)r.end();server.close();await live.terminate();await lab.evaluator.close();const pid=path.join(DATA,'server.pid');if(fs.existsSync(pid)&&fs.readFileSync(pid,'utf8')===String(process.pid))fs.unlinkSync(pid);process.exit();}
process.on('SIGINT',stop);process.on('SIGTERM',stop);
