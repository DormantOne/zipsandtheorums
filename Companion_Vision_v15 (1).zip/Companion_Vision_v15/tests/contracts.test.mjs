import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {makeFounder,mutateVision,makeVisualNetwork,validateGenome,SENSOR_COUNT} from '../rig/companion/brain.mjs';
import {toHeir,projectHeir,transferShadow,assertFrozen,paramGroups,topologyFingerprint} from '../rig/core/hybrid.mjs';
import {rigAudit,unpackRig} from '../rig/brain.mjs';
import {Rng} from '../rig/core/rng.mjs';
import {TrainingLab} from '../rig/companion/trainer.mjs';
test('structural evolution and shadow inheritance retain the strict and continuous contracts',()=>{
 const rng=new Rng(17);let source=makeFounder(rng),heir=toHeir(source);const before=Array.from(source);
 for(const k of paramGroups(heir).motor)heir[k]*=.86;
 assert(assertFrozen(source,heir));assert.deepEqual(Array.from(source),before);assert.equal(topologyFingerprint(source),topologyFingerprint(heir));
 const projection=projectHeir(heir,source);assert(rigAudit(projection).ok);assert.equal(projection[6],4);
 for(let i=0;i<100;i++){const child=mutateVision(source,rng,{count:1+i%4}),shadow=transferShadow(child,source,heir);assert(rigAudit(child).ok);assert(assertFrozen(child,shadow));validateGenome(shadow);source=child;heir=shadow;}
});
test('the visual network accepts exactly retinal/proprioceptive sensors and bounded finite commands',()=>{
 const g=toHeir(makeFounder(new Rng(29))),net=makeVisualNetwork(g);assert.equal(SENSOR_COUNT,24);assert.throws(()=>net.control(Array(36).fill(0)));
 for(let j=0;j<50;j++){const obs=Array.from({length:24},(_,i)=>Math.sin(j+i));const u=net.control(obs);assert.equal(u.length,6);assert(Array.from(u).every(v=>Number.isFinite(v)&&Math.abs(v)<=1));}
 net.reset();const a=Array.from(net.control(Array(24).fill(.2)));net.reset();assert.deepEqual(Array.from(net.control(Array(24).fill(.2))),a);
});
test('resuming while a pause is finishing keeps one training loop',async()=>{
 let release,steps=0;const gate=new Promise(r=>{release=r;}),lab=new TrainingLab({evaluator:{close:async()=>{}}});
 lab.initialize=async()=>gate;lab.step=async()=>{steps++;lab.running=false;};
 lab.start();const original=lab.job;lab.pause();lab.start();assert.equal(lab.job,original);release();await original;assert.equal(steps,1);assert(!lab.busy);await lab.close();
});
test('a complete saved family restores without erasing parents or nursery; corrupt imports are rejected atomically',async()=>{
 const checkpoint=JSON.parse(fs.readFileSync(new URL('../starter/ready-to-follow.json',import.meta.url)));
 const lab=new TrainingLab({evaluator:{close:async()=>{},evaluate:async()=>{throw Error('Unexpected evaluation during restore');}}});
 try{lab.restore(checkpoint);assert.equal(lab.hybrid.lineages.length,checkpoint.hybrid.lineages.length);assert.equal(lab.hybrid.nursery.length,checkpoint.hybrid.nursery.length);assert.equal(lab.hybrid.stepCount,checkpoint.hybrid.stepCount);assert(lab.hybrid.lineages.length>=2);assert(lab.hybrid.nursery.length>0);
  const before=JSON.stringify(lab.serialize()),bad=structuredClone(checkpoint);bad.hybrid.lineages[0].best[0]=0;assert.throws(()=>lab.restore(bad));assert.equal(JSON.stringify(lab.serialize()),before);
  const wrong=structuredClone(checkpoint);wrong.checks.body='another-body';assert.throws(()=>lab.restore(wrong));assert.equal(JSON.stringify(lab.serialize()),before);
 }finally{await lab.close();}
});
