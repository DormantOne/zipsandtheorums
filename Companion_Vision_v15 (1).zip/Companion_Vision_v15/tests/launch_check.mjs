import assert from 'node:assert/strict';
import {loadMujoco} from '../rig/gait/mujoco_loader.mjs';
import {CompanionSim} from '../rig/companion/sim.mjs';
import {makeFounder} from '../rig/companion/brain.mjs';
import {Rng} from '../rig/core/rng.mjs';
const mj=await loadMujoco(),sim=new CompanionSim(mj,{genome:makeFounder(new Rng(7))});
try{assert.equal(sim.body.plant.model.nu,14);assert.equal(sim.body.camera.length,2);assert(sim.retina.features[4]||sim.retina.features[5]);for(let i=0;i<80;i++)assert(!sim.step().fallen);assert(sim.body.data.qpos[2]>.30);console.log('Body, sixteen leg muscles, steering joints, neck and both RGB eyes: OK');}finally{sim.dispose();}
