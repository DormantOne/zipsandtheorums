import assert from 'node:assert/strict';
import fs from 'node:fs';
import {loadMujoco} from '../rig/gait/mujoco_loader.mjs';
import {CompanionSim} from '../rig/companion/sim.mjs';
import {makeFounder} from '../rig/companion/brain.mjs';
import {toHeir} from '../rig/core/hybrid.mjs';
import {Rng} from '../rig/core/rng.mjs';
import {makeSuite,runEpisode,summarize} from '../rig/companion/evaluate.mjs';
const mj=await loadMujoco(),sim=new CompanionSim(mj,{genome:toHeir(makeFounder(new Rng(47017)))}),results=[];
try{
 for(const turn of [0,.16,-.16]){
  sim.settings.mode='manual';sim.settings.targetMode='still';sim.manual={speed:.18,turn,headYaw:0,headPitch:.1};sim.reset();
  for(let i=0;i<500;i++)assert(!sim.step().fallen);
  const f=sim.snapshot({images:false});assert(f.metrics.hp>.97);assert.equal(f.metrics.nonfoot,0);
  if(!turn)assert(f.xy[0]>1.4,'the new body must retain the original forward gait');else assert(f.yaw*Math.sign(turn)>1,'the steering joints must turn the body in both directions');
  results.push({test:'manual gait',turn,xy:f.xy,yaw:f.yaw,hp:f.metrics.hp,slip:f.metrics.slip});
 }
 for(const yaw of [-1,1]){sim.settings.mode='manual';sim.manual={speed:0,turn:0,headYaw:yaw,headPitch:.5};sim.reset();for(let i=0;i<250;i++)sim.step();const f=sim.snapshot({images:false});assert(Math.abs(f.head[0]-yaw)<.05,'head must reach its full yaw range without torso collision');assert(Math.abs(f.head[1]-.5)<.05);results.push({test:'physical neck',head:f.head});}
 const starter=JSON.parse(fs.readFileSync(new URL('../starter/ready-to-follow.json',import.meta.url))),follower=[...starter.hybrid.lineages].sort((a,b)=>b.bestVal.quality-a.bestVal.quality)[0],g=Float64Array.from(follower.best);
 const targets=[[1.8,.65,.38],[1.8,-.65,.38],[1.6,0,.38]];
 for(const target of targets){const row=runEpisode(sim,g,{id:'fixed',target,seconds:24,seed:419,targetMode:'still'});assert(!row.fell);assert(row.visible>.9);assert(Math.abs(row.gap-.85)<.25);assert(row.hp>.97);results.push({test:'visual following',target,...row,positions:undefined});}
 for(const targetMode of ['sway','lead','circle']){const row=runEpisode(sim,g,{id:targetMode,target:[1.6,.2,.38],seconds:36,seed:819,targetMode});assert(!row.fell);assert(row.visible>.72,`${targetMode} must retain useful visual contact`);assert(row.progress>.5);results.push({test:'moving visual following',targetMode,...row,positions:undefined});}
 const suite=makeSuite(71611,'hold',0,{count:8,seconds:24}),rows=suite.map(s=>runEpisode(sim,g,s)),score=summarize(rows);
 assert.equal(score.falls,0);assert(score.visible>.75);results.push({test:'new reserved seeds',...score,rows:rows.map(r=>({...r,positions:undefined}))});
 console.log(JSON.stringify(results,null,2));
}finally{sim.dispose();}
