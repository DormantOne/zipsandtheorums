import test from 'node:test';
import assert from 'node:assert/strict';
import {loadMujoco} from '../rig/gait/mujoco_loader.mjs';
import {CompanionSim} from '../rig/companion/sim.mjs';
import {readEyes} from '../rig/companion/vision.mjs';
import {makeFounder} from '../rig/companion/brain.mjs';
import {Rng} from '../rig/core/rng.mjs';
const mj=await loadMujoco();
test('physical RGB eyes distinguish left, right, occluded and covered targets',()=>{
 const s=new CompanionSim(mj,{genome:makeFounder(new Rng(3))});
 try{const capture=target=>{s.setTarget(target);s.updateWorld();return readEyes(s.body);};
  const left=capture([1.8,.6,.38]),right=capture([1.8,-.6,.38]);assert(left.features[4]&&right.features[4]);assert(left.features[0]<0);assert(right.features[0]>0);assert.notDeepEqual(left.rgb[0],right.rgb[0]);
  s.settings.occluder=[1.1,0,.45];const hidden=capture([1.8,0,.38]);assert.equal(hidden.features[4],0);assert.equal(hidden.features[5],0);
  const covered=readEyes(s.body,{blackout:true});assert(covered.rgb.every(a=>a.every(v=>v===0)));assert(covered.features.every(v=>v===0));
 }finally{s.dispose();}
});
test('changing the private world target cannot change a controller input until a new image is rendered',()=>{
 const s=new CompanionSim(mj,{genome:makeFounder(new Rng(3))});
 try{const a=s.makeInputs().slice();s.setTarget([-5,8,.8]);const b=s.makeInputs().slice();assert.deepEqual(a,b);assert.equal(a.length,24);
  // Absolute floor coordinates do not enter the higher brain, either.
  s.body.data.qpos[0]+=3;s.body.data.qpos[1]-=2;assert.deepEqual(s.makeInputs(),a);
 }finally{s.dispose();}
});
test('a restored or improved brain can replace the live brain without resetting the animal or stopping physics',()=>{
 const s=new CompanionSim(mj,{genome:makeFounder(new Rng(3))});
 try{for(let i=0;i<10;i++)s.step();const t=s.t;s.setGenome(makeFounder(new Rng(29)));assert.doesNotThrow(()=>s.step());assert(s.t>t);assert(s.inputs.every(Number.isFinite));}finally{s.dispose();}
});
