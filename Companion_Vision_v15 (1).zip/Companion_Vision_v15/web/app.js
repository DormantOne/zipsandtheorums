const $=id=>document.getElementById(id),clamp=(v,a,b)=>Math.max(a,Math.min(b,v)),fmt=(n,d=1)=>Number.isFinite(n)?n.toFixed(d):'—';
let frame=null,state=null,arena=null,description=null,brain=null,lastFrameAt=0,toastTimer=null,importing=false;
const color={mint:'#a9e0c4',gold:'#dfbc7c',white:'#e5ede1',grid:'#2a4445',muted:'#7d9e8e'};
function toast(message){$('toast').textContent=message;$('toast').classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').classList.remove('show'),4500);}
async function cmd(command,args={}){
  try{const response=await fetch('/api/cmd',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({cmd:command,args})}),result=await response.json();if(!response.ok)throw Error(result.error||'Request failed');return result;}
  catch(e){toast(e.message);throw e;}
}
function fire(command,args){cmd(command,args).catch(()=>{});}
const settings=v=>fire('settings',v);
$('follow').onclick=()=>{settings({mode:'learned'});$('controller').value='learned';fire('run',{on:true});};
$('rest').onclick=()=>{settings({mode:'rest'});$('controller').value='rest';};
$('reset').onclick=()=>{fire('reset');$('targetMode').value='still';settings({targetMode:'still'});};
$('pauseScene').onclick=()=>fire('run',{on:!frame?.running});
$('rate').onchange=e=>fire('rate',{rate:Number(e.target.value)});
$('cameraHome').onclick=()=>arena?.home();
$('targetMode').onchange=e=>settings({targetMode:e.target.value});
for(const id of ['maxSpeed','followGap']){
  let timer;$(id).oninput=e=>{$(id+'Value').textContent=id==='maxSpeed'?`${Math.round(Number(e.target.value)*100)} cm/s`:`${Number(e.target.value).toFixed(2)} m`;clearTimeout(timer);timer=setTimeout(()=>settings({[id]:Number(e.target.value)}),80);};
}
for(const button of document.querySelectorAll('[data-gait]'))button.onclick=()=>{settings({gait:button.dataset.gait});document.querySelectorAll('[data-gait]').forEach(b=>b.classList.toggle('selected',b===button));};
for(const button of document.querySelectorAll('[data-target]'))button.onclick=()=>{const yaw=(frame?.yaw||0)+({left:.52,ahead:0,right:-.52}[button.dataset.target]),p=frame?.xy||[0,0];fire('target',{xyz:[p[0]+1.6*Math.cos(yaw),p[1]+1.6*Math.sin(yaw),.38]});$('targetMode').value='still';};
$('train').onclick=()=>{fire('train');toast('Learning runs alongside the playground. You can keep moving the ball.');};
$('pauseTrain').onclick=()=>fire('pauseTraining');
$('save').onclick=async()=>{try{const r=await cmd('save');toast(r.message||'Progress saved');}catch{}};
$('learningWindow').onchange=e=>fire('trainSettings',{hybridLearnSteps:Number(e.target.value)});
$('evoWindow').onchange=e=>fire('trainSettings',{hybridEvoGens:Number(e.target.value)});
$('learnRate').onchange=e=>fire('trainSettings',{hybridRate:Number(e.target.value)});
$('learnSigma').onchange=e=>fire('trainSettings',{hybridSigma:Number(e.target.value)});
$('stageLearn').onclick=()=>{fire('stage',{stage:'learning'});toast('The stage changes after the current evaluation. Start learning if paused.');};
$('stageEvolve').onclick=()=>{fire('stage',{stage:'evolution'});toast('Offspring will be projected after the current evaluation. Start learning if paused.');};
$('test').onclick=()=>{if(state?.training?.busy)return toast('Pause learning and wait for the current evaluation to finish.');fire('test');toast('Testing the saved mind on the reserved target set…');};
$('blackout').onchange=e=>settings({eyeBlackout:e.target.checked});
$('steering').onchange=e=>settings({steering:e.target.checked});
$('controller').onchange=e=>settings({mode:e.target.value});
for(const id of ['manualSpeed','manualTurn','headYaw','headPitch']){let timer;$(id).oninput=e=>{const v=Number(e.target.value);$(id+'Value').textContent=v.toFixed(2)+(id==='manualSpeed'?' m/s':'');clearTimeout(timer);timer=setTimeout(()=>{const key={manualSpeed:'speed',manualTurn:'turn',headYaw:'headYaw',headPitch:'headPitch'}[id];fire('manual',{[key]:v});$('controller').value='manual';},60);};}
$('import').onclick=()=>$('checkpointFile').click();
$('checkpointFile').onchange=async e=>{const file=e.target.files[0];if(!file)return;if(state?.training?.busy){toast('Pause learning and wait for the current evaluation before restoring.');e.target.value='';return;}
  importing=true;try{const text=await file.text();JSON.parse(text);const r=await fetch('/api/checkpoint',{method:'POST',headers:{'Content-Type':'application/json'},body:text}),j=await r.json();if(!r.ok)throw Error(j.error);toast('Checkpoint restored. Your learning can continue.');await poll();await loadBrain();}catch(err){toast('Restore: '+err.message);}finally{importing=false;e.target.value='';}};
addEventListener('keydown',e=>{if(['INPUT','SELECT','TEXTAREA','BUTTON'].includes(e.target.tagName))return;const k=e.key.toLowerCase();if(k===' '){e.preventDefault();$('rest').click();}else if(k==='r')$('reset').click();else if(['w','s','a','d'].includes(k)){
  const id=k==='w'||k==='s'?'manualSpeed':'manualTurn',step=id==='manualSpeed'?.02:.08,input=$(id),v=clamp(Number(input.value)+(k==='w'||k==='a'?step:-step),Number(input.min),Number(input.max));input.value=v;input.dispatchEvent(new Event('input'));}
});
function showEye(id,encoded){if(!encoded)return;const bytes=Uint8Array.from(atob(encoded),c=>c.charCodeAt(0)),canvas=$(id),ctx=canvas.getContext('2d'),image=ctx.createImageData(64,48);for(let i=0;i<3072;i++){image.data[4*i]=bytes[3*i];image.data[4*i+1]=bytes[3*i+1];image.data[4*i+2]=bytes[3*i+2];image.data[4*i+3]=255;}ctx.putImageData(image,0,0);}
function onFrame(f){frame=f;lastFrameAt=Date.now();arena?.update(f);showEye('eyeLeft',f.vision.rgb?.[0]);showEye('eyeRight',f.vision.rgb?.[1]);
  const vis=f.vision.features,seen=vis[4]||vis[5];$('leftSeen').textContent=vis[4]?'target seen':'searching';$('rightSeen').textContent=vis[5]?'target seen':'searching';$('visionState').textContent=$('blackout').checked?'Both eyes covered':seen?'The red ball is in sight':'Looking for the red ball';$('visionDot').style.background=seen?'#addabb':'#d1aa6a';
  $('gap').innerHTML=fmt(f.metrics.gap,2)+'<small>m</small>';$('eyeLock').innerHTML=Math.round(f.metrics.visible*100)+'<small>%</small>';$('bodySpeed').innerHTML=fmt(f.speed*100,1)+'<small>cm/s</small>';$('hp').innerHTML=fmt(f.metrics.hp*100,1)+'<small>%</small>';
  $('liveMode').textContent=!f.running?'Paused':f.mode==='rest'?'Resting':f.mode==='manual'?'Manual drive':f.mode==='reflex'?'Visual reflex':f.mode==='strict'?'Ternary follower':seen?'Following the ball':'Searching';
  $('pauseScene').textContent=f.running?'Ⅱ':'▶';$('pauseScene').setAttribute('aria-label',f.running?'Pause simulation':'Resume simulation');$('follow').classList.toggle('active',f.mode==='learned');
  if($('inspect').open)drawNetworks();
}
function renderTraining(t){
  const h=t.hybrid,learning=h.stage==='learning';$('train').disabled=t.running||t.testing;$('pauseTrain').disabled=!t.running;$('test').disabled=t.busy||t.testing||!t.best;$('import').disabled=t.busy;$('save').disabled=!t.initialized;
  $('train').textContent=t.running?'✦ Learning continues':t.initialized?'✦ Continue learning':'✦ Start learning';$('pauseTrain').textContent=t.busy&&!t.running?'Finishing trial…':'Pause learning';
  $('bestScore').textContent=t.follower?fmt(t.follower.score.quality*100,1):'—';$('updateCount').textContent=h.updates.toLocaleString();$('lineageCount').textContent=h.counts.lineages;$('nurseryCount').textContent=h.counts.nursery;
  $('windowProgress').textContent=learning?`${h.stageProgress} / ${t.cfg.hybridLearnSteps} this window`:`generation ${t.generation}`;
  $('nurserySub').textContent=h.counts.nurseryPromoted?`${h.counts.nurseryPromoted} promotions · ${h.counts.nurseryBorn} born`:'offspring kept alive';
  $('stageLearning').classList.toggle('on',learning);$('stageEvolution').classList.toggle('on',!learning);$('stageNursery').classList.toggle('on',!learning&&h.counts.nursery>0);
  $('trainBadge').textContent=t.error?'NEEDS ATTENTION':t.testing?'RESERVED EVALUATION':t.busy&&!t.running?'PAUSING AFTER TRIAL':t.running?(learning?'CONTINUOUS LEARNING':'TERNARY EVOLUTION'):'LEARNING PAUSED';
  $('trainNote').textContent=t.error||t.note;$('progressFill').style.width=clamp(learning?h.stageProgress/t.cfg.hybridLearnSteps*100:((t.generation-(h.startedAtGen||0))/t.cfg.hybridEvoGens*100),0,100)+'%';
  $('learnerRows').innerHTML=h.lineages.length?h.lineages.slice().sort((a,b)=>b.quality-a.quality).map(x=>`<tr><td>L${safe(x.lineageId)}</td><td>${safe(x.origin)}</td><td>${safe(x.updates)}</td><td>${fmt(x.quality*100,1)}</td></tr>`).join(''):'<tr><td colspan="4" class="empty">A family of learners will appear here.</td></tr>';
  $('nurseryRows').innerHTML=h.nursery.length?h.nursery.slice().sort((a,b)=>b.quality-a.quality).map(x=>`<tr><td>#${safe(x.id)} · L${safe(x.lineageId)}</td><td>${safe(x.attempts)}</td><td>${safe(x.wins)}</td><td>${fmt(x.quality*100,1)}</td></tr>`).join(''):'<tr><td colspan="4" class="empty">The next completed learning window creates offspring.</td></tr>';
  if(t.holdout)$('testResult').textContent=`${t.holdout.kind==='ternary'?'Ternary':'Continuous'} · reserved score ${fmt(t.holdout.quality*100,1)} · seen ${fmt(t.holdout.visible*100,0)}% · ${t.holdout.falls} falls / ${t.holdout.rows.length} trials`;
  else if(t.testing)$('testResult').textContent='Running the reserved target trials…';
  for(const [id,key] of [['learningWindow','hybridLearnSteps'],['evoWindow','hybridEvoGens'],['learnRate','hybridRate'],['learnSigma','hybridSigma']])if(document.activeElement!==$(id)){
    if(id==='learningWindow'&&!Array.from($(id).options).some(o=>Number(o.value)===t.cfg[key]))$(id).add(new Option(String(t.cfg[key]),t.cfg[key]));$(id).value=t.cfg[key];}
  $('chartFoot').textContent=t.baseline?`Visual-reflex baseline ${fmt(t.baseline.continuous*100,1)} · best validation ${fmt(t.best?.score.quality*100,1)}. The chart zooms to the observed scores. Following, visual contact, and steady footing determine the score.`:'The initial chase comes from a visual-reflex seed. Only measured improvements count as learning.';
  drawChart(t.history);
}
const safe=x=>String(x??'').replace(/[&<>"']/g,s=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[s]));
function canvasSize(canvas){const r=canvas.getBoundingClientRect(),d=Math.min(2,devicePixelRatio),w=Math.max(100,r.width),h=Math.max(80,r.height);if(canvas.width!==Math.round(w*d)||canvas.height!==Math.round(h*d)){canvas.width=Math.round(w*d);canvas.height=Math.round(h*d);}const c=canvas.getContext('2d');c.setTransform(d,0,0,d,0,0);return {c,w,h};}
function drawChart(rows=[]){const {c,w,h}=canvasSize($('progressChart')),L=35,R=12,T=10,B=27;c.clearRect(0,0,w,h);c.font='10px -apple-system, sans-serif';c.textBaseline='middle';
  const values=rows.flatMap(r=>[r.strict,r.learned,r.best]).filter(Number.isFinite),lo=values.length?Math.max(0,Math.floor((Math.min(...values)-.035)*20)/20):0,hi=values.length?Math.min(1,Math.max(lo+.1,Math.ceil((Math.max(...values)+.035)*20)/20)):1;
  for(let i=0;i<=4;i++){const v=lo+(hi-lo)*i/4,y=T+(h-T-B)*(1-i/4);c.strokeStyle=color.grid;c.lineWidth=.6;c.beginPath();c.moveTo(L,y);c.lineTo(w-R,y);c.stroke();c.fillStyle=color.muted;c.fillText(fmt(v*100,Number.isInteger(v*100)?0:1),2,y);}
  if(!rows.length){c.fillStyle='#8da89a';c.textAlign='center';c.fillText('Measured learning progress will appear here',w/2,h/2);c.textAlign='left';return;}
  const x=i=>L+(w-L-R)*i/Math.max(1,rows.length-1),y=v=>T+(h-T-B)*(1-clamp((v-lo)/(hi-lo),0,1));
  for(const [key,col,width] of [['strict',color.gold,1.5],['learned',color.mint,2],['best',color.white,1]]){
    c.strokeStyle=col;c.lineWidth=width;if(key==='best')c.setLineDash([3,4]);else c.setLineDash([]);c.beginPath();rows.forEach((r,i)=>{i?c.lineTo(x(i),y(r[key])):c.moveTo(x(i),y(r[key]));});c.stroke();c.setLineDash([]);
    if(rows.length===1){c.fillStyle=col;c.beginPath();c.arc(x(0),y(rows[0][key]),3,0,Math.PI*2);c.fill();}}
  c.fillStyle=color.muted;c.fillText('start',L,h-8);c.textAlign='right';c.fillText(`${rows.at(-1).step} updates · ${rows.at(-1).generation} generations`,w-R,h-8);c.textAlign='left';
}
async function loadBrain(){try{const r=await fetch('/api/brain');if(r.ok)brain=await r.json();}catch{}}
function drawNetworks(){
  if(!description||!frame)return;const spine=$('spineCanvas').getContext('2d'),W=760,H=440;spine.clearRect(0,0,W,H);const net=description.spine,values=frame.network?.spine||[],positions=net.nodes.map(n=>[30+n.x*700,20+n.y*390]);
  const lookup=new Map(net.nodes.map((n,i)=>[n.id,i]));for(const e of net.edges){const a=positions[lookup.get(e.from)],b=positions[lookup.get(e.to)];if(!a||!b)continue;spine.strokeStyle=e.w<0?'#b37c6c33':'#7cc29f33';spine.lineWidth=.65;spine.beginPath();spine.moveTo(...a);spine.lineTo(...b);spine.stroke();}
  net.nodes.forEach((n,i)=>{const [x,y]=positions[i],v=values[i]||0;spine.fillStyle=v>.08?`rgba(167,224,185,${.4+.6*Math.abs(v)})`:v<-.08?'#c67b78':'#355248';spine.beginPath();spine.arc(x,y,n.group==='rg'?6:3.5,0,Math.PI*2);spine.fill();if(n.group==='desc'||n.group==='rg'){spine.fillStyle='#9bb8a9';spine.font='9px sans-serif';spine.textAlign='center';spine.fillText(n.short||'',x,y-10);}});
  $('limbPhases').innerHTML=['FL','FR','RL','RR'].map((l,i)=>`<div class="limb">${l}<span><i style="width:${frame.ph[i]*100}%"></i></span></div>`).join('');
  if(!brain)return;const c=$('brainCanvas').getContext('2d'),N=brain.N,S=brain.S,A=brain.A,points=Array.from({length:N},(_,i)=>[380+155*Math.cos(i/N*Math.PI*2),220+155*Math.sin(i/N*Math.PI*2)]),inputs=Array.from({length:S},(_,i)=>[30,30+i*380/(S-1)]),outputs=Array.from({length:A},(_,i)=>[708,65+i*310/(A-1)]),activity=frame.network?.brain||[];c.clearRect(0,0,W,H);
  for(let i=0;i<N;i++)for(let k=0;k<3;k++){const j=3*i+k;if(!brain.w[j])continue;const source=brain.src[j],a=source<S?inputs[source]:points[source-S],b=points[i];if(!a)continue;c.strokeStyle=brain.w[j]>0?'#86c6a64d':'#d2917b3d';c.lineWidth=.7;c.beginPath();c.moveTo(...a);c.lineTo(...b);c.stroke();}
  for(let a=0;a<A;a++)for(let i=0;i<N;i++)if(brain.dec[a*N+i]){c.strokeStyle='#d3c58e55';c.beginPath();c.moveTo(...points[i]);c.lineTo(...outputs[a]);c.stroke();}
  points.forEach(([x,y],i)=>{const v=activity[i]||0;c.fillStyle=v>.08?'#a9e2be':v<-.08?'#c18a79':'#48665b';c.beginPath();c.arc(x,y,3.8,0,Math.PI*2);c.fill();});
  c.font='8px sans-serif';c.textAlign='left';inputs.forEach(([x,y],i)=>{c.fillStyle='#9dc7b0';c.fillRect(x-3,y-3,5,5);c.fillStyle='#8fac9c';c.fillText((description.sensors[i]||'').slice(0,25),x+8,y+3);});
  c.textAlign='right';outputs.forEach(([x,y],i)=>{c.fillStyle='#ddc78e';c.fillRect(x-3,y-3,6,6);c.fillStyle='#b2c3a6';c.fillText((description.outputs[i]||'').slice(0,21),x-8,y-8);});c.textAlign='left';
}
$('inspect').ontoggle=()=>{if($('inspect').open){loadBrain().then(drawNetworks);}};
async function poll(){try{const r=await fetch('/api/status',{cache:'no-store'});if(!r.ok)throw Error('Server error');state=await r.json();renderTraining(state.training);$('status').textContent=state.training.error||state.note;const live=Date.now()-lastFrameAt<3000;$('connection').className='connection'+(live?'':' offline');$('connection').innerHTML='<i></i>'+(live?'Live & local':'Reconnecting');if(!description?.ready&&state.liveReady)await loadDescription();}catch(e){$('connection').className='connection offline';$('connection').innerHTML='<i></i>Server offline';$('status').textContent='The local server is not responding. Reopen the Companion launcher.';}}
async function loadDescription(){const r=await fetch('/api/describe');description=await r.json();if(description.ready&&arena){arena.build(description);if(frame)arena.update(frame);}}
async function boot(){
  try{const {Arena}=await import('./arena.js');arena=new Arena($('arena'),{onTarget:xyz=>{fire('target',{xyz});$('targetMode').value='still';},following:()=>$('followCamera').checked});$('canvasFallback').hidden=true;}
  catch(e){$('canvasFallback').textContent='The 3D viewer could not start. Enable WebGL in your browser and reload. The eye feeds and learning controls are still available.';console.error(e);}
  await loadDescription();await loadBrain();await poll();const events=new EventSource('/api/stream');events.onmessage=e=>{try{const m=JSON.parse(e.data);if(m.type==='frame')onFrame(m);else if(m.type==='training'){if(state)state.training=m.state;renderTraining(m.state);loadBrain();}else if(m.type==='event')toast(m.text);}catch(err){console.error(err);}};
  events.onerror=()=>{$('connection').className='connection offline';};setInterval(poll,2000);setInterval(loadBrain,10000);
}
addEventListener('resize',()=>{if(state)drawChart(state.training.history);});boot().catch(e=>{$('status').textContent=e.message;console.error(e);});
