import * as THREE from 'three';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
const tmp=new THREE.Vector3(),q=new THREE.Quaternion();
export class Arena{
  constructor(container,{onTarget=()=>{},following=()=>true}={}){
    this.container=container;this.onTarget=onTarget;this.following=following;this.groups=new Map();this.last=null;this.poses=new Map();
    this.renderer=new THREE.WebGLRenderer({antialias:true,alpha:false,powerPreference:'low-power'});this.renderer.setPixelRatio(Math.min(2,devicePixelRatio));
    this.renderer.shadowMap.enabled=true;this.renderer.shadowMap.type=THREE.PCFSoftShadowMap;this.renderer.outputColorSpace=THREE.SRGBColorSpace;this.renderer.toneMapping=THREE.ACESFilmicToneMapping;this.renderer.toneMappingExposure=1.15;
    container.appendChild(this.renderer.domElement);this.scene=new THREE.Scene();this.scene.background=new THREE.Color('#b7cdc8');this.scene.fog=new THREE.Fog('#b7cdc8',13,36);
    this.camera=new THREE.PerspectiveCamera(39,1,.025,80);this.camera.up.set(0,0,1);this.camera.position.set(2.2,-2.65,1.7);
    this.controls=new OrbitControls(this.camera,this.renderer.domElement);this.controls.target.set(.6,0,.25);this.controls.enableDamping=true;this.controls.dampingFactor=.07;this.controls.maxPolarAngle=Math.PI*.48;this.controls.minDistance=1.4;this.controls.maxDistance=14;
    const hemi=new THREE.HemisphereLight('#eaf7ee','#6a7058',2.3);hemi.up.set(0,0,1);hemi.position.set(0,0,10);this.scene.add(hemi);
    const sun=new THREE.DirectionalLight('#fff4df',3.0);sun.position.set(-2,-4,8);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);sun.shadow.camera.left=-5;sun.shadow.camera.right=5;sun.shadow.camera.top=5;sun.shadow.camera.bottom=-5;sun.shadow.camera.near=.5;sun.shadow.camera.far=20;sun.shadow.normalBias=.025;sun.shadow.bias=-.0001;this.scene.add(sun);this.sun=sun;this.scene.add(sun.target);
    const ground=new THREE.Mesh(new THREE.PlaneGeometry(160,160),new THREE.MeshStandardMaterial({color:'#c5cfaf',roughness:1}));ground.position.z=-.001;ground.receiveShadow=true;this.scene.add(ground);this.ground=ground;
    const grid=new THREE.GridHelper(100,100,'#a1b695','#b5c3a6');grid.rotation.x=Math.PI/2;grid.position.z=.001;grid.material.transparent=true;grid.material.opacity=.35;this.scene.add(grid);
    const ring=new THREE.Mesh(new THREE.RingGeometry(.14,.155,48),new THREE.MeshBasicMaterial({color:'#bb605c',transparent:true,opacity:.5,side:THREE.DoubleSide}));ring.position.z=.006;this.scene.add(ring);this.targetRing=ring;
    this.raycaster=new THREE.Raycaster();let down=null;
    container.addEventListener('pointerdown',e=>{if(e.target!==this.renderer.domElement)return;down=[e.clientX,e.clientY];});
    container.addEventListener('pointerup',e=>{if(!down||Math.hypot(e.clientX-down[0],e.clientY-down[1])>5){down=null;return;}down=null;
      const r=this.renderer.domElement.getBoundingClientRect();this.raycaster.setFromCamera(new THREE.Vector2((e.clientX-r.left)/r.width*2-1,-(e.clientY-r.top)/r.height*2+1),this.camera);
      const point=new THREE.Vector3(),hit=this.raycaster.ray.intersectPlane(new THREE.Plane(new THREE.Vector3(0,0,1),0),point);if(hit&&Math.abs(point.x)<15&&Math.abs(point.y)<15)this.onTarget([point.x,point.y,.38]);});
    new ResizeObserver(()=>this.resize()).observe(container);this.resize();this.draw();
  }
  geometry(g){
    const s=g.size;
    if(g.type===2)return new THREE.SphereGeometry(s[0],24,16);
    if(g.type===3){const geo=new THREE.CapsuleGeometry(s[0],2*s[1],6,16);geo.rotateX(Math.PI/2);return geo;}
    if(g.type===4){const geo=new THREE.SphereGeometry(1,24,16);geo.scale(...s);return geo;}
    if(g.type===5){const geo=new THREE.CylinderGeometry(s[0],s[0],2*s[1],24);geo.rotateX(Math.PI/2);return geo;}
    return new THREE.BoxGeometry(2*s[0],2*s[1],2*s[2]);
  }
  build(description){
    if(this.built)return;this.built=true;
    for(const b of description.bodies){const group=new THREE.Group();this.groups.set(b.id,group);this.scene.add(group);}
    for(const g of description.geoms){if(g.type===0)continue;const mat=new THREE.MeshStandardMaterial({color:new THREE.Color(...g.rgba.slice(0,3)),roughness:g.name?.includes('glass')?.23:.74,metalness:g.name?.includes('glass')?.05:0});
      if(g.name==='torso_geom')mat.color.setRGB(.72,.52,.30);if(g.name?.endsWith('_foot'))mat.color.setRGB(.19,.25,.23);if(g.name?.includes('_shin_geom'))mat.color.setRGB(.67,.46,.25);if(g.name?.includes('_thigh_geom'))mat.color.setRGB(.78,.59,.35);
      const mesh=new THREE.Mesh(this.geometry(g),mat);mesh.position.set(...g.pos);mesh.quaternion.set(g.quat[1],g.quat[2],g.quat[3],g.quat[0]);mesh.castShadow=true;mesh.receiveShadow=true;
      if(g.name==='target_ball'){this.ball=mesh;mesh.position.set(1.8,.1,.38);this.scene.add(mesh);}
      else if(g.name==='vision_screen'){this.screen=mesh;this.scene.add(mesh);mesh.position.set(0,0,-5);}
      else this.groups.get(g.body)?.add(mesh);
    }
    const torso=this.groups.get(description.bodies[0].id);this.torsoId=description.bodies[0].id;
    // Collar is visual, attached to the torso. It never supplies a sensor.
    const collar=new THREE.Mesh(new THREE.BoxGeometry(.045,.292,.148),new THREE.MeshStandardMaterial({color:'#456b60',roughness:.8}));collar.position.set(.255,0,.005);torso.add(collar);
    const trailGeo=new THREE.BufferGeometry();trailGeo.setAttribute('position',new THREE.Float32BufferAttribute(new Float32Array(900),3));this.trail=new THREE.Line(trailGeo,new THREE.LineBasicMaterial({color:'#567d67',transparent:true,opacity:.45}));this.scene.add(this.trail);
  }
  update(f){this.last=f;for(const b of f.bodies)this.poses.set(b.id,b);if(this.ball)this.ball.position.set(...f.target);if(this.screen)this.screen.position.set(...f.screen);this.targetRing.position.set(f.target[0],f.target[1],.005);
    if(this.trail){const a=this.trail.geometry.attributes.position.array;f.trail.forEach((p,i)=>{a[3*i]=p[0];a[3*i+1]=p[1];a[3*i+2]=.009;});this.trail.geometry.setDrawRange(0,f.trail.length);this.trail.geometry.attributes.position.needsUpdate=true;}}
  home(){this.camera.position.set((this.last?.xy[0]||0)+2.2,(this.last?.xy[1]||0)-2.65,1.7);this.controls.target.set((this.last?.xy[0]||0)+.6,this.last?.xy[1]||0,.25);this.controls.update();}
  resize(){const w=this.container.clientWidth,h=this.container.clientHeight;if(!w||!h)return;this.renderer.setSize(w,h);this.camera.aspect=w/h;this.camera.updateProjectionMatrix();}
  draw(){requestAnimationFrame(()=>this.draw());for(const [id,p] of this.poses){const group=this.groups.get(id);if(!group)continue;tmp.set(...p.pos);group.position.lerp(tmp,.45);q.set(p.quat[1],p.quat[2],p.quat[3],p.quat[0]);group.quaternion.slerp(q,.45);}
    if(this.last&&this.following()){const target=tmp.set(this.last.xy[0]+.45,this.last.xy[1],.25),delta=target.clone().sub(this.controls.target).multiplyScalar(.035);this.camera.position.add(delta);this.controls.target.add(delta);this.sun.position.set(this.last.xy[0]-2,this.last.xy[1]-4,8);this.sun.target.position.set(this.last.xy[0],this.last.xy[1],0);}
    this.controls.update();this.renderer.render(this.scene,this.camera);}
}
