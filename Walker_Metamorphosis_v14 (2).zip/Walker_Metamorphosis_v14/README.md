# Walker v14 — Metamorphosis

**Start here:** `OPEN_METAMORPHOSIS_FIRST.txt`. On a Mac, double-click `START_METAMORPHOSIS_MAC.command` (or the equivalent `START_EVOLVE_LEARN_MAC.command`). On Windows, double-click `START_METAMORPHOSIS_WINDOWS.bat`. The full 3-D walker is at **http://127.0.0.1:8796**. All experiment data are kept separately under `data_metamorphosis/`; the older walker projects are not overwritten.

The blue **Start metamorphosis** button initiates automatic cycles. The original strict-fixed recurrent ternary genome evolves in real MuJoCo; the new continuous learning engine trains descendants by paired perturbation (SPSA-style; **not** backpropagation through the physics). A learner retains its full-precision best checkpoint, and can be revisited or slightly mutated in a later learning cycle. Projected strictly ternary offspring **are retained in a bounded nursery even if they do not pass immediate elite admission**; each receives additional MuJoCo mutation evaluations. A nursery offspring can enter the evolutionary elite, or become a new continuous learner with inherited *matching* connection values stored in a shadow genome. Unchanged endpoints/signs inherit learned magnitudes; new or changed connections restart in ternary form.

## Front-page experiments

The main 3-D arena, connectome, behaviour map, friction, muscle model, archive, diagnostic tools, and normal validation history remain. New **Metamorphosis** panels provide:

- A four-node evolution → learning → ternary nursery → next-cycle stage indicator.
- Persistent learner count, nursery count, nursery improvements, and elite promotions.
- Continuous-vs-projected validation-score graph and cumulative nursery-outcome graph.
- Columns for living learning lines, ternary nursery offspring, and every completed learning/return event, including held-out continuous and strict scores.
- A **Download learning JSON** checkpoint, a **Download champion archive** option, and a **Replay best learned walker** button.

**Save both files** to preserve the complete experiment. Previous v13 `WALKER_EVOLVE_LEARN_CHECKPOINT` version-1 learning checkpoints can be imported using the Restore learning checkpoint control after starting a compatible strictly ternary run. An imported v13 learning checkpoint contains no v14 nursery history, since that stage did not exist then. It must match the source run's seed, brain kind, neuron count, friction, and joints.

### Why apparently failed ternary offspring matter

Continuous gains often vanish when every weight is reduced to its sign; this is exactly what the v13 checkpoint showed. v14 tests discrete variants and allows failed-but-distinct ternary offspring to evolve before another learning attempt. **The nursery consumes additional simulated physics evaluations**; it is not a fair equal-compute comparison by default. Ternary offspring and full-precision learners have different activation functions, so use each one's own baseline and compare held-out results, not just a single mixed score.

### Verification and limitations

`npm test` runs the mock-physics and structural regression suites (including the new v14 `metamorphosis_test.mjs`). The launcher additionally installs `@mujoco/mujoco` and `three`, then executes `rig/tests/metamorphosis_mujoco_smoke.mjs` using the real simulation before starting the server. The current build's new lineage engine has not been demonstrated to improve actual MuJoCo walking in this environment; do not treat passing mock tests as evidence of better gait. More detail is in `SMOKE_TEST_REPORT.txt`.

v14 no longer exposes the old Hebbian-plastic comparison controls or a separate Protoneuron GUI. Old implementation modules and legacy tests are retained only for backwards-compatible file reading and reference, not as a second visible interface. The old v13 installation should be kept separately for reproducibility.
