#!/bin/bash
# Walker v14: completely separate port and data from the original strict walker.
cd "$(dirname "$0")" || exit 1
PORT=8796
DIR="$(pwd)/data_metamorphosis"
URL="http://127.0.0.1:$PORT"
export RIG_PORT="$PORT" RIG_DATA_DIR="$DIR" RIG_WORKERS=4
unset RIG_START_STRICT
pause_close(){ read -r -p "Press Enter to close this window." _; }
echo '=== WALKER v14 · METAMORPHOSIS · EVOLVE / LEARN / NURSERY · MuJoCo + strict ternary + continuous heirs ==='
echo 'Port 8796. This launcher does NOT touch the old data_strict or port 8794.'
command -v node >/dev/null 2>&1 || { echo 'Node.js 22+ is required: https://nodejs.org'; pause_close; exit 1; }
node -e "process.exit(Number(process.versions.node.split('.')[0])>=22?0:1)" || { echo 'Node.js 22+ required.'; pause_close; exit 1; }
mkdir -p "$DIR"
if curl -fsS -m 2 "$URL/api/status" >/dev/null 2>&1; then
  echo 'Walker v14 is already running. Opening it.'; open "$URL"; exit 0
fi
if [ ! -d node_modules/@mujoco/mujoco ] || [ ! -d node_modules/three ]; then
  echo 'Installing the MuJoCo + Three.js dependencies (requires internet the first time)...'
  npm install --no-audit --no-fund || { echo 'Dependency install failed; no training process started.'; pause_close; exit 1; }
fi
if [ ! -f "$DIR/.verified_v14" ]; then
  echo 'Running all regression and hybrid tests...'
  node rig/tests/run_all.mjs || { echo 'Regression suite FAILED. No server started.'; pause_close; exit 1; }
  echo 'Running real-MuJoCo controller smoke test...'
  node rig/tests/metamorphosis_mujoco_smoke.mjs || { echo 'Real MuJoCo smoke FAILED. No server started.'; pause_close; exit 1; }
  date > "$DIR/.verified_v14"
fi
rm -f "$DIR/server.pid"
RIG_START_STRICT=0 nohup node rig/server.mjs >> "$DIR/server.log" 2>&1 &
PID=$!
command -v caffeinate >/dev/null && caffeinate -is -w "$PID" >/dev/null 2>&1 &
for i in $(seq 1 80); do
  [ "$(cat "$DIR/server.pid" 2>/dev/null)" = "$PID" ] && break
  kill -0 "$PID" 2>/dev/null || break
  sleep 0.2
done
if ! kill -0 "$PID" 2>/dev/null; then
  echo 'Server did not start. Last lines:'; tail -25 "$DIR/server.log"; pause_close; exit 1
fi
open "$URL"
echo "Walker v14 running at $URL · PID $PID"
echo 'Press the blue START METAMORPHOSIS · EVOLVE / LEARN / NURSERY button in the page.'
echo 'For a permanent archive, export BOTH the champion file and the learning checkpoint.'
