@echo off
cd /d "%~dp0"
set "RIG_PORT=8796"
set "RIG_DATA_DIR=%CD%\data_metamorphosis"
set "RIG_WORKERS=4"
set "RIG_START_STRICT="
echo === WALKER v14 EVOLVE ^<--^> LEARN : dedicated port 8796 ===
where node >nul 2>&1
if errorlevel 1 (echo Node.js 22+ is needed. & goto :fail)
if not exist data_metamorphosis mkdir data_metamorphosis
if not exist node_modules\@mujoco\mujoco (
 call npm install --no-audit --no-fund
 if errorlevel 1 goto :fail
)
if not exist node_modules\three (
 call npm install --no-audit --no-fund
 if errorlevel 1 goto :fail
)
if not exist data_metamorphosis\.verified_v14 (
 node rig\tests\run_all.mjs
 if errorlevel 1 goto :fail
 node rig\tests\metamorphosis_mujoco_smoke.mjs
 if errorlevel 1 goto :fail
 echo verified>data_metamorphosis\.verified_v14
)
set "RIG_START_STRICT=0"
start "Walker v14" /min cmd /c "node rig\server.mjs >> data_metamorphosis\server.log 2>&1"
timeout /t 3 >nul
start "" http://127.0.0.1:8796
echo Open the page and click START METAMORPHOSIS.
exit /b 0
:fail
echo An installation/test failed. Server was NOT started.
pause
exit /b 1
