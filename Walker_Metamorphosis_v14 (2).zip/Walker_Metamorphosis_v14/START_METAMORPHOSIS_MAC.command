#!/bin/bash
cd "$(dirname "$0")" || exit 1
exec bash ./START_EVOLVE_LEARN_MAC.command
