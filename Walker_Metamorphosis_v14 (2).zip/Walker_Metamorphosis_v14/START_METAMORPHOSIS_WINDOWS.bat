@echo off
cd /d "%~dp0"
call START_EVOLVE_LEARN_WINDOWS.bat
