@echo off
cd /d "%~dp0"
echo Gracefully stopping evolve-learn walker on port 8796...
curl -s --max-time 5 -X POST -H "Content-Type: application/json" -d "{\"cmd\":\"shutdown\"}" http://127.0.0.1:8796/api/cmd
echo.
echo The v12 strict walker on port 8794 is not affected.
