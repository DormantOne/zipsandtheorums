@echo off
cd /d "%~dp0"
call STOP_EVOLVE_LEARN_WINDOWS.bat
