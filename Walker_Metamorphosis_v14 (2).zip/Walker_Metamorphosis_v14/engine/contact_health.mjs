export const CONTACT_HEALTH_VERSION='nonfoot-health-v3-physics-ticks';

// Every 4 ms physics interval is sampled. The union of its two boundary
// contacts is charged conservatively; no force threshold or scraping grace.
export class ContactHealth{
  constructor(names){this.names=names;this.ticks=0;this.badTicks=0;this.kneeTicks=0;this.byPart=Object.fromEntries(names.map(n=>[n,0]));this.maxConsecutive=0;this.consecutive=0}
  step(parts,kneeContact=false){
    const bad=parts.size>0;this.ticks++;if(bad)this.badTicks++;
    if(kneeContact)this.kneeTicks++;
    this.consecutive=bad?this.consecutive+1:0;this.maxConsecutive=Math.max(this.maxConsecutive,this.consecutive);
    for(const n of parts)if(n in this.byPart)this.byPart[n]++;
    return bad;
  }
  /* v7.0 early exit: charge `ticks` unrun physics ticks as non-foot contact,
   * attributed to the parts that were touching when the rollout stopped.
   * Additive; nothing calls it unless a rollout opted into early exit. */
  chargeRemainder(ticks,parts=[]){
    const n=Math.max(0,Math.trunc(ticks));this.ticks+=n;this.badTicks+=n;this.consecutive+=n;
    this.maxConsecutive=Math.max(this.maxConsecutive,this.consecutive);
    for(const p of parts)if(p in this.byPart)this.byPart[p]+=n;
    return n;
  }
  snapshot(dt){
    const n=Math.max(1,this.ticks),fraction=this.badTicks/n;
    return {version:CONTACT_HEALTH_VERSION,health:1-fraction,contactFree:this.badTicks===0,
      contactFraction:fraction,contactSeconds:this.badTicks*dt,kneeContactFraction:this.kneeTicks/n,
      kneeContactSeconds:this.kneeTicks*dt,maxContactSeconds:this.maxConsecutive*dt,
      secondsByPart:Object.fromEntries(this.names.map(k=>[k,this.byPart[k]*dt])),sampleDt:dt};
  }
}
