import {clamp,num,quantile,mean} from './utils.mjs';
import {FOOT_SLIP_DEFAULTS} from './foot_slip.mjs';
import {sustainedGait} from './sustained_gait.mjs';

/* Dual constitution.
 * WALK: clean forward COM speed × sustained-step factor × completion × strict bank contact health. Positive forward
 * translation during any non-foot contact interval is blocked; retreat counts.
 * TARGET: stage-specific target goal × strict bank contact health.
 * Both tasks also multiply by exp(-worst individual foot slide / 0.05 m).
 */
export const DIFFICULTY_GAIT_VERSION='walk-or-target-v4-sustained-steps';

export function difficultyGaitScore({taskMode='walk',goalScore,cleanWalkSpeedMps,distanceM,health,footDragIndex=0}={}){
  const contactHealth=clamp(num(health),0,1),d=Math.max(0,num(distanceM));
  const footSlipHealth=Math.exp(-Math.max(0,num(footDragIndex))),h=contactHealth*footSlipHealth;
  const safety={health:h,contactHealth,footSlipHealth};
  if(taskMode==='target'){
    const g=clamp(num(goalScore),0,1);return {fitness:g*h,goalScore:g,cleanWalkSpeedMps:0,distanceM:d,...safety};
  }
  const v=Math.max(0,num(cleanWalkSpeedMps));return {fitness:v*h,goalScore:0,cleanWalkSpeedMps:v,distanceM:d,...safety};
}

export function aggregateDifficultyGait(rows){
  const rs=[...(rows||[])],taskMode=rs.some(r=>r?.taskMode==='target')?'target':'walk';
  if(!rs.length)return {...difficultyGaitScore({taskMode,goalScore:0,cleanWalkSpeedMps:0,distanceM:0,health:0}),taskMode,goalMean:0,goalQ25:0,walkSpeedMean:0,walkSpeedQ25:0,distanceMean:0,distanceQ25:0,healthMean:0,healthQ25:0,healthMin:0,forwardSpeedMean:0,forwardSpeedQ25:0,contactMean:1,dragMean:0};
  const goals=rs.map(r=>clamp(num(r.targetGoalScore),0,1));
  const walkSpeeds=rs.map(r=>Math.max(0,num(r.cleanWalkSpeedMps)));
  const gaitEvidence=rs.map(sustainedGait),sustainedSpeeds=walkSpeeds.map((v,i)=>v*gaitEvidence[i].factor);
  const walkDistances=rs.map(r=>Math.max(0,num(r.cleanWalkDistanceM)));
  const targetDistances=rs.map(r=>Math.max(0,num(r.targetDistanceM,r.forwardDistanceM)));
  const distances=taskMode==='target'?targetDistances:walkDistances;
  const healths=rs.map(r=>1-clamp(num(r.nonfootGroundContactFraction,r.gait?.nonfootGeometricContactFraction??1),0,1));
  const speeds=rs.map(r=>Math.max(0,num(r.forwardSpeedMps)));
  const contacts=rs.map(r=>clamp(num(r.nonfootGroundContactFraction,r.gait?.nonfootGeometricContactFraction??1),0,1));
  const drags=rs.map(r=>Math.max(0,r.footSlip?num(r.footSlip.maxSlipM)/FOOT_SLIP_DEFAULTS.scaleM:num(r.footDragIndex)));
  const groundHealths=healths.map((h,i)=>h*Math.exp(-drags[i]));
  const distanceQ25=quantile(distances,.25),healthQ25=quantile(groundHealths,.25),contactHealthMin=Math.min(...healths),goalQ25=quantile(goals,.25),walkSpeedQ25=quantile(walkSpeeds,.25);
  const dragMax=Math.max(...drags),footSlipHealthMin=Math.exp(-dragMax),healthMin=contactHealthMin*footSlipHealthMin;
  const sustainedSpeedQ25=quantile(sustainedSpeeds,.25);
  return {...difficultyGaitScore({taskMode,goalScore:goalQ25,cleanWalkSpeedMps:sustainedSpeedQ25,distanceM:distanceQ25,health:contactHealthMin,footDragIndex:dragMax}),taskMode,
    sustainedSpeedQ25,gaitFactorQ25:quantile(gaitEvidence.map(g=>g.factor),.25),
    repeatableGaitRate:mean(gaitEvidence.map(g=>g.repeatable?1:0)),
    lateAutonomousDistanceQ25:quantile(gaitEvidence.map(g=>num(g.lateAutonomousDistanceM)),.25),
    goalMean:mean(goals),goalQ25,walkSpeedMean:mean(walkSpeeds),walkSpeedQ25,
    distanceMean:mean(distances),distanceQ25,healthMean:mean(groundHealths),healthQ25,healthMin,contactHealthMin,footSlipHealthMin,
    footSlipWorstM:dragMax*FOOT_SLIP_DEFAULTS.scaleM,
    forwardSpeedMean:mean(speeds),forwardSpeedQ25:quantile(speeds,.25),contactMean:mean(contacts),dragMean:mean(drags),dragMax};
}

export function formulaText(cfg={}){
  const safety='minimum(contact health) × exp(−worst foot slide / 0.05 m)';
  const rule=' Any non-foot floor contact blocks positive progress; retreat counts. Grounded foot sliding directly reduces fitness; the worst foot in the worst trial governs. Only 2 mm/s of solver jitter is ignored.';
  if(cfg?.taskMode==='target')return `TARGET: R = Q25(task-stage score) × ${safety}. Curriculum: reach → reach+stop → smooth follow → follow-then-stop → delayed shift-then-stop.${rule}`;
  return `WALK: R = Q25(clean forward COM speed × sustained-step factor × completion) × ${safety}. The step factor ranges from 0.10 to 1 using repeated steps, multiple feet, progress across time, and passive-relative total and second-half progress. The three target channels are zero.${rule}`;
}
