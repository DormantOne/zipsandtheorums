/* engine/eval_pool.mjs — parallel candidate evaluation.
 *
 * WHY. A generation is a few hundred independent rollouts and each one is
 * single-threaded MuJoCo; the brain costs next to nothing. The measured
 * bottleneck was never the network, it was one core doing all the physics.
 *
 * WHAT IT GUARANTEES. A job is (genome, scenarios, steps, physics spec,
 * early-exit rule). Every worker thread owns a private MuJoCo instance and
 * builds its runtimes exactly as the engine does, and every rollout resets
 * its MjData from the scenario seed, so a pooled result is bit-identical to
 * the same rollout on the engine's own thread and does not depend on which
 * worker ran it or in what order (tests/parallel_eval_test.mjs checks the
 * whole result object, field by field). Results are returned in job order.
 *
 * WHAT IT DOES NOT DO. It never chooses anything. Ranking, selection,
 * aggregation and every KG decision stay on the engine thread.
 */
import {Worker} from 'node:worker_threads';
import os from 'node:os';

export const EVAL_POOL_VERSION='eval-pool-v1-worker-threads';

export function defaultPoolSize(requested=0){
  const env=Number(process.env.WALKER_EVAL_WORKERS);
  const cores=Math.max(1,typeof os.availableParallelism==='function'?os.availableParallelism():os.cpus().length);
  const want=Number.isFinite(env)&&env>0?env:Number(requested)>0?Number(requested):(cores<=2?cores:cores-1);
  return Math.max(1,Math.min(16,Math.trunc(want)));
}

export class EvalPool{
  constructor({size=0}={}){
    this.size=defaultPoolSize(size);this.workers=[];this.idle=[];this.queue=[];this.pending=new Map();
    this.nextId=1;this.closed=false;this.failed=null;this.stats={jobs:0,rollouts:0,busyMs:0,wallMs:0,startedAt:Date.now()};
    this._ready=null;
  }
  ready(){
    if(this._ready)return this._ready;
    this._ready=Promise.all(Array.from({length:this.size},()=>new Promise((resolve,reject)=>{
      /* Deliberately NOT unref'd: an engine awaiting a result must keep the
       * process alive. Shutdown paths call close() or process.exit(). */
      const w=new Worker(new URL('./eval_worker.mjs',import.meta.url));
      const onReady=m=>{if(m?.type==='ready'){w.off('message',onReady);w.off('error',onErr);this._attach(w);resolve()}};
      const onErr=e=>{reject(e)};
      w.on('message',onReady);w.once('error',onErr);w.postMessage({type:'init'});
    })));
    return this._ready;
  }
  _attach(w){
    this.workers.push(w);this.idle.push(w);
    w.on('message',m=>{
      if(m?.type!=='result'&&m?.type!=='error')return;
      const p=this.pending.get(m.id);this.pending.delete(m.id);w.__job=null;this.idle.push(w);
      if(p){
        if(m.type==='error')p.reject(new Error(`eval worker failed: ${m.error}`));
        else{this.stats.busyMs+=m.ms||0;this.stats.jobs++;this.stats.rollouts+=m.rows.length;p.resolve(m.rows)}
      }
      this._pump();
    });
    w.on('error',e=>this._fail(e));
    w.on('exit',code=>{if(!this.closed&&code!==0)this._fail(new Error(`eval worker exited with code ${code}`))});
  }
  _fail(e){
    if(this.failed)return;this.failed=e;
    for(const [,p] of this.pending)p.reject(e);this.pending.clear();
    for(const q of this.queue)q.reject(e);this.queue=[];
    this.close();
  }
  _pump(){
    while(this.idle.length&&this.queue.length){
      const w=this.idle.pop(),q=this.queue.shift(),id=this.nextId++;
      this.pending.set(id,q);w.__job=id;
      // A Float64Array genome is copied by structured clone; nothing is shared.
      w.postMessage({type:'job',id,job:q.job});
    }
  }
  run(job){
    if(this.closed||this.failed)return Promise.reject(this.failed||new Error('evaluation pool is closed'));
    return new Promise((resolve,reject)=>{this.queue.push({job,resolve,reject});this._pump()});
  }
  /* Evaluate many jobs; results come back in job order. `onDone` is called
   * after each job (the engine uses it for its heartbeat). */
  async evaluate(jobs,{onDone=null}={}){
    await this.ready();const t0=Date.now();
    const out=await Promise.all(jobs.map(j=>this.run(j).then(rows=>{onDone?.();return rows})));
    this.stats.wallMs+=Date.now()-t0;return out;
  }
  summary(){
    const s=this.stats,wall=Math.max(1,s.wallMs);
    return {version:EVAL_POOL_VERSION,workers:this.size,jobs:s.jobs,rollouts:s.rollouts,
      parallelSpeedup:Number((s.busyMs/wall).toFixed(2)),failed:this.failed?String(this.failed.message||this.failed):null};
  }
  async close(){
    if(this.closed)return;this.closed=true;
    await Promise.allSettled(this.workers.map(w=>w.terminate()));this.workers=[];this.idle=[];
  }
}
