/* engine/eval_worker.mjs — one evaluation thread of the parallel pool.
 *
 * Each thread owns a private MuJoCo WASM instance and builds its physics
 * runtimes EXACTLY as FoundryEngine.createPhysicsRuntime does (same plant
 * options, calibrateStanding + probe on the evaluation buffer, same run
 * configuration). A rollout resets its MjData from the scenario seed, so a
 * result depends only on (genome, scenario, steps, physics spec) and is
 * bit-identical to the same rollout on the engine's own thread — the pool's
 * test proves that rather than assuming it.
 */
import {parentPort} from 'node:worker_threads';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {WalkerPlant,PLANT} from './plant.js';
import {makeTernaryController} from './ternary.mjs';

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const ROOT=path.resolve(__dirname,'..');
let mujoco=null;
const runtimes=new Map();

async function loadMujoco(){
  if(mujoco)return mujoco;
  const mod=await import('@mujoco/mujoco'),load=mod.default||mod,require=createRequire(import.meta.url);
  let opts={};
  try{
    const entry=require.resolve('@mujoco/mujoco'),dir=path.dirname(entry),localWasm=path.join(ROOT,'engine','vendor','mujoco.wasm');
    opts={locateFile:p=>(String(p).endsWith('.wasm')&&fs.existsSync(localWasm))?localWasm:path.join(dir,p)};
  }catch{}
  try{mujoco=await load(opts)}catch(e){mujoco=await load()}
  return mujoco;
}
function runtimeFor(spec){
  const key=JSON.stringify([spec.legScale,spec.frictionMu,spec.run]);
  let rt=runtimes.get(key);if(rt)return rt;
  const s=spec.legScale;
  const plant=new WalkerPlant(mujoco,{frictionMu:spec.frictionMu,thighLength:PLANT.thighLength*s,shinLength:PLANT.shinLength*s});
  const evalData=new mujoco.MjData(plant.model),passiveData=new mujoco.MjData(plant.model);
  plant.calibrateStanding(evalData);plant.probe(evalData);plant.configure(spec.run);
  rt={plant,evalData,passiveData};runtimes.set(key,rt);
  while(runtimes.size>6){const [k,old]=runtimes.entries().next().value;for(const h of [old.evalData,old.passiveData,old.plant.model])try{h.delete?.()}catch{};runtimes.delete(k)}
  return rt;
}
function runJob(job){
  const rt=runtimeFor(job.physics),rows=[];
  for(const scenario of job.scenarios){
    if(job.controller?.kind!=='ternary')throw new Error(`eval worker cannot run controller kind ${job.controller?.kind}`);
    const c=makeTernaryController(job.controller.genome,{lesion:job.controller.lesion??null});
    const r=rt.plant.rollout({control:c.control,hidden:null,steps:job.steps,scenario,data:rt.evalData,passiveData:rt.passiveData,
      record:false,recordStride:2,earlyExit:job.earlyExit||null});
    delete r.frames;rows.push(r);
  }
  return rows;
}
parentPort.on('message',async msg=>{
  try{
    if(msg?.type==='init'){await loadMujoco();parentPort.postMessage({type:'ready'});return}
    if(msg?.type==='job'){
      await loadMujoco();
      const t0=performance.now(),rows=runJob(msg.job);
      parentPort.postMessage({type:'result',id:msg.id,rows,ms:performance.now()-t0});
      return;
    }
  }catch(e){
    parentPort.postMessage({type:'error',id:msg?.id??null,error:String(e?.stack||e)});
  }
});
