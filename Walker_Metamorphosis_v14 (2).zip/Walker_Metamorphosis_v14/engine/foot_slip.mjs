import {clamp} from './utils.mjs';

export const FOOT_SLIP_VERSION='grounded-foot-surface-velocity-v2';
// Fixed measurement constants, outside the evolutionary search grammar.
// 2 mm/s allows solver jitter; 10 nm is only a roundoff allowance at the plane.
// Neither is a walking target, a swing-clearance target, or an injury threshold.
export const FOOT_SLIP_DEFAULTS=Object.freeze({toleranceMps:.002,scaleM:.05,contactEpsilonM:1e-8});

export function stanceFraction(beforeGap,afterGap,limit=0){
  if(beforeGap<=limit&&afterGap<=limit)return 1;
  if(beforeGap>limit&&afterGap>limit)return 0;
  return clamp((limit-Math.min(beforeGap,afterGap))/Math.abs(afterGap-beforeGap),0,1);
}

// Exact instantaneous velocity at MuJoCo's sphere-plane contact point.
// MuJoCo cvel is [angular, linear], world-oriented at the body's ROOT subtree
// COM, not the shin origin or foot centre. Translate that spatial velocity to
// the contact point with omega x offset, then discard the vertical component.
// MuJoCo places the point halfway between the sphere bottom and floor. This
// matters with soft penetration: using the undeformed radius would mislabel
// some solver-sticking/rolling contacts as sliding.
// Requires current mj_kinematics -> mj_comPos -> mj_comVel, in that order.
// Read typed views directly: no contact ClassHandles or WASM buffer allocations.
export function footSurfaceSpeed(data,siteId,bodyId,rootId,radius){
  const p=3*siteId,b=6*bodyId,c=3*rootId,P=data.site_xpos,V=data.cvel,C=data.subtree_com;
  const dx=P[p]-C[c],dy=P[p+1]-C[c+1],dz=(P[p+2]-radius)/2-C[c+2];
  const vx=V[b+3]+V[b+1]*dz-V[b+2]*dy;
  const vy=V[b+4]+V[b+2]*dx-V[b]*dz;
  return Math.hypot(vx,vy);
}

// Sphere against the stationary horizontal floor. Actual contact margins are
// supplied by the plant; the 1 mm non-foot safety buffer is NOT used for feet.
// Integrate only grounded time. At touchdown/liftoff use the grounded endpoint
// velocity, so tangential motion in the airborne endpoint is never called drag.
export class FootSlip{
  constructor(names,radius,contactMargins=names.map(()=>0)){
    this.names=names;this.radius=radius;
    this.contactLimits=Float64Array.from(contactMargins,x=>x+FOOT_SLIP_DEFAULTS.contactEpsilonM);
    this.gaps=new Float64Array(names.length);this.speeds=new Float64Array(names.length);
    this.slipM=new Float64Array(names.length);
    this.contactSeconds=new Float64Array(names.length);this.slidingSeconds=new Float64Array(names.length);
    this.contactFeet=new Uint8Array(names.length);this.slidingFeet=new Uint8Array(names.length);
    this.intervalSlidingFeet=new Uint8Array(names.length);
    this.intervalStart=new Float64Array(names.length);this.intervalEnd=new Float64Array(names.length);
    this.ticks=0;this.anySlidingSeconds=0;this.isSliding=false;this.intervalSliding=false;
  }
  sample(f,data,siteId,bodyId,rootId){
    this.gaps[f]=data.site_xpos[3*siteId+2]-this.radius;
    this.speeds[f]=footSurfaceSpeed(data,siteId,bodyId,rootId,this.radius);
    this.contactFeet[f]=this.gaps[f]<=this.contactLimits[f]?1:0;
    this.slidingFeet[f]=this.contactFeet[f]&&this.speeds[f]>FOOT_SLIP_DEFAULTS.toleranceMps?1:0;
    if(this.slidingFeet[f])this.isSliding=true;
  }
  prime(data,siteIds,bodyIds,rootIds){
    this.isSliding=false;
    for(let f=0;f<this.names.length;f++)this.sample(f,data,siteIds[f],bodyIds[f],rootIds[f]);
  }
  step(data,siteIds,bodyIds,rootIds,dt){
    this.ticks++;this.isSliding=false;this.intervalSliding=false;this.intervalSlidingFeet.fill(0);
    this.intervalStart.fill(1);this.intervalEnd.fill(0);
    for(let f=0;f<this.names.length;f++){
      const beforeGap=this.gaps[f],beforeSpeed=this.speeds[f],beforeContact=this.contactFeet[f];
      this.sample(f,data,siteIds[f],bodyIds[f],rootIds[f]);
      const fraction=stanceFraction(beforeGap,this.gaps[f],this.contactLimits[f]);
      if(fraction<=0)continue;
      const groundedDt=dt*fraction;
      this.contactSeconds[f]+=groundedDt;
      // Both endpoints grounded: integrate the linearly interpolated speed
      // above tolerance. One grounded endpoint: use that endpoint on the
      // prorated contact interval. Never average opposing velocity vectors.
      const a=(beforeContact?beforeSpeed:this.speeds[f])-FOOT_SLIP_DEFAULTS.toleranceMps;
      const b=(this.contactFeet[f]?this.speeds[f]:beforeSpeed)-FOOT_SLIP_DEFAULTS.toleranceMps;
      const peak=Math.max(a,b);
      if(peak<=0)continue;
      const activeFraction=a>=0&&b>=0?1:peak/Math.abs(b-a);
      const excessMean=a>=0&&b>=0?(a+b)/2:peak*activeFraction/2;
      this.slipM[f]+=excessMean*groundedDt;this.slidingSeconds[f]+=activeFraction*groundedDt;
      this.intervalSlidingFeet[f]=1;this.intervalSliding=true;
      const groundStart=beforeContact?0:1-fraction;
      this.intervalStart[f]=groundStart+(a<0?1-activeFraction:0)*fraction;
      this.intervalEnd[f]=groundStart+(b<0?activeFraction:1)*fraction;
    }
    // Union of the (at most four) drag intervals for episode telemetry.
    let seen=0,end=0,union=0;
    for(let k=0;k<this.names.length;k++){
      let next=-1,start=Infinity;
      for(let f=0;f<this.names.length;f++)if(!(seen&(1<<f))&&this.intervalSlidingFeet[f]&&this.intervalStart[f]<start){next=f;start=this.intervalStart[f]}
      if(next<0)break;
      seen|=1<<next;const stop=this.intervalEnd[next];
      union+=Math.max(0,stop-Math.max(start,end));end=Math.max(end,stop);
    }
    this.anySlidingSeconds+=dt*union;
    return this.intervalSliding||this.isSliding;
  }
  snapshot(){
    const maxSlipM=Math.max(0,...this.slipM),worstIndex=this.slipM.indexOf(maxSlipM);
    return {version:FOOT_SLIP_VERSION,...FOOT_SLIP_DEFAULTS,maxSlipM,
      health:Math.exp(-maxSlipM/FOOT_SLIP_DEFAULTS.scaleM),slideFree:maxSlipM===0,
      worstFoot:maxSlipM>0?this.names[worstIndex]:null,sliding:this.isSliding,
      contactFeet:this.names.filter((_,i)=>this.contactFeet[i]),
      slidingFeet:this.names.filter((_,i)=>this.slidingFeet[i]),
      slidingDuringInterval:this.intervalSliding,
      anySlidingSeconds:this.anySlidingSeconds,samples:this.ticks,
      byFoot:Object.fromEntries(this.names.map((n,i)=>[n,{
        state:this.slidingFeet[i]?'dragging':this.contactFeet[i]?'contact':'airborne',
        tangentialSpeedMps:this.speeds[i],gapM:this.gaps[i],contactLimitM:this.contactLimits[i],
        slipM:this.slipM[i],contactSeconds:this.contactSeconds[i],slidingSeconds:this.slidingSeconds[i]}]))};
  }
}
