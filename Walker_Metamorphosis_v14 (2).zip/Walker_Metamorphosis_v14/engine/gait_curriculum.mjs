import {clamp,num} from './utils.mjs';
import {GAIT_REQUIREMENTS} from './sustained_gait.mjs';

/* CYCLIC RUNG CURRICULUM  (ported from the 2-D liquid dog's cycling gates)
 *
 * Three rungs in a fixed order -- posture, footfalls, distance -- ordered by
 * LEARNABILITY rather than importance. Standing is learnable from a random
 * controller; footfalls once you can stand; distance only once you have
 * footfalls. The order never changes. What repeats is the whole cycle.
 *
 * Two rules carry the whole idea and both are load-bearing:
 *
 *   1) Rungs are CUMULATIVE. Clearing one demotes it to a multiplicative
 *      constraint on every later rung instead of retiring it, and a revisit
 *      re-applies it as a HARD gate. That is what stops the distance rung
 *      from quietly trading away the reliability the earlier rungs bought.
 *
 *   2) The rung score is TRAINING RANK ONLY. It never becomes the objective
 *      of record. `distance` returns the untouched WALK reward verbatim, so a
 *      one-rung curriculum is bit-identical to the pre-curriculum engine, and
 *      champions, yardstick probes, fossils, the plateau monitor and every
 *      paired KG comparison keep measuring exactly what they measured before.
 *      (Liquid dog's own rule: champions are always judged on the real
 *      objective, whatever gate is currently active.)
 *
 * WHY THE BUDGETS LOOK LIKE THIS. Liquid dog reports its own failure mode
 * honestly: cycling chopped 320 uninterrupted generations of distance into
 * 60-to-70-generation chunks, and each chunk reset the mutation size and the
 * stagnation tracker and spent its first stretch re-climbing ground it had
 * already covered. It calls that FRAGMENTATION and blames it for 0.05 m/s.
 * So here: the warm-up rungs are short and bounded, the distance rung is
 * deliberately unbounded within its visit, and a rung change never resets the
 * plateau monitor, the mutation state, or the population. A revisit is a
 * detour, not a restart.
 *
 * WHAT IS NOT CLAIMED. These are ordinary walker measurements recombined into
 * a ranking; no new physics, no new sensor, no reference trajectory, no phase
 * or clock input, no prescribed leg-phase relationship. The footfall rung
 * scores footfall DISTRIBUTION (how many steps, across how many feet, how
 * evenly, sustained over how much of the episode). The walker has no
 * inter-step interval statistic, so it is not scoring footfall RHYTHM, and
 * this module deliberately does not add one.
 */
export const GAIT_CURRICULUM_VERSION='cyclic-rung-curriculum-v1';

/* Anti-statue reference. Liquid dog's "liveliness" clause exists because
 * "do not hurt yourself" is won perfectly by locking every joint, and that
 * animal is a genetic dead end. The walker's cheapest honest liveliness
 * evidence is how far a foot is relocated; the reference is the plant's own
 * step-detection scale rather than a new tuned constant. */
export const LIVELINESS_REFERENCE_M=0.04;

/* Harm reference. Non-foot ground contact and planted-foot sliding are the
 * two things the WALK constitution already pays for. Both are normalised
 * against the legal-contact limit the developmental ladder already uses
 * (phenotype.js: nonfoot <= 0.08) and the established slide scale. */
export const CONTACT_HARM_LIMIT=0.08;
export const SLIDE_HARM_LIMIT=1.0;
export const HARM_TOLERANCE=1.25;   // liquid dog's impact_norm <= 1.25 pass bar
export const FOOTFALL_PASS=0.72;    // liquid dog's gate-2 bar and gate-3 floor
export const DISTANCE_PASS_MPS=0.06;

export const RUNG_ORDER=Object.freeze(['posture','footfalls','distance']);
export const RUNG_TARGETS=Object.freeze(['A','B','full']);

/* CYCLING GENERATIONS. Per-visit generation budgets, in liquid dog's shape:
 * the first visit of a run is the expensive one because it is climbing from
 * random controllers, and later visits are cheap because a population that
 * can already stand clears rung 1 in a generation or two.
 *
 * Liquid dog's own numbers are (20, 30, 100) then (6, 10, 150) -- note that
 * its distance gate IS bounded. v6.18.x made the distance rung unbounded to
 * avoid the fragmentation its README describes, and a round-147 biopsy showed
 * the cost of overcorrecting: at `phaseMinGens 480` no lane had completed a
 * single cycle in 147 generations, so the ladder never revisited, no cycle
 * fossil was ever frozen, and 14 of 20 lanes had drifted back to floor
 * contact with nothing to pull them back.
 *
 * The right reading of liquid dog's post-mortem is not "never bound the
 * distance gate" but "do not RESET anything when you leave it, and give it a
 * long run". So the distance rung is bounded and generous -- 360 then 420
 * generations, against liquid dog's 100/150 -- and a rung change still resets
 * no sigma, no stagnation tracker, no monitor and no population. A cycle
 * completes on a schedule; nothing is fragmented.
 *
 * 0 restores unbounded, in which case only the engine's plateau ends a visit.
 * The first cycle totals 460 generations, close to the engine's own
 * `phaseMinGens` lease of 480, so a cycle and a phase stay commensurable. */
export const FIRST_CYCLE_BUDGET=Object.freeze({posture:40,footfalls:60,distance:360});
export const LATER_CYCLE_BUDGET=Object.freeze({posture:12,footfalls:20,distance:420});

export function rungName(v){return RUNG_ORDER.includes(v)?v:RUNG_ORDER[0]}
export function rungIndex(v){const i=RUNG_ORDER.indexOf(v);return i<0?0:i}

// ── the measurements every rung reads ──────────────────────────────────────
/* One extractor, so training rank, pass tests, the behaviour descriptor and
 * the dashboard can never disagree about what a rollout panel showed. Every
 * field comes from the existing aggregate; nothing is measured here. */
export function curriculumObservation(st={}){
  const g=st.gait||{},r=GAIT_REQUIREMENTS;
  const survival=clamp(num(st.survival),0,1);
  const contact=clamp(num(st.nonfootContactFraction,num(g.nonfootGeometricContactMean,1)),0,1);
  const slide=Math.max(0,num(st.footDragIndex,num(g.footDragIndex)));
  const contactHealth=clamp(num(st.contactHealth,1-contact),0,1);
  const slipHealth=clamp(num(st.footSlipHealth,Math.exp(-slide)),0,1);
  const relocation=Math.max(0,num(g.footRelocationQ25));
  const steps=Math.max(0,num(g.genuineStepsQ25));
  const feet=Math.max(0,num(g.steppingFeetQ25));
  const segments=Math.max(0,num(g.positiveSegmentsQ25));
  const evenness=clamp(num(g.stepEvennessQ25,feet>0?clamp(feet/r.feet,0,1):0),0,1);
  const speed=Math.max(0,num(st.cleanWalkSpeedMps,num(st.forwardSpeed)));
  const lateAutonomous=num(st.lateAutonomousDistanceQ25,num(g.lateAutonomousDistanceM));
  // Hinged like liquid dog's slam term: gentle contact is free, harm is not.
  const harm=Math.max(contact/CONTACT_HARM_LIMIT,slide/SLIDE_HARM_LIMIT);
  return {survival,contact,slide,contactHealth,slipHealth,relocation,steps,feet,segments,evenness,
    speed,lateAutonomous,harm,slam:Math.max(0,harm-0.5),
    liveliness:clamp(relocation/LIVELINESS_REFERENCE_M,0,1),
    safety:clamp(contactHealth*slipHealth,0,1),
    stepTerm:clamp(steps/r.steps,0,1),footTerm:clamp(feet/r.feet,0,1),
    segmentTerm:clamp(segments/r.segments,0,1),
    lateTerm:clamp(lateAutonomous/r.lateAutonomousM,0,1)};
}

/* Footfall quality. Multiplicative on purpose, exactly as in liquid dog: no
 * credit for how evenly or how persistently the feet are used unless feet are
 * actually leaving the ground and coming back. Weights are liquid dog's. */
export function footfallQuality(o){
  return o.stepTerm*(0.45+0.25*o.segmentTerm+0.15*o.footTerm+0.15*o.evenness);
}

// ── the rungs ──────────────────────────────────────────────────────────────
/* `score` ranks the training population. `passed` is the hard gate a cohort
 * must clear to promote. `constraintsHeld` is what an EARLIER rung demands of
 * a LATER one once it has been cleared -- this is the cumulative part. */
/* THE RETENTION FACTORS.
 *
 * Liquid dog's distance gate is not the raw speed reward: it is
 * `speed × upright × gentle × rhythmic`, so every gate already cleared stays
 * in the distance SCORE as a multiplicative factor rather than only as a
 * pass condition. v6.18.0 shipped the conservative reading -- earlier rungs
 * held as pass conditions only, on the argument that the WALK reward already
 * carries them multiplicatively through contact health and the slide term.
 *
 * A biopsy at round 147 showed that argument is wrong at low fitness. With
 * the sustained-step factor pinned at its 0.10 exploration floor on 13 of 20
 * lanes, speed dominates the reward and contact health at 0.06 is far too
 * weak a multiplier to stop a floor-dragger outranking a clean stander: 14 of
 * 20 lanes had rotted to 0.37-0.94 non-foot floor contact, four of them AFTER
 * clearing the posture rung on merit. The constraint was present and did not
 * bite.
 *
 * So these factors restore liquid dog's cumulative multiplication. They are
 * soft and saturating -- full credit once the rung's own bar is met, decaying
 * smoothly below it -- because a hard zero would discard every candidate in a
 * population that has already drifted and leave nothing to breed from.
 *
 * This is training rank only, as every rung score is. The WALK reward of
 * record is untouched, and `verbatim` mode below restores the v6.18.0
 * behaviour exactly for use as an ablation baseline. */
export function postureRetention(o){
  // 1.0 while harm is inside tolerance, decaying toward a floor above it.
  const over=Math.max(0,o.harm-HARM_TOLERANCE);
  return clamp(o.survival,0,1)*clamp(1/(1+over),RETENTION_FLOOR,1);
}
export function footfallRetention(o){
  const q=footfallQuality(o);
  return q>=FOOTFALL_PASS?1:clamp(RETENTION_FLOOR+(1-RETENTION_FLOOR)*(q/FOOTFALL_PASS),RETENTION_FLOOR,1);
}
/* Never zero: a drifted population still needs a gradient back to posture. */
export const RETENTION_FLOOR=0.05;

export const DISTANCE_GUARDS=Object.freeze(['cumulative','verbatim']);
export function distanceGuard(cfg={}){
  const g=String(cfg.curriculumDistanceGuard??'cumulative');
  return DISTANCE_GUARDS.includes(g)?g:'cumulative';
}

export const RUNGS=Object.freeze({
  posture:{
    name:'posture',index:0,
    blurb:'stay up, stay awake, stay off the floor',
    /* Completing the episode is worth exactly 1.0 and not a point more, so
     * among controllers that can stand, selection is driven only by
     * liveliness, gentleness and whatever diversity the pools are holding. */
    score:o=>o.survival+0.60*o.liveliness-0.50*o.slam,
    passed:o=>o.survival>=0.999&&o.liveliness>=1&&o.harm<=HARM_TOLERANCE,
    constraintsHeld:o=>o.survival>=0.999&&o.harm<=HARM_TOLERANCE,
    retention:postureRetention,
  },
  footfalls:{
    name:'footfalls',index:1,
    blurb:'repeated steps on several feet, still no reward for distance',
    score:o=>(o.survival>=0.999?1:0.15*o.survival)*footfallQuality(o)-0.35*o.slam,
    passed:o=>o.survival>=0.999&&footfallQuality(o)>=FOOTFALL_PASS&&o.harm<=HARM_TOLERANCE,
    constraintsHeld:o=>footfallQuality(o)>=FOOTFALL_PASS,
    retention:footfallRetention,
  },
  distance:{
    name:'distance',index:2,
    blurb:'cover ground on the WALK reward, holding the posture and footfalls already earned',
    /* `cumulative` (default): the WALK reward times the retention factors of
     * every rung below, which is liquid dog's own gate-3 shape and what makes
     * a 500-generation visit safe to leave running.
     * `verbatim`: the WALK reward alone, bit-identical to the pre-curriculum
     * engine, retained as the ablation baseline. */
    score:(o,st,guard='cumulative')=>{
      const q=num(st?.qFitness);
      return guard==='verbatim'?q:q*postureRetention(o)*footfallRetention(o);
    },
    passed:o=>o.survival>=0.999&&o.speed>=DISTANCE_PASS_MPS&&footfallQuality(o)>=FOOTFALL_PASS,
    constraintsHeld:()=>true,
    retention:()=>1,
  },
});

/* The warm-up rungs are set directly; the distance rung takes whatever is
 * left of the cycle. That way "how long is a cycle" is ONE number the
 * operator sets, rather than three that have to be kept in step. */
/* `fresh` marks a cycle whose controller was just re-initialised at random
 * (a cyclic lane's first visit to phase B). It has to learn to stand from
 * scratch, so it gets first-visit budgets whatever the cycle number is. */
export function warmupBudget(rung,cycle,cfg={},fresh=false){
  const first=cycle<=1||!!fresh,key=rungName(rung);
  const table=first?FIRST_CYCLE_BUDGET:LATER_CYCLE_BUDGET;
  const override=first?cfg[`curriculumFirst_${key}`]:cfg[`curriculumLater_${key}`];
  const v=override===undefined?table[key]:override;
  if(v===null||v===undefined)return null;
  const n=Math.trunc(num(v,0));return n>0?n:null;
}

/* CYCLE LENGTH, and why the default is what it is.
 *
 * `curriculumCycleGens` is the X in "cycle for X generations". Everything
 * else is derived from it, so the cycle stays commensurable with the two
 * other clocks the engine already runs on:
 *
 *     480 generations = 3 x plateauLabBudgetGens (160) = 1 phaseMinGens lease
 *
 * So one cycle spans about three KG-governed experiments and about one phase
 * lease. A cycle that completes on budget WITHOUT the engine detecting a
 * plateau simply revisits the ladder, which is the normal case and the point:
 * the lane re-earns posture and footfalls as hard gates instead of coasting.
 *
 * 0 restores unbounded, in which case only the engine's plateau ends a visit
 * and the ladder may not revisit for thousands of generations. */
export const DEFAULT_CYCLE_GENS=480;

export function cycleGens(cfg={}){
  const v=Math.trunc(num(cfg.curriculumCycleGens,DEFAULT_CYCLE_GENS));
  return v>0?v:null;
}

export function rungBudget(rung,cycle,cfg={},fresh=false){
  const key=rungName(rung);
  if(key!=='distance')return warmupBudget(key,cycle,cfg,fresh);
  // Explicit distance override wins, so the old per-rung settings still work.
  const explicit=(cycle<=1||fresh)?cfg.curriculumFirst_distance:cfg.curriculumLater_distance;
  if(explicit!==undefined&&explicit!==null){
    const n=Math.trunc(num(explicit,0));if(n>0)return n;
    if(n===0&&cfg.curriculumCycleGens===undefined)return null;
  }
  const total=cycleGens(cfg);if(total===null)return null;
  let warm=0;
  for(const r of RUNG_ORDER){
    if(r==='distance')continue;
    const b=warmupBudget(r,cycle,cfg,fresh);
    if(b===null)return null;   // an unbounded warm-up rung makes the rest moot
    warm+=b;
  }
  // The distance rung always gets the majority of the cycle, whatever the
  // warm-up rungs are set to.
  return Math.max(Math.ceil(total*0.5),total-warm);
}

export function cycleBudgetReport(cycle,cfg={},fresh=false){
  const per=Object.fromEntries(RUNG_ORDER.map(r=>[r,rungBudget(r,cycle,cfg,fresh)]));
  const total=RUNG_ORDER.reduce((n,r)=>n===null||per[r]===null?null:n+per[r],0);
  const lab=Math.max(1,Math.trunc(num(cfg.plateauLabBudgetGens,160)));
  return {cycle,perRung:per,totalGens:total,
    targetGens:cycleGens(cfg),
    kgExperimentBudgetGens:lab,
    kgExperimentsPerCycle:total===null?null:Number((total/lab).toFixed(2)),
    phaseLeaseGens:Math.max(1,Math.trunc(num(cfg.phaseMinGens,480))),
    rule:'a cycle that completes on budget without a detected plateau revisits the ladder; a rung change resets no sigma, no stagnation tracker, no plateau monitor and no population'};
}

/* The score a candidate is RANKED by while a rung is active, and the reward
 * of record for everything else. */
export function rungScore(rung,st={},cfg={}){
  const r=RUNGS[rungName(rung)],o=curriculumObservation(st);
  return num(r.score(o,st,distanceGuard(cfg)),-Infinity);
}

/* How much of the WALK reward a candidate keeps after the rungs below the
 * active one take their cut. 1.0 means nothing was given up. Telemetry, so
 * the dashboard can show WHY a lane is ranked where it is. */
export function retentionReport(rung,st={}){
  const o=curriculumObservation(st);
  return {posture:Number(postureRetention(o).toFixed(4)),
    footfalls:Number(footfallRetention(o).toFixed(4)),
    combined:Number((postureRetention(o)*footfallRetention(o)).toFixed(4)),
    harm:Number(o.harm.toFixed(3)),footfallQuality:Number(footfallQuality(o).toFixed(4))};
}

// ── WIDE TO NARROW: the population telescope ───────────────────────────────
/* Liquid dog runs a wide population for its early cycles and a narrow one
 * after, on the reasoning that breadth is what finds a posture worth having
 * and depth is what refines it. The walker's per-lane search policy already
 * carries popN and eliteN as a registered, KG-comparable dimension, so the
 * telescope is expressed there rather than as a new mechanism.
 *
 * COMPUTE IS NOT CONSERVED ACROSS CYCLES. A wide cycle costs more evaluations
 * per generation than a narrow one, so a "generation" stops being a constant
 * unit of work once the telescope is on. `telescopeState` reports the
 * evaluations per generation for the active cycle so the cost is recorded
 * rather than silently absorbed. */
export const TELESCOPE_DEFAULTS=Object.freeze({widePopN:32,wideEliteN:8,narrowPopN:16,narrowEliteN:4,wideCycles:2});

export function telescopeSettings(cfg={}){
  const on=cfg.curriculumTelescopeEnabled!==false&&!!cfg.gaitCurriculumEnabled;
  const d=TELESCOPE_DEFAULTS;
  const widePopN=Math.max(4,Math.trunc(num(cfg.curriculumWidePopN,d.widePopN)));
  const narrowPopN=Math.max(4,Math.trunc(num(cfg.curriculumNarrowPopN,d.narrowPopN)));
  return {enabled:on,
    widePopN,narrowPopN,
    wideEliteN:clamp(Math.trunc(num(cfg.curriculumWideEliteN,d.wideEliteN)),1,widePopN-1),
    narrowEliteN:clamp(Math.trunc(num(cfg.curriculumNarrowEliteN,d.narrowEliteN)),1,narrowPopN-1),
    wideCycles:clamp(Math.trunc(num(cfg.curriculumWideCycles,d.wideCycles)),0,50)};
}

/* The search policy the telescope asks for at a given curriculum cycle.
 * Returns null when the telescope is off, so the lane keeps whatever policy
 * it already had and a KG-assigned search-policy seat is never overwritten. */
export function telescopeFor(cycle,cfg={}){
  const t=telescopeSettings(cfg);
  if(!t.enabled)return null;
  const wide=Math.max(1,Math.trunc(num(cycle,1)))<=t.wideCycles;
  return wide?{popN:t.widePopN,eliteN:t.wideEliteN,stage:'wide'}
             :{popN:t.narrowPopN,eliteN:t.narrowEliteN,stage:'narrow'};
}

export function telescopeState(lane,cfg={}){
  const t=telescopeSettings(cfg),c=hydrateCurriculum(lane?.gaitCurriculum,cfg);
  const want=telescopeFor(c.cycle,cfg);
  return {...t,cycle:c.cycle,stage:want?want.stage:'off',
    popN:want?want.popN:null,eliteN:want?want.eliteN:null,
    evalsPerGeneration:want?want.popN:null,
    narrowsAtCycle:t.enabled?t.wideCycles+1:null,
    costRule:'a wide cycle costs more evaluations per generation than a narrow one; generations are not a constant unit of work across cycles'};
}

export function rungPass(rung,st={}){
  const key=rungName(rung),o=curriculumObservation(st);
  if(!RUNGS[key].passed(o))return false;
  // Cumulative: every rung already cleared in this cycle must still hold.
  for(const earlier of RUNG_ORDER.slice(0,RUNGS[key].index))
    if(!RUNGS[earlier].constraintsHeld(o))return false;
  return true;
}

/* Does this rung curriculum apply to this lane at all?
 *
 * WALK only -- the rungs are defined by gait measurements, and TARGET already
 * runs its own 5-stage skill curriculum that this must not stack on top of.
 * Primary and fork lanes only -- a plateau-lab lane is a short paired
 * comparison measured on the objective, and a curriculum inside one arm of a
 * matched pair would confound the very contrast it exists to draw.
 * Never mono -- there are no A/B segments to aim a rung at. */
export function curriculumApplies(lane,cfg={}){
  if(!cfg.gaitCurriculumEnabled)return false;
  if((cfg.taskMode||'walk')!=='walk')return false;
  if(!lane||lane.kind==='mono')return false;
  if(lane.scope==='plateau_lab'||lane.scope==='scout'||lane.morphologyBranch)return false;
  return curriculumTargetsMode(evaluationTargetOf(lane),cfg);
}

/* Which controller a lane is expressing right now, in the engine's own
 * vocabulary. A cyclic lane in phase A expresses segment A alone; a joint or
 * fork lane expresses the whole organism. */
export function evaluationTargetOf(lane){
  const mode=lane?.continuationMode||(lane?.kind==='cyclic'?(lane.phase==='A'?'Aalone':lane.phase==='B'?'Balone':'full'):'full');
  return mode==='Aalone'?'A':mode==='Balone'?'B':'full';
}

/* The curriculum can be aimed at segment A, segment B, or the whole organism
 * with its bridge -- any combination. A rung asks a controller to stand and
 * step; a half-controller may simply be unable to, in which case the rung
 * spends its bounded budget and promotes anyway, so the cost of aiming wrong
 * is a known number of generations rather than a stall. */
export function curriculumTargets(cfg={}){
  const raw=cfg.gaitCurriculumTargets;
  const list=(Array.isArray(raw)?raw:String(raw??'full').split(/[^A-Za-z]+/))
    .map(x=>String(x).trim()).filter(Boolean)
    .map(x=>x==='Aalone'?'A':x==='Balone'?'B':x)
    .filter(x=>RUNG_TARGETS.includes(x));
  const seen=[...new Set(list)];
  return seen.length?RUNG_TARGETS.filter(t=>seen.includes(t)):['full'];
}
export function curriculumTargetsMode(target,cfg={}){return curriculumTargets(cfg).includes(target)}

// ── per-lane curriculum state ──────────────────────────────────────────────
/* Additive and self-healing: an older checkpoint has no curriculum block, and
 * hydrating one simply starts it at the bottom of the ladder on cycle 1. */
export function blankCurriculum(cfg={}){
  return {version:GAIT_CURRICULUM_VERSION,rung:RUNG_ORDER[0],rungGen:0,cycle:1,
    cyclesCompleted:0,cyclesSinceReview:0,promotions:0,budgetExits:0,
    lastAdvance:null,log:[],reviewDue:false,cycleStartGen:0,freshModule:false};
}
export function hydrateCurriculum(c,cfg={}){
  const b=blankCurriculum(cfg);
  if(!c||typeof c!=='object')return b;
  return {...b,...c,version:GAIT_CURRICULUM_VERSION,
    rung:rungName(c.rung),
    rungGen:Math.max(0,Math.trunc(num(c.rungGen,0))),
    cycle:Math.max(1,Math.trunc(num(c.cycle,1))),
    cyclesCompleted:Math.max(0,Math.trunc(num(c.cyclesCompleted,0))),
    cyclesSinceReview:Math.max(0,Math.trunc(num(c.cyclesSinceReview,0))),
    promotions:Math.max(0,Math.trunc(num(c.promotions,0))),
    budgetExits:Math.max(0,Math.trunc(num(c.budgetExits,0))),
    log:Array.isArray(c.log)?c.log.slice(-40):[],
    reviewDue:!!c.reviewDue,
    cycleStartGen:Math.max(0,Math.trunc(num(c.cycleStartGen,0))),freshModule:!!c.freshModule};
}

/* One generation of curriculum bookkeeping.
 *
 * A rung is left when the elite COHORT clears it -- not merely the best
 * individual, which would promote on a single lucky panel -- or when its
 * budget is spent. Leaving the last rung completes a cycle, freezes a fossil
 * generation in the champion pools, and after `reviewEveryCycles` complete
 * cycles raises `reviewDue`, which is what hands the floor to the KG.
 *
 * Deliberately absent: any reset of sigma, mutation state, the plateau
 * monitor, the material frontier, or the population. That omission IS the
 * fragmentation fix. */
export function advanceCurriculum(cur,{cohortPassed,cycles,reviewEveryCycles,cfg={},generation=0}={}){
  const c=hydrateCurriculum(cur,cfg),budget=rungBudget(c.rung,c.cycle,cfg,c.freshModule);
  c.rungGen=Math.max(0,Math.trunc(num(c.rungGen,0)))+1;
  const spent=budget!==null&&c.rungGen>=budget;
  const promote=!!cohortPassed;
  if(!promote&&!spent)return {curriculum:c,changed:false,cycleCompleted:false,reviewDue:false,
    rung:c.rung,budget,reason:null};
  const from=c.rung,i=RUNGS[from].index,why=promote?'cohort cleared it':'budget spent';
  if(promote)c.promotions++;else c.budgetExits++;
  if(i+1<RUNG_ORDER.length){
    const gens=c.rungGen;c.rung=RUNG_ORDER[i+1];c.rungGen=0;
    c.lastAdvance={from,to:c.rung,why,generation,gens,cycle:c.cycle};
    c.log=[...(c.log||[]),c.lastAdvance].slice(-40);
    return {curriculum:c,changed:true,cycleCompleted:false,reviewDue:!!c.reviewDue,rung:c.rung,budget,reason:why};
  }
  // Leaving the last rung wraps the whole cycle.
  const closed=closeCurriculumCycle(c,{why,cycles,reviewEveryCycles,cfg,generation});
  return {...closed,changed:true,cycleCompleted:true,budget,reason:why};
}

/* Close the current cycle wherever the ladder happens to be, and start the
 * next one at the bottom.
 *
 * Two things reach this: leaving the top rung on merit, and the engine's own
 * patient plateau/cap machinery ending the phase or episode underneath the
 * curriculum. The second is the normal case, because the distance rung is
 * unbounded on purpose -- so a curriculum cycle is exactly "one climb of the
 * ladder followed by as long a run at the real reward as the lane can
 * sustain". Both paths share this function so the cycle count, the review
 * clock and the fossil generation can never disagree. */
export function closeCurriculumCycle(cur,{why='visit ended',cycles,reviewEveryCycles,cfg={},generation=0}={}){
  const c=hydrateCurriculum(cur,cfg),from=c.rung,gens=c.rungGen,cycle=c.cycle;
  c.rung=RUNG_ORDER[0];c.rungGen=0;c.cycle=cycle+1;c.cyclesCompleted++;c.cyclesSinceReview++;
  c.cycleStartGen=Math.max(0,Math.trunc(num(generation,0)))+1;c.freshModule=false;
  const need=Math.max(1,Math.trunc(num(reviewEveryCycles,num(cycles,2))));
  if(c.cyclesSinceReview>=need){c.reviewDue=true;c.cyclesSinceReview=0}
  c.lastAdvance={from,to:c.rung,why,generation,gens,cycle,cycleCompleted:true};
  c.log=[...(c.log||[]),c.lastAdvance].slice(-40);
  return {curriculum:c,cycleCompleted:true,reviewDue:!!c.reviewDue,rung:c.rung,reason:why,closedCycle:cycle};
}

/* A CYCLE THAT IS TOO YOUNG TO CLOSE. Two clocks can end a visit: the cycle's
 * own generation budget and the engine's patient plateau. A plateau that
 * matures a few dozen generations after a budget close would otherwise close
 * a second, near-empty cycle -- freezing a second fossil generation, stepping
 * the telescope from wide straight to narrow and raising the review clock.
 * Below half a cycle the ladder restarts in place instead; nothing else moves. */
export const MIN_CLOSABLE_CYCLE_FRACTION=0.5;
export function cycleAge(cur,generation=0){
  return Math.max(0,Math.trunc(num(generation,0))-Math.trunc(num(cur?.cycleStartGen,0)));
}
export function visitMayCloseCycle(cur,generation=0,cfg={}){
  const total=cycleGens(cfg);if(total===null)return true;
  return cycleAge(hydrateCurriculum(cur,cfg),generation)>=Math.ceil(total*MIN_CLOSABLE_CYCLE_FRACTION);
}
export function restartLadderInCycle(cur,{why='visit ended',cfg={},generation=0}={}){
  const c=hydrateCurriculum(cur,cfg),from=c.rung,gens=c.rungGen;
  c.rung=RUNG_ORDER[0];c.rungGen=0;
  c.lastAdvance={from,to:c.rung,why,generation,gens,cycle:c.cycle,restartedInCycle:true};
  c.log=[...(c.log||[]),c.lastAdvance].slice(-40);
  return {curriculum:c,cycleCompleted:false,reviewDue:!!c.reviewDue,rung:c.rung,reason:why,restartedInCycle:true};
}

/* Consume the review flag. The KG is handed the floor exactly once per
 * `reviewEveryCycles` completed cycles, whatever else is happening. */
export function takeCurriculumReview(cur,cfg={}){
  const c=hydrateCurriculum(cur,cfg);
  if(!c.reviewDue)return {curriculum:c,due:false};
  c.reviewDue=false;
  return {curriculum:c,due:true,cycle:c.cycle,cyclesCompleted:c.cyclesCompleted};
}

export function curriculumSignature(lane,cfg={}){
  if(!curriculumApplies(lane,cfg))return 'off';
  const t=telescopeSettings(cfg);
  return [GAIT_CURRICULUM_VERSION,curriculumTargets(cfg).join('+'),distanceGuard(cfg),
    t.enabled?`tel:${t.widePopN}/${t.wideEliteN}x${t.wideCycles}->${t.narrowPopN}/${t.narrowEliteN}`:'tel:off',
    num(cfg.gaitCurriculumReviewCycles,2),
    RUNG_ORDER.map(r=>`${r}:${rungBudget(r,1,cfg)??'open'}/${rungBudget(r,2,cfg)??'open'}`).join(',')].join('|');
}

export function curriculumSummary(lane,cfg={}){
  const active=curriculumApplies(lane,cfg),c=hydrateCurriculum(lane?.gaitCurriculum,cfg);
  const r=RUNGS[c.rung],budget=rungBudget(c.rung,c.cycle,cfg,c.freshModule);
  return {version:GAIT_CURRICULUM_VERSION,active,enabled:!!cfg.gaitCurriculumEnabled,
    targets:curriculumTargets(cfg),evaluationTarget:evaluationTargetOf(lane),
    distanceGuard:distanceGuard(cfg),telescope:telescopeState(lane,cfg),
    rung:c.rung,rungIndex:r.index,rungCount:RUNG_ORDER.length,blurb:r.blurb,
    rungGen:c.rungGen,budget,cycle:c.cycle,cyclesCompleted:c.cyclesCompleted,
    cyclesSinceReview:c.cyclesSinceReview,reviewEveryCycles:Math.max(1,Math.trunc(num(cfg.gaitCurriculumReviewCycles,2))),
    reviewDue:!!c.reviewDue,promotions:c.promotions,budgetExits:c.budgetExits,
    cycleBudget:cycleBudgetReport(c.cycle,cfg,c.freshModule),freshModule:!!c.freshModule,
    cycleStartGen:c.cycleStartGen,cycleAge:cycleAge(c,lane?.generation??0),
    lastAdvance:c.lastAdvance||null,log:(c.log||[]).slice(-8),
    rungs:RUNG_ORDER.map(k=>({name:k,index:RUNGS[k].index,blurb:RUNGS[k].blurb,
      firstBudget:rungBudget(k,1,cfg),laterBudget:rungBudget(k,2,cfg)}))};
}

export function formulaText(cfg={}){
  if(!cfg?.gaitCurriculumEnabled)return 'Cyclic rung curriculum OFF: training rank is the WALK reward at every generation.';
  const g=distanceGuard(cfg),t=telescopeSettings(cfg);
  const dist=g==='verbatim'
    ?'distance (the WALK reward alone — verbatim baseline)'
    :'distance (the WALK reward × posture retention × footfall retention, liquid dog\u2019s cumulative gate-3 shape)';
  const tel=t.enabled
    ?` Population telescopes wide→narrow: ${t.widePopN}/${t.wideEliteN} for the first ${t.wideCycles} cycle(s), then ${t.narrowPopN}/${t.narrowEliteN}.`
    :' Population telescope off.';
  return `Cyclic rung curriculum on ${curriculumTargets(cfg).join('+')}: posture (survival + 0.60·liveliness − 0.50·slam) → footfalls (steps × [0.45 + 0.25·segments + 0.15·feet + 0.15·evenness], pass ${FOOTFALL_PASS}) → ${dist}. A rung is left when every elite clears it or its budget is spent; the distance rung is unbounded and cleared rungs keep their cut of its score.${tel} Training rank only — champions, yardstick, fossils and all KG evidence stay on the WALK reward.`;
}
