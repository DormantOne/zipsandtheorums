/* injury.js — port of Liquid_Foundry foundry/injury.py
 *
 * Frozen public weakest-part injury ledger. This is an engineering injury
 * proxy, not a calibrated biomedical injury model. Its per-part budgets,
 * thresholds and damage rates are fixed outside the searchable experiment
 * grammar. The weakest remaining anatomical health fraction is the public
 * Non-Injury axis.
 *
 * Differences from the Python original, all forced by the target body:
 *   - the strain geometry is precomputed once per body instead of per step
 *   - parts are integer-indexed typed arrays in the hot path; the string-keyed
 *     snapshot is built only when asked for
 * The rates, powers and thresholds are byte-for-byte the Python values.
 */
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const num=(v,d=0)=>Number.isFinite(Number(v))?Number(v):d;

export const ANATOMICAL_HIT_POINT_VERSION='public-anatomical-hp-v4-chronic-loaded-flexion';
export const DEFAULT_HIT_POINT_BUDGET=200;
export const STRAIN_FREE_FRACTION=0.39;

export const LEG_ORDER=['fl','fr','rl','rr'];
export const JOINT_NAMES=LEG_ORDER.flatMap(l=>[`${l}_hip`,`${l}_knee`]);
export const FOOT_NAMES=[...LEG_ORDER];
export const SURFACE_NAMES=['torso',...LEG_ORDER.flatMap(l=>[`${l}_thigh`,`${l}_shin`])];
export const CAUSES=['jointStrain','jointShock','sustainedActuatorLoad','chronicLoadedFlexion','adaptedFootOverload',
  'loadedSlipShear','nonAdaptedSurfaceLoad','severeInstability','fatalFailure'];
export const PART_NAMES=['core',...JOINT_NAMES.map(n=>`joint:${n}`),
  ...SURFACE_NAMES.map(n=>`surface:${n}`),...FOOT_NAMES.map(n=>`foot:${n}`)];

const CAUSE_IX=Object.fromEntries(CAUSES.map((c,i)=>[c,i]));
const PART_IX=Object.fromEntries(PART_NAMES.map((p,i)=>[p,i]));
export const NPARTS=PART_NAMES.length;
const P_CORE=PART_IX['core'],P_JOINT0=PART_IX['joint:fl_hip'],P_FOOT0=PART_IX['foot:fl'];
const NC=CAUSES.length;

export const SURFACE_TOLERANCE_BW={torso:0.30,
  ...Object.fromEntries(LEG_ORDER.map(l=>[`${l}_thigh`,0.16])),
  ...Object.fromEntries(LEG_ORDER.map(l=>[`${l}_shin`,0.10]))};
const SURFACE_PART=Object.fromEntries(SURFACE_NAMES.map(n=>[n,PART_IX[`surface:${n}`]]));

/* Strain geometry, precomputed from the body's real limits and its calibrated
 * standing pose. A fixed fraction of the mechanical range around neutral is
 * load-bearing territory; damage begins only after leaving that band and rises
 * toward the corresponding hard stop. Because a knee's neutral pose sits near
 * its lower stop, the lower safe boundary clips at the mechanical limit rather
 * than declaring standing to be strain. */
export function strainGeometry(jointLimits,neutralPose,freeFraction=STRAIN_FREE_FRACTION){
  return jointLimits.map((lim,i)=>{
    const lo=Number(lim[0]),hi=Number(lim[1]);
    const span=Math.max(1e-9,hi-lo);
    const neutral=clamp(Number(neutralPose[i]),lo,hi);
    const free=Math.max(1e-9,clamp(freeFraction,0.05,0.49)*span);
    const upEdge=Math.min(hi,neutral+free),dnEdge=Math.max(lo,neutral-free);
    return {lo,hi,neutral,upEdge,dnEdge,
      upDen:Math.max(1e-9,hi-upEdge),dnDen:Math.max(1e-9,dnEdge-lo)};
  });
}

export function publicInjuryContract(budget=DEFAULT_HIT_POINT_BUDGET,extra={}){
  return {
    version:ANATOMICAL_HIT_POINT_VERSION,
    budget_per_part_hp:Number(budget),
    weakest_part_governs:true,
    fatal_fall_exhausts_core:true,
    part_count:NPARTS,
    joint:{strain_reference:'plant-calibrated neutral joint pose',
      strain_free_excursion_fraction_of_mechanical_range:STRAIN_FREE_FRACTION,
      strain_scale:'remaining excursion from the neutral safe band to the mechanical limit',
      strain_rate:18.0,strain_power:3.0,
      shock_free_angular_accel_rad_s2:45.0,shock_scale_rad_s2:100.0,shock_rate:5.0,shock_power:2.2,
      actuator_load_free_fraction:0.55,actuator_load_scale:0.45,actuator_load_rate:4.0,actuator_load_power:2.0,
      chronic_loaded_flexion:{
        target:'stance knees only',
        principle:'posture alone is free; loaded knee flexion accumulates recoverable fatigue before any HP loss',
        free_flexion_beyond_neutral_rad:0.12,
        support_load_free_bw:0.08,
        fatigue_recovery_tau_s:5.0,
        fatigue_damage_threshold:0.045,
        fatigue_damage_scale:0.11,
        damage_rate:7.0,damage_power:2.0,
        note:'brief crouches and unloaded flexion recover without damage; sustained loaded crouching becomes progressively costly'
      }},
    foot:{adapted_load_free_bw:0.65,overload_scale_bw:0.65,overload_rate:6.0,overload_power:2.0,
      slip_free_m_s:0.04,slip_scale_m_s:0.25,loaded_slip_rate:12.0,loaded_slip_power:1.5},
    nonadapted_surface_tolerance_bw:SURFACE_TOLERANCE_BW,
    nonadapted_surface_rate:8.0,nonadapted_surface_power:1.8,
    core:{tilt_free_rad:0.45,tilt_scale_rad:0.45,instability_rate:10.0,instability_power:2.0},
    ...extra
  };
}

export class AnatomicalHitPointState{
  constructor({budget=DEFAULT_HIT_POINT_BUDGET,strain}={}){
    this.budget=clamp(num(budget,DEFAULT_HIT_POINT_BUDGET),1,10000);
    this.strain=strain;
    this.rem=new Float64Array(NPARTS).fill(this.budget);
    this.cause=new Float64Array(NPARTS*NC);
    this.prevVel=null;
    // Per-leg recoverable loaded-flexion fatigue. This is deliberately separate
    // from HP: a brief crouch can accumulate fatigue and then fully recover.
    this.crouchFatigue=new Float64Array(LEG_ORDER.length);
    this.crouchStress=new Float64Array(LEG_ORDER.length);
    this.depleted=false;
  }
  _spend(part,cause,amount){
    const req=amount>0?amount:0;if(req<=0)return;
    const spent=Math.min(this.rem[part],req);if(spent<=0)return;
    this.rem[part]-=spent;this.cause[part*NC+cause]+=spent;
    if(this.rem[part]<=1e-12){this.rem[part]=0;this.depleted=true}
  }
  /* Spend public per-part HP for one deterministic control interval. */
  step(o){
    const dt=o.dt>0?o.dt:0;if(dt<=0)return this;
    const q=o.jointAngles,qd=o.jointVelocities,tq=o.normalizedTorques,prev=this.prevVel;
    for(let i=0;i<JOINT_NAMES.length;i++){
      const st=this.strain[i],a=num(q[i]);
      const edge=a>=st.neutral
        ? Math.max(0,a-st.upEdge)/st.upDen
        : Math.max(0,st.dnEdge-a)/st.dnDen;
      if(edge>0){const e=Math.min(1.5,edge);this._spend(P_JOINT0+i,CAUSE_IX.jointStrain,18.0*e*e*e*dt)}
      if(prev){
        const acc=Math.abs((num(qd[i])-prev[i])/dt),ex=(acc-45.0)/100.0;
        if(ex>0)this._spend(P_JOINT0+i,CAUSE_IX.jointShock,5.0*Math.pow(ex,2.2)*dt);
      }
      const load=(Math.min(2,Math.abs(num(tq[i])))-0.55)/0.45;
      if(load>0)this._spend(P_JOINT0+i,CAUSE_IX.sustainedActuatorLoad,4.0*load*load*dt);
    }

    /* Chronic loaded crouch / tendon-demand proxy.
     *
     * This is intentionally NOT an uprightness reward. Knee angle alone costs
     * nothing.  Only a stance leg carrying body load while flexed beyond the
     * calibrated standing neutral accumulates a recoverable fatigue state.
     * The fatigue has a grace region; HP loss begins only after sustained
     * exposure.  When the leg unloads or straightens, fatigue decays.
     *
     * The squared sine term is a simple geometry proxy: as a loaded knee bends,
     * the perpendicular moment arm of support force grows. It is not claimed to
     * be a calibrated tendon-force model; it only closes the loophole where a
     * permanently crouched, heavily loaded gait looked harmless to an acute-only
     * ledger. */
    const crouchFree=0.12,loadFree=0.08,recoveryTau=5.0,damageThreshold=0.045,damageScale=0.11;
    for(let f=0;f<LEG_ORDER.length;f++){
      const knee=2*f+1,st=this.strain[knee];
      const flex=Math.max(0,num(q[knee])-st.neutral-crouchFree);
      const lever=Math.sin(Math.min(Math.PI/2,flex));
      const support=Math.max(0,num(o.footForceBW[f])-loadFree);
      const stress=support*lever*lever;
      this.crouchStress[f]=stress;
      const decay=Math.exp(-dt/recoveryTau);
      this.crouchFatigue[f]=this.crouchFatigue[f]*decay+stress*dt;
      const ex=(this.crouchFatigue[f]-damageThreshold)/damageScale;
      if(ex>0)this._spend(P_JOINT0+knee,CAUSE_IX.chronicLoadedFlexion,7.0*ex*ex*dt);
    }
    for(let f=0;f<FOOT_NAMES.length;f++){
      const over=(Math.max(0,num(o.footForceBW[f]))-0.65)/0.65;
      if(over>0)this._spend(P_FOOT0+f,CAUSE_IX.adaptedFootOverload,6.0*over*over*dt);
      const slip=Math.max(0,num(o.footSlipSpeed[f]))-0.04;
      if(slip>0){
        const ls=Math.max(0,num(o.footShearBW[f]))*slip/0.25;
        if(ls>0)this._spend(P_FOOT0+f,CAUSE_IX.loadedSlipShear,12.0*Math.pow(ls,1.5)*dt);
      }
    }
    const surf=o.nonfootSurfaceForceBW||{};
    for(const name of SURFACE_NAMES){
      const load=Math.max(0,num(surf[name]));
      if(load>0)this._spend(SURFACE_PART[name],CAUSE_IX.nonAdaptedSurfaceLoad,
        8.0*Math.pow(load/SURFACE_TOLERANCE_BW[name],1.8)*dt);
    }
    const tilt=(Math.max(0,num(o.tiltRadians))-0.45)/0.45;
    if(tilt>0)this._spend(P_CORE,CAUSE_IX.severeInstability,10.0*tilt*tilt*dt);
    if(!this.prevVel)this.prevVel=new Float64Array(JOINT_NAMES.length);
    for(let i=0;i<JOINT_NAMES.length;i++)this.prevVel[i]=num(qd[i]);
    return this;
  }
  /* A catastrophic fall or escape exhausts the core public budget. */
  fatal(){this._spend(P_CORE,CAUSE_IX.fatalFailure,this.rem[P_CORE]);this.depleted=true;return this}
  weakestIndex(){let w=0;for(let i=1;i<NPARTS;i++)if(this.rem[i]<this.rem[w])w=i;return w}
  remainingFraction(){return this.rem[this.weakestIndex()]/this.budget}
  snapshot(){
    const w=this.weakestIndex(),remaining=this.rem[w];
    const damageByPart={},damageByCause={},totalDamageByCause={};
    for(let i=0;i<NPARTS;i++)damageByPart[PART_NAMES[i]]=this.budget-this.rem[i];
    for(let c=0;c<NC;c++){
      const v=this.cause[w*NC+c];if(v>0)damageByCause[CAUSES[c]]=v;
      let t=0;for(let i=0;i<NPARTS;i++)t+=this.cause[i*NC+c];
      if(t>0)totalDamageByCause[CAUSES[c]]=t;
    }
    const chronicCrouchFatigue=Object.fromEntries(LEG_ORDER.map((l,i)=>[l,this.crouchFatigue[i]]));
    const chronicCrouchStress=Object.fromEntries(LEG_ORDER.map((l,i)=>[l,this.crouchStress[i]]));
    return {version:ANATOMICAL_HIT_POINT_VERSION,initial:this.budget,remaining,
      remainingFraction:remaining/this.budget,
      depleted:!!(this.depleted||remaining<=0),
      weakestPart:PART_NAMES[w],damage:this.budget-remaining,
      damageByCause,damageByPart,totalDamageByCause,chronicCrouchFatigue,chronicCrouchStress,partCount:NPARTS};
  }
}
