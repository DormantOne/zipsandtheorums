/* phenotype.js — port of Liquid_Foundry foundry/phenotype.py
 *
 * The developmental ladder. It answers "how far up the gait hierarchy is this
 * genome, and what is stopping it going higher", which is what tells you why a
 * lane is stuck rather than merely that it is stuck.
 *
 * Quartile statistics (q25) are used rather than means so that one lucky
 * scenario in a panel cannot promote a genome up the ladder.
 */
const num=(v,d=0)=>Number.isFinite(Number(v))?Number(v):d;

export const DEVELOPMENTAL_ORDER=['stationary','foot_relocation','com_translation','support_event',
  'repeated_support','multi_foot_coordination','sustained_locomotion','robust_locomotion'];
export const STATE_RANK=Object.fromEntries(DEVELOPMENTAL_ORDER.map((s,i)=>[s,i]));

function quantile(xs,p){
  const a=xs.map(x=>num(x)).sort((x,y)=>x-y);
  if(!a.length)return 0;
  const pos=(a.length-1)*p,lo=Math.floor(pos),hi=Math.ceil(pos);
  return lo===hi?a[lo]:a[lo]+(a[hi]-a[lo])*(pos-lo);
}
const q25=xs=>quantile(xs,0.25);
const mean=xs=>xs.length?xs.reduce((s,x)=>s+num(x),0)/xs.length:0;

/* Summarize a panel of rollouts into a developmental state and a bottleneck.
 * Thresholds are the Python originals. */
export function summarizeRollouts(rollouts){
  const rows=[...rollouts];
  if(!rows.length)return {distance:0,noninjury:0,state:'stationary',developmentalRank:0,bottleneck:'foot_relocation'};
  const d=rows.map(r=>num(r.distance)),h=rows.map(r=>num(r.noninjury));
  const g=rows.map(r=>r.gait||{});

  const footGate=mean(g.map(x=>x.footDistanceGateOpen?1:0));
  const relocation=q25(g.map(x=>x.maxFootRelocationM));
  const signed=q25(g.map(x=>x.signedAutonomousDistanceM));
  const steps=q25(g.map(x=>x.genuineSteps));
  const feet=q25(g.map(x=>x.steppingFeet));
  const segments=q25(g.map(x=>x.positiveProgressSegments));
  const nonfoot=mean(g.map(x=>num(x.nonfootContactFraction,1)));
  const torso=mean(g.map(x=>num(x.torsoContactFraction,1)));
  const peak=Math.max(0,...g.map(x=>num(x.peakNonfootForceBW)));
  const catastrophic=mean(g.map(x=>x.catastrophic?1:0));
  const nh=h.length?Math.min(...h):0;

  let state='stationary',bottleneck='foot_relocation';
  if(footGate>=0.75){state='foot_relocation';bottleneck='com_translation'}
  if(signed>=0.04){state='com_translation';bottleneck='support_event'}
  if(steps>=1){state='support_event';bottleneck='repeated_support'}
  if(steps>=4){state='repeated_support';bottleneck='multi_foot_coordination'}
  if(steps>=4&&feet>=3){state='multi_foot_coordination';bottleneck='legal_support_contact'}
  if(signed>=0.08&&steps>=4&&feet>=3&&segments>=3){state='sustained_locomotion';bottleneck='noninjury_or_contact'}
  const legal=(nonfoot<=0.08&&torso<=0.04&&peak<=3.5);
  if(state==='sustained_locomotion'&&legal&&nh>=0.60){state='robust_locomotion';bottleneck='challenge_robustness'}
  if(steps>=4&&feet>=3){
    if(nonfoot>0.08||torso>0.04||peak>3.5)bottleneck='legal_support_contact';
    else if(nh<0.60)bottleneck='noninjury';
    else if(signed<0.08)bottleneck='distance';
    else if(segments<3)bottleneck='progress_persistence';
  }
  const weakest={};
  for(const r of rows){const w=String(r.weakestPart||'unknown');weakest[w]=(weakest[w]||0)+1}

  return {
    distance:mean(d),distanceQ25:q25(d),
    noninjury:mean(h),noninjuryMin:nh,
    footGateRate:footGate,footRelocationQ25:relocation,
    signedAutonomousDistanceQ25:signed,genuineStepsQ25:steps,steppingFeetQ25:feet,
    positiveSegmentsQ25:segments,nonfootContactMean:nonfoot,torsoContactMean:torso,
    peakNonfootForceBW:peak,catastrophicRate:catastrophic,weakestParts:weakest,
    state,developmentalRank:STATE_RANK[state],bottleneck,legalContact:legal
  };
}
export const developmentalState=p=>String(p?.state||'stationary');
export const identifyBottleneck=p=>String(p?.bottleneck||'foot_relocation');
