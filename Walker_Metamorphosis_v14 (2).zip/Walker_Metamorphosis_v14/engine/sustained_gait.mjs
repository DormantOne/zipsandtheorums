import {clamp,num} from './utils.mjs';

export const SUSTAINED_GAIT_VERSION='sustained-steps-v1';
export const GAIT_REQUIREMENTS=Object.freeze({steps:4,feet:3,segments:3,autonomousM:.08,lateAutonomousM:.02,explorationFloor:.10});
export const GAIT_OBSERVATION_KEYS=['genuineSteps','steppingFeet','positiveProgressSegments','signedAutonomousDistanceM','lateAutonomousDistanceM','survival'];

// One extractor for simulation, reproduction and paired adjudication. Missing
// evidence earns no persistence credit and cannot establish a walking milestone.
export function gaitObservation(row={}){
  const g=row.gait||{};
  return {
    genuineSteps:row.genuineSteps??g.genuineSteps,
    steppingFeet:row.steppingFeet??g.steppingFeet,
    positiveProgressSegments:row.positiveProgressSegments??g.positiveProgressSegments,
    signedAutonomousDistanceM:row.signedAutonomousDistanceM??g.signedAutonomousDistanceM,
    lateAutonomousDistanceM:row.lateAutonomousDistanceM??g.lateAutonomousDistanceM,
    survival:row.survival,
  };
}
export function sustainedGait(row={}){
  const o=gaitObservation(row),r=GAIT_REQUIREMENTS;
  const complete=GAIT_OBSERVATION_KEYS.every(k=>Number.isFinite(o[k]));
  const components=[num(o.genuineSteps)/r.steps,num(o.steppingFeet)/r.feet,
    num(o.positiveProgressSegments)/r.segments,num(o.signedAutonomousDistanceM)/r.autonomousM,
    num(o.lateAutonomousDistanceM)/r.lateAutonomousM].map(x=>clamp(x,0,1));
  const persistence=complete?Math.pow(components.reduce((a,b)=>a*b,1),1/5):0;
  const factor=(r.explorationFloor+(1-r.explorationFloor)*persistence)*clamp(num(o.survival),0,1);
  return {version:SUSTAINED_GAIT_VERSION,...o,complete,persistence,factor,
    repeatable:complete&&components.every(x=>x>=1)&&o.survival>=.999};
}
