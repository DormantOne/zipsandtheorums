import {clamp,hash32,RNG} from './utils.mjs';

export const TARGET_VERSION='reach-stop-world-target-v2';
export const TARGET_SENSORS=3;
export const TARGET_CASES=Object.freeze({stationary:'Reach and stop',moving:'Smooth moving target',move_stop:'Move, then stop',shift_stop:'Delayed shift, then stop'});
export const TARGET_DEFAULTS=Object.freeze({leadM:1.8,leadJitterM:.4,speedMps:.12,swayM:.28,periodSeconds:20,initialSideM:.35,distanceScaleM:2,arrivalRadiusM:.18,stopSpeedMps:.06,headSpeedMps:.10,holdSeconds:.75});
export function targetMode(mode){return Object.hasOwn(TARGET_CASES,mode)?mode:'stationary'}
const smooth5=u=>{u=clamp(u,0,1);return u*u*u*(10+u*(-15+6*u))};

// Separate RNG: target generation never consumes disturbance or sensor-noise RNG.
// Coordinates are fixed in the world, never tethered to the animal.
export function makeTargetPath(seed,steps,dt,mode='stationary'){
  mode=targetMode(mode);
  const rng=new RNG(hash32(seed^0x54415247)),side=rng.next()<.5?-1:1;
  const phase=(rng.next()-.5)*1.2,period=TARGET_DEFAULTS.periodSeconds+4*rng.next();
  const x0=TARGET_DEFAULTS.leadM+(2*rng.next()-1)*TARGET_DEFAULTS.leadJitterM,y0=side*(.20+.15*rng.next());
  const points=new Float64Array((steps+1)*2),w=2*Math.PI/period,seconds=steps*dt;
  const moveStart=mode==='shift_stop'?.25*seconds:0,moveEnd=.65*seconds,moveDuration=Math.max(dt,moveEnd-moveStart);
  const travelDuration=moveDuration*Math.min(1,moveDuration/3);
  for(let i=0;i<=steps;i++){
    const t=i*dt;let x=x0,y=y0;
    if(mode==='moving'){
      x+=TARGET_DEFAULTS.speedMps*t;
      y+=side*TARGET_DEFAULTS.swayM*(Math.sin(w*t+phase)-Math.sin(phase));
    }else if(mode==='move_stop'||mode==='shift_stop'){
      // Quintic ease has zero velocity and acceleration at both ends. Travel
      // scales with duration so even short test episodes remain gentle.
      const u=smooth5((t-moveStart)/moveDuration);
      x+=(mode==='shift_stop'?.08:TARGET_DEFAULTS.speedMps)*travelDuration*u;
      y+=side*(mode==='shift_stop'?-.10:.05)*travelDuration*u;
    }
    points[2*i]=x;points[2*i+1]=y;
  }
  return {version:TARGET_VERSION,mode,seed:seed>>>0,dt,steps,side,phase,period,moveStart,moveEnd,points};
}

// Goal quality uses the terminal position, not the closest-ever approach.
// Arrival/holding is measured from the head; clean COM translation is required
// for credit, preventing a head swing or target motion from creating progress.
export class TargetGoal{
  constructor(head,com,target,dt){
    this.head={...head};this.com=[...com];this.target=[...target];this.dt=dt;
    this.initialDistanceM=Math.hypot(target[0]-head.x,target[1]-head.y);
    this.finalDistanceM=this.initialDistanceM;this.closestDistanceM=this.initialDistanceM;
    this.bodySpeedMps=0;this.headSpeedMps=0;this.targetSpeedMps=0;this.relativeSpeedMps=0;
    this.holdSeconds=0;this.settledSeconds=0;this.trackingSeconds=0;this.atTarget=false;this.reached=false;
    this.firstArrivalSeconds=null;this.elapsed=0;this.mode='stopped';
  }
  step(head,com,target,nonfootContact=false){
    const dt=this.dt,tvx=(target[0]-this.target[0])/dt,tvy=(target[1]-this.target[1])/dt;
    const vx=(com[0]-this.com[0])/dt,vy=(com[1]-this.com[1])/dt;
    const hx=(head.x-this.head.x)/dt,hy=(head.y-this.head.y)/dt,hz=((head.z||0)-(this.head.z||0))/dt;
    this.bodySpeedMps=Math.hypot(vx,vy);this.headSpeedMps=Math.hypot(hx,hy,hz);
    this.targetSpeedMps=Math.hypot(tvx,tvy);this.relativeSpeedMps=Math.hypot(vx-tvx,vy-tvy);
    this.finalDistanceM=Math.hypot(target[0]-head.x,target[1]-head.y);
    this.closestDistanceM=Math.min(this.closestDistanceM,this.finalDistanceM);this.elapsed+=dt;
    this.atTarget=this.finalDistanceM<=TARGET_DEFAULTS.arrivalRadiusM;
    if(this.atTarget){this.reached=true;this.firstArrivalSeconds??=this.elapsed}
    const moving=this.targetSpeedMps>.01;
    const controlled=this.atTarget&&!nonfootContact&&
      (moving?this.relativeSpeedMps:this.bodySpeedMps)<=TARGET_DEFAULTS.stopSpeedMps&&
      (moving?Math.hypot(hx-tvx,hy-tvy,hz):this.headSpeedMps)<=TARGET_DEFAULTS.headSpeedMps;
    this.mode=moving?'tracking':'stopped';
    this.holdSeconds=controlled?this.holdSeconds+dt:0;
    this.settledSeconds=controlled&&!moving?this.settledSeconds+dt:0;
    this.trackingSeconds=controlled&&moving?this.trackingSeconds+dt:0;
    this.head={...head};this.com=[...com];this.target=[...target];return this;
  }
  snapshot(progress,requirement='stop'){
    const required=Math.max(.1,this.initialDistanceM-TARGET_DEFAULTS.arrivalRadiusM);
    const approach=clamp(Math.min((this.initialDistanceM-this.finalDistanceM)/required,progress.progressM/required),0,1);
    const dwell=this.mode==='tracking'?this.trackingSeconds:this.settledSeconds;
    const holdQuality=clamp(dwell/TARGET_DEFAULTS.holdSeconds,0,1);
    const reachOnly=requirement==='reach';
    const goalScore=reachOnly?approach*(.85+.15*progress.straightness):approach*(.70+.10*progress.straightness+.20*holdQuality);
    const success=this.atTarget&&approach>=.95&&(reachOnly||holdQuality>=1-1e-9);
    return {goalScore,approach,holdQuality,atTarget:this.atTarget,reached:this.reached,
      success,requirement,mode:this.mode,
      initialDistanceM:this.initialDistanceM,finalDistanceM:this.finalDistanceM,closestDistanceM:this.closestDistanceM,
      firstArrivalSeconds:this.firstArrivalSeconds,settledSeconds:this.settledSeconds,trackingSeconds:this.trackingSeconds,
      bodySpeedMps:this.bodySpeedMps,headSpeedMps:this.headSpeedMps,targetSpeedMps:this.targetSpeedMps,relativeSpeedMps:this.relativeSpeedMps};
  }
}

export function targetSensors(headX,headY,yaw,targetX,targetY,out,offset=33){
  const dx=targetX-headX,dy=targetY-headY,distance=Math.hypot(dx,dy);
  const bearing=distance>1e-10?Math.atan2(dy,dx)-yaw:0;
  out[offset]=distance/(distance+TARGET_DEFAULTS.distanceScaleM);
  out[offset+1]=Math.sin(bearing);out[offset+2]=Math.cos(bearing);
  return out;
}

export class TargetProgress{
  constructor(x,y){this.x=x;this.y=y;this.signedProgressM=0;this.pathLengthM=0;this.blockedProgressM=0;this.errorSum=0;this.ticks=0}
  step(x,y,tx,ty,nonfootContact=false){
    // Freeze the target over this displacement. Target motion alone earns zero.
    const before=Math.hypot(tx-this.x,ty-this.y),after=Math.hypot(tx-x,ty-y);
    const progress=before-after;
    this.pathLengthM+=Math.hypot(x-this.x,y-this.y);
    // Retreat always counts, including retreat while scraping. No clean-forward /
    // dirty-backward ratchet. Positive translation with illegal support is lost.
    if(nonfootContact&&progress>0)this.blockedProgressM+=progress;
    else this.signedProgressM+=progress;
    this.errorSum+=after;this.ticks++;this.x=x;this.y=y;
    return this;
  }
  snapshot(){
    const progressM=Math.max(0,this.signedProgressM);
    const straightness=this.pathLengthM>1e-9?clamp(progressM/this.pathLengthM,0,1):0;
    return {progressM,signedProgressM:this.signedProgressM,pathLengthM:this.pathLengthM,straightness,
      effectiveDistanceM:progressM*straightness,blockedProgressM:this.blockedProgressM,
      meanDistanceM:this.ticks?this.errorSum/this.ticks:0};
  }
}
