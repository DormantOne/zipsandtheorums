import {clamp,num} from './utils.mjs';

export const TASK_CURRICULUM_VERSION='walker-task-curriculum-v1';
export const TASK_MODES=Object.freeze({walk:'Regular walking',target:'Target curriculum'});
export const TARGET_SKILL_STAGES=Object.freeze([
  {level:0,id:'reach',label:'Reach target',targetMode:'stationary',requirement:'reach'},
  {level:1,id:'reach_stop',label:'Reach + stop',targetMode:'stationary',requirement:'stop'},
  {level:2,id:'follow',label:'Follow moving target',targetMode:'moving',requirement:'follow'},
  {level:3,id:'move_stop',label:'Follow, then stop',targetMode:'move_stop',requirement:'stop'},
  {level:4,id:'shift_stop',label:'Delayed shift, then stop',targetMode:'shift_stop',requirement:'stop'},
]);

export function taskMode(v){return Object.hasOwn(TASK_MODES,v)?v:'walk'}
export function targetSkillStage(level){
  const i=clamp(Math.trunc(num(level,0)),0,TARGET_SKILL_STAGES.length-1);
  return TARGET_SKILL_STAGES[i];
}
export function applyTaskScenario(sc,{mode='walk',stage=0}={}){
  const m=taskMode(mode);sc.taskMode=m;
  if(m==='walk'){
    sc.targetSkillStage=null;sc.targetSkillId=null;sc.targetRequirement=null;sc.targetMode='stationary';
  }else{
    const s=targetSkillStage(stage);sc.targetSkillStage=s.level;sc.targetSkillId=s.id;sc.targetRequirement=s.requirement;sc.targetMode=s.targetMode;
  }
  return sc;
}
export function promotionThreshold(stage,cfg={}){
  const s=targetSkillStage(stage),hold=s.requirement!=='reach';
  return {
    rewardFloor:clamp(num(cfg.targetPromotionRewardFloor,.45),0,1),
    healthFloor:clamp(num(cfg.targetPromotionHealthFloor,.995),0,1),
    successFloor:hold?clamp(num(cfg.targetPromotionSuccessFloor,.50),0,1):0,
  };
}
export function targetStagePass(stats,stage,cfg={}){
  const t=promotionThreshold(stage,cfg),s=targetSkillStage(stage);
  const reward=num(stats?.qFitness),health=num(stats?.difficultyHealth),success=num(stats?.targetHealthySuccessRate);
  const passed=reward>=t.rewardFloor&&health>=t.healthFloor&&(s.requirement==='reach'||success>=t.successFloor);
  return {passed,stage:s,thresholds:t,reward,health,healthySuccessRate:success};
}
