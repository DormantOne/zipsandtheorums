/* engine/ternary.mjs — the ternary protoneuron brain on the MuJoCo walker.
 *
 * WHERE THIS COMES FROM
 * A direct port of the Protoneuron Triple-Pendulum Lab (v12) brain, kept as
 * close to the lab as the new body allows. Every unit is the lab's unit:
 *
 *   - exactly THREE incoming slots; each slot names a source (a ternary sensor,
 *     or ANY unit's output from the previous control step, itself included)
 *     and a ternary weight w in {-1, 0, +1};
 *   - z = bias + sum_k w_k * source_k;
 *   - three affine pieces  r0 = fb0 - d, r1 = fb1, r2 = fb2 + d  with
 *     d = gain * clamp(z, -12, 12) / T  (T = 0.22, the lab's DECT);
 *   - the output is the ARGMAX piece mapped to -1 / 0 / +1, with the lab's
 *     tie rules (outer ties go to -1, anything unresolved stays 0).
 *
 * The network is NOT layered. Every unit reads the previous step's outputs of
 * any units it likes, so a unit->unit hop costs one 20 ms control step and a
 * sensor->unit->voter path acts within the same step. Latches (w=+1 self slot),
 * flip-flops (w=-1 self slot) and rings are all expressible; nothing is
 * prescribed.
 *
 * The decoder is the lab's vote tally: every actuator reads a set of units
 * with ternary signs and emits tanh(sum / max(3, 0.55 * voters)). The walker
 * version fixes the number of voters per actuator at V (default 6) and only
 * ever MOVES or re-signs a vote, never adds or deletes one, so an actuator's
 * gain cannot drift with the decoder density the way the lab's did.
 *
 * THE GENOME IS SELF-DESCRIBING. A Float64Array, so it rides through every
 * existing copyG / checkpoint / fossil / pool path unchanged, laid out as
 *
 *   [0] code (1)   [1] N units   [2] S sensors   [3] A actuators (8)
 *   [4] V voters per actuator    [5] pacemaker period P (control steps, 0=off)
 *   [6] reserved (0)             [7] reserved (0)
 *   src[3N]  w[3N]  bias[N]  fireBias[3N]  gain[N]  dec[A*N]   (8 + 19N)
 *
 * src codes 0..S-1 are sensors, S..S+N-1 are units (so growing N at the end
 * never renumbers an existing source). Values are exact doubles; nothing is
 * rounded on save or load (the lab's packBrain toFixed(3) rounding is gone).
 *
 * THE ENCODER. The lab's pendulum sensors were ternary by construction
 * (tri(x/scale) with a 0.33 dead zone). The walker's 36 public sensors are
 * continuous, so each is given a physical dead zone here (3 degrees of pitch,
 * 0.1 rad of joint angle, 7.5 cm/s of forward velocity ...), plus the lab's
 * constant +1 sensor, four hip-phase difference channels (the lab also fed
 * angle differences) and an optional two-channel pacemaker clock that is OFF
 * unless the KG turns it on (header P). All thresholds are fixed measurement
 * constants, not searchable design factors.
 */
import {clamp,num,hash32,RNG} from './utils.mjs';
import {PLANT} from './plant.js';

export const TERNARY_VERSION='ternary-protoneuron-v1';
export const TERNARY_OPERATOR_VERSION='ternary-protoneuron-operator-v1';
export const TERNARY_GENOME_CODE=1;
export const HEADER=8;
export const T_ACT=8;
export const DECT=0.22;
export const T_LIMITS=Object.freeze({bias:2.5,biasStep:.25,fireBias:5,fireBiasStep:.3,gainMin:.08,gainMax:3.5,
  gainDown:.82,gainUp:1.22,gainInit:.9,zClamp:12});
export const N_RANGE=Object.freeze({min:8,max:512,base:12});
export const V_RANGE=Object.freeze({min:3,max:24,base:6});
export const PACEMAKER_RANGE=Object.freeze({min:0,max:100});

/* The operator's registered rule. Kind boundaries are the lab's mutate(). */
export const TERNARY_RULE=Object.freeze({version:TERNARY_OPERATOR_VERSION,
  kinds:Object.freeze({weight:.26,rewire:.50,bias:.62,fireBias:.72,gain:.78}),   // cumulative; the rest is the decoder
  silenceOdds:.10,          // a live weight flip silences with probability 1/10 (P(live) -> ~0.91)
  regrowRewire:.50,         // a regrown (silent -> live) slot also takes a fresh source half the time
  focus:.85,                // mutation targets units the decoder reads (and their inputs) 85 % of the time
  sensorBias:.50,           // half of all rewires go to a sensor
  orphanPreference:.50,     // a unit-source rewire prefers an unread unit half the time
  joltProbability:.08,joltScale:1.5,   // the lab's "strong" mutation, as liquid dog's jolt rate
  crossover:.25,            // unit-block crossover between two elites, with repair
  countDivisor:32,minCount:2});

export function baseMutationCount(N){return Math.max(TERNARY_RULE.minCount,Math.round(num(N,12)/TERNARY_RULE.countDivisor))}

// ── the encoder ────────────────────────────────────────────────────────────
const KNEE_REST=clamp(PLANT.kneeRangeMin+PLANT.kneeRestOffset,PLANT.kneeRangeMin,PLANT.kneeRangeMax);
const JOINT_NAMES_SHORT=['FL hip','FL knee','FR hip','FR knee','RL hip','RL knee','RR hip','RR knee'];
/* [label, group, observation index, centre, dead-zone half-width, key]. Values
 * are in the plant's own normalised observation units; the physical meaning
 * of each dead zone is in the comment. */
const LINEAR=[
  ['pitch','posture',0,0,.05,true],           // ~3 deg nose up/down
  ['roll','posture',1,0,.05,true],            // ~3 deg
  ['tilt','posture',2,-1,.03,true],           // 1-cos(tilt) > .03 (~14 deg): 0 or +1
  ['roll rate','posture',3,0,.125,true],      // 0.5 rad/s
  ['pitch rate','posture',4,0,.125,true],     // 0.5 rad/s
  ['yaw rate','posture',5,0,.125,false],      // 0.5 rad/s
  ['height','posture',6,0,.10,true],          // 3 cm from the calibrated stance
  ['fwd vel','motion',7,0,.05,true],          // 7.5 cm/s body-frame
  ['lat vel','motion',8,0,.05,false],
  ['vert vel','motion',9,0,.05,false],
  ['sin yaw','heading',10,0,.10,false],
  ...JOINT_NAMES_SHORT.map((n,j)=>[`${n} q`,'joint angle',12+j,j%2===0?0:(KNEE_REST+.2)/1.5,.1/1.5,true]),   // 0.1 rad; knees centred 0.2 rad flexed from rest
  ...JOINT_NAMES_SHORT.map((n,j)=>[`${n} qd`,'joint velocity',20+j,0,.1,j%2===0]),                    // 0.5 rad/s
];
export const TERNARY_SENSORS=Object.freeze([
  ...LINEAR.map(([label,group,obs,center,thr,key])=>({label,group,kind:'linear',obs,center,thr,key})),
  ...[0,1,2,3].map(f=>({label:`${['FL','FR','RL','RR'][f]} contact`,group:'contact',kind:'contact',obs:28+f,key:true})),
  {label:'lateral pos',group:'heading',kind:'linear',obs:32,center:0,thr:.05,key:false},
  {label:'target range',group:'target',kind:'linear',obs:33,center:0,thr:.2,key:false,target:true},
  {label:'target sin',group:'target',kind:'linear',obs:34,center:0,thr:.2,key:false,target:true},
  {label:'target cos',group:'target',kind:'linear',obs:35,center:0,thr:.2,key:false,target:true},
  {label:'constant +1',group:'bias',kind:'constant',key:true},
  {label:'FL-FR hip',group:'phase',kind:'diff',a:12,b:14,thr:.1,key:false},
  {label:'RL-RR hip',group:'phase',kind:'diff',a:16,b:18,thr:.1,key:false},
  {label:'FL-RL hip',group:'phase',kind:'diff',a:12,b:16,thr:.1,key:false},
  {label:'FL-RR hip',group:'phase',kind:'diff',a:12,b:18,thr:.1,key:false},
  {label:'clock sin',group:'pacemaker',kind:'clock',phase:0,thr:.5,key:false,clock:true},
  {label:'clock cos',group:'pacemaker',kind:'clock',phase:1,thr:.5,key:false,clock:true},
].map((s,i)=>Object.freeze({...s,index:i})));
export const T_SENS=TERNARY_SENSORS.length;
export const TERNARY_SENSOR_LABELS=Object.freeze(TERNARY_SENSORS.map(s=>s.label));
export const TERNARY_SENSOR_GROUPS=Object.freeze([...new Set(TERNARY_SENSORS.map(s=>s.group))]);
export const CONSTANT_SENSOR=TERNARY_SENSORS.findIndex(s=>s.kind==='constant');
/* Birth coverage order: what a standing, stepping body most needs to feel. */
const KEY_PRIORITY=['FL contact','FR contact','RL contact','RR contact','pitch','roll','FL hip q','FR hip q','RL hip q','RR hip q',
  'FL knee q','FR knee q','RL knee q','RR knee q','pitch rate','roll rate','height','tilt','fwd vel','constant +1',
  'FL hip qd','FR hip qd','RL hip qd','RR hip qd'];
export const KEY_SENSORS=Object.freeze(KEY_PRIORITY.map(l=>TERNARY_SENSORS.findIndex(s=>s.label===l)).filter(i=>i>=0));

const tri=(v,thr)=>v>thr?1:v<-thr?-1:0;
/* Encode one observation vector into the ternary sensor vector `s`. `t` is
 * the control step inside the rollout (the pacemaker's only input). */
export function encodeTernary(obs,t,s,pacemaker=0){
  for(let i=0;i<T_SENS;i++){
    const d=TERNARY_SENSORS[i];
    switch(d.kind){
      case 'linear':s[i]=tri(num(obs[d.obs])-d.center,d.thr);break;
      case 'contact':s[i]=num(obs[d.obs])>.5?1:-1;break;
      case 'constant':s[i]=1;break;
      case 'diff':s[i]=tri(num(obs[d.a])-num(obs[d.b]),d.thr);break;
      case 'clock':{if(!(pacemaker>0)){s[i]=0;break}const ph=2*Math.PI*t/pacemaker;s[i]=tri(d.phase===0?Math.sin(ph):Math.cos(ph),d.thr);break}
      default:s[i]=0;
    }
  }
  return s;
}
/* Sensors that can never change in this task, whatever the body does. */
export function deadSensorSet(taskMode='walk',pacemaker=0){
  const dead=new Set();
  for(const d of TERNARY_SENSORS){
    if(d.target&&taskMode!=='target')dead.add(d.index);
    if(d.clock&&!(pacemaker>0))dead.add(d.index);
  }
  return dead;
}

// ── genome layout ──────────────────────────────────────────────────────────
export function ternaryLayout(N,S=T_SENS,A=T_ACT){
  N=Math.trunc(N);const o={N,S,A};let p=HEADER;
  o.src=p;p+=3*N;o.w=p;p+=3*N;o.bias=p;p+=N;o.fireBias=p;p+=3*N;o.gain=p;p+=N;o.dec=p;p+=A*N;o.total=p;
  return o;
}
export function ternaryGenomeLength(N){return ternaryLayout(N).total}
export function isTernaryGenome(g){
  if(!g||g.length<HEADER||num(g[0])!==TERNARY_GENOME_CODE)return false;
  const N=Math.trunc(num(g[1])),S=Math.trunc(num(g[2])),A=Math.trunc(num(g[3]));
  return N>=1&&S===T_SENS&&A===T_ACT&&g.length===ternaryLayout(N,S,A).total;
}
export function ternaryHeader(g){
  return {code:num(g?.[0]),N:Math.trunc(num(g?.[1])),S:Math.trunc(num(g?.[2])),A:Math.trunc(num(g?.[3])),
    V:Math.trunc(num(g?.[4])),pacemaker:Math.trunc(num(g?.[5])),length:g?.length??0};
}
/* Structured, typed copy of a genome. Every function below works on this and
 * writes it back with packTernary, so a genome is never half-edited. */
export function unpackTernary(g){
  if(!isTernaryGenome(g))throw new Error(`not a ternary genome (header ${JSON.stringify(ternaryHeader(g))})`);
  const h=ternaryHeader(g),L=ternaryLayout(h.N,h.S,h.A),N=h.N;
  const b={N,S:h.S,A:h.A,V:h.V,P:h.pacemaker,
    src:new Int32Array(3*N),w:new Int8Array(3*N),bias:new Float64Array(N),fireBias:new Float64Array(3*N),gain:new Float64Array(N),dec:new Int8Array(h.A*N)};
  for(let i=0;i<3*N;i++){b.src[i]=Math.trunc(num(g[L.src+i]));b.w[i]=Math.sign(Math.round(num(g[L.w+i])));b.fireBias[i]=num(g[L.fireBias+i])}
  for(let i=0;i<N;i++){b.bias[i]=num(g[L.bias+i]);b.gain[i]=num(g[L.gain+i],T_LIMITS.gainInit)}
  for(let i=0;i<h.A*N;i++)b.dec[i]=Math.sign(Math.round(num(g[L.dec+i])));
  return b;
}
export function packTernary(b){
  const L=ternaryLayout(b.N,b.S,b.A),g=new Float64Array(L.total);
  g[0]=TERNARY_GENOME_CODE;g[1]=b.N;g[2]=b.S;g[3]=b.A;g[4]=b.V;g[5]=b.P||0;g[6]=0;g[7]=0;
  g.set(Float64Array.from(b.src),L.src);g.set(Float64Array.from(b.w),L.w);g.set(b.bias,L.bias);
  g.set(b.fireBias,L.fireBias);g.set(b.gain,L.gain);g.set(Float64Array.from(b.dec),L.dec);
  return g;
}
function cloneBrain(b){return {...b,src:b.src.slice(),w:b.w.slice(),bias:b.bias.slice(),fireBias:b.fireBias.slice(),gain:b.gain.slice(),dec:b.dec.slice()}}

// ── the controller ─────────────────────────────────────────────────────────
/* One fresh controller per rollout: state starts at zero, exactly as the lab's
 * runEpisode starts every episode from prev = 0. `lesion` silences one unit
 * (its output is forced to 0 every step), which is the KG's functional
 * ablation. `hidden()` returns [unit outputs N | ternary sensors S | motor 8]. */
export function makeTernaryController(genome,{lesion=null}={}){
  const b=unpackTernary(genome),N=b.N,S=b.S,A=b.A,P=b.P;
  const src=b.src,w=b.w,bias=b.bias,fb=b.fireBias,gain=b.gain;
  const voters=[];for(let a=0;a<A;a++){const u=[],sg=[];for(let i=0;i<N;i++){const v=b.dec[a*N+i];if(v){u.push(i);sg.push(v)}}voters.push({u:Int32Array.from(u),s:Int8Array.from(sg)})}
  const norm=Math.max(3,b.V*.55),s=new Int8Array(S),input=new Int8Array(S+N),h=new Int8Array(N),out=new Float64Array(A);
  const lesioned=Number.isInteger(lesion)&&lesion>=0&&lesion<N?lesion:-1,zc=T_LIMITS.zClamp;
  let t=0;
  const control=obs=>{
    encodeTernary(obs,t,s,P);
    input.set(s,0);   // input[S..S+N) still holds the PREVIOUS step's unit outputs
    for(let i=0;i<N;i++){
      let z=bias[i];const k0=3*i;
      for(let k=0;k<3;k++){const wk=w[k0+k];if(wk)z+=wk*input[src[k0+k]]}
      const zz=z>zc?zc:z<-zc?-zc:z,d=gain[i]*zz/DECT,r0=fb[k0]-d,r1=fb[k0+1],r2=fb[k0+2]+d;
      h[i]=i===lesioned?0:((r0>r1&&r0>=r2)?-1:(r2>r1&&r2>r0)?1:0);
    }
    for(let a=0;a<A;a++){const V=voters[a];let sum=0;for(let j=0;j<V.u.length;j++)sum+=V.s[j]*h[V.u[j]];out[a]=Math.tanh(sum/norm)}
    input.set(h,S);t++;
    return out;
  };
  const hidden=()=>{const z=new Float64Array(N+S+A);for(let i=0;i<N;i++)z[i]=h[i];for(let i=0;i<S;i++)z[N+i]=s[i];for(let a=0;a<A;a++)z[N+S+a]=out[a];return z};
  return {control,hidden,N,S,A,V:b.V,P,reset(){t=0;input.fill(0);h.fill(0);out.fill(0);s.fill(0)}};
}

// ── wiring analysis (shared by birth, the operator, telemetry and the GUI) ──
export function wiringState(b,{taskMode='walk'}={}){
  const N=b.N,S=b.S,dead=deadSensorSet(taskMode,b.P);
  const readByUnits=new Int32Array(N),votes=new Int32Array(N),live=new Int32Array(N),sensorSlots=new Int32Array(N);
  for(let i=0;i<N;i++)for(let k=0;k<3;k++){
    const x=3*i+k;if(!b.w[x])continue;live[i]++;const c=b.src[x];
    if(c<S){if(!dead.has(c))sensorSlots[i]++}else if(c-S!==i)readByUnits[c-S]++;
  }
  for(let a=0;a<b.A;a++)for(let i=0;i<N;i++)if(b.dec[a*N+i])votes[i]++;
  /* Structurally constant: every live slot reads a dead sensor or the +1
   * constant (a unit reading any unit is conservatively treated as varying,
   * because rings and self-slots can oscillate). */
  const constant=new Uint8Array(N);
  for(let i=0;i<N;i++){let varying=false;for(let k=0;k<3;k++){const x=3*i+k;if(!b.w[x])continue;const c=b.src[x];if(c>=S||(!dead.has(c)&&c!==CONSTANT_SENSOR)){varying=true;break}}constant[i]=varying?0:1}
  const unread=[];for(let i=0;i<N;i++)if(!readByUnits[i]&&!votes[i])unread.push(i);
  return {dead,readByUnits,votes,live,sensorSlots,constant,unread};
}
function relevantUnits(b){
  const N=b.N,S=b.S,read=new Set();
  for(let a=0;a<b.A;a++)for(let i=0;i<N;i++)if(b.dec[a*N+i])read.add(i);
  const deep=new Set(read);
  for(const i of read)for(let k=0;k<3;k++){const c=b.src[3*i+k];if(c>=S)deep.add(c-S)}
  return [...deep].sort((x,y)=>x-y);
}
const pick=(rng,a)=>a[Math.floor(rng.next()*a.length)];
function liveSensorList(b,taskMode){const dead=deadSensorSet(taskMode,b.P),out=[];for(let i=0;i<b.S;i++)if(!dead.has(i))out.push(i);return out}
/* Source choice for a rewire of unit i: sensor-biased, orphan-preferring,
 * never a dead sensor, and a structurally constant unit only if nothing else
 * exists. */
function chooseSource(b,i,rng,ws,{sensorBias=TERNARY_RULE.sensorBias,orphanPreference=TERNARY_RULE.orphanPreference,taskMode='walk'}={}){
  const sensors=liveSensorList(b,taskMode);
  if(rng.next()<sensorBias||b.N<1)return pick(rng,sensors);
  const unread=ws.unread.filter(u=>u!==i);
  if(unread.length&&rng.next()<orphanPreference)return b.S+pick(rng,unread);
  for(let tries=0;tries<8;tries++){
    const c=Math.floor(rng.next()*(sensors.length+b.N));
    if(c<sensors.length)return sensors[c];
    const u=c-sensors.length;if(!ws.constant[u])return b.S+u;
  }
  return pick(rng,sensors);
}
/* Opposite-sign duplicate live slots on one unit cancel exactly and waste two
 * slots; repair by redrawing the later source, or failing that by matching
 * signs (a same-sign duplicate is a legitimate weight of 2). */
function repairUnitDuplicates(b,i,rng,ws,opts){
  let fixed=0;
  for(let k1=0;k1<3;k1++)for(let k2=k1+1;k2<3;k2++){
    const x1=3*i+k1,x2=3*i+k2;
    if(!b.w[x1]||!b.w[x2]||b.src[x1]!==b.src[x2]||b.w[x1]===b.w[x2])continue;
    let ok=false;
    for(let t=0;t<8&&!ok;t++){const c=chooseSource(b,i,rng,ws,opts);if(c!==b.src[x1]){b.src[x2]=c;ok=true}}
    if(!ok)b.w[x2]=b.w[x1];
    fixed++;
  }
  return fixed;
}
/* Exactly V votes per actuator, each on a distinct unit. */
function repairVoters(b,rng){
  const N=b.N,V=clamp(Math.trunc(b.V),1,N);b.V=V;let moved=0;
  for(let a=0;a<b.A;a++){
    const on=[],off=[];for(let i=0;i<N;i++)(b.dec[a*N+i]?on:off).push(i);
    while(on.length>V){const j=Math.floor(rng.next()*on.length),[i]=on.splice(j,1);b.dec[a*N+i]=0;off.push(i);moved++}
    while(on.length<V&&off.length){const j=Math.floor(rng.next()*off.length),[i]=off.splice(j,1);b.dec[a*N+i]=rng.next()<.5?-1:1;on.push(i);moved++}
  }
  return moved;
}
function clampParams(b){
  for(let i=0;i<b.N;i++){
    b.bias[i]=clamp(num(b.bias[i]),-T_LIMITS.bias,T_LIMITS.bias);
    b.gain[i]=clamp(num(b.gain[i],T_LIMITS.gainInit),T_LIMITS.gainMin,T_LIMITS.gainMax);
    for(let k=0;k<3;k++){const x=3*i+k;b.fireBias[x]=clamp(num(b.fireBias[x]),-T_LIMITS.fireBias,T_LIMITS.fireBias);b.src[x]=clamp(Math.trunc(b.src[x]),0,b.S+b.N-1);b.w[x]=Math.sign(b.w[x])}
  }
  for(let i=0;i<b.dec.length;i++)b.dec[i]=Math.sign(b.dec[i]);
}
/* Enforce every invariant. Deterministic: any random repair draws from an RNG
 * seeded by the genome's own bytes. */
export function repairTernary(g,{taskMode='walk'}={}){
  const b=unpackTernary(g);clampParams(b);
  let h=0x811C9DC5;for(let i=0;i<g.length;i++){h^=Math.trunc(num(g[i])*1e6)&0xffff;h=Math.imul(h,0x01000193)>>>0}
  const rng=new RNG(hash32(h)),ws=wiringState(b,{taskMode});
  for(let i=0;i<b.N;i++)repairUnitDuplicates(b,i,rng,ws,{taskMode});
  repairVoters(b,rng);
  return packTernary(b);
}

// ── birth: the wiring optimizer ────────────────────────────────────────────
/* A newborn is built, not sampled. The rules (from the design review):
 *   1. every unit has three LIVE slots on three DISTINCT sources;
 *   2. every unit has at least one sensor slot (so nothing starts deaf);
 *   3. the key sensors are covered first, in priority order (feet, posture,
 *      hips, knees ...), cycling if there are more units than key sensors;
 *   4. unit sources go to the least-read unit first, so every unit is read by
 *      someone whenever there are enough slots (always, for N >= 4);
 *   5. the 8V votes are spread so each unit votes on about 8V/N actuators and
 *      no unit votes twice for one actuator.
 * Weights are +/-1, bias 0, fire biases 0, gain 0.9: the lab's makeNet
 * defaults, so a newborn unit is exactly sign(z). */
export function birthTernary(rng,{N=N_RANGE.base,V=V_RANGE.base,pacemaker=0,taskMode='walk'}={}){
  N=clamp(Math.trunc(num(N,N_RANGE.base)),1,N_RANGE.max);V=clamp(Math.trunc(num(V,V_RANGE.base)),1,N);
  const S=T_SENS,A=T_ACT,P=clamp(Math.trunc(num(pacemaker,0)),0,PACEMAKER_RANGE.max);
  const b={N,S,A,V,P,src:new Int32Array(3*N),w:new Int8Array(3*N),bias:new Float64Array(N),fireBias:new Float64Array(3*N),gain:new Float64Array(N).fill(T_LIMITS.gainInit),dec:new Int8Array(A*N)};
  const sensors=liveSensorList(b,taskMode),keys=KEY_SENSORS.filter(k=>sensors.includes(k));
  let keyCursor=Math.floor(rng.next()*Math.max(1,Math.min(4,keys.length)));   // start among the four feet
  const readCount=new Int32Array(N),order=[...Array(N).keys()];
  for(let i=N-1;i>0;i--){const j=Math.floor(rng.next()*(i+1));[order[i],order[j]]=[order[j],order[i]]}
  /* least-read unit not already used by this unit; reading oneself costs a
   * half point so a self-slot (latch / flip-flop) is possible but not favoured */
  const leastRead=(exclude,self)=>{let best=Infinity,cands=[];for(let j=0;j<N;j++){if(exclude.has(j))continue;const c=readCount[j]+(j===self?.5:0);if(c<best){best=c;cands=[j]}else if(c===best)cands.push(j)}return cands.length?pick(rng,cands):-1};
  const freshSensor=used=>{let s,t=0;do{s=pick(rng,sensors)}while(used.has(s)&&t++<64);return s};
  for(const i of order){
    const used=new Set();
    const s0=keys.length?keys[keyCursor++%keys.length]:pick(rng,sensors);used.add(s0);
    let s1;
    if(rng.next()<.5||N<3)s1=freshSensor(used);
    else{const j=leastRead(new Set(),i);s1=j>=0?S+j:freshSensor(used)}
    if(used.has(s1))s1=freshSensor(used);
    used.add(s1);
    let s2=-1;
    if(N>=2){const ex=new Set();for(const u of used)if(u>=S)ex.add(u-S);const j=leastRead(ex,i);if(j>=0)s2=S+j}
    if(s2<0||used.has(s2))s2=freshSensor(used);
    const slots=[s0,s1,s2];
    for(let k=0;k<3;k++){b.src[3*i+k]=slots[k];b.w[3*i+k]=rng.next()<.5?-1:1;if(slots[k]>=S)readCount[slots[k]-S]++}
  }
  const voteCount=new Int32Array(N);
  for(let a=0;a<A;a++){
    const chosen=new Set();
    for(let v=0;v<V;v++){
      let best=Infinity,cands=[];
      for(let i=0;i<N;i++){if(chosen.has(i))continue;const c=voteCount[i]*4+(readCount[i]>0?0:-1);if(c<best){best=c;cands=[i]}else if(c===best)cands.push(i)}
      const i=pick(rng,cands);chosen.add(i);voteCount[i]++;b.dec[a*N+i]=rng.next()<.5?-1:1;
    }
  }
  return packTernary(b);
}

// ── the operator ───────────────────────────────────────────────────────────
/* The lab's mutate(), with the three walker amendments from the design
 * review: silencing odds 1/10 (a flip of a live weight silences only one time
 * in ten, so ~91 % of slots stay live instead of the lab's drift toward 2/3),
 * regrowth (a silent slot that revives takes a fresh source half the time),
 * and a vote-conserving decoder. Everything else — the kind table, the 85 %
 * focus on units the decoder reads, the 50 % sensor bias of rewiring, bias
 * steps of 0.25, fire-bias steps of 0.3, gain x0.82 / x1.22 — is the lab's. */
export function mutateTernary(genome,rng,{count=null,heat=1,taskMode='walk',focus=TERNARY_RULE.focus,sensorBias=TERNARY_RULE.sensorBias,silenceOdds=TERNARY_RULE.silenceOdds,allowJolt=true}={}){
  const b=unpackTernary(genome),N=b.N,S=b.S,rule=TERNARY_RULE.kinds;
  const base=count===null?baseMutationCount(N):Math.max(1,Math.trunc(num(count,1)));
  const n=Math.max(1,Math.round(base*clamp(num(heat,1),1,4)));
  const jolt=allowJolt&&rng.next()<TERNARY_RULE.joltProbability;
  const opts={sensorBias,taskMode};let ws=wiringState(b,{taskMode});
  const rel=relevantUnits(b),target=()=>rel.length&&rng.next()<focus?pick(rng,rel):Math.floor(rng.next()*N);
  const ops={weight:0,silence:0,regrow:0,rewire:0,bias:0,fireBias:0,gain:0,voteMove:0,voteSign:0,jolt:0,repairs:0};
  for(let z=0;z<n;z++){
    const i=target(),k=Math.floor(rng.next()*3),x=3*i+k,u=rng.next();
    if(u<rule.weight){
      if(!b.w[x]){b.w[x]=rng.next()<.5?-1:1;ops.regrow++;if(rng.next()<TERNARY_RULE.regrowRewire)b.src[x]=chooseSource(b,i,rng,ws,opts)}
      else if(rng.next()<silenceOdds){b.w[x]=0;ops.silence++}
      else{b.w[x]=-b.w[x];ops.weight++}
    }else if(u<rule.rewire){b.src[x]=chooseSource(b,i,rng,ws,opts);ops.rewire++}
    else if(u<rule.bias){b.bias[i]=clamp(b.bias[i]+(rng.next()<.5?-1:1)*T_LIMITS.biasStep,-T_LIMITS.bias,T_LIMITS.bias);ops.bias++}
    else if(u<rule.fireBias){const c=3*i+Math.floor(rng.next()*3);b.fireBias[c]=clamp(b.fireBias[c]+(rng.next()<.5?-1:1)*T_LIMITS.fireBiasStep,-T_LIMITS.fireBias,T_LIMITS.fireBias);ops.fireBias++}
    else if(u<rule.gain){b.gain[i]=clamp(b.gain[i]*(rng.next()<.5?T_LIMITS.gainDown:T_LIMITS.gainUp),T_LIMITS.gainMin,T_LIMITS.gainMax);ops.gain++}
    else{
      const a=Math.floor(rng.next()*b.A),row=a*N;
      if(b.dec[row+i]){
        if(rng.next()<.5){b.dec[row+i]=-b.dec[row+i];ops.voteSign++}
        else{const zeros=[];for(let j=0;j<N;j++)if(!b.dec[row+j])zeros.push(j);
          if(zeros.length){const j=pick(rng,zeros);b.dec[row+j]=rng.next()<.5?-1:1;b.dec[row+i]=0;ops.voteMove++}else{b.dec[row+i]=-b.dec[row+i];ops.voteSign++}}
      }else{
        const on=[];for(let j=0;j<N;j++)if(b.dec[row+j])on.push(j);
        if(on.length){const j=pick(rng,on);b.dec[row+j]=0;b.dec[row+i]=rng.next()<.5?-1:1;ops.voteMove++}
      }
    }
    if(u<rule.rewire)ws=wiringState(b,{taskMode});
  }
  if(jolt){
    /* the lab's strong mutation: extra rewires with a fresh weight. The lab
     * drew that weight uniformly from {-1,0,+1}; here it obeys the same 1/10
     * silencing odds as a flip, otherwise jolts alone would hold the live
     * fraction near 0.83 instead of the registered ~0.91. */
    const extra=Math.max(2,Math.round(n*TERNARY_RULE.joltScale));
    for(let z=0;z<extra;z++){const i=target(),x=3*i+Math.floor(rng.next()*3);b.src[x]=chooseSource(b,i,rng,ws,opts);b.w[x]=rng.next()<silenceOdds?0:(rng.next()<.5?-1:1);ops.jolt++}
    ws=wiringState(b,{taskMode});
  }
  for(let i=0;i<N;i++)ops.repairs+=repairUnitDuplicates(b,i,rng,ws,opts);
  ops.repairs+=repairVoters(b,rng);
  return {genome:packTernary(b),count:n,jolt,ops,eligible:ternaryLayout(N).total-HEADER};
}

/* Unit-block crossover (the lab's crossover(): a contiguous block of 20-60 %
 * of the units, wrapping, taken whole from the second parent — slots, biases,
 * fire biases, gain and that unit's votes). Votes are then repaired back to
 * exactly V per actuator. Mismatched sizes return a copy of the first parent. */
export function crossoverTernary(a,b0,rng,{taskMode='walk'}={}){
  const A=unpackTernary(a),B=unpackTernary(b0);
  if(A.N!==B.N||A.V!==B.V||A.P!==B.P)return {genome:new Float64Array(a),crossed:false,why:'shape mismatch'};
  const N=A.N,cut=Math.floor(rng.next()*N),len=Math.max(1,Math.floor(N*(.2+rng.next()*.4)));
  for(let x=0;x<len;x++){
    const i=(cut+x)%N;
    for(let k=0;k<3;k++){A.src[3*i+k]=B.src[3*i+k];A.w[3*i+k]=B.w[3*i+k];A.fireBias[3*i+k]=B.fireBias[3*i+k]}
    A.bias[i]=B.bias[i];A.gain[i]=B.gain[i];
    for(let c=0;c<A.A;c++)A.dec[c*N+i]=B.dec[c*N+i];
  }
  const ws=wiringState(A,{taskMode});let repairs=0;
  for(let i=0;i<N;i++)repairs+=repairUnitDuplicates(A,i,rng,ws,{taskMode});
  repairs+=repairVoters(A,rng);
  return {genome:packTernary(A),crossed:true,block:[cut,len],repairs};
}

// ── structural surgery (growth, pruning, excision, voters, pacemaker) ──────
/* Grow to newN by appending SILENT units: all slots w=0 (sources parked on
 * live sensors for later regrowth), bias 0, no votes. A silent unit outputs 0
 * and nothing reads it, so behaviour is bit-identical until mutation recruits
 * it. Existing source codes never change because units are appended. */
export function growTernary(genome,newN,rng,{taskMode='walk'}={}){
  const b=unpackTernary(genome),N=b.N,M=clamp(Math.trunc(num(newN,N)),N,N_RANGE.max);
  if(M===N)return new Float64Array(genome);
  const sensors=liveSensorList(b,taskMode),S=b.S;
  const src=new Int32Array(3*M),w=new Int8Array(3*M),fireBias=new Float64Array(3*M),bias=new Float64Array(M),gain=new Float64Array(M).fill(T_LIMITS.gainInit),dec=new Int8Array(b.A*M);
  for(let x=0;x<3*N;x++){src[x]=b.src[x];w[x]=b.w[x];fireBias[x]=b.fireBias[x]}
  for(let i=0;i<N;i++){bias[i]=b.bias[i];gain[i]=b.gain[i]}
  for(let x=3*N;x<3*M;x++){src[x]=pick(rng,sensors);w[x]=0}
  for(let a=0;a<b.A;a++)for(let i=0;i<N;i++)dec[a*M+i]=b.dec[a*N+i];
  return packTernary({...b,N:M,src,w,fireBias,bias,gain,dec,S});
}
/* Remove unit u. Slots that read it go silent (parked on a live sensor), its
 * votes move to other units (V is conserved), higher units shift down. Not
 * behaviour-preserving in general: this is the KG's structural excision. */
export function exciseTernaryUnit(genome,u,rng,{taskMode='walk'}={}){
  const b=unpackTernary(genome),N=b.N,S=b.S;u=Math.trunc(u);
  if(N<=Math.max(2,b.V)||u<0||u>=N)return new Float64Array(genome);
  const sensors=liveSensorList(b,taskMode),M=N-1,map=j=>j<u?j:j-1;
  const src=new Int32Array(3*M),w=new Int8Array(3*M),fireBias=new Float64Array(3*M),bias=new Float64Array(M),gain=new Float64Array(M),dec=new Int8Array(b.A*M);
  for(let i=0,o=0;i<N;i++){if(i===u)continue;
    for(let k=0;k<3;k++){const x=3*i+k,y=3*o+k;let c=b.src[x],wk=b.w[x];
      if(c>=S){if(c-S===u){c=pick(rng,sensors);wk=0}else c=S+map(c-S)}
      src[y]=c;w[y]=wk;fireBias[y]=b.fireBias[x]}
    bias[o]=b.bias[i];gain[o]=b.gain[i];for(let a=0;a<b.A;a++)dec[a*M+o]=b.dec[a*N+i];o++}
  const out={...b,N:M,src,w,fireBias,bias,gain,dec};repairVoters(out,rng);
  return packTernary(out);
}
/* Drop every unit that is read by nobody and votes nowhere: dead code, so the
 * result is behaviour-identical (proved by the tests, not assumed). */
export function pruneUnreadTernary(genome,{taskMode='walk',keepMin=N_RANGE.min}={}){
  let g=new Float64Array(genome);
  for(;;){
    const b=unpackTernary(g);if(b.N<=Math.max(keepMin,b.V))return g;
    const ws=wiringState(b,{taskMode}),victim=ws.unread.at(-1);
    if(victim===undefined)return g;
    g=exciseTernaryUnit(g,victim,new RNG(hash32(b.N^0x9E1)),{taskMode});
  }
}
export function setTernaryVoters(genome,V,rng){
  const b=unpackTernary(genome);b.V=clamp(Math.trunc(num(V,b.V)),V_RANGE.min,Math.min(V_RANGE.max,b.N));repairVoters(b,rng);return packTernary(b);
}
export function setTernaryPacemaker(genome,period){
  const b=unpackTernary(genome);b.P=clamp(Math.trunc(num(period,0)),PACEMAKER_RANGE.min,PACEMAKER_RANGE.max);return packTernary(b);
}

// ── telemetry ──────────────────────────────────────────────────────────────
/* Everything the dashboard and the KG context need to know about a wiring,
 * computed from the genome alone. */
export function ternaryWiring(genome,{taskMode='walk'}={}){
  const b=unpackTernary(genome),N=b.N,S=b.S,ws=wiringState(b,{taskMode});
  let liveSlots=0,sensorSlots=0,selfSlots=0,sameSignDup=0,deadSensorSlots=0,distinct=0;const fanIn=[0,0,0,0];
  for(let i=0;i<N;i++){
    const seen=new Map();let l=0;
    for(let k=0;k<3;k++){const x=3*i+k;if(!b.w[x])continue;l++;liveSlots++;const c=b.src[x];
      if(c<S){if(ws.dead.has(c))deadSensorSlots++;else sensorSlots++}else if(c-S===i)selfSlots++;
      if(seen.has(c)&&seen.get(c)===b.w[x])sameSignDup++;seen.set(c,b.w[x])}
    fanIn[l]++;distinct+=seen.size;
  }
  const covered=new Set();for(let x=0;x<3*N;x++)if(b.w[x]&&b.src[x]<S)covered.add(b.src[x]);
  const keysCovered=KEY_SENSORS.filter(k=>covered.has(k)).length;
  const voting=[...ws.votes].filter(v=>v>0).length;
  return {N,V:b.V,pacemaker:b.P,sensors:S,slots:3*N,liveSlots,liveFraction:liveSlots/Math.max(1,3*N),fullyWired:fanIn[3],fanIn,
    meanEffectiveFanIn:distinct/Math.max(1,N),sensorSlots,selfSlots,sameSignDuplicates:sameSignDup,deadSensorSlots,
    unreadUnits:ws.unread.length,constantUnits:[...ws.constant].filter(Boolean).length,votingUnits:voting,
    keySensorsCovered:keysCovered,keySensors:KEY_SENSORS.length,sensorsCovered:covered.size,
    focusSet:relevantUnits(b).length};
}
/* The exact circuit, for drawing. */
export function ternaryTopology(genome){
  const b=unpackTernary(genome),N=b.N,S=b.S,edges=[],voters=[];
  for(let i=0;i<N;i++)for(let k=0;k<3;k++){const x=3*i+k;edges.push({to:i,slot:k,from:b.src[x]<S?{sensor:b.src[x]}:{unit:b.src[x]-S},w:b.w[x]})}
  for(let a=0;a<b.A;a++)for(let i=0;i<N;i++)if(b.dec[a*N+i])voters.push({actuator:a,unit:i,sign:b.dec[a*N+i]});
  const units=Array.from({length:N},(_,i)=>({i,bias:b.bias[i],gain:b.gain[i],fireBias:[b.fireBias[3*i],b.fireBias[3*i+1],b.fireBias[3*i+2]]}));
  return {kind:'ternary',N,S,A:b.A,V:b.V,pacemaker:b.P,sensorLabels:TERNARY_SENSOR_LABELS,sensorGroups:TERNARY_SENSORS.map(s=>s.group),edges,voters,units};
}
/* Behavioural fingerprint of a wiring for diversity bookkeeping: identical
 * brains give identical keys, whatever float noise rides in unused genes. */
export function ternaryKey(genome){
  const b=unpackTernary(genome);let h=0x811C9DC5;
  const mix=v=>{h^=v&0xff;h=Math.imul(h,0x01000193)>>>0;h^=(v>>>8)&0xff;h=Math.imul(h,0x01000193)>>>0};
  mix(b.N);mix(b.V);mix(b.P);
  for(let x=0;x<3*b.N;x++){mix(b.w[x]?b.src[x]:65535);mix(b.w[x]+1)}
  for(let i=0;i<b.N;i++){mix(Math.round(b.bias[i]*4)+64);mix(Math.round(b.gain[i]*1000));for(let k=0;k<3;k++)mix(Math.round(b.fireBias[3*i+k]*10)+64)}
  for(let x=0;x<b.dec.length;x++)mix(b.dec[x]+1);
  return h.toString(16).padStart(8,'0');
}
export function ternaryDescriptor(genome,extra={}){
  const h=ternaryHeader(genome);
  return {kind:'ternary',version:TERNARY_VERSION,units:h.N,voters:h.V,pacemaker:h.pacemaker,sensors:h.S,actuators:h.A,
    totalCells:h.N,params:h.length,label:`${h.N}-unit ternary${h.pacemaker>0?` · clock ${h.pacemaker}`:''}`,...extra};
}
