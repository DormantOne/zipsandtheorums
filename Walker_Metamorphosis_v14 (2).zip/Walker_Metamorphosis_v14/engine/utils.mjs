import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import v8 from 'node:v8';

export const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
export const num=(v,d=0)=>Number.isFinite(Number(v))?Number(v):d;
export const mean=a=>a.length?a.reduce((s,x)=>s+num(x),0)/a.length:NaN;
export function median(a){if(!a.length)return NaN;const b=[...a].sort((x,y)=>x-y),m=b.length>>1;return b.length%2?b[m]:(b[m-1]+b[m])/2}
export function quantile(xs,p){const a=xs.map(x=>num(x)).sort((x,y)=>x-y);if(!a.length)return 0;const pos=(a.length-1)*p,lo=Math.floor(pos),hi=Math.ceil(pos);return lo===hi?a[lo]:a[lo]+(a[hi]-a[lo])*(pos-lo)}
export function hash32(x){x=(x+0x9E3779B9)>>>0;x=Math.imul(x^(x>>>16),0x85EBCA6B)>>>0;x=Math.imul(x^(x>>>13),0xC2B2AE35)>>>0;return (x^(x>>>16))>>>0}

export class RNG{
  constructor(seed){this.rngState=seed>>>0}
  next(){let a=this.rngState>>>0;a=(a+0x6D2B79F5)>>>0;this.rngState=a;let t=Math.imul(a^(a>>>15),1|a);t=(t+Math.imul(t^(t>>>7),61|t))^t;return ((t^(t>>>14))>>>0)/4294967296}
  randn(){let u=0,v=0;while(!u)u=this.next();while(!v)v=this.next();return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v)}
}

export function deriveRoots(runSeed,count){
  const CANONICAL=[3478229368,2580876847,3585447848],out=[];
  for(let i=0;i<count;i++)out.push(i<CANONICAL.length?CANONICAL[i]:hash32(0x5EEDC0DE^Math.imul(i+1,0x9E3779B1))>>>0);
  const r=Math.trunc(num(runSeed,0));return r?out.map(sd=>hash32(sd^hash32(r))>>>0):out;
}
export const sleep=ms=>new Promise(r=>setTimeout(r,ms));
export function ensureDir(p){fs.mkdirSync(p,{recursive:true})}
export function atomicWrite(file,data){ensureDir(path.dirname(file));const tmp=file+`.tmp-${process.pid}`;fs.writeFileSync(tmp,data);fs.renameSync(tmp,file)}
export function atomicJson(file,obj){atomicWrite(file,JSON.stringify(obj,null,2))}
export function atomicGzipJson(file,obj){
  const text=JSON.stringify(obj,(k,v)=>ArrayBuffer.isView(v)?Array.from(v):v);
  atomicWrite(file,zlib.gzipSync(Buffer.from(text),{level:6}));
}
export function readGzipJson(file){return JSON.parse(zlib.gunzipSync(fs.readFileSync(file)).toString('utf8'))}

export function atomicGzipV8(file,obj){
  const raw=v8.serialize(obj);
  atomicWrite(file,zlib.gzipSync(raw,{level:3}));
}
export function readGzipV8(file){return v8.deserialize(zlib.gunzipSync(fs.readFileSync(file)))}
export function appendJsonl(file,obj){ensureDir(path.dirname(file));fs.appendFileSync(file,JSON.stringify(obj)+'\n')}
export function copyG(g){return new Float64Array(g)}
