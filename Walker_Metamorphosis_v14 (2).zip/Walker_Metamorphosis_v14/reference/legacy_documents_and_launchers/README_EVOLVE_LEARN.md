# Walker v13 — strict ternary evolution ⇄ continuous learning

**Built from the uploaded `Walker_Strict_Ternary_v12_1_Fixed(10).zip` and the uploaded `Triple_Wire_Endurance_Evolve_to_Learn_ORIGINAL(1).html`.** The triple cartpole HTML is preserved **unaltered** in `reference/` for provenance. This release retains all of v12's MuJoCo physics, injury/contact model, opposing muscles, gait curriculum, diverse MAP-Elites archive, 3D playback, connectome, landscape, governor, bandit and original lab modes. It adds a new reversible learning stage, rather than replacing any of these components.

## First run

On macOS, double-click **`START_EVOLVE_LEARN_MAC.command`**. On Windows, double-click **`START_EVOLVE_LEARN_WINDOWS.bat`**. Initial launch installs Node packages and runs regression tests plus a real-MuJoCo controller smoke (requires internet access to install dependencies). The new server opens at **http://127.0.0.1:8795**; data lives exclusively in **`data_evolve_learn/`**, so the older 8794 `data_strict/` remains untouched. Use the matching STOP launcher to shut down cleanly.

Press the **blue `▶ Start evolve ⇄ learn`** button in the usual GUI. The rig begins with strict ternary evolution, collects gait-diverse champions, and switches after 30 evolutionary generations by default. The new learning panel provides a visible phase marker, progress bar, individual heir scores, update counts, replay, checkpoint and stage-switch controls. **The original 3D visualizer, motion playback, archive map, history, and connectome remain in their existing positions.** The new panel sits under the main training setup, and the small arena overlay identifies the current training stage.

If you press **Start fresh run (current settings)** instead, it does **not** turn on auto-cycling unless you previously enabled the `Automatically switch stages` checkbox. This defaults to off to protect strict-v12 baseline comparisons. You can manually **Switch to learning** after there is a champion, and **Return to evolution** at any point. Existing strict fixed/plastic comparison can still operate; learning acts on the currently displayed arm and temporarily disables arm switching until that learning window ends.

## Exact mechanism and what is / is not inherited

1. **Evolution (unchanged v12 search):** strict kind-4 / kind-5 brains have three ternary wires per neuron, synchronous recurrence, role constraints, 16 independently controlled opposing muscles, and a diverse MAP-Elites archive. The original `ChampionRun`, frontier, mutation and gait scoring remain unchanged.
2. **Select distinct champions:** greedily select the best and then champions differentiated by **observed gait** and **structural wiring**, not merely high score. Identical endpoint+mask fingerprints do not spawn duplicates. Each champion is independently trainable and keeps its ancestor intact.
3. **Freeze endpoints and soften:** make kind-6 copies with identical source indices, neuron roles, motor-vote positions, 16 muscle connections, and number of neuron ticks. Nonzero ternary synapses/votes become continuous floating-point values; neurons use `tanh(2.4 * weighted_input)` and still read the **original ternary sensor encoder**. The continuous heir is not misrepresented as a strict-ternary brain.
4. **Learn against real MuJoCo, without a teacher:** the JavaScript MuJoCo library does not expose backpropagation through time. This implementation uses **symmetric simultaneous perturbation stochastic approximation (SPSA)** with paired evaluations on the same walker initializations, then validates a candidate step (or a winning probe). This is a **stochastic reward-gradient estimate**, **not** the cartpole's differentiable BPTT. Updates operate primarily on selected motor votes and wire groups; optional cell-bias unlocking is separately controlled. Active edge/vote masks remain unchanged throughout learning.
5. **No rigid crawl→walk gate:** independent reward lenses posture, footfalls and distance can be selected **from the first update**. Each line gets a UCB-style lens scheduler; lenses are periodically revisited rather than mastered in a hard prescribed order. Learning perturbation amplitude also adapts based on how often a candidate wins. The original walker reward definitions, contact penalties, and injury signals are reused, not re-authored.
6. **Keep best continuously validated heir:** training comparisons use paired, short, rotated training seeds. Original validation starts (same suite across the run) select the heir's best checkpoint; learned descendants are never directly inserted into the discrete archive. A separate holdout suite is evaluated when a stage ends and is **not** used for training acceptance or archive admission.
7. **Return to evolution safely:** before re-entering evolution, each heir is quantized. The system evaluates (a) ordinary sign quantization and (b) conservative synapse-pruning variants where continuous synapse magnitudes suggest the connection may be dispensable. **Motor vote counts never change** during projection. Every proposed strict genome passes the original `rigAudit` and is re-tested on the same fixed original walker validation starts. Only the ordinary MAP-Elites quality gate can admit it; a weak novelty admission does **not** force the current best search state to regress. Continuous heir snapshots survive for later learning windows even if projection is unsuccessful. Structural evolution can then change wires and neuron counts as before.

### Honest differences from the cartpole

The cartpole HTML performs numerical-Jacobian BPTT through its own small differentiable 4-DOF rigid-body integrator, followed by its own gradient and schedule search. This v13 MuJoCo walker **does not claim that gradient**; it estimates a walker-policy gradient through objective evaluations. A full physics-adjoint/BPTT MuJoCo port would require a differentiable physics backend or carefully checked per-timestep sensitivities. There is no teacher, external imitation policy, or fabricated motion trace.

Different continuous and ternary brain implementations can show different initial performance despite inherited signs: **compare inherited continuous quality to its own initial continuous score**, and separately compare the quantized proposal to the existing strict archive. Improvements on training episodes do **not** prove a general gait improvement. Multiple independent seeds and genuine MuJoCo holdout tests remain essential.

## Suggested settings for a first real run

In the first `Evolve ⇄ learn` settings group: auto switch ON, evolution window **30 generations**, learning window **24 total updates across champions** (fast integration smoke; raise substantially for overnight learning), **3 diverse champions**, **2 training starts per update**, validate each heir every **6 updates**, perturbation **0.12**, continuous learning step **0.07**, neuron bias unlocking OFF. The original strict launcher default 192 neurons with growth up to 512 remains available; at 512/1024 each MuJoCo rollout can be considerably slower. Run at 192 before trying 1024. Control how many experiments you can afford in real physics, not just generations per minute.

The training score can favor one lens while producing no improvement in the fixed validation quality. Also, projecting a continuous heir back to strict ternary can eliminate an apparent gain. These failures are meaningful experimental outcomes and should be preserved, not hidden by the display.

## Save, resume and protection

- Original champion saves: `data_evolve_learn/champions-...json` (unchanged format; only strict-genome archive entries).
- Separate learning state: `data_evolve_learn/evolve-learn-checkpoint.json` includes current phase, separate full-precision heirs, exact inherited ancestors, lens success counters, random state and source metadata. It is saved during stage transitions, every 5 minutes, and on graceful stop.
- GUI buttons **Save learning checkpoint**, **Restore learning checkpoint**, **Download learning JSON**, and the unchanged **Save / Download** champion controls.
- To resume both: relaunch, **Start from saved champions**, then **Restore learning checkpoint**, and press **Resume**. The checkpoint checks source seed, N, joint actuation, friction and brain family; it is deliberately refused on a mismatch. The continuous checkpoint does not replace original ternary archive files.
- A downloaded learning JSON can be kept as a portable full snapshot. To restore from the UI, place the file under `data_evolve_learn/evolve-learn-checkpoint.json` first; imported archives use the existing separate v12 mechanism.

## Internal verification carried out here

`node rig/tests/run_all.mjs` **passes all 12 test files** (legacy v12 + two new v13 integration suites), including strict audits at 24, 192, 512 and 1024 neurons, projection and mask invariants, brain controller finite outputs, multi-heir independence, simulated learning and evolution in a mock walker, versioned checkpoint serialization and restore, real HTTP API stage toggling, 3D replay transport, and conservation of a strictly ternary archive. The static HTML/JS check verified 88 unique GUI element IDs, all 79 directly referenced controls, and the original 3D/physics/brain canvas elements.

**Testing limitation:** this machine had no usable installed `@mujoco/mujoco` npm package and cannot reach the package registry. The **real MuJoCo executable training run, browser rendering, actual locomotion quality, physical gradient efficacy, and macOS/Windows launcher behavior were not verified here**. The new launchers install the runtime dependencies and run a real MuJoCo controller smoke before training. These tests are a safeguard, not a claim that the quadruped has learned to walk.

## Main code changes

`rig/core/hybrid.mjs` (new): hybrid stage engine, learned heir archive, diverse parent selection, paired SPSA, reward lens scheduler, quantization and checkpoint serialization.

`rig/brain.mjs` (extended): kind-6 continuous descendant with unchanged rig geometry and new controller; preserves types and strict audits for kinds 0–5.

`rig/lab.mjs` (extended): training-phase transitions, UI status, autosaving, learner replay, manual/automatic commands.

`rig/gui/index.html` and `rig/gui/app.js` (extended): phase badge, new controls, per-heir reports, progression bar. Existing visualizers retained.

`rig/server.mjs` (extended): separate learning JSON export route.

`rig/tests/hybrid_test.mjs`, `rig/tests/hybrid_server_test.mjs` (new): invariant and whole-application smoke tests.

`engine/` and `rig/plants/` are **unchanged** from the uploaded original.
