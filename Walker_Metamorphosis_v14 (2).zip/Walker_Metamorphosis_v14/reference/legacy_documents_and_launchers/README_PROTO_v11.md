# Protoneuron Walker v11 — Living Curriculum & Reward Learning

**Built on the original Walker Ternary Rig v10.1.0, with the original MuJoCo model, muscles, friction and physical scoring preserved.** The classic regular/plastic evolutionary lab still appears at `/` and works as before. The separate, experimental continuous-learning laboratory is at `/proto`.

## One-button launch

- **Mac:** double-click `START_PROTO_MAC.command`. It checks Node.js >=22, installs the original project's `@mujoco/mujoco` and `three` dependencies if necessary, runs the original test suite, the physical parity check, and the new physical v11 controller smoke test, then opens `http://127.0.0.1:8793/proto`.
- **Windows:** double-click `START_PROTO_WINDOWS.bat` for the same process.
- **Terminal:** `npm install && npm test && node rig/tests/proto_mujoco_smoke.mjs && npm start`, then open `http://127.0.0.1:8793/proto`.
- **Stop:** use the original `STOP_MAC.command` / `STOP_HERE.bat`, which requests the local server shutdown. The v11 lab checkpoints separately.

**Do not double-click proto.html directly:** it is a frontend for the local Node server and its MuJoCo workers. The app uses localhost only. MuJoCo's WASM binary is provided in `engine/vendor/mujoco.wasm` exactly as in the original rig; the JavaScript runtime loads from the npm package.

## What is new

- A separate continuous genome format (`C_MAGIC`) with 100 undifferentiated recurrent `tanh` neurons and exactly 3 incoming synapses each, simulated for 10 synchronous sub-ticks per 20ms control step.
- 24 motor-facing neurons generate 8 joint drives. Each drive is mirrored into a pair of opposing 16-muscle commands. At the final stage a second set of 24 motor-facing neurons learns 8 independent co-contraction controls.
- 6 motor shortcut inputs per joint (pitch, roll, angular velocities, its joint position and joint velocity). This makes a direct-learning ablation possible; it does **not** add extra incoming synapses to any neuron.
- Teacher-free antithetic reward perturbations (+epsilon/-epsilon tested on the same scenarios), small continuous weight updates, 20-round learning blocks, occasional single-slot rewiring followed by a three-round retuning budget.
- Monotonic posture → footfalls → distance → stiffness curriculum, using **the existing walker's physical reward, constraints and passes**, never synthetic reward or learned world models. The stage gate is checked on 12 validation cases and the winner archive on a fixed 8-case validation set.
- Champion archive with a behavior descriptor (duty, coordination, cadence), independent 24-scenario test on fresh starting conditions, reset/refill/pause, and atomic save/resume of neural weights, wiring, random-number state, training budget and archive.
- Complete connectome BX export and genuine MuJoCo replay diagnostics (forward displacement from recorded physics frames).

## Exact learning parameters at the defaults

- Initial 420 reward-learning rounds, refills of 420. Each round: 4 perturbation directions × 2 signs × 2 start conditions = 16 rollouts; 6 simulated seconds per trial (plus validation/rewiring overhead). Default 152 trainable parameters at stages 1–3: 72 motor dendrites + 24 decoder gains + 48 sensory shortcut gains + 8 output biases. All 300 neural synapses exist; deeper recurrent synapses remain continuous but fixed until rewired.
- A batch of 20 rounds evaluates the trained candidate, refreshes the current archive and checks promotion. Every second block tries one rewiring candidate with three short retuning rounds. Later tone training doubles the motor-facing neurons and readouts.
- **The initial untrained muscle system may already stand**, because opposing muscles at equal activation maintain the calibrated servo pose. The baseline is measured and labeled rather than counted as evidence of *learned* standing. Independent improvement must be demonstrated above that baseline.
- The original rig's legacy evolution, plastic rule, MAP-Elites, tuning and data files remain separate. There is no automatic import of ternary champions into a continuous network: the representational mismatch is substantial.

## Results and limitations

Automated controller and training-loop tests are provided in `rig/tests/protoneuron_test.mjs` (using an explicitly **fake plant** for pipeline tests). The original rig's seven suites also run and must continue to pass. **Neither passing the fake-plant tests nor passing the one-trial real MuJoCo smoke test demonstrates learned walking.** Demonstrating actual standing, stepping and distance improvement on held-out MuJoCo starts remains the experiment.

The included node project must install its two npm dependencies once (internet usually required). If the original server is already using port 8793, stop it first or use `node rig/server.mjs --port 8794` and open `http://127.0.0.1:8794/proto`.
