# Walker v12.1 — strictly ternary neurons at scale

Open **START_STRICT_MAC.command** (macOS) or **START_STRICT_WINDOWS.bat** (Windows).

The strict lab runs at `http://127.0.0.1:8794` with independent `data_strict/` storage. The original v11 launcher, `/proto` lab, and v10.1 modes remain at port 8793; your old champions are not altered.

## Hypothesis

Can increasing the number of *minimal* recurrent neural elements recover the control capability lost by removing evolved neuronal gain, bias and firing preferences?

## Architecture

Strict neuron output = `sign(w1*x1 + w2*x2 + w3*x3)`, `sign(0)=0`. All 3 weights and all presynaptic signals are in `{-1,0,1}`. No floating thresholds, gains, biases or fire preferences affect decisions. Tonic cells always fire +1. Optional Hebbian/anti-Hebbian local plasticity can step weights one ternary notch within a trial; updates reset at trial end. Learning-rate and trace-fade *rule genes* are still discrete choices and their accumulators are continuous; these are not firing parameters. Inputs are binarized by fixed physical sensor thresholds; MuJoCo and averaging/`tanh`-squashing of muscle commands remain continuous. This is a **strict ternary neural-core** test, not a globally integer-only simulator.

## Settings and comparisons

Dedicated strict preset: **192 neurons**, **512 max cells**, **16 founders**, **12 candidates/gen**, *mixed sizes off*, strict fixed vs strict plastic, 16 opposing muscles, 10 brain ticks per 20 ms of physics, 6 motor votes, and independent seeded comparisons. Set **Cells** to 128, 256, 512, or up to 1024 to explore scaling (higher counts will be substantially slower). To compare across sizes use separate seeds and report MuJoCo physics steps as well as generation count. Growth and shrinkage are still allowed by the evolutionary machinery; `Max cells` caps growth. For a controlled fixed-size study disable the grow/shrink bandit and growth actions or verify champion sizes from biopsies.

**Strict fixed (kind 4)** has no learning genes, **strict plastic (kind 5)** has inherited discrete Hebbian/anti-Hebbian learning rates and fade choices, as in v10.1. Each new strict plastic brain starts with zero learning rates, and evolution may switch them on. Compare does not isolate learning efficacy *within the same champion*; an additional on/off ablation of a champion remains necessary.

## Verification

`node rig/tests/strict_test.mjs` checks ternary neurons, fixed firing parameters, matching newborns and neural outputs, plastic updates and reset, mutation, crossover, growth, 512 and 1024 cells. `node rig/tests/run_all.mjs` runs legacy tests. Physical MuJoCo training still must be run on your machine. An automated code test does **not** demonstrate walking.

The old genome includes five compatibility slots (bias, gain, three firing preferences), fixed at 0 / 1 / 0 in strict models. The auditor refuses any strict genome with changed slots; the controller ignores them even if a genome was tampered with.

## v12.1 startup correction

The v12 Mac and Windows launchers accidentally passed `RIG_START_STRICT=1` to the
legacy regression suite. That made `lab_test.mjs` instantiate strict kind 4
when testing a saved regular kind 0 brain and aborted startup despite the
strict-neuron tests passing. v12.1 runs legacy tests without the strict
startup preset; `strict_server_test.mjs` still starts a strict server explicitly.
Only the actual walker server runs with the strict preset. No controller,
physics, training, or genome rules were changed in this correction.
