#!/bin/bash
cd "$(dirname "$0")"
echo "=== Walker Ternary Rig v10.1.0 · regular vs plastic brains on the MuJoCo walker ==="
pause_close(){ read -r -p "Press Enter to close." _; }
command -v node >/dev/null 2>&1 || { echo "Node.js 22 or newer is required (https://nodejs.org). Install it, then relaunch."; pause_close; exit 1; }
node -e "process.exit(Number(process.versions.node.split('.')[0])>=22?0:1)" || { echo "Node.js 22 or newer is required. Upgrade Node, then relaunch."; pause_close; exit 1; }
mkdir -p data
if [ -f data/server.pid ] && kill -0 "$(cat data/server.pid)" 2>/dev/null; then echo "The rig is already running."; open "http://127.0.0.1:8793"; exit 0; fi
if curl -s -m 2 -o /dev/null http://127.0.0.1:8793/api/status 2>/dev/null; then echo "Another rig is already running on port 8793. Stop it with its own STOP_MAC.command, then launch this one again."; pause_close; exit 1; fi
if [ ! -d node_modules/@mujoco/mujoco ] || [ ! -d node_modules/three ]; then
  echo "Installing MuJoCo and three.js, once..."
  npm install --no-audit --no-fund || { echo "npm install failed. Nothing was started."; pause_close; exit 1; }
  rm -f data/.verified_v10_1_0
fi
if [ ! -f data/.verified_v10_1_0 ]; then
  echo "First launch: the rig's tests (seconds), then the MuJoCo parity check against the lab's own evaluator (about a minute), plus the servo, walking and muscle checks..."
  if node rig/tests/run_all.mjs && node rig/check_parity.mjs --workers 8; then date > data/.verified_v10_1_0
  else echo "VERIFICATION FAILED. The rig was not started."; pause_close; exit 1; fi
fi
rm -f data/server.pid
nohup node rig/server.mjs >> data/server.log 2>&1 &
PID=$!
caffeinate -is -w $PID >/dev/null 2>&1 &
for i in $(seq 1 75); do [ "$(cat data/server.pid 2>/dev/null)" = "$PID" ] && break; kill -0 $PID 2>/dev/null || break; sleep 0.2; done
if ! kill -0 $PID 2>/dev/null; then echo "The rig did not start. The end of data/server.log:"; tail -20 data/server.log; pause_close; exit 1; fi
open "http://127.0.0.1:8793"
echo "The rig is running at http://127.0.0.1:8793 (PID $PID). The Mac is kept awake while it runs."
echo "This window can be closed. STOP_MAC.command stops the rig and saves the champions."
