#!/bin/bash
# Strict recurrent ternary walker. Dedicated server and storage: never touches v10/v11 champions.
cd "$(dirname "$0")" || exit 1
PORT=8794
DIR="$(pwd)/data_strict"
export RIG_PORT="$PORT" RIG_DATA_DIR="$DIR" RIG_WORKERS=4
# Strict preset applies ONLY to the launched server, not to legacy regression tests.
unset RIG_START_STRICT
URL="http://127.0.0.1:$PORT"
pause_close(){ read -r -p "Press Enter to close." _; }
echo '=== WALKER v12.1 · STRICT TERNARY SCALE · 192 neurons (up to 1024) ==='
echo 'Dedicated port 8794; saves go to data_strict (NOT the old data folder).'
command -v node >/dev/null 2>&1 || { echo 'Node.js 22+ needed; get it from https://nodejs.org'; pause_close; exit 1; }
node -e "process.exit(Number(process.versions.node.split('.')[0])>=22?0:1)" || { echo 'Node.js 22+ required.'; pause_close; exit 1; }
mkdir -p "$DIR"
if [ -f "$DIR/server.pid" ] && kill -0 "$(cat "$DIR/server.pid")" 2>/dev/null; then
  echo 'Your strict walker is already running.'; open "$URL"; exit 0
fi
if curl -fsS -m 2 "$URL/api/status" >/dev/null 2>&1; then
  echo 'Port 8794 is already occupied. Open it, or stop the other server first.'; pause_close; exit 1
fi
if [ ! -d node_modules/@mujoco/mujoco ] || [ ! -d node_modules/three ]; then
  echo 'Installing MuJoCo and visualizer dependencies...'; npm install --no-audit --no-fund || { echo 'Install failed.'; pause_close; exit 1; }
fi
if [ ! -f "$DIR/.verified_strict_v12_1" ]; then
  echo 'Running strict and original regression tests, parity check, and MuJoCo smoke test...'
  if node rig/tests/run_all.mjs && node rig/check_parity.mjs --workers 4 && node rig/tests/proto_mujoco_smoke.mjs; then
    date > "$DIR/.verified_strict_v12_1"
  else
    echo 'Verification failed. The strict server was NOT launched.'; pause_close; exit 1
  fi
fi
rm -f "$DIR/server.pid"
RIG_START_STRICT=1 nohup node rig/server.mjs >> "$DIR/server.log" 2>&1 &
PID=$!
command -v caffeinate >/dev/null && caffeinate -is -w "$PID" >/dev/null 2>&1 &
for i in $(seq 1 75); do
  [ "$(cat "$DIR/server.pid" 2>/dev/null)" = "$PID" ] && break
  kill -0 "$PID" 2>/dev/null || break
  sleep 0.2
done
if ! kill -0 "$PID" 2>/dev/null; then
  echo 'Server failed. Recent log:'; tail -25 "$DIR/server.log"; pause_close; exit 1
fi
open "$URL"
echo "Strict rig running on $URL with PID $PID."
echo 'Leave the experiment on, export periodic checkpoints, and use STOP_STRICT_MAC.command to stop safely.'
