@echo off
cd /d "%~dp0"
set "RIG_PORT=8794"
set "RIG_DATA_DIR=%CD%\data_strict"
rem Tests must inherit legacy defaults. Set strict preset only before starting the server.
set "RIG_START_STRICT="
set "RIG_WORKERS=4"
echo === Walker v12.1 STRICT ternary neural scaling: 192 cells, up to 1024 ===
echo Independent port 8794 and folder data_strict -- does not touch old champions.
where node >nul 2>&1
if errorlevel 1 (echo Node.js 22 or later is required at https://nodejs.org & goto :fail)
if not exist data_strict mkdir data_strict
if not exist node_modules\@mujoco\mujoco (
 call npm install --no-audit --no-fund
 if errorlevel 1 goto :fail
)
if not exist data_strict\.verified_strict_v12_1 (
 node rig\tests\run_all.mjs
 if errorlevel 1 goto :fail
 node rig\check_parity.mjs --workers 4
 if errorlevel 1 goto :fail
 node rig\tests\proto_mujoco_smoke.mjs
 if errorlevel 1 goto :fail
 echo verified>data_strict\.verified_strict_v12_1
)
set "RIG_START_STRICT=1"
start "Strict walker" /min cmd /c "node rig\server.mjs >> data_strict\server.log 2>&1"
timeout /t 3 >nul
start "" http://127.0.0.1:8794
echo Use STOP_STRICT_WINDOWS.bat to stop the strict server only.
exit /b 0
:fail
echo STRICT STARTUP OR TESTS FAILED, not launching.
pause
exit /b 1
