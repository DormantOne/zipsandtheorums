@echo off
cd /d "%~dp0"
curl -s -X POST -d "{\"cmd\":\"shutdown\"}" http://127.0.0.1:8793/api/cmd >nul 2>&1
echo Stop requested; the rig saves the champions and exits.
pause
