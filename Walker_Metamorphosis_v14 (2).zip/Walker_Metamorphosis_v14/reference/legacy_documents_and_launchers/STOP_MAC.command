#!/bin/bash
cd "$(dirname "$0")"
if [ -f data/server.pid ] && kill -0 "$(cat data/server.pid)" 2>/dev/null; then
  echo "Stopping the rig; it saves the champions first..."
  curl -s -X POST -d '{"cmd":"shutdown"}' http://127.0.0.1:8793/api/cmd >/dev/null 2>&1 || kill "$(cat data/server.pid)"
  for i in $(seq 1 75); do [ -f data/server.pid ] || break; sleep 0.2; done
  [ -f data/server.pid ] && kill "$(cat data/server.pid)" 2>/dev/null
  echo "Stopped."
else echo "The rig is not running."; fi
read -r -p "Press Enter to close." _
