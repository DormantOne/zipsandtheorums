#!/bin/bash
cd "$(dirname "$0")" || exit 1
if [ -f data_strict/server.pid ] && kill -0 "$(cat data_strict/server.pid)" 2>/dev/null; then
 echo 'Stopping strict walker; saving champions...'
 curl -fsS -m 5 -X POST -H 'Content-Type: application/json' -d '{"cmd":"shutdown"}' http://127.0.0.1:8794/api/cmd >/dev/null 2>&1 || kill "$(cat data_strict/server.pid)"
 for i in $(seq 1 75); do [ -f data_strict/server.pid ] || break; sleep 0.2; done
 echo 'Strict walker stopped. Old v10/v11 server left untouched.'
else echo 'No active strict walker server found.'; fi
