@echo off
cd /d "%~dp0"
echo Sending graceful stop to strict walker on port 8794...
curl -s --max-time 5 -X POST -H "Content-Type: application/json" -d "{\"cmd\":\"shutdown\"}" http://127.0.0.1:8794/api/cmd
echo.
echo The legacy walker on port 8793 is not affected.
