#!/usr/bin/env node
/* rig/check_parity.mjs — the rig's MuJoCo path must BE the lab's MuJoCo path.
 *
 * The same brains run on the same scenarios twice: through the lab's own
 * evaluator (engine/eval_pool.mjs + engine/eval_worker.mjs, the threads the lab
 * uses for every rollout it scores) and through the rig's worker
 * (rig/plants/walker_worker.mjs, which adds a contact-recording wrapper around
 * the controller). Every field that feeds the reward of record is compared bit
 * for bit, together with the per-trial reward itself. Needs no fossils, so it
 * runs in a fresh folder; the launcher runs it once before the first rig job.
 *
 *   node rig/check_parity.mjs [--workers 4]
 */
import {EvalPool} from '../engine/eval_pool.mjs';
import {birthTernary,mutateTernary} from '../engine/ternary.mjs';
import {aggregateDifficultyGait} from '../engine/difficulty_gait.mjs';
import {makeScenario} from '../engine/plant.js';
import {applyTaskScenario} from '../engine/task_curriculum.mjs';
import {makeWalkerPlant,labYardstick,WALKER_PHYSICS} from './plants/walker.mjs';
import {Rng} from './core/rng.mjs';

const args=process.argv.slice(2),opt=(k,d)=>{const i=args.indexOf(k);return i>=0?args[i+1]:d};
const workers=Math.max(1,Number(opt('--workers',4)));
const rng=new Rng(20261001),brains=[];
for(const N of [12,24,48]){
  const g=birthTernary(rng,{N,V:6,pacemaker:0,taskMode:'walk'});
  let m=g;for(let k=0;k<20;k++)m=mutateTernary(m,rng,{taskMode:'walk'}).genome;
  brains.push({label:`${N} units, newborn`,genome:g},{label:`${N} units, 20 mutations`,genome:m});
}
// two yardstick scenarios (8 s) and one training-length scenario (6 s) with its own pushes
const scenarios=[...labYardstick().slice(0,2),applyTaskScenario(makeScenario(987654321,1,300),{mode:'walk'})];
const physics=WALKER_PHYSICS;

const FIELDS=['score','cleanWalkSpeedMps','cleanWalkDistanceM','forwardDistanceM','forwardSpeedMps','nonfootGroundContactFraction','survival','physicsSteps',
  'signedAutonomousDistanceM','lateAutonomousDistanceM','targetGoalScore','footDragIndex'];
const pick=(r,k)=>k.split('.').reduce((o,x)=>o?.[x],r);
const NESTED=['footSlip.maxSlipM','footSlip.health','gait.genuineSteps','gait.steppingFeet','gait.positiveProgressSegments','gait.maxFootRelocationM','contactHealth.health'];

console.log(`parity check: ${brains.length} brains x ${scenarios.length} scenarios, through the lab's evaluator and through the rig's worker (${workers} threads each)`);
const t0=Date.now(),pool=new EvalPool({size:workers});
let labRows;
try{
  const jobs=[];for(const b of brains)for(const sc of scenarios)jobs.push({physics,controller:{kind:'ternary',genome:b.genome},scenarios:[sc],steps:sc.steps,earlyExit:null});
  // the lab's pool waits forever if MuJoCo cannot load in its threads; give it 90 s
  await Promise.race([pool.ready(),new Promise((_,rej)=>setTimeout(()=>rej(new Error('its threads did not start within 90 s')),90000).unref())]);
  labRows=(await pool.evaluate(jobs)).map(r=>r[0]);
}catch(e){
  console.error(`\nThe lab's own evaluator could not run: ${e.message}\nIs MuJoCo installed? Run START_MAC.command once (it runs npm install and the lab's own MuJoCo smoke test), then try again.`);
  pool.close().catch(()=>{});process.exit(2);
}
await pool.close();
const t1=Date.now(),plant=await makeWalkerPlant({workers});
let rigTrials;
try{rigTrials=await plant.evaluate(brains.map(b=>b.genome),scenarios)}catch(e){console.error(`\nThe rig's worker could not run: ${e.message}`);await plant.close();process.exit(2)}
await plant.close();
const t2=Date.now();
let bad=0,k=0;
for(let i=0;i<brains.length;i++){
  for(let j=0;j<scenarios.length;j++,k++){
    const a=labRows[k],b=rigTrials[i][j].row,diffs=[];
    for(const f of [...FIELDS,...NESTED]){const x=pick(a,f),y=pick(b,f);if(!Object.is(x,y))diffs.push(`${f}: lab ${x} rig ${y}`)}
    const qa=aggregateDifficultyGait([a]).fitness,qb=rigTrials[i][j].q;if(!Object.is(qa,qb))diffs.push(`per-trial reward: lab ${qa} rig ${qb}`);
    if(diffs.length){bad++;console.log(`  DIFFERENT  ${brains[i].label}, scenario ${j+1}: ${diffs.slice(0,4).join('; ')}`)}
    else console.log(`  identical  ${brains[i].label.padEnd(24)} scenario ${j+1}  reward ${qa.toFixed(6)}  slide ${(100*(a.footSlip?.maxSlipM??0)).toFixed(1)} cm`);
  }
}
const n=brains.length*scenarios.length;
console.log(`\nlab evaluator ${((t1-t0)/1000).toFixed(1)} s, rig worker ${((t2-t1)/1000).toFixed(1)} s`);
if(bad){console.log(`MISMATCH: ${bad} of ${n} rollouts differ. The rig's walker results cannot be compared with the lab's until this is resolved.`);process.exit(1)}
console.log(`OK: all ${n} rollouts are bit-identical. The rig scores brains exactly as the lab does.`);

/* v10.0.1: the servo joints. A zero command must hold the standing pose: the PD
 * is recomputed every 4 ms physics step (held for a whole 20 ms step, the stock
 * kd 5 made the body skate and fall). A plain open-loop trot is reported too. */
{const {loadMujoco,gaitDescriptors}=await import('./plants/walker_worker.mjs');const {WalkerPlant,PLANT}=await import('../engine/plant.js');const {scoreTrial}=await import('./plants/walker.mjs');
 const mujoco=await loadMujoco(),s=WALKER_PHYSICS.legScale,pl=new WalkerPlant(mujoco,{frictionMu:WALKER_PHYSICS.frictionMu,thighLength:PLANT.thighLength*s,shinLength:PLANT.shinLength*s});
 const d=new mujoco.MjData(pl.model),pd=new mujoco.MjData(pl.model);pl.calibrateStanding(d);pl.probe(d);
 const calm=applyTaskScenario(makeScenario(12345,0,400),{mode:'walk'});
 const roll=(run,control)=>{pl.configure(run);const bits=new Uint8Array(4*calm.steps);let t=0;
   const r=pl.rollout({control:obs=>{if(t<calm.steps)for(let f=0;f<4;f++)bits[4*t+f]=obs[28+f]>.5?1:0;t++;return control(t)},hidden:null,steps:calm.steps,scenario:calm,data:d,passiveData:pd,record:false,earlyExit:null});
   return scoreTrial(r,gaitDescriptors(r,bits,Math.min(t,calm.steps)))};
 const zero=()=>new Float64Array(8),trot=(()=>{const o=new Float64Array(8),ph=[0,.5,.5,0];return t=>{const time=t*PLANT.dt*PLANT.frameSkip;
   for(let l=0;l<4;l++){const a=2*Math.PI*(time+ph[l]);o[2*l]=.1*Math.sin(a);o[2*l+1]=-.3+.6*Math.max(0,-Math.cos(a))}return o}})();
 const servo={...WALKER_PHYSICS.run,actuation:'pd'},tier=x=>['fell or harmed','upright, not stepping','upright and stepping'][x.tier];
 const hold=roll(servo,zero),step=roll(servo,trot),limp=roll(WALKER_PHYSICS.run,zero);
 console.log(`\nservo joints (v10.0.1): zero command -> ${tier(hold)}, slide ${(100*hold.slipM).toFixed(1)} cm; open-loop 1 Hz trot -> ${tier(step)} at ${(100*step.rate).toFixed(1)} cm/s; torque joints, zero command -> ${tier(limp)}`);
 if(!(hold.tier>=1&&hold.slipM<.01)){console.log('SERVO CHECK FAILED: a servo with a zero command must hold the standing pose without sliding.');process.exit(1)}
 console.log('OK: the servo joints hold the standing pose.');

 /* v10.0.2: the body CAN walk under the rig's own rules. A 13-number open-loop
  * rhythm (found by CMA-ES on servo joints, firm friction) is scored on the 24
  * validation scenarios exactly as a brain would be. With firm friction it must
  * step on nearly every trial and pass the distance rung (6 cm/s, footfalls and
  * posture held) on most; with the Foundry's soft friction the same motion
  * slides its feet past the 6.25 cm harm line and is scored as falling. If this
  * fails, the physics no longer allows walking and no brain can be blamed. */
 const P=await makeWalkerPlant({backend:'mock'}),VAL=P.suites(1,P.searchDefaults(48)).val;
 const G={hz:0.7897998110679638,ph:[0,0.5754805651120913,0.6654706356652066,0.16627182299944288],hipA:[0.2672796408819048,0.17799688377115183],hipB:[-0.44826740312420854,-0.05974890820995615],kneeA:[1.5515824281177526,1.5611762467594144],kneeB:[-0.7412137350704275,0.5225572913168064],lag:0.5811240504080001},c1=v=>Math.max(-1,Math.min(1,v));
 const refGait=()=>{const o=new Float64Array(8);return (obs,t)=>{const time=t*PLANT.dt*PLANT.frameSkip;
   for(let l=0;l<4;l++){const r=l<2?0:1,a=2*Math.PI*(G.hz*time+G.ph[l]);o[2*l]=c1(G.hipB[r]+G.hipA[r]*Math.sin(a));o[2*l+1]=c1(G.kneeB[r]+G.kneeA[r]*Math.max(0,Math.sin(a+2*Math.PI*G.lag)))}return o}};
 const suiteOn=friction=>{const b=new WalkerPlant(mujoco,{frictionMu:WALKER_PHYSICS.frictionMu,thighLength:PLANT.thighLength*s,shinLength:PLANT.shinLength*s,...friction});
   const bd=new mujoco.MjData(b.model),bp=new mujoco.MjData(b.model);b.calibrateStanding(bd);b.probe(bd);b.configure(servo);
   const tr=VAL.map(sc=>{const bits=new Uint8Array(4*sc.steps),ctl=refGait();let t=0;
     const r=b.rollout({control:obs=>{if(t<sc.steps)for(let f=0;f<4;f++)bits[4*t+f]=obs[28+f]>.5?1:0;t++;return ctl(obs,t)},hidden:null,steps:sc.steps,scenario:sc,data:bd,passiveData:bp,record:false,earlyExit:null});
     return scoreTrial(r,gaitDescriptors(r,bits,Math.min(t,sc.steps)))});
   const m=f=>tr.reduce((a,x)=>a+f(x),0)/tr.length;
   return {stepping:tr.filter(x=>x.tier===2).length,harmed:tr.filter(x=>x.tier===0).length,passed:tr.filter(x=>x.pass.distance).length,speed:m(x=>x.speed),slide:m(x=>x.slipM),ladder:m(x=>x.L)}};
 const firm=suiteOn({frictionCone:'elliptic',impratio:10}),soft=suiteOn({frictionCone:'pyramidal',impratio:1});
 const say=(k,x)=>`${k}: stepping ${x.stepping}/24, harmed ${x.harmed}/24, distance passed ${x.passed}/24, ${(100*x.speed).toFixed(1)} cm/s, worst-foot slide ${(100*x.slide).toFixed(1)} cm, ladder ${x.ladder.toFixed(3)}`;
 console.log(`\nreference trot (open loop, servo joints) on the 24 validation scenarios:\n  ${say('firm friction  ',firm)}\n  ${say('legacy friction',soft)}`);
 if(!(firm.stepping>=20&&firm.passed>=18)){console.log('WALKING CHECK FAILED: with firm friction the reference trot must step on 20+ and pass the distance rung on 18+ of the 24 validation scenarios.');process.exit(1)}
 console.log('OK: the walker can walk cleanly under the rig\'s rules; the distance rung is reachable.');

 /* v10.1.0: muscle joints. Half tone in both muscles must hold the standing pose
  * like the servo; relaxing both must let the body fold; and the reference trot
  * driven through reciprocal muscle pairs (plus = c, minus = -c) must walk exactly
  * as it does on the servo. */
 {const mus={...WALKER_PHYSICS.run,actuation:'muscle'},b=new WalkerPlant(mujoco,{frictionMu:WALKER_PHYSICS.frictionMu,thighLength:PLANT.thighLength*s,shinLength:PLANT.shinLength*s});
  const bd=new mujoco.MjData(b.model),bp=new mujoco.MjData(b.model);b.calibrateStanding(bd);b.probe(bd);b.configure(mus);
  const rollM=(ctl,sc)=>{const bits=new Uint8Array(4*sc.steps);let t=0;const r=b.rollout({control:obs=>{if(t<sc.steps)for(let f=0;f<4;f++)bits[4*t+f]=obs[28+f]>.5?1:0;t++;return ctl(obs,t)},hidden:null,steps:sc.steps,scenario:sc,data:bd,passiveData:bp,record:false,earlyExit:null});return scoreTrial(r,gaitDescriptors(r,bits,Math.min(t,sc.steps)))};
  const tone=rollM(()=>new Float64Array(16),calm),limp=rollM(()=>new Float64Array(16).fill(-1),calm);
  const g8=refGait(),trot16=(obs,t)=>{const c=g8(obs,t),o=new Float64Array(16);for(let i=0;i<8;i++){o[i]=c[i];o[8+i]=-c[i]}return o};
  const tr=VAL.map(sc=>rollM(trot16,sc)),passed=tr.filter(x=>x.pass.distance).length,stepping=tr.filter(x=>x.tier===2).length;
  console.log(`\nmuscle joints (v10.1.0): half tone -> ${tier(tone)}, slide ${(100*tone.slipM).toFixed(1)} cm; both relaxed -> ${tier(limp)}; reference trot through reciprocal muscle pairs -> stepping ${stepping}/24, distance passed ${passed}/24 (servo: ${firm.stepping}/24, ${firm.passed}/24)`);
  if(!(tone.tier>=1&&tone.slipM<.01&&limp.tier===0&&stepping>=20&&passed>=18)){console.log('MUSCLE CHECK FAILED: half tone must stand, full relaxation must fold, and reciprocal muscles must walk the reference trot.');process.exit(1)}
  console.log('OK: muscles stand at half tone, go limp when relaxed, and walk like the servo when driven in reciprocity.')}}
process.exit(0);
