/* Protoneuron v11 continuous recurrent controller; a different, versioned genome.
 * Deliberately NOT accepted as a ternary/rig genome. Three inputs per neuron;
 * 100 undifferentiated, recurrent tanh cells. Eight reciprocal muscle drives,
 * with eight co-contraction channels unlocked by curriculum stage four.
 * The brain has no backpropagation and is trained by symmetric perturbations.
 */
import {encodeTernary,T_SENS,CONSTANT_SENSOR,KEY_SENSORS} from '../engine/ternary.mjs';
export const C_MAGIC=11.0172026,C_VERSION=1,C_N=100,C_MOTOR=48,C_ACT=16,C_K=10;
const H=10,clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const starts=()=>({src:H,weights:H+3*C_N,read:H+6*C_N,direct:H+6*C_N+3*C_ACT,bias:H+6*C_N+9*C_ACT,end:H+6*C_N+10*C_ACT});
export const C_LAYOUT=Object.freeze(starts());
export function isContinuous(g){return g instanceof Float64Array&&g.length===C_LAYOUT.end&&g[0]===C_MAGIC&&g[1]===C_VERSION&&g[2]===C_N&&g[3]===T_SENS&&g[4]===C_ACT&&g[5]===C_K&&g[6]===C_MOTOR}
function validate(g){if(!isContinuous(g))throw Error('Not a v11 continuous genome');for(let x=0;x<3*C_N;x++){const addr=g[C_LAYOUT.src+x];if(!Number.isInteger(addr)||addr<0||addr>=T_SENS+C_N)throw Error('Invalid neural address');if(!Number.isFinite(g[C_LAYOUT.weights+x]))throw Error('Invalid dendrite weight')}
  for(let i=C_LAYOUT.read;i<g.length;i++)if(!Number.isFinite(g[i]))throw Error('Invalid continuous weight');return g}
export function makeContinuous(seed=47017){const r=prng(seed),g=new Float64Array(C_LAYOUT.end);g[0]=C_MAGIC;g[1]=C_VERSION;g[2]=C_N;g[3]=T_SENS;g[4]=C_ACT;g[5]=C_K;g[6]=C_MOTOR;g[7]=seed>>>0;
  const key=KEY_SENSORS.filter(j=>j!==CONSTANT_SENSOR);
  for(let i=0;i<C_N;i++){
    const row=new Set();if(i<C_MOTOR){row.add(key[i%key.length]);row.add(CONSTANT_SENSOR)}
    while(row.size<3){const a=r()<.50?key[Math.floor(r()*key.length)]:T_SENS+Math.floor(r()*C_N);row.add(a)}
    let j=0;for(const addr of row){g[C_LAYOUT.src+3*i+j]=addr;g[C_LAYOUT.weights+3*i+j]=(r()<.5?-1:1)*(.35+.45*r());j++}
  }
  for(let a=0;a<C_ACT;a++)for(let k=0;k<3;k++)g[C_LAYOUT.read+a*3+k]=(r()-.5)*.10;
  // Zero direct shortcuts / output biases at birth. Reciprocal muscles at stage 1.
  return validate(g)
}
export function prng(seed){let x=seed>>>0;return ()=>{let t=x+=0x6d2b79f5;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return ((t^(t>>>14))>>>0)/4294967296}}
export function trainableIndices({plastic=true,tone=false,shortcuts=true}={}){
  const a=[],m=tone?C_MOTOR:24,ac=tone?16:8;
  if(plastic)for(let i=0;i<3*m;i++)a.push(C_LAYOUT.weights+i);
  for(let i=0;i<3*ac;i++)a.push(C_LAYOUT.read+i);
  if(shortcuts)for(let i=0;i<6*ac;i++)a.push(C_LAYOUT.direct+i);
  for(let i=0;i<ac;i++)a.push(C_LAYOUT.bias+i);
  return a
}
export function rewireContinuous(src,rand,{all=false}={}){
  const g=validate(src).slice(),cell=Math.floor(rand()*(all?C_N:24)),slot=Math.floor(rand()*3),idx=C_LAYOUT.src+3*cell+slot;
  let address=g[idx];const row=[0,1,2].map(k=>g[C_LAYOUT.src+3*cell+k]);
  for(let tries=0;tries<80;tries++){const candidate=rand()<.53?Math.floor(rand()*T_SENS):T_SENS+Math.floor(rand()*C_N);if(!row.includes(candidate)){address=candidate;break}}
  if(address===g[idx])return null;
  g[idx]=address;g[C_LAYOUT.weights+3*cell+slot]=(rand()<.5?-1:1)*.20;
  return {genome:g,cell,slot,address}
}
export function makeContinuousController(genome,{tone=false}={}){
  const g=validate(genome),sens=new Int8Array(T_SENS),prev=new Float64Array(C_N),next=new Float64Array(C_N),out=new Float64Array(16);let t=0;
  const features=(obs,j)=>[
    clamp((Number(obs[0])||0)/.2,-3,3),clamp((Number(obs[1])||0)/.2,-3,3),
    clamp((Number(obs[3])||0)/.6,-3,3),clamp((Number(obs[4])||0)/.6,-3,3),
    clamp((Number(obs[12+j])||0)/1.5,-3,3),clamp((Number(obs[20+j])||0)/1.5,-3,3)];
  const control=obs=>{
    encodeTernary(obs,t++,sens,0);
    for(let tick=0;tick<C_K;tick++){
      for(let i=0;i<C_N;i++){
        let z=0,off=3*i;
        for(let k=0;k<3;k++){const addr=g[C_LAYOUT.src+off+k];z+=(addr<T_SENS?sens[addr]:prev[addr-T_SENS])*g[C_LAYOUT.weights+off+k]}
        next[i]=Math.tanh(z)
      }
      prev.set(next)
    }
    for(let j=0;j<8;j++){
      const f=features(obs,j),calc=a=>{let z=g[C_LAYOUT.bias+a];for(let k=0;k<3;k++)z+=g[C_LAYOUT.read+3*a+k]*prev[3*a+k];for(let k=0;k<6;k++)z+=g[C_LAYOUT.direct+6*a+k]*f[k];return z};
      const u=calc(j),s=tone?calc(j+8):0;
      // Odd symmetry is exact until tone unlocked, and commands use original 16-muscle actuator.
      out[j]=Math.tanh(u+s);out[j+8]=Math.tanh(-u+s)
    }
    return out
  };
  return {N:C_N,S:T_SENS,A:16,K:C_K,control,hidden:()=>{
    const x=new Float64Array(C_N+T_SENS+16);x.set(prev);x.set(sens,C_N);x.set(out,C_N+T_SENS);return x},reset(){prev.fill(0);next.fill(0);out.fill(0);t=0}};
}
export function inspectContinuous(g){validate(g);let rec=0,sen=0;for(let i=0;i<3*C_N;i++)g[C_LAYOUT.src+i]>=T_SENS?rec++:sen++;return {version:C_VERSION,cells:C_N,incoming:3*C_N,recurrent:rec,sensorDendrites:sen,learnableInitial:trainableIndices().length,actuators:16,mode:'continuous tanh; reciprocal plus/minus muscles; tone optional'}}
