/* rig/core/archive.mjs — DIVERSE CHAMPIONS, the pendulum lab's way.
 *
 * One elite per behaviour cell (MAP-Elites). Cells are defined by what a brain
 * DOES (plant-supplied behaviour descriptors), never by how good it is, and the
 * axes track the range actually observed, rebinning when it widens (rebinning
 * is free because every elite carries its descriptor). Every elite's quality is
 * measured on the SAME fixed validation suite, so "beats this cell's elite"
 * always compares like with like.
 *
 * The champion POOL is derived from the archive, best first, skipping any
 * brain that is a functional near-copy of one already picked, then backfilled
 * so it is always full. Near-copy is a COUNT of functional differences (live
 * slots, signs, votes), not a percentage: a percentage that works at 12 units
 * is unreachable at 200 and collapses the pool to one lineage (the lab's own
 * recorded failure, paper section 8).
 */
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const fin=(x,d=0)=>Number.isFinite(x)?x:d;

export class Archive{
  constructor({axes,ranges,bins=5,cap=120,poolSize=8,poolMinDiff=6,distance}){
    this.axes=[...axes];this.initialRanges=JSON.parse(JSON.stringify(ranges));this.ranges=JSON.parse(JSON.stringify(ranges));
    this.bins=bins;this.cap=cap;this.poolSize=poolSize;this.poolMinDiff=poolMinDiff;this.distance=distance;
    this.cells=new Map();this.pool=[];this.serial=0;this.admissions={new:0,improved:0,rejected:0};
  }
  key(cell){return cell.join('|')}
  noteDesc(d){let widened=false;for(const k of this.axes){const v=clamp(fin(d[k]),0,1),r=this.ranges[k];
    if(v<r[0]-1e-9){r[0]=v;widened=true}if(v>r[1]+1e-9){r[1]=v;widened=true}}return widened}
  binOf(d){const b=this.bins;return this.axes.map(k=>{const [lo,hi]=this.ranges[k],span=Math.max(1e-6,hi-lo);
    return Math.min(b-1,Math.max(0,Math.floor((clamp(fin(d[k]),lo,hi)-lo)/span*b*.999999)))})}
  hasCellFor(d){return this.cells.has(this.key(this.binOf(d)))}
  rebin(){const all=[...this.cells.values()];this.cells=new Map();
    for(const e of all){e.cell=this.binOf(e.desc);const k=this.key(e.cell),cur=this.cells.get(k);if(!cur||e.quality>cur.quality)this.cells.set(k,e)}}
  /* entry = {genome, quality, desc, ...anything else to keep}. Returns 'new',
   * 'improved' or false. The descriptor and quality must come from the fixed
   * validation suite. */
  tryAdd(entry){
    if(this.noteDesc(entry.desc))this.rebin();
    const cell=this.binOf(entry.desc),k=this.key(cell),cur=this.cells.get(k);
    if(!cur||entry.quality>cur.quality+1e-12){
      const e={...entry,id:++this.serial,cell};this.cells.set(k,e);this.prune();
      const r=cur?'improved':'new';this.admissions[r]++;return r;
    }
    this.admissions.rejected++;return false;
  }
  /* over the cap, drop the weakest elite of the most crowded SIZE class when
   * size is an axis (so small brains cannot crowd big ones out), else the weakest */
  prune(){const si=this.axes.indexOf('size');
    while(this.cells.size>this.cap){let pool=[...this.cells.entries()];
      if(si>=0){const by=new Map();for(const x of pool){const k=x[1].cell[si];if(!by.has(k))by.set(k,[]);by.get(k).push(x)}pool=[...by.values()].sort((a,b)=>b.length-a.length)[0]}
      let worst=pool[0];for(const x of pool)if(x[1].quality<worst[1].quality)worst=x;this.cells.delete(worst[0])}}
  ranked(){return [...this.cells.values()].sort((a,b)=>b.quality-a.quality)}
  best(){return this.ranked()[0]||null}
  derivePool(){
    const all=this.ranked(),picked=[];
    for(const e of all){if(picked.length>=this.poolSize)break;
      if(this.poolMinDiff>0&&picked.some(p=>this.distance(p.genome,e.genome)<this.poolMinDiff))continue;picked.push(e)}
    for(const e of all){if(picked.length>=this.poolSize)break;if(!picked.includes(e))picked.push(e)}
    this.pool=picked;return picked;
  }
  pickPool(rng,selExp=1.8){const p=this.pool;if(!p.length)return null;return p[Math.min(p.length-1,Math.floor(Math.pow(rng.next(),selExp)*p.length))]}
  pickAny(rng){if(!this.cells.size)return null;const a=[...this.cells.values()];return a[Math.floor(rng.next()*a.length)]}
  coverage(){const total=Math.pow(this.bins,this.axes.length);return {cells:this.cells.size,total,frac:this.cells.size/total}}
  /* Functional spread of the pool: min and mean pairwise differences. */
  spread(){const p=this.pool;if(p.length<2)return {min:0,mean:0};let mn=Infinity,s=0,n=0,x=0;
    for(let i=0;i<p.length;i++)for(let j=i+1;j<p.length;j++){const d=this.distance(p[i].genome,p[j].genome);if(!Number.isFinite(d)){x++;continue}mn=Math.min(mn,d);s+=d;n++}   // pairs of different sizes are counted apart
    return {min:Number.isFinite(mn)?mn:0,mean:n?s/n:0,crossSize:x}}
  toJSON(enc=g=>g){return {axes:this.axes,ranges:this.ranges,initialRanges:this.initialRanges,bins:this.bins,cap:this.cap,poolSize:this.poolSize,poolMinDiff:this.poolMinDiff,
    serial:this.serial,admissions:this.admissions,cells:[...this.cells.values()].map(e=>({...e,genome:enc(e.genome)})),poolIds:this.pool.map(e=>e.id)}}
  static fromJSON(o,{distance,dec=g=>g}){
    const a=new Archive({axes:o.axes,ranges:o.initialRanges||o.ranges,bins:o.bins,cap:o.cap,poolSize:o.poolSize,poolMinDiff:o.poolMinDiff,distance});
    a.ranges=JSON.parse(JSON.stringify(o.ranges));a.serial=o.serial|0;a.admissions=o.admissions||a.admissions;
    for(const e of o.cells||[]){const x={...e,genome:dec(e.genome)};a.cells.set(a.key(x.cell),x)}
    const byId=new Map([...a.cells.values()].map(e=>[e.id,e]));a.pool=(o.poolIds||[]).map(id=>byId.get(id)).filter(Boolean);
    return a;
  }
}
