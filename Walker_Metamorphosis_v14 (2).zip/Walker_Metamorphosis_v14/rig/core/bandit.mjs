/* rig/core/bandit.mjs — adaptive operator selection: the run learns its own settings.
 * Each candidate draws one option in each dimension (mutation count, parent,
 * crossover, grow/shrink). Its gain over the current brain's training fitness
 * (0 if it lost), divided by the typical gain, credits every option it used, as
 * an exponentially weighted average per candidate, so the shares follow a
 * changing landscape. Probability matching with a floor: nothing is abandoned.
 * A pinned dimension is neither drawn nor credited. */
export const BASIN_ARMS=Object.freeze({mutations:[1,2,4,8],cross:[0,1],structure:['none','grow','shrink']});   // basin search: the parent is the peak
export const DEFAULT_ARMS=Object.freeze({mutations:[1,2,4,8],parent:['current','pool','archive'],cross:[0,1],structure:['none','grow','shrink']});
export class Bandit{
  constructor(arms=DEFAULT_ARMS,{floor=.05,alpha=.01}={}){
    this.arms=JSON.parse(JSON.stringify(arms));this.floor=floor;this.alpha=alpha;this.scale=0;this.events=0;this.q={};this.n={};this.wins={};
    for(const [d,a] of Object.entries(this.arms)){this.q[d]=a.map(()=>.5);this.n[d]=a.map(()=>0);this.wins[d]=a.map(()=>0)}
  }
  probs(d){const q=this.q[d],k=q.length,s=q.reduce((x,y)=>x+y,0),f=Math.min(this.floor,1/k);return q.map(v=>f+(1-k*f)*(s>0?v/s:1/k))}
  sample(rng,pins={}){const c={};for(const d of Object.keys(this.arms)){if(pins[d]!==undefined&&pins[d]!==null){c[d]=pins[d];continue}
    const p=this.probs(d);let r=rng.next(),i=0;for(;i<p.length-1;i++){if(r<p[i])break;r-=p[i]}c[d]=this.arms[d][i]}return c}
  credit(choice,gain,pins={}){
    const g=Number.isFinite(gain)&&gain>0?gain:0;this.events++;if(g>0)this.scale=this.scale>0?.98*this.scale+.02*g:g;
    const c=g>0?Math.min(5,g/(this.scale||g)):0;
    for(const d of Object.keys(this.arms)){if(pins[d]!==undefined&&pins[d]!==null)continue;const i=this.arms[d].indexOf(choice[d]);if(i<0)continue;
      this.q[d][i]=(1-this.alpha)*this.q[d][i]+this.alpha*c;this.n[d][i]++;if(g>0)this.wins[d][i]++}
  }
  snapshot(){const o={};for(const d of Object.keys(this.arms)){const p=this.probs(d);o[d]=this.arms[d].map((a,i)=>({arm:a,share:p[i],credit:this.q[d][i],tried:this.n[d][i],wins:this.wins[d][i]}))}return {dims:o,events:this.events}}
}
