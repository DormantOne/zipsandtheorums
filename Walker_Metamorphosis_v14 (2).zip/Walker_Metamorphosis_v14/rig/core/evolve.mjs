import {Bandit,BASIN_ARMS} from './bandit.mjs';
/* rig/core/evolve.mjs — one run of champion evolution (the pendulum lab's trainGeneration).
 *
 * Each generation: lambda candidates; each candidate's parent is the current
 * brain, a pool champion, or a random archive cell; a share are crossed with a
 * second champion first; all are mutated (a strong jump on the last candidate
 * every `strongEvery` generations) and scored on the training suite. The best
 * candidate replaces the current brain only if it beats it on the same suite.
 * Every `valEvery` generations the current brain is scored on the fixed
 * validation suite and offered to the archive, and so is the best candidate
 * that landed in an EMPTY behaviour cell even if it lost -- that is how the
 * archive fills with strategies the winner never tried. After `threshold`
 * generations without improvement the run restarts from a strongly mutated
 * champion. The training suite rotates every `rotate` generations.
 *
 * Plant-agnostic: everything about bodies, brains and scores comes from the
 * plant adapter (rig/plants/*.mjs). Evaluation is awaited, so a worker pool can
 * serve many runs at once.
 */
import {Rng,hash32} from './rng.mjs';
import {Archive} from './archive.mjs';

export class ChampionRun{
  constructor({plant,cfg,seed,id=null,genome=null,suites=null,metric='best',target=null}){
    this.metric=metric;this.target=target;this.certifiedId=null;
    this.plant=plant;this.cfg={...plant.searchDefaults(cfg.N),...cfg};this.seed=seed>>>0;this.id=id||`${plant.name}-N${this.cfg.N}-s${this.seed}`;
    this.rng=new Rng(hash32(this.seed^0x52494721));this.seedGenome=genome;this.seeded=!!genome;this.suites=suites;
    this.generation=0;this.stagnation=0;this.epoch=-1;this.train=null;this.current=null;this.currentTrain=null;this.foundersDone=false;this.immigrantsTried=0;
    this.lastValidated=null;this.history=[];this.events=[];this.solvedAt=null;this.stopped=null;
    this.compute={rollouts:0,steps:0,neuronUpdates:0,physicsSteps:0,generations:0};
    this.parentWins={current:0,pool:0,archive:0,crossover:0,strong:0};this.improvements=0;
    this.archive=new Archive({axes:plant.axes,ranges:plant.ranges,bins:this.cfg.bins,cap:this.cfg.archiveCap,poolSize:this.cfg.poolSize,poolMinDiff:this.cfg.poolMinDiff,distance:plant.distance});
  }
  get spent(){return this.compute[this.plant.costUnit]}
  charge(trialsList,genomes){const c=this.plant.cost(trialsList,genomes);for(const k of Object.keys(c))this.compute[k]=(this.compute[k]||0)+c[k]}
  async score(genomes,suite,{train=false}={}){const t=await this.plant.evaluate(genomes,suite,{cfg:this.cfg,train});this.charge(t,genomes);
    /* a brain's size is part of its descriptor, so the archive keeps elites of every size */
    return t.map((tr,i)=>{const s=this.plant.summarize(tr,{cfg:this.cfg});if(this.plant.sizeDescriptor)s.desc={...s.desc,size:this.plant.sizeDescriptor(genomes[i])};return s})}
  async init(){
    if(!this.suites)this.suites=this.plant.suites(this.seed,this.cfg);
    this.current=this.seedGenome||this.plant.birth(this.rng,this.cfg);
    if(this.cfg.bandit&&!this.bandit)this.bandit=new Bandit(this.cfg.banditArms||(this.cfg.search==='basin'?BASIN_ARMS:undefined));
    return this;
  }
  /* VARIED CHAMPIONS from the start (v7.1.3). A run used to begin from one
   * newborn, so every "champion" in its archive was a near-copy of that one
   * brain, and the run's outcome mostly reflected that newborn's luck. With
   * cfg.founders > 1 the run first scores that many INDEPENDENT newborns on the
   * validation suite and offers each to the archive, then climbs from the
   * best; a seeded run (a fossil) gets the fossil plus strong mutants of it.
   * The founders' rollouts are charged to the run, so arms with and without
   * founders still compare at equal physics. */
  async found(){
    this.foundersDone=true;const F=Math.max(1,Math.trunc(this.cfg.founders||1));if(F<=1)return;
    const p=this.plant,c=this.cfg,brains=[this.current];
    const sizes=Array.isArray(c.founderSizes)&&c.founderSizes.length?c.founderSizes:null;   // mixed sizes: founders span them
    for(let i=1;i<F;i++)brains.push(this.seedGenome?p.mutate(this.seedGenome,this.rng,{strong:true,cfg:c}):p.birth(this.rng,sizes?{...c,N:sizes[i%sizes.length]}:c));
    const vs=await this.score(brains,this.suites.val);
    this.founderGenomes=brains.slice();
    brains.forEach((g,k)=>this.archive.tryAdd({genome:g,quality:vs[k].quality,record:vs[k].record,guard:vs[k].guard,desc:vs[k].desc,stats:slim(vs[k]),generation:0,spent:this.spent,founder:k}));
    this.archive.derivePool();
    let best=0;for(let k=1;k<F;k++)if(vs[k].quality>vs[best].quality)best=k;
    this.current=brains[best];this.lastValidated=this.current;this.currentTrain=null;
    this.events.push({generation:0,kind:'founders',count:F,best,bestQuality:vs[best].quality});
    await this.certifyBest();this.history.push(this.snapshotRow());
  }
  pickParentBy(kind){const a=this.archive;
    if(kind==='pool'){const e=a.pickPool(this.rng,this.cfg.selExp);if(e)return {genome:e.genome,from:'pool'}}
    if(kind==='archive'){const e=a.pickAny(this.rng);if(e)return {genome:e.genome,from:'archive'}}
    return {genome:this.current,from:'current'};
  }
  pickParent(){
    const c=this.cfg,a=this.archive;
    if(this.rng.next()*100<c.revisitPct){
      if(this.rng.next()*100<c.archivePct){const e=a.pickAny(this.rng);if(e)return {genome:e.genome,from:'archive'}}
      const e=a.pickPool(this.rng,c.selExp);if(e)return {genome:e.genome,from:'pool'};
    }
    return {genome:this.current,from:'current'};
  }
  async step(){
    if(this.cfg.search==='basin')return this.stepBasin();
    const c=this.cfg,p=this.plant;
    if(!this.foundersDone)await this.found();
    const wantEpoch=c.rotate>0?Math.floor(this.generation/c.rotate):0;
    if(wantEpoch!==this.epoch){this.epoch=wantEpoch;this.train=p.trainingSuite(this.seed,this.epoch,c);this.currentTrain=null}
    /* with the bandit on, each candidate's mutation count, parent, crossover
     * and grow/shrink are drawn from what has been paying (rig/core/bandit.mjs) */
    const cands=[],meta=[],B=this.bandit,pins=c.banditPins||{};
    for(let i=0;i<c.lambda;i++){
      const ch=B?B.sample(this.rng,pins):null;
      const par=ch?this.pickParentBy(ch.parent):this.pickParent();let base=par.genome,from=par.from,crossed=false,structure='none';
      if(this.archive.pool.length>1&&(ch?ch.cross===1:this.rng.next()*100<c.crossPct)){const o=this.archive.pickPool(this.rng,c.selExp);
        if(o&&o.genome!==base){const x=p.crossover(base,o.genome,this.rng);if(x){base=x;crossed=true}}}
      if(ch&&ch.structure!=='none'&&p[ch.structure]){const y=p[ch.structure](base,this.rng,c);if(y){base=y;structure=ch.structure}}
      const strong=c.strongEvery>0&&i===c.lambda-1&&(this.generation%c.strongEvery)===c.strongEvery-1;
      cands.push(p.mutate(base,this.rng,{strong,cfg:c,count:ch?ch.mutations:null}));meta.push({from,crossed,strong,structure,ch,parent:par.genome});
    }
    /* v9.1: the bandit credits each child against its OWN parent on these trials,
     * so re-deriving a champion from a weak current brain earns nothing. Pool and
     * archive parents are scored once per trial set and rung. */
    const key=`${this.epoch}|${c.rung??''}`;this.parentScores??=new WeakMap();
    const need=B?[...new Set(meta.filter(m=>m.ch&&m.from!=='current').map(m=>m.parent))].filter(g=>this.parentScores.get(g)?.key!==key):[];
    const batch=[...(this.currentTrain?[]:[this.current]),...cands,...need];
    const scored=await this.score(batch,this.train,{train:true});
    if(!this.currentTrain)this.currentTrain=scored.shift();
    need.forEach((g,i)=>{this.parentScores.set(g,{key,selection:scored[cands.length+i].selection});this.parentsScored=(this.parentsScored||0)+1});scored.length=cands.length;
    const baseSel=this.currentTrain.selection;let win=-1,winSel=baseSel,explorer=-1,expSel=-Infinity;
    for(let i=0;i<cands.length;i++){const s=scored[i];
      if(!this.archive.hasCellFor(s.desc)&&s.selection>expSel){explorer=i;expSel=s.selection}
      if(s.selection>winSel){win=i;winSel=s.selection}}
    const parentSel=m=>m.from==='current'?baseSel:(this.parentScores.get(m.parent)?.selection??baseSel);
    if(B)for(let i=0;i<cands.length;i++)if(meta[i].ch)B.credit(meta[i].ch,scored[i].selection-parentSel(meta[i]),pins);
    if(win>=0){const m=meta[win];this.current=cands[win];this.currentTrain=scored[win];this.stagnation=0;this.improvements++;
      this.parentWins[m.from]++;if(m.crossed)this.parentWins.crossover++;if(m.strong)this.parentWins.strong++}
    else this.stagnation++;
    this.generation++;this.compute.generations=this.generation;
    return await this.validateAndRecord(explorer>=0&&cands[explorer]!==this.current?cands[explorer]:null);
  }
  /* shared by both search modes: every valEvery generations the current brain,
   * the best explorer and any immigrants are validated and offered to the archive */
  async validateAndRecord(explorerGenome){
    const c=this.cfg,p=this.plant;let row=null;
    if(this.generation%c.valEvery===0){
      const toVal=[];if(this.lastValidated!==this.current)toVal.push(this.current);
      if(explorerGenome&&explorerGenome!==this.current)toVal.push(explorerGenome);
      /* immigrants: every immigrantEvery generations, a few NEW lineages are
       * scored and offered to the archive (fresh newborns from birth; strong
       * mutants of a random elite for a seeded run), so the champions keep
       * varying instead of converging on one family */
      if(c.immigrants>0&&c.immigrantEvery>0&&this.generation%c.immigrantEvery===0){
        for(let i=0;i<c.immigrants;i++){const e=this.seeded?this.archive.pickAny(this.rng):null;
          const fs=Array.isArray(c.founderSizes)&&c.founderSizes.length?c.founderSizes:null;
          toVal.push(e?p.mutate(e.genome,this.rng,{strong:true,cfg:c}):p.birth(this.rng,fs?{...c,N:fs[Math.floor(this.rng.next()*fs.length)]}:c));this.immigrantsTried++}}
      if(toVal.length){const vs=await this.score(toVal,this.suites.val);
        /* distance mode: the farthest brain on the fixed validation scenarios, kept apart from the archive */
        if(c.selection==='distance')toVal.forEach((g,k)=>{const s=vs[k];if(Number.isFinite(s.distRate)&&(!this.farthest||s.distRate>this.farthest.val.distRate))this.farthest={genome:g,val:{distRate:s.distRate,injury:s.injury,quality:s.quality,meanL:s.meanL,meanQ:s.meanQ,slipMedianCm:s.slipMedianCm,desc:s.desc},generation:this.generation}});
        toVal.forEach((g,k)=>{this.archive.tryAdd({genome:g,quality:vs[k].quality,record:vs[k].record,guard:vs[k].guard,desc:vs[k].desc,stats:slim(vs[k]),generation:this.generation,spent:this.spent})});
        if(toVal[0]===this.current){this.lastValidated=this.current;this.currentVal=vs[0]}
        this.archive.derivePool();}
      /* the plant sees every validation of the current brain: the walker's
       * cycled curriculum advances its rung here (rig/plants/walker.mjs) */
      if(p.onValidated&&this.currentVal)p.onValidated(this,this.currentVal);
      await this.certifyBest();
      row=this.snapshotRow();this.history.push(row);
      const hit=this.target!==null&&this.target!==undefined?row[this.metric]>=this.target-1e-12:(p.criterion?.solved?p.criterion.solved(row.best):false);
      if(this.solvedAt===null&&hit)this.solvedAt={generation:this.generation,spent:this.spent,compute:{...this.compute}};
    }
    if(c.search!=='basin'&&this.stagnation>=c.threshold){
      const e=(this.rng.next()*100<c.archivePct?this.archive.pickAny(this.rng):null)||this.archive.pickPool(this.rng,c.selExp);
      if(e){this.current=p.mutate(e.genome,this.rng,{strong:true,cfg:c});this.currentTrain=null;this.events.push({generation:this.generation,kind:'revisit',from:e.id})}
      this.stagnation=0;
    }
    return row;
  }
  /* ── basin search (v9.1): the pendulum's fitness-map search, on the walker ──
   * A frontier of up to 4K diverse brains. Each generation picks K separated
   * peaks (a different size always counts as separated); most candidates are
   * local mutants of a peak, escapePct % are bigger jumps from founders,
   * archive elites or the best brain. Each peak is re-ranked by its basin score:
   * half its own fitness, 0.3 x its children's mean (less 0.15 x their spread)
   * and 0.2 x its best child. The best brain on the current trials is never
   * dropped, and every frontier brain is re-scored whenever the training trials
   * rotate or the curriculum's rung changes, so fitnesses never go stale. */
  async stepBasin(){
    const c=this.cfg,p=this.plant,B=this.bandit,pins=c.banditPins||{},K=Math.max(1,Math.round(c.peaks??4)),cap=Math.max(4*K,K),lam=Math.max(K,c.lambda);
    if(!this.foundersDone)await this.found();
    const wantEpoch=c.rotate>0?Math.floor(this.generation/c.rotate):0;
    if(wantEpoch!==this.epoch){this.epoch=wantEpoch;this.train=p.trainingSuite(this.seed,this.epoch,c)}
    const key=`${this.epoch}|${c.rung??''}|${c.selection??''}`;
    if(!this.frontier){const seen=new Set();this.frontier=[this.current,...this.archive.ranked().map(e=>e.genome)].filter(g=>!seen.has(g)&&seen.add(g)).slice(0,cap).map(genome=>({genome}))}
    const stale=this.frontier.filter(f=>f.key!==key);
    if(stale.length){const s=await this.score(stale.map(f=>f.genome),this.train,{train:true});stale.forEach((f,i)=>{f.train=s[i];f.key=key});this.rescored=(this.rescored||0)+stale.length}
    const norm=(a,b)=>{const d=p.distance(a,b);return Number.isFinite(d)?d/(15*Math.max(1,p.sizeOf?p.sizeOf(a):24)):Infinity};
    const byFit=[...this.frontier].sort((a,b)=>b.train.selection-a.train.selection),peaks=[];
    /* v9.3: what peaks must differ in: wiring (normalised wiring difference, a
     * different size always counts), gait (distance in duty x coordination x
     * cadence, each scaled to the archive's range; 0.2 = one archive bin), or
     * both. Relaxed by half, then dropped, if too few qualify. */
    const sepMode=c.separation||'wiring',AR=this.archive.ranges||{};
    const gd=(a,b)=>{const x=a.train?.desc,y=b.train?.desc;if(!x||!y)return Infinity;let s=0;for(const k of ['duty','coordination','cadence']){const r=AR[k]||[0,1];s+=((x[k]-y[k])/Math.max(1e-6,r[1]-r[0]))**2}return Math.sqrt(s)};
    const apart=(q,f,t)=>{const w=norm(q.genome,f.genome)>t.w;if(sepMode==='wiring')return w;const g=gd(q,f)>t.g;return sepMode==='gait'?g:w&&g};
    const ps=c.peakSep??.04;
    for(const t of [{w:ps,g:.2},{w:ps/2,g:.1},{w:-1,g:-1}])for(const f of byFit){if(peaks.length>=K)break;if(!peaks.includes(f)&&peaks.every(q=>apart(q,f,t)))peaks.push(f)}
    const escN=Math.min(lam-peaks.length,Math.max(0,Math.round(lam*(c.escapePct??20)/100))),locN=lam-escN,cands=[],meta=[];
    for(let i=0;i<locN;i++){const pk=peaks[i%peaks.length],ch=B?B.sample(this.rng,pins):null;let g=pk.genome,crossed=false;
      if(peaks.length>1&&(ch?ch.cross===1:this.rng.next()*100<c.crossPct)){const o=peaks[(peaks.indexOf(pk)+1+Math.floor(this.rng.next()*(peaks.length-1)))%peaks.length],x=p.crossover(g,o.genome,this.rng);if(x){g=x;crossed=true}}
      if(ch&&ch.structure!=='none'&&p[ch.structure]){const y=p[ch.structure](g,this.rng,c);if(y)g=y}
      cands.push(p.mutate(g,this.rng,{cfg:c,count:ch?ch.mutations:(c.mutations??2)}));meta.push({kind:'local',peak:pk,ch,crossed})}
    for(let i=0;i<escN;i++){const u=this.rng.next(),F=this.founderGenomes||[],a=this.archive.pickAny(this.rng),o=u<1/3&&F.length?F[Math.floor(this.rng.next()*F.length)]:u<2/3&&a?a.genome:byFit[0].genome;
      cands.push(p.mutate(o,this.rng,{cfg:c,count:Math.max((c.mutations??2)+2,4+Math.floor(this.rng.next()*3))}));meta.push({kind:'escape'})}
    const scored=await this.score(cands,this.train,{train:true});
    if(B)for(let i=0;i<cands.length;i++)if(meta[i].ch)B.credit(meta[i].ch,scored[i].selection-meta[i].peak.train.selection,pins);   // against its own parent
    const roots=peaks.map(pk=>{const v=meta.map((m,i)=>m.peak===pk?scored[i].selection:null).filter(x=>x!==null),s=pk.train.selection;
      if(!v.length)return {...pk,basin:s};const avg=v.reduce((a,b)=>a+b,0)/v.length,sd=Math.sqrt(v.reduce((a,x)=>a+(x-avg)**2,0)/v.length);
      return {...pk,basin:.5*s+.3*(avg-.15*sd)+.2*Math.max(...v)}});
    const fresh=cands.map((g,i)=>({genome:g,train:scored[i],key,basin:scored[i].selection,kind:meta[i].kind,crossed:meta[i].crossed}));
    const all=[...roots,...fresh],pool=[];
    for(const e of [...all].sort((a,b)=>b.basin-a.basin)){if(pool.length>=cap)break;if(pool.every(q=>norm(q.genome,e.genome)>=(c.frontierSep??.02)))pool.push(e)}
    for(const e of [...fresh].sort((a,b)=>b.train.selection-a.train.selection))if(pool.length<cap&&!pool.includes(e)&&e.train.selection>=(pool.at(-1)?.train.selection??-Infinity))pool.push(e);
    const top=[...all].sort((a,b)=>b.train.selection-a.train.selection)[0];if(!pool.includes(top)){if(pool.length>=cap)pool.pop();pool.unshift(top)}
    /* distance mode: the frontier also keeps the farthest brain of every injury tier (harm up to 0.5,
     * 1.25, 2.5, beyond), so clean lineages stay in play beside the fast sloppy ones */
    if(c.selection==='distance'){const T=[.5,1.25,2.5,Infinity];T.forEach((t,i)=>{const lo=i?T[i-1]:-Infinity,b=[...all].filter(e=>{const v=e.train?.injury??Infinity;return v>lo&&v<=t}).sort((a,b)=>b.train.selection-a.train.selection)[0];
      if(b&&!pool.includes(b)){if(pool.length>=cap)pool.splice(pool.length-1,1);pool.push(b)}})}
    /* what the landscape map shows: this generation's peaks and candidates */
    this.lastMap={generation:this.generation,peaks:peaks.map(pk=>pk.genome),peakInfo:peaks.map(pk=>({sel:pk.train.selection,desc:pk.train.desc})),cands:fresh.map((f,i)=>({genome:f.genome,sel:f.train.selection,desc:f.train.desc,kind:meta[i].kind,peak:meta[i].peak?peaks.indexOf(meta[i].peak):-1}))};
    this.frontier=pool;
    if(top.train.selection>byFit[0].train.selection){this.stagnation=0;this.improvements++;const k=top.kind==='escape'?'escape':'peak';this.parentWins[k]=(this.parentWins[k]||0)+1;if(top.crossed)this.parentWins.crossover++}else this.stagnation++;
    this.current=top.genome;this.currentTrain=top.train;
    this.lastPeaks=peaks.map(pk=>({n:p.sizeOf?p.sizeOf(pk.genome):0,sel:pk.train.selection}));
    let explorer=-1,expSel=-Infinity;for(let i=0;i<cands.length;i++){const s=scored[i];if(!this.archive.hasCellFor(s.desc)&&s.selection>expSel){explorer=i;expSel=s.selection}}
    this.generation++;this.compute.generations=this.generation;
    return await this.validateAndRecord(explorer>=0?cands[explorer]:null);
  }
  /* bring a brain into the search: the frontier in basin mode, the current brain otherwise */
  /* what the KG counts as progress: the farthest brain's speed in distance mode, the champion's ladder otherwise */
  progress(){return this.cfg.selection==='distance'?(this.farthest?.val.distRate??0):(this.archive.best()?.quality??0)}
  adopt(g){if(!g)return;if(this.cfg.search==='basin')(this.frontier??=[]).push({genome:g});else{this.current=g;this.currentTrain=null;this.stagnation=0}}
  /* a curriculum cycle restarts from the best brains found, not from a wandering lineage */
  restartFromBest(){const b=this.archive.best();if(!b)return;
    if(this.cfg.search==='basin'){for(const e of [b,...this.archive.pool])if(!(this.frontier??=[]).some(f=>f.genome===e.genome))this.frontier.push({genome:e.genome})}
    else{this.current=b.genome;this.currentTrain=null}}
  /* The record statistic on the certification panel, for the archive's best
   * entry whenever that entry changes (plants without a cert suite skip this). */
  async certifyBest(){
    const b=this.archive.best();if(!b||!this.suites.cert||b.id===this.certifiedId)return;
    const s=(await this.score([b.genome],this.suites.cert))[0];b.cert={record:s.record,meanQ:s.meanQ??null,guard:s.guard,quality:s.quality};this.certifiedId=b.id;
  }
  snapshotRow(){
    const b=this.archive.best(),cov=this.archive.coverage(),sp=this.archive.spread();
    let bestMeanQ=null;for(const e of this.archive.cells.values()){const m=e.stats?.meanQ;if(Number.isFinite(m)&&(bestMeanQ===null||m>bestMeanQ))bestMeanQ=m}
    const cv=this.currentVal||null;
    return {generation:this.generation,spent:this.spent,compute:{...this.compute},rung:this.cfg.rung??null,far:this.farthest?.val.distRate??null,farInj:this.farthest?.val.injury??null,cycle:this.curriculum?.cycle??0,
      current:cv?{quality:cv.quality,meanQ:cv.meanQ??null,selection:cv.selection,pass:cv.pass??null,slipMedianCm:cv.slipMedianCm??null,speed:cv.speed??null}:null,best:b?b.quality:-Infinity,bestMeanQ,bestRecord:b?b.record:null,bestGuard:b?b.guard:null,bestCert:b?.cert??null,
      bestStats:b?b.stats:null,cells:cov.cells,coverage:cov.frac,poolMinDiff:sp.min,poolMeanDiff:sp.mean,parentWins:{...this.parentWins},improvements:this.improvements};
  }
  bestAt(spent,key=this.metric){let y=-Infinity;for(const h of this.history){if(h.spent>spent)break;const v=h[key];if(Number.isFinite(v)&&v>y)y=v}return y}
  async advanceTo(budget,{maxGenerations=Infinity,onRow=null}={}){
    let lastYield=Date.now();
    while(this.spent<budget&&this.generation<maxGenerations&&!this.stopped){const r=await this.step();if(r&&onRow)onRow(this,r);
      /* A synchronous plant (the pendulum) never waits on anything, so yield to
       * the event loop now and then: a stop signal is then handled at once. */
      if(Date.now()-lastYield>200){await new Promise(res=>setImmediate(res));lastYield=Date.now()}
      if(this.solvedAt&&this.cfg.stopWhenSolved!==false)break}
    return this;
  }
  toJSON(){const enc=this.plant.encode;return {id:this.id,seed:this.seed,cfg:this.cfg,metric:this.metric,target:this.target,certifiedId:this.certifiedId,rngState:this.rng.rngState,generation:this.generation,stagnation:this.stagnation,epoch:this.epoch,
    current:enc(this.current),history:this.history.slice(),foundersDone:this.foundersDone,immigrantsTried:this.immigrantsTried,seeded:this.seeded,curriculum:this.curriculum??null,
    epoch:this.epoch,currentTrain:this.currentTrain,currentValidated:this.lastValidated===this.current,events:this.events.slice(-200),solvedAt:this.solvedAt,stopped:this.stopped,compute:{...this.compute},parentWins:{...this.parentWins},improvements:this.improvements,
    archive:this.archive.toJSON(enc)}}
  static fromJSON(o,plant){
    const r=new ChampionRun({plant,cfg:o.cfg,seed:o.seed,id:o.id,metric:o.metric||'best',target:o.target??null});r.certifiedId=o.certifiedId??null;
    Object.assign(r,{generation:o.generation,stagnation:o.stagnation,epoch:-1,history:o.history||[],events:o.events||[],solvedAt:o.solvedAt,stopped:o.stopped,compute:o.compute,parentWins:o.parentWins,improvements:o.improvements|0});
    r.rng.rngState=o.rngState>>>0;r.current=plant.decode(o.current);r.archive=Archive.fromJSON(o.archive,{distance:plant.distance,dec:plant.decode});
    r.suites=plant.suites(r.seed,r.cfg);
    // v7.1.3: a resumed run continues exactly as an uninterrupted one would
    r.foundersDone=o.foundersDone??true;r.immigrantsTried=o.immigrantsTried|0;r.seeded=!!o.seeded;if(o.curriculum)r.curriculum=o.curriculum;
    if(Number.isInteger(o.epoch)&&o.epoch>=0){r.epoch=o.epoch;r.train=plant.trainingSuite(r.seed,r.epoch,r.cfg);r.currentTrain=o.currentTrain??null}
    if(o.currentValidated)r.lastValidated=r.current;
    return r;
  }
}
function slim(s){const o={};for(const [k,v] of Object.entries(s))if(typeof v==='number'||(v&&typeof v==='object'&&!Array.isArray(v)&&Object.values(v).every(x=>typeof x==='number')))o[k]=v;return o}
