/* rig/core/governor.mjs — the plateau governor, the scaled-back KG.
 * Watches the champion. After plateauGens generations without a better one it
 * (1) checks the champion against the holdout scenarios and demotes it if it
 * only shines on validation, then (2) tries ONE intervention for trialGens
 * generations, chosen by Thompson sampling on the ledger of past outcomes. A
 * trial WINS if the champion improves within its window. Temporary settings
 * are restored when it ends. The ledger is saved and carries over between runs,
 * so over many plateaus it learns which moves break them. */
export const INTERVENTIONS=Object.freeze({
  grow:'grow the current brain by internal cells',
  switch:'switch to a different archive elite (another size if there is one)',
  explore:'explore harder for a while (more escape probes, strong jumps and immigrants, a higher bandit floor)',
  refine:'refine locally for a while (1 mutation, no crossover, growth or escape probes)'});
export class Governor{
  constructor({ledger=null,plateauGens=3000,trialGens=1500,eps=.002,demoteGap=.3}={}){
    Object.assign(this,{plateauGens,trialGens,eps,demoteGap});this.ledger=ledger||{};for(const t of Object.keys(INTERVENTIONS))this.ledger[t]??={tries:0,wins:0};
    this.bestQ=null;this.since=0;this.trial=null;this.log=[];this.plateaus=0;
  }
  note(g,text){this.log.push({generation:g,at:new Date().toISOString(),text});if(this.log.length>200)this.log.shift()}
  choose(rng){let best=null,bv=-1;for(const t of Object.keys(INTERVENTIONS)){const L=this.ledger[t],v=betaSample(rng,L.wins+1,L.tries-L.wins+1);if(v>bv){bv=v;best=t}}return best}
  /* a plateau trial is due (used by the lab so a settings test never starts while one is waiting) */
  due(g){return !this.trial&&this.bestQ!==null&&g-this.since>=this.plateauGens}
  async onRow(run,plant,{defer=false}={}){
    const b=run.archive.best(),g=run.generation;if(!b)return;const bq=run.progress?run.progress():b.quality;   // distance mode: the farthest brain's speed
    if(this.bestQ===null){this.bestQ=bq;this.since=g;return}
    if(bq>this.bestQ+this.eps){const old=this.bestQ;this.bestQ=bq;this.since=g;if(this.trial)this.close(run,true,`the champion rose from ${old.toFixed(4)} to ${bq.toFixed(4)}`);return}
    if(this.trial){if(g-this.trial.start>=this.trialGens)this.close(run,false,`no better champion in ${this.trialGens} generations`);return}
    if(g-this.since<this.plateauGens)return;
    if(defer)return;                     // a settings test is running: the plateau trial waits until it finishes
    this.plateaus++;await this.audit(run);
    const type=this.choose(run.rng),L=this.ledger[type];
    this.note(g,`plateau ${this.plateaus}: champion ${Number(this.bestQ).toFixed(4)} unchanged for ${g-this.since} generations -> trying "${INTERVENTIONS[type]}" (record ${L.wins} of ${L.tries})`);
    this.trial={type,start:g,undo:this.apply(type,run,plant)};this.since=g;
  }
  close(run,win,why){const t=this.trial;this.trial=null;const L=this.ledger[t.type];L.tries++;if(win)L.wins++;if(t.undo)t.undo();
    this.note(run.generation,`trial "${INTERVENTIONS[t.type]}" ${win?'WON':'ended'}: ${why}${t.undo?'; temporary settings restored':''} (record now ${L.wins} of ${L.tries})`)}
  apply(type,run,plant){
    const c=run.cfg,rng=run.rng;
    if(type==='grow'){const g=plant.grow?plant.grow(run.current,rng,{...c,growCount:Math.max(2,Math.round(.15*(plant.sizeOf?.(run.current)||12)))}):null;if(g){if(run.adopt)run.adopt(g);else{run.current=g;run.currentTrain=null}run.stagnation=0}return null}
    if(type==='switch'){const size=plant.sizeOf?.(run.current),top=run.archive.ranked().slice(0,16).filter(e=>e.genome!==run.current),other=top.filter(e=>plant.sizeOf?.(e.genome)!==size),e=(other.length?other:top)[0];
      if(e){if(run.adopt)run.adopt(e.genome);else{run.current=e.genome;run.currentTrain=null}run.stagnation=0}return null}
    if(type==='explore'){const s={strongEvery:c.strongEvery,immigrants:c.immigrants,escapePct:c.escapePct,floor:run.bandit?.floor};c.strongEvery=Math.max(1,Math.round((c.strongEvery||20)/2));c.immigrants=Math.max(2,2*(c.immigrants||0));c.escapePct=Math.min(50,2*(c.escapePct??20));if(run.bandit)run.bandit.floor=Math.min(.2,3*run.bandit.floor);
      return ()=>{c.strongEvery=s.strongEvery;c.immigrants=s.immigrants;c.escapePct=s.escapePct;if(run.bandit&&s.floor!==undefined)run.bandit.floor=s.floor}}
    if(type==='refine'){const s=c.banditPins,se=c.escapePct;c.banditPins={...(s||{}),mutations:1,parent:'current',cross:0,structure:'none'};c.escapePct=0;return ()=>{c.banditPins=s;c.escapePct=se}}
    return null;
  }
  async audit(run){const b=run.archive.best();if(!b)return;const [h]=await run.score([b.genome],run.suites.hold),gap=b.quality-h.quality;
    if(gap>this.demoteGap){run.archive.cells.delete(run.archive.key(b.cell));run.archive.derivePool();this.bestQ=run.progress?run.progress():(run.archive.best()?.quality??null);
      this.note(run.generation,`holdout audit: champion #${b.id} scores ${h.quality.toFixed(3)} on unseen scenarios against ${b.quality.toFixed(3)} on validation -> demoted`)}
    else this.note(run.generation,`holdout audit: champion #${b.id} holds up on unseen scenarios (${h.quality.toFixed(3)} against ${b.quality.toFixed(3)} on validation)`)}
  snapshot(){return {ledger:this.ledger,trial:this.trial?{type:this.trial.type,start:this.trial.start,label:INTERVENTIONS[this.trial.type]}:null,since:this.since,bestQ:this.bestQ,plateaus:this.plateaus,plateauGens:this.plateauGens,trialGens:this.trialGens,log:this.log.slice(-40)}}
}
function betaSample(rng,a,b){const x=gamma(rng,a),y=gamma(rng,b);return x/(x+y)}
function gamma(rng,k){if(k<1)return gamma(rng,k+1)*Math.pow(Math.max(1e-12,rng.next()),1/k);const d=k-1/3,c=1/Math.sqrt(9*d);
  for(;;){let x,v;do{x=normal(rng);v=1+c*x}while(v<=0);v=v*v*v;const u=rng.next();if(u<1-.0331*x**4||Math.log(u)<.5*x*x+d*(1-v+Math.log(v)))return d*v}}
function normal(rng){return Math.sqrt(-2*Math.log(Math.max(1e-12,rng.next())))*Math.cos(2*Math.PI*rng.next())}
