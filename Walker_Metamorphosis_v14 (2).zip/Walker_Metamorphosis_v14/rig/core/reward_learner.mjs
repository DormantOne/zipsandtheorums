/* Reward-difference continuous Protoneuron research mode, separate from v10 lab.
 * It reuses the existing walker physics, scoring and worker pool. No surrogate.
 */
import fs from 'node:fs';import path from 'node:path';
import {makeContinuous,isContinuous,rewireContinuous,trainableIndices,inspectContinuous,prng} from '../continuous.mjs';
import {makeWalkerPlant,rungScores,RUNG_ORDER} from '../plants/walker.mjs';
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x)),safe=(n,d=0)=>Number.isFinite(n)?n:d;
const DEF=Object.freeze({seed:47017,rounds:420,refill:420,autoFuel:false,dirs:4,starts:2,seconds:6,plastic:true,shortcuts:true,rewiring:true,diversity:true,pool:6,gate:.70,tone:false,workers:4});
const fail=(s)=>{throw Error(s)};
const cloneG=g=>Float64Array.from(g);
function randNorm(rand){return Math.sqrt(-2*Math.log(Math.max(1e-12,rand())))*Math.cos(2*Math.PI*rand())}
function fingerprint(trials){return trials.flatMap(t=>[t.desc?.duty||0,t.desc?.coordination||0,t.desc?.cadence||0])}
function sigDist(a,b){if(!a||!b||a.length!==b.length)return 0;let v=0;for(let i=0;i<a.length;i++)v+=(a[i]-b[i])**2;return Math.sqrt(v/a.length)}
export class RewardWalker{
 constructor({dataDir,workers=4,backend,plantFactory=null}={}){
  this.dataDir=dataDir;this.plantFactory=plantFactory;this.active=false;this.workers=Math.max(1,Math.min(8,workers|0||4));this.backend=backend;
  this.file=path.join(dataDir,'protoneuron_v11_checkpoint.json');this.plant=null;this.state=null;this.busy=false;this.error=null;this.events=[];this.promise=null;this.nextId=1;
  this.loadLocal();
 }
 async plantReady(){if(!this.plant){this.plant=await (this.plantFactory?this.plantFactory():makeWalkerPlant({workers:this.workers,backend:this.backend}));this.plant.setJoints('muscles');this.plant.setFriction('firm')}return this.plant}
 log(s){this.events.push(`[${this.state?.round||0}] ${s}`);if(this.events.length>120)this.events.shift()}
 config(opts={}){const p={...DEF,...opts};for(const k of ['seed','rounds','refill','dirs','starts','pool','workers'])p[k]=Math.trunc(Number(p[k]));p.seed=p.seed>>>0;p.rounds=clamp(p.rounds,1,5000000);p.refill=clamp(p.refill,1,500000);p.dirs=clamp(p.dirs,2,12);p.starts=clamp(p.starts,1,6);p.pool=clamp(p.pool,2,16);p.seconds=clamp(Number(p.seconds),2,10);p.gate=clamp(Number(p.gate),.50,1);for(const k of ['plastic','shortcuts','rewiring','diversity','autoFuel'])p[k]=!!p[k];p.tone=false;return p}
 fresh(p={}){
  if(this.active||this.busy)fail('A previous training batch is still finishing; pause and retry after it settles');const cfg=this.config(p),g=makeContinuous(cfg.seed);
  this.state={format:'protoneuron-walker-v11',version:1,cfg,stage:0,round:0,block:0,spent:0,rollouts:0,rng:(cfg.seed^0x74d88d17)>>>0,brain:g,best:g.slice(),archive:[],hall:[],curve:[],gate:null,fullGate:false,rewires:0,rewireWins:0,selected:null,lastDelta:0,lastTraining:0,lastValidation:null,mode:'ready',checkpoints:0,independentTests:0};
  this.nextId=1;this.events=[];this.log('Fresh continuous brain. Original v10.1 evolution laboratory remains unchanged.');this.save();return this.status()
 }
 rng(){let s=this.state,rand=prng(s.rng);const v=rand();s.rng=(s.rng+0x6d2b79f5)>>>0;return v}
 seed(){return Math.floor(this.rng()*4294967296)>>>0}
 stageName(){return ['posture','footfalls','distance','distance'][this.state?.stage||0]}
 settings(){const s=this.state;return {selection:'curriculum',rung:this.stageName(),worstWeight:.25,trainEarlyExit:{nonfootSeconds:1,mode:'cumulative'},tone:s.stage>=3,seconds:s.cfg.seconds}}
 async cases(which,epoch=0,n=null){const p=await this.plantReady(),s=this.state,cfg={trainCases:n??s.cfg.starts,trainSeconds:s.cfg.seconds,valCases:n??8,valSeconds:s.cfg.seconds,holdCases:n??16,difficulty:1,suiteSeed:s.cfg.seed+101,labRunSeed:s.cfg.seed+501};
  if(which==='train')return p.trainingSuite(s.cfg.seed,epoch,cfg);
  const suite=p.suites(s.cfg.seed,cfg);return which==='val'?suite.val:suite.hold
 }
 async evaluate(genomes,suite,{train=false}={}){
  const p=await this.plantReady(),s=this.state;const trials=await p.evaluate(genomes,suite,{cfg:this.settings(),train});
  for(const group of trials)for(const t of group){s.spent+=safe(t.steps);s.rollouts++}
  return trials.map(group=>{const k=this.stageName();const values=group.map(t=>safe(t.rs?.[k],-50)),mean=values.reduce((a,b)=>a+b,0)/values.length,loss=Math.min(...values),passes={};for(const r of RUNG_ORDER)passes[r]=group.filter(t=>t.pass[r]).length/group.length;
    return {reward:mean+.25*loss,mean,passes,ladder:group.reduce((a,t)=>a+t.L,0)/group.length,speed:group.reduce((a,t)=>a+t.rate,0)/group.length,signature:fingerprint(group),trials:group};});
 }
 metrics(z){return {reward:z.reward,mean:z.mean,passes:z.passes,ladder:z.ladder,speed:z.speed,signature:z.signature}}
 async assess(g,kind='val',n=8){const cases=await this.cases(kind,0,n);return (await this.evaluate([g],cases))[0]}
 addChamp(g,stats,origin){const s=this.state,ch={id:this.nextId++,genome:cloneG(g),stats:this.metrics(stats),origin,stage:s.stage,round:s.round};if(!s.archive.length){s.archive.push(ch);return true}
  const arr=s.archive,top=arr[0],near=arr.map((p,i)=>({i,d:sigDist(p.stats.signature,ch.stats.signature)})).sort((a,b)=>a.d-b.d)[0];
  if(near.d<.035){if(ch.stats.reward>arr[near.i].stats.reward+.005){arr[near.i]=ch;arr.sort((a,b)=>b.stats.reward-a.stats.reward);return true}return false}
  if(ch.stats.reward<top.stats.reward-(s.cfg.diversity?0.5:.10))return false;
  if(arr.length<s.cfg.pool){arr.push(ch);arr.sort((a,b)=>b.stats.reward-a.stats.reward);return true}
  const utility=x=>x.stats.reward+(s.cfg.diversity?.16*Math.min(...arr.filter(y=>y!==x).map(y=>sigDist(x.stats.signature,y.stats.signature))):0);
  let worst=1;for(let i=2;i<arr.length;i++)if(utility(arr[i])<utility(arr[worst]))worst=i;
  if(utility(ch)>utility(arr[worst])+.003){arr[worst]=ch;arr.sort((a,b)=>b.stats.reward-a.stats.reward);return true}
  return false
 }
 async stepLearning(g,epoch,{dirs,starts}={}){
  const s=this.state,c=s.cfg,dimensions=trainableIndices({plastic:c.plastic,tone:s.stage>=3,shortcuts:c.shortcuts}),rand=prng(this.seed()),sigma=.15,eta=.075;
  const samples=[],genomes=[];for(let i=0;i<(dirs??c.dirs);i++){
    const d=dimensions.map(()=>randNorm(rand)),p=g.slice(),n=g.slice();for(let j=0;j<dimensions.length;j++){p[dimensions[j]]+=sigma*d[j];n[dimensions[j]]-=sigma*d[j]}samples.push(d);genomes.push(p,n)
  }
  const suite=await this.cases('train',epoch,starts??c.starts),results=await this.evaluate(genomes,suite,{train:true});
  const entries=samples.map((d,i)=>({d,up:results[i*2].reward,down:results[i*2+1].reward,best:Math.max(results[i*2].reward,results[i*2+1].reward)}));
  entries.sort((a,b)=>b.best-a.best);const chosen=entries.slice(0,Math.max(1,Math.floor(entries.length/2)));
  const av=chosen.flatMap(x=>[x.up,x.down]),mean=av.reduce((a,b)=>a+b,0)/av.length,std=Math.sqrt(av.reduce((a,b)=>a+(b-mean)**2,0)/av.length);
  const target=g.slice();for(let i=0;i<dimensions.length;i++){
    let grad=0;for(const item of chosen)grad+=(item.up-item.down)*item.d[i];
    target[dimensions[i]]=clamp(target[dimensions[i]]+clamp((eta/(chosen.length*Math.max(.05,std)))*grad,-.12,.12),-6,6)
  }
  s.lastDelta=chosen.reduce((a,b)=>a+Math.abs(b.up-b.down),0)/chosen.length;s.lastTraining=Math.max(...entries.map(z=>z.best));
  return target
 }
 async maybePromote(){const s=this.state,a=s.archive[0];if(!a)return;
  const tests=await this.assess(a.genome,'val',12);s.gate={stage:s.stage,round:s.round,mean:tests.mean,passes:tests.passes,ladder:tests.ladder,speed:tests.speed};
  if((s.stage===0&&tests.passes.posture>=s.cfg.gate)||(s.stage===1&&tests.passes.footfalls>=s.cfg.gate)||(s.stage===2&&tests.passes.distance>=s.cfg.gate)){
    const stage=s.stage;s.hall.push(...s.archive.map(ch=>({...ch,genome:ch.genome.slice()})));if(s.hall.length>60)s.hall.splice(0,s.hall.length-60);
    s.stage++;const transferred=s.archive.map(c=>c.genome.slice());s.archive=[];
    // Scores are stage-specific; every transfer is reassessed under the new rung.
    for(const genome of transferred){const test=await this.assess(genome,'val',8);this.addChamp(genome,test,'transferred')}
    s.brain=s.archive[0]?.genome.slice()||transferred[0];s.fullGate=s.stage===3;this.log(`PROMOTED ${['posture','footfalls','distance','stiffness'][s.stage]}: previous-stage gate ${Math.round(100*tests.passes[RUNG_ORDER[Math.min(stage,2)]])}%`)
  }
 }
 async rewire(){const s=this.state;if(!s.cfg.rewiring||!s.archive.length)return;const parent=s.archive[Math.floor(this.rng()*Math.min(s.archive.length,3))],attempt=rewireContinuous(parent.genome,()=>this.rng(),{all:false});if(!attempt)return;
  s.rewires++;let child=attempt.genome;for(let j=0;j<3;j++)child=await this.stepLearning(child,s.round*23+j,{dirs:2,starts:1});
  const z=await this.assess(child,'val',8);if(this.addChamp(child,z,`rewire N${attempt.cell}.${attempt.slot}`)){s.rewireWins++;this.log(`New wiring admitted: N${attempt.cell} input ${attempt.slot}`)}
 }
 async oneRound(){const s=this.state;s.brain=await this.stepLearning(s.brain,s.round);s.round++;
  if(s.round%20===0){s.block++;const z=await this.assess(s.brain,'val',8);this.addChamp(s.brain,z,'reward learning');
    if(s.block%2===0)await this.rewire();await this.maybePromote();if(s.archive.length){const choice=this.rng()<.72?0:Math.floor(this.rng()*s.archive.length);s.brain=s.archive[choice].genome.slice()}
    s.curve.push({round:s.round,stage:s.stage,score:s.archive[0]?.stats.reward??z.reward,ladder:s.archive[0]?.stats.ladder??z.ladder,posture:s.gate?.passes?.posture??0,footfalls:s.gate?.passes?.footfalls??0});if(s.curve.length>1000)s.curve.shift();this.save()
  }
 }
 start({fresh=false,cfg={}}={}){if(this.active||this.busy)fail('A run is already active or a previous batch is finishing');if(fresh||!this.state)this.fresh(cfg);
  const s=this.state;if(s.round>=s.cfg.rounds)s.cfg.rounds+=s.cfg.refill;
  s.mode='running';this.busy=true;this.active=true;this.error=null;
  this.promise=(async()=>{
    try{await this.plantReady();if(!s.archive.length){const baseline=await this.assess(s.brain,'val',8);this.addChamp(s.brain,baseline,'untrained baseline');this.log(`Baseline measured: ladder ${baseline.ladder.toFixed(3)}, posture ${Math.round(100*baseline.passes.posture)}%. No learning claim from default muscle tone.`);this.save()}while(this.busy&&s.round<s.cfg.rounds){await this.oneRound();await new Promise(r=>setImmediate(r));if(this.busy&&s.round>=s.cfg.rounds&&s.cfg.autoFuel){s.cfg.rounds+=s.cfg.refill;this.log('Automatic refuel '+s.cfg.refill)}}
      if(s.mode==='running'){s.mode=s.round>=s.cfg.rounds?'complete':'paused'}
    }catch(e){this.error=e.stack||e.message;s.mode='error';this.log('ERROR '+e.message)}finally{this.busy=false;this.active=false;this.save()}
  })();return this.status()
 }
 pause(){if(this.state){this.busy=false;this.state.mode='paused'}this.save();return this.status()}
 fuel(amount){const s=this.state;if(!s)fail('Start an experiment first');amount=clamp(Math.floor(Number(amount)||s.cfg.refill),1,500000);s.cfg.rounds=Math.max(s.cfg.rounds,s.round)+amount;this.log(`Refuel +${amount} rounds`);this.save();return this.status()}
 autoFuel(yes){if(!this.state)fail('Start an experiment first');this.state.cfg.autoFuel=!!yes;this.save();return this.status()}
 async benchmark(){if(!this.state||this.busy)fail('Pause to run an independent benchmark');const s=this.state,g=s.archive[0]?.genome||s.brain;
  // Different seed from both fixed validation and historical holdout; each call new.
  const seed=s.cfg.seed+0x55a102+9973*++s.independentTests;const p=await this.plantReady();const suite=p.trainingSuite(seed,90000+s.independentTests,{trainCases:24,trainSeconds:s.cfg.seconds,difficulty:1});
  const z=(await this.evaluate([g],suite))[0];s.independent={round:s.round,stage:s.stage,seed,ladder:z.ladder,mean:z.mean,passes:z.passes,speed:z.speed};this.save();return s.independent
 }
 async replay(){if(!this.state||this.busy)fail('Pause to replay');const g=this.state.archive[0]?.genome||this.state.brain,p=await this.plantReady(),suite=await this.cases('val',0,1);return await p.replay(g,suite[0],{stride:5,tone:this.state.stage>=3})}
 status(){const s=this.state;if(!s)return {exists:false,busy:this.busy,events:this.events.slice(-30)};
  return {exists:true,busy:this.busy,active:this.active,mode:s.mode,cfg:s.cfg,stage:s.stage,rung:this.stageName(),round:s.round,block:s.block,spent:s.spent,rollouts:s.rollouts,gate:s.gate,fullGate:s.fullGate,rewires:s.rewires,rewireWins:s.rewireWins,lastDelta:s.lastDelta,lastTraining:s.lastTraining,independent:s.independent||null,archive:s.archive.map(c=>({id:c.id,stage:c.stage,round:c.round,origin:c.origin,...c.stats,signature:undefined})),hallCount:s.hall.length,curve:s.curve,events:this.events.slice(-35),error:this.error,brain:inspectContinuous(s.brain)}
 }
 biopsy(){const s=this.state;if(!s)return 'No Protoneuron experiment yet';const c=s.archive[0],g=c?.genome||s.brain;return JSON.stringify({title:'PROTONEURON WALKER V11 BX',date:new Date().toISOString(),mode:s.mode,round:s.round,stage:s.stage,settings:s.cfg,metrics:c?.stats||null,connections:Array.from({length:100},(_,i)=>Array.from({length:3},(_,k)=>({src:g[10+i*3+k],weight:Number(g[310+i*3+k].toFixed(4))}))),decoder:Array.from(g.slice(610,770)),counts:inspectContinuous(g)},null,2)}
 serialize(){const s=this.state;if(!s)return null;return {...s,brain:Array.from(s.brain),best:Array.from(s.best),archive:s.archive.map(c=>({...c,genome:Array.from(c.genome)})),hall:s.hall.map(c=>({...c,genome:Array.from(c.genome)})),events:this.events,nextId:this.nextId}}
 save(){if(!this.state)return null;fs.mkdirSync(this.dataDir,{recursive:true});const tmp=this.file+'.tmp';fs.writeFileSync(tmp,JSON.stringify(this.serialize()));fs.renameSync(tmp,this.file);return this.file}
 restore(obj){if(this.busy||this.active)fail('Pause and let the current batch finish before importing');if(obj?.format!=='protoneuron-walker-v11'||obj.version!==1)fail('Expected a v11 continuous-learning checkpoint');
  const brain=Float64Array.from(obj.brain);if(!isContinuous(brain))fail('Invalid v11 checkpoint brain');const archive=(obj.archive||[]).map(c=>({...c,genome:Float64Array.from(c.genome)})),hall=(obj.hall||[]).map(c=>({...c,genome:Float64Array.from(c.genome)}));
  if([...archive,...hall].some(c=>!isContinuous(c.genome)))fail('Invalid champion genome');const cfg=this.config(obj.cfg);if(!Number.isInteger(obj.stage)||obj.stage<0||obj.stage>3||!Number.isInteger(obj.round)||obj.round<0)fail('Checkpoint stage or round invalid');this.state={...obj,cfg,brain,best:isContinuous(Float64Array.from(obj.best||[]))?Float64Array.from(obj.best):brain.slice(),archive,hall,mode:'paused'};
  this.events=(obj.events||[]).slice(-120);this.nextId=Math.max(Number(obj.nextId)||1,1,...archive.map(c=>c.id+1),...hall.map(c=>c.id+1));this.error=null;this.save();return this.status()
 }
 loadLocal(){if(fs.existsSync(this.file))try{const obj=JSON.parse(fs.readFileSync(this.file,'utf8'));this.restore(obj);this.log('Restored v11 checkpoint, paused.')}catch(e){this.error='Checkpoint not loaded: '+e.message}}
 async close(){this.pause();await this.promise?.catch(()=>{});await this.plant?.close()}
}
