/* rig/core/rng.mjs — the same mulberry32 generator the lab and the engine use. */
export function hash32(x){x=(x+0x9E3779B9)>>>0;x=Math.imul(x^(x>>>16),0x85EBCA6B)>>>0;x=Math.imul(x^(x>>>13),0xC2B2AE35)>>>0;return (x^(x>>>16))>>>0}
export class Rng{
  constructor(seed){this.rngState=(seed>>>0)||1}
  next(){let a=this.rngState>>>0;a=(a+0x6D2B79F5)>>>0;this.rngState=a;let t=Math.imul(a^(a>>>15),1|a);t=(t+Math.imul(t^(t>>>7),61|t))^t;return ((t^(t>>>14))>>>0)/4294967296}
  int(n){return Math.floor(this.next()*n)}
  pick(a){return a[Math.floor(this.next()*a.length)]}
}
/* The lab's function-style PRNG (protoneuron-champion-lab-v12.html), kept so the
 * pendulum case suites are exactly the lab's. Same arithmetic as Rng. */
export function PRNG(seed){let s=(seed>>>0)||1;return()=>{s=(s+0x6D2B79F5)>>>0;let t=s;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296}}
export function seedFor(root,role,k=0){let s=hash32((root>>>0)^Math.imul(k+1,0x9E3779B1));for(const c of String(role))s=hash32(s^c.charCodeAt(0));return s}
