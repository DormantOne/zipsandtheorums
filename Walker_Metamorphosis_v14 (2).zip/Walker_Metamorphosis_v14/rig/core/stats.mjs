/* rig/core/stats.mjs — the few statistics the rig relies on, written out so
 * every verdict can be traced to a formula. */
export const mean=a=>a.length?a.reduce((s,x)=>s+x,0)/a.length:NaN;
export function variance(a){const n=a.length;if(n<2)return NaN;const m=mean(a);let s=0;for(const x of a)s+=(x-m)*(x-m);return s/(n-1)}
export const sd=a=>Math.sqrt(variance(a));
/* Linear-interpolation quantile, identical to engine/utils.mjs quantile(). */
export function quantile(xs,p){const a=xs.map(Number).sort((x,y)=>x-y);if(!a.length)return NaN;const pos=(a.length-1)*p,lo=Math.floor(pos),hi=Math.ceil(pos);return lo===hi||a[lo]===a[hi]?a[lo]:a[lo]+(a[hi]-a[lo])*(pos-lo)}
export const median=a=>quantile(a,.5);

// ── Student t, via the regularized incomplete beta function ────────────────
function lnGamma(z){const g=7,c=[0.99999999999980993,676.5203681218851,-1259.1392167224028,771.32342877765313,-176.61502916214059,12.507343278686905,-0.13857109526572012,9.9843695780195716e-6,1.5056327351493116e-7];
  if(z<.5)return Math.log(Math.PI/Math.sin(Math.PI*z))-lnGamma(1-z);z-=1;let x=c[0];for(let i=1;i<g+2;i++)x+=c[i]/(z+i);const t=z+g+.5;return .5*Math.log(2*Math.PI)+(z+.5)*Math.log(t)-t+Math.log(x)}
function betacf(a,b,x){const MAXIT=300,EPS=3e-14,FPMIN=1e-300;let qab=a+b,qap=a+1,qam=a-1,c=1,d=1-qab*x/qap;if(Math.abs(d)<FPMIN)d=FPMIN;d=1/d;let h=d;
  for(let m=1;m<=MAXIT;m++){const m2=2*m;let aa=m*(b-m)*x/((qam+m2)*(a+m2));d=1+aa*d;if(Math.abs(d)<FPMIN)d=FPMIN;c=1+aa/c;if(Math.abs(c)<FPMIN)c=FPMIN;d=1/d;h*=d*c;
    aa=-(a+m)*(qab+m)*x/((a+m2)*(qap+m2));d=1+aa*d;if(Math.abs(d)<FPMIN)d=FPMIN;c=1+aa/c;if(Math.abs(c)<FPMIN)c=FPMIN;d=1/d;const del=d*c;h*=del;if(Math.abs(del-1)<EPS)break}
  return h}
export function betaInc(x,a,b){if(x<=0)return 0;if(x>=1)return 1;const bt=Math.exp(lnGamma(a+b)-lnGamma(a)-lnGamma(b)+a*Math.log(x)+b*Math.log(1-x));
  return x<(a+1)/(a+b+2)?bt*betacf(a,b,x)/a:1-bt*betacf(b,a,1-x)/b}
export function tCdf(t,df){if(!Number.isFinite(t))return t>0?1:0;const x=df/(df+t*t),ib=betaInc(x,df/2,.5);return t>=0?1-.5*ib:.5*ib}
export function tQuantile(p,df){if(p<=0)return -Infinity;if(p>=1)return Infinity;let lo=-1e3,hi=1e3;for(let i=0;i<200;i++){const m=(lo+hi)/2;if(tCdf(m,df)<p)lo=m;else hi=m}return (lo+hi)/2}

/* Mean of a sample with a two-sided t interval at `level`. */
export function meanCI(xs,level=.95){
  const n=xs.length,m=mean(xs);if(n<2)return {n,mean:m,sd:NaN,se:NaN,lo:-Infinity,hi:Infinity,t:NaN,p:NaN};
  const s=sd(xs),se=s/Math.sqrt(n),q=tQuantile(1-(1-level)/2,n-1),t=se>0?m/se:(m===0?0:Math.sign(m)*Infinity);
  const p=se>0?2*(1-tCdf(Math.abs(t),n-1)):(m===0?1:0);
  return {n,mean:m,sd:s,se,lo:m-q*se,hi:m+q*se,t,p};
}
export function bootstrap(xs,stat,{B=2000,rng,level=.9}={}){
  const n=xs.length,out=[];if(!n)return {lo:NaN,hi:NaN,dist:[]};
  for(let b=0;b<B;b++){const r=new Array(n);for(let i=0;i<n;i++)r[i]=xs[Math.floor(rng.next()*n)];out.push(stat(r))}
  const fin=out.filter(Number.isFinite).sort((a,b)=>a-b),a=(1-level)/2;
  return {lo:fin.length?fin[Math.floor(fin.length*a)]:Infinity,hi:fin.length?fin[Math.min(fin.length-1,Math.floor(fin.length*(1-a)))]:Infinity,
    censoredFrac:(out.length-fin.length)/out.length,dist:fin};
}
export function spearman(a,b){
  const rank=v=>{const idx=v.map((x,i)=>[x,i]).sort((p,q)=>p[0]-q[0]),r=new Array(v.length);let i=0;
    while(i<idx.length){let j=i;while(j+1<idx.length&&idx[j+1][0]===idx[i][0])j++;const avg=(i+j)/2+1;for(let k=i;k<=j;k++)r[idx[k][1]]=avg;i=j+1}return r};
  const ra=rank(a),rb=rank(b),ma=mean(ra),mb=mean(rb);let num=0,da=0,db=0;
  for(let i=0;i<a.length;i++){num+=(ra[i]-ma)*(rb[i]-mb);da+=(ra[i]-ma)**2;db+=(rb[i]-mb)**2}
  return da>0&&db>0?num/Math.sqrt(da*db):NaN;
}
/* The paper's compute-to-half-solved (Appendix H): the ceil(n/2)-th smallest
 * crossing, censored seeds entered as Infinity. Exact under right-censoring
 * as long as more than half the seeds cross. */
export function halfSolved(vals){const s=vals.slice().sort((a,b)=>a-b);return s[Math.ceil(s.length/2)-1]}
export function holm(ps){const idx=ps.map((p,i)=>[p,i]).sort((a,b)=>a[0]-b[0]),adj=new Array(ps.length);let run=0;
  idx.forEach(([p,i],k)=>{run=Math.max(run,Math.min(1,(ps.length-k)*p));adj[i]=run});return adj}
/* Least-squares slope of y on log2(x), the "gain per doubling" of a curve. */
export function slopePerDoubling(xs,ys){const lx=xs.map(x=>Math.log2(x)),mx=mean(lx),my=mean(ys);let n=0,d=0;for(let i=0;i<xs.length;i++){n+=(lx[i]-mx)*(ys[i]-my);d+=(lx[i]-mx)**2}return d>0?n/d:NaN}
