/* rig/core/tuner.mjs — the KG's settings tuner (v9.3).
 * One experiment at a time: one setting, the current value against a
 * neighbouring one, in four windows of windowGens generations ordered ABBA
 * (old, new, new, old), so a run that naturally slows down biases neither.
 * Each window is scored per billion physics steps (so a costlier setting pays
 * for its cost): the champion's ladder gain on the fixed validation suite, and,
 * when the champion does not move, the archive's total quality gain. The new
 * value is adopted only if it beats the old by 10 %; otherwise the old stays.
 * Choices come from a ledger of past outcomes (Thompson sampling), saved and
 * carried over between runs. A plateau trial of the governor takes precedence:
 * the tuner stops its experiment and restores the old value.
 *
 * v10.0.1, against noise. One run's windows carry seed-scale noise: identical
 * settings on different seeds differ by 2x, and a plateaued champion moves in
 * single small steps. So a new value is adopted only if it wins BOTH halves of
 * the test -- window 2 against window 1 and window 3 against window 4 -- as
 * well as the total, on the same measure. One lucky improvement can no longer
 * carry a test. And no test starts while the run is still climbing steeply
 * (progress over the last window above 2 % of its level), because a front-
 * loaded climb is not the linear drift that the old-new-new-old order cancels. */
export const TUNABLE=Object.freeze({earlyExit:[true,false],lambda:[12,16,20,24],peaks:[3,4,6],escapePct:[10,20,30],trainCases:[6,8,12],separation:['wiring','gait','both']});
export const TUNABLE_LABEL={earlyExit:'stop fallen trials early',lambda:'candidates per generation',peaks:'peaks',escapePct:'escape probes %',trainCases:'training trials',separation:'peaks must differ in'};
const BASIN_ONLY=new Set(['peaks','escapePct','separation']);
export class Tuner{
  constructor({ledger=null,windowGens=500,margin=.1}={}){
    /* saved as {ledger, adopted} since v9.3.1 (v9.3.0 saved the ledger alone) */
    const sv=ledger;this.adopted=sv&&sv.ledger?{...(sv.adopted||{})}:{};ledger=sv&&sv.ledger?sv.ledger:sv;this.ledger=ledger||{};this.windowGens=windowGens;this.margin=margin;this.exp=null;this.log=[];this.trail=[];this.climbTol=.02;this.waitNoted=false}
  /* progress over the last window, tracked on every row; still climbing steeply?
   * (no full window of history yet counts as climbing) */
  track(m){this.trail.push({gen:m.gen,best:m.best});while(this.trail.length>1&&this.trail[1].gen<=m.gen-this.windowGens)this.trail.shift()}
  climbing(m){
    const first=this.trail[0];if(!first||m.gen-first.gen<this.windowGens)return true;
    return m.best-first.best>this.climbTol*Math.max(Math.abs(m.best),1e-6);
  }
  note(g,text){this.log.push({generation:g,text});if(this.log.length>120)this.log.shift()}
  choose(run){
    const opts=[];for(const [k,vals] of Object.entries(TUNABLE)){if(BASIN_ONLY.has(k)&&run.cfg.search!=='basin')continue;
      const i=vals.indexOf(run.cfg[k]);for(const v of i<0?vals:[vals[i-1],vals[i+1]])if(v!==undefined&&v!==run.cfg[k])opts.push([k,v])}
    let best=null,bv=-1;for(const [k,v] of opts){const L=this.ledger[`${k}=${v}`]||{tries:0,wins:0},s=beta(run.rng,L.wins+1,L.tries-L.wins+1);if(s>bv){bv=s;best=[k,v]}}
    return best;
  }
  /* v9.3.1: scored by walking quality: the champion and the mean of the top 8 elites (not the whole archive, which rewards filling new cells) */
  measure(run){const top=(run.archive.ranked?run.archive.ranked():[...run.archive.cells.values()].sort((a,b)=>b.quality-a.quality)).slice(0,8),qd=top.length?top.reduce((a,e)=>a+e.quality,0)/top.length:0;
    return {gen:run.generation,spent:run.spent,best:run.progress?run.progress():(run.archive.best()?.quality??0),qd}}
  /* the KG remembers what it adopted: applied to every new run */
  applyAdopted(run){const done=[];for(const [k,v] of Object.entries(this.adopted||{}))if(k in TUNABLE&&run.cfg[k]!==v){run.cfg[k]=v;done.push(`${k} ${v}`)}
    if(done.length)this.note(run.generation,`applied the KG's earlier adoptions: ${done.join(', ')}`);return done}
  set(run,k,v){run.cfg[k]=v;if(k==='trainCases')run.epoch=-1;if(k==='earlyExit')run.cfg.trainEarlyExit=v?{nonfootSeconds:1,mode:'cumulative'}:null}             // new trial set at the next generation
  onRow(run){
    const now=this.measure(run);this.track(now);
    if(!this.exp){if(this.climbing(now)){if(!this.waitNoted&&run.generation>=this.windowGens){this.waitNoted=true;this.note(run.generation,'waiting to test settings: the champion is still climbing steeply')}return}
      this.waitNoted=false;const pick=this.choose(run);if(!pick)return;const [k,v]=pick;
      this.exp={k,old:run.cfg[k],nu:v,order:['old','new','new','old'],w:0,start:this.measure(run),scores:[]};
      this.note(run.generation,`testing ${TUNABLE_LABEL[k]}: ${this.exp.old} against ${v}, in 4 windows of ${this.windowGens} generations (old, new, new, old)`);return}
    const e=this.exp;if(run.generation-e.start.gen<this.windowGens)return;
    const m=this.measure(run),bil=Math.max(1e-9,(m.spent-e.start.spent)/1e9);
    e.scores.push({arm:e.order[e.w],best:(m.best-e.start.best)/bil,qd:(m.qd-e.start.qd)/bil});e.w++;
    if(e.w<e.order.length){e.start=m;this.set(run,e.k,e.order[e.w]==='new'?e.nu:e.old);return}
    const sum=(a,f)=>e.scores.filter(s=>s.arm===a).reduce((x,s)=>x+s[f],0),nb=sum('new','best'),ob=sum('old','best'),nq=sum('new','qd'),oq=sum('old','qd');
    const beats=(n,o)=>n>o+this.margin*Math.abs(o)+1e-9,f=Math.abs(nb-ob)>1e-6?'best':'qd',W=e.scores;
    const halves=[beats(W[1][f],W[0][f]),beats(W[2][f],W[3][f])],total=f==='best'?beats(nb,ob):beats(nq,oq),win=total&&halves[0]&&halves[1];
    const why=win?'won both halves':total?`won the total but only ${halves.filter(Boolean).length} of 2 halves`:'did not win the total';
    const L=(this.ledger[`${e.k}=${e.nu}`]??={tries:0,wins:0});L.tries++;if(win)L.wins++;
    this.set(run,e.k,win?e.nu:e.old);if(win)this.adopted[e.k]=e.nu;
    this.note(run.generation,`${TUNABLE_LABEL[e.k]} ${e.nu} ${win?'WON and is adopted':`did not win; ${e.old} kept`} (${why}, on ${f==='best'?'champion gain':'top-8 gain'}) — champion gain per billion steps ${fmt(nb)} against ${fmt(ob)}, top-8 walkers gain ${fmt(nq)} against ${fmt(oq)} (record ${L.wins} of ${L.tries})`);
    this.exp=null;return win;
  }
  start(run){if(this.exp&&this.exp.w===0&&this.exp.order[0]==='old')return;}             // (the first window runs the old value: nothing to set)
  abort(run,why){if(!this.exp)return;this.set(run,this.exp.k,this.exp.old);this.note(run.generation,`stopped the test of ${TUNABLE_LABEL[this.exp.k]}: ${why}; ${this.exp.old} restored`);this.exp=null}
  snapshot(){const e=this.exp;return {adopted:this.adopted,experiment:e?{setting:TUNABLE_LABEL[e.k],key:e.k,old:e.old,new:e.nu,window:e.w+1,of:e.order.length,arm:e.order[e.w],since:e.start.gen}:null,ledger:this.ledger,windowGens:this.windowGens,log:this.log.slice(-30)}}
}
const fmt=x=>Number.isFinite(x)?x.toFixed(4):'—';
function beta(rng,a,b){const x=gamma(rng,a),y=gamma(rng,b);return x/(x+y)}
function gamma(rng,k){if(k<1)return gamma(rng,k+1)*Math.pow(Math.max(1e-12,rng.next()),1/k);const d=k-1/3,c=1/Math.sqrt(9*d);
  for(;;){let x,v;do{x=Math.sqrt(-2*Math.log(Math.max(1e-12,rng.next())))*Math.cos(2*Math.PI*rng.next());v=1+c*x}while(v<=0);v=v*v*v;const u=rng.next();if(u<1-.0331*x**4||Math.log(u)<.5*x*x+d*(1-v+Math.log(v)))return d*v}}
