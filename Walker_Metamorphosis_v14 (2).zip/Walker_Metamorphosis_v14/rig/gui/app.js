import * as THREE from 'three';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
const $=id=>document.getElementById(id),num=(v,d=0)=>Number.isFinite(Number(v))?Number(v):d;
const fx=(v,d)=>Number.isFinite(Number(v))&&v!==null?Number(v).toFixed(d):'—',pct=v=>Number.isFinite(Number(v))&&v!==null?(100*v).toFixed(0)+'%':'—';
let S=null,replay=null,lastReplayId=0,playing=false,frameIx=0,lastFrameT=0,knobsBuilt=false;

function drawMetamorphosis(H){
  const esc=v=>String(v??'—').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const lines=(H.lineages||[]).slice().sort((a,b)=>(b.quality||0)-(a.quality||0));
  $('metaLineageRows').innerHTML=lines.length?lines.map(t=>`<tr><td>L${t.lineageId} (#${esc(t.id)})</td><td>${esc(t.origin)}</td><td>${t.visits||0}</td><td>${t.updates||0}</td><td>${fx(t.quality,4)}</td></tr>`).join(''):'<tr><td colspan="5">Awaiting continuous learners…</td></tr>';
  const babies=H.nursery||[];
  $('metaNurseryRows').innerHTML=babies.length?babies.slice().sort((a,b)=>b.quality-a.quality).map(n=>`<tr><td>#${n.id} · depth ${n.depth}</td><td>L${n.lineageId}</td><td>${n.attempts}/${S.cfg.hybridNurseryTrials}</td><td>${n.wins} ${n.wins?'✓':''}</td><td>${fx(n.quality,4)}</td></tr>`).join(''):'<tr><td colspan="5">No ternary offspring currently in the nursery.</td></tr>';
  const history=H.history||[];
  $('metaHistoryRows').innerHTML=history.length?history.slice(-35).reverse().map(t=>`<tr><td>${t.cycle}</td><td>L${t.lineageId}</td><td>${fx(t.before,4)}</td><td>${fx(t.after,4)}</td><td>${fx(t.strict,4)}</td><td>${fx(t.holdContinuous,4)}</td><td>${fx(t.holdStrict,4)}</td><td>${t.admitted||0}</td></tr>`).join(''):'<tr><td colspan="8">Awaiting first completed learning window.</td></tr>';
  const chart=(id,points,series,yMax=3)=>{
    const svg=$(id),W=640,HH=270,L=42,R=625,T=15,B=230;let code=`<rect width="640" height="270" fill="#091522"/>`;
    const safeMax=Math.max(1,yMax),x=i=>L+(R-L)*(points.length<=1?.5:i/(points.length-1)),y=v=>B-(B-T)*Math.min(safeMax,Math.max(0,v||0))/safeMax;
    for(let i=0;i<=3;i++){let q=i*safeMax/3,yy=y(q);code+=`<line x1="${L}" y1="${yy}" x2="${R}" y2="${yy}" stroke="#29415f" stroke-dasharray="3 6"/><text x="7" y="${yy+4}" fill="#9fb1c8" font-size="11">${q.toFixed(2)}</text>`}
    code+=`<text x="${R}" y="255" fill="#9fb1c8" text-anchor="end" font-size="11">${points.length} record(s)</text>`;
    for(const s of series){let d='';points.forEach((p,i)=>{const v=p[s.key];if(Number.isFinite(v))d+=(d?' L ':'M ')+x(i).toFixed(1)+' '+y(v).toFixed(1)});code+=`<path d="${d}" fill="none" stroke="${s.color}" stroke-width="2.8"/>`;}
    series.forEach((s,i)=>{code+=`<rect x="${L+i*175}" y="5" width="10" height="7" fill="${s.color}"/><text x="${L+i*175+14}" y="12" fill="#c6d5e5" font-size="11">${s.name}</text>`});
    if(!points.length)code+='<text x="320" y="135" text-anchor="middle" fill="#91acbd" font-size="14">Waiting for completed learning cycles</text>';
    svg.innerHTML=code;
  };
  chart('metaQualityChart',history.slice(-70),[{key:'before',name:'Entered learning',color:'#86a5ed'},{key:'after',name:'Best learned',color:'#69e0ae'},{key:'strict',name:'Ternary offspring',color:'#efc272'}]);
  const events=(H.events||[]).filter(e=>['nursery-birth','nursery-improve','nursery-promote','nursery-retire'].includes(e.kind));
  const series=events.map(e=>({born:e.offspringBorn??0,improved:e.offspringImproved??0,promoted:e.offspringPromoted??0}));
  const counts={born:H.counts?.nurseryBorn||series.at(-1)?.born||0,improved:H.counts?.nurseryMatured||0,promoted:H.counts?.nurseryPromoted||0};
  chart('metaNurseryChart',series,[{key:'born',name:'Offspring',color:'#86a5ed'},{key:'improved',name:'Improved',color:'#69e0ae'},{key:'promoted',name:'Promoted',color:'#efc272'}],Math.max(2,counts.born));
}

// ── settings (grouped like the pendulum lab) ────────────────────────────────
const GROUPS=[
 ['Metamorphosis · three-stage cycle',[['hybridAuto','Automatically switch stages',0,1,1],['hybridEvoGens','Evolution generations per window',1,10000,1],['hybridLearnSteps','Total learning updates per window',1,10000,1],['hybridTracks','Diverse champions to learn',1,6,1],['hybridCases','MuJoCo training starts per update',1,4,1],['hybridValEvery','Validation cadence per heir',1,100,1],['hybridRotate','New training scenarios every updates',1,100,1],['hybridRate','Continuous learning step',.001,.5,.001],['hybridSigma','Symmetric perturbation size',.005,.8,.005],['hybridBias','Unlock neuron biases',0,1,1],['hybridNurseryCap','Max ternary offspring in nursery',3,48,1],['hybridNurseryTrials','Nursery mutation trials per offspring',2,200,1],['hybridLineageCap','Max persistent continuous lineages',8,32,1]]],
 ['Brain and population',[['brain','Brain model',['strictFixed']],['joints','Joints',['muscles','servo','torque']],['friction','Friction',['firm','legacy']],['N','Cells',8,1024,8],['voters','Votes per motor',1,24,1],['ticks','Brain ticks / 20 ms step',1,40,1],['internalPct','Internal cells %',0,90,1],['tonicPct','Tonic cells %',0,30,1],['mixedSizes','Mixed sizes (½× to 4×)',0,1,1],['maxCells','Max cells',8,1024,8],['seed','Seed',0,4294967295,1],['founders','Founders',1,128,1],['lambda','Candidates/gen',1,64,1],['immigrants','Immigrants',0,16,1],['immigrantEvery','Immigrants every',1,500,1]]],
 ['Search and mutation strategy',[['basin','Basin search (off = champion climber)',0,1,1],['peaks','Peaks K',1,8,1],['separation','Peaks must differ in',['gait','wiring','both']],['escapePct','Escape probes %',0,50,1],['bandit','Bandit picks mutations, crossover, grow/shrink (and parent when climbing)',0,1,1],['mutations','Mutations/candidate',1,64,1],['strongEvery','Strong jump every',0,500,1],['focus','Mutate read cells %',0,100,1],['sensorBias','Rewire to sensors %',0,100,1],['silenceOdds','Silence odds %',0,100,1],['crossPct','Crossover %',0,100,1]]],
 ['Fitness and cycled curriculum',[['selection','Fitness',['curriculum','distance']],['distanceFloor','Cleanest-walker floor (cm/s)',0,20,0.5],['worstWeight','Worst-trial weight %',0,300,5],['passShare','Advance at % passing',10,100,5],['distanceGens','Gens on distance / cycle',10,5000,10],['earlyExit','Stop fallen trials (1 s)',0,1,1],['trainCases','Training trials',1,32,1],['trainSeconds','Trial seconds',2,20,0.5],['rotate','Rotate trials every',0,500,1],['valCases','Validation trials',4,128,1],['holdCases','Holdout trials',4,128,1],['valEvery','Validate every',1,50,1]]],
 ['Champion feeds and archive',[['poolSize','Champion pool',1,24,1],['threshold','Revisit threshold',5,1000,1],['revisitPct','Parent from champions %',0,100,1],['archivePct','…of those, archive %',0,100,1],['selExp','Selection exponent',.3,8,.1],['bins','Bins per axis',2,10,1],['archiveCap','Archive cap',8,400,1],['poolMinDiff','Min wiring differences',0,200,1],['governor','Plateau governor (KG)',0,1,1],['plateauGens','Plateau after gens',100,100000,100],['trialGens','Trial window gens',100,100000,100]]],
 ['The KG and the view',[['tuner','KG tunes settings (switchback tests)',0,1,1],['tunerWindow','KG test window (gens)',100,5000,50],['liveView','Live walker view',0,1,1],['liveEvery','Live replay every (s)',10,600,5],['mapDims','Map dimensions',2,8,1]]],
];
function buildKnobs(){
  const box=$('knobs');box.innerHTML='';const reset=new Set(S.resetKeys||[]);
  for(const [title,items] of GROUPS){
    const h=document.createElement('div');h.className='head';h.textContent=title;box.appendChild(h);
    const row=document.createElement('div');row.className='controls';
    for(const [k,label,min,max,step] of items){
      const l=document.createElement('label');if(reset.has(k))l.className='reset';l.append(label+' ');
      let i;
      if(Array.isArray(min)){i=document.createElement('select');i.innerHTML=min.map(o=>`<option value="${o}">${o}</option>`).join('');i.value=S.cfg[k];i.onchange=()=>cmd('set',{cfg:{[k]:i.value}})}
      else{i=document.createElement('input');if(typeof S.defaults[k]==='boolean'){i.type='checkbox';i.checked=!!S.cfg[k]}else{i.type='number';i.min=min;i.max=max;i.step=step;i.value=S.cfg[k]}
        i.onchange=()=>cmd('set',{cfg:{[k]:i.type==='checkbox'?i.checked:Number(i.value)}})}
      i.id='k_'+k;l.appendChild(i);row.appendChild(l);
    }
    box.appendChild(row);
  }
  knobsBuilt=true;
}

// ── server calls ────────────────────────────────────────────────────────────
async function cmd(c,args={}){
  try{const r=await fetch('/api/cmd',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({cmd:c,args})});const j=await r.json();if(!r.ok)$('status').textContent=j.error||'error';}
  catch(e){$('status').textContent='The rig server is not answering: '+e.message}
  poll();
}
async function poll(){
  try{S=await (await fetch('/api/status',{cache:'no-store'})).json()}catch(e){$('status').textContent='Waiting for the rig server… ('+e.message+')';return}
  if(!knobsBuilt)buildKnobs();
  render();
  if(S.replayId&&S.replayId!==lastReplayId){lastReplayId=S.replayId;loadReplay(await (await fetch('/api/replay',{cache:'no-store'})).json())}
}
setInterval(poll,1000);

function render(){
  drawHybrid();
  $('mode').textContent=S.mode;$('gen').textContent=S.generation;$('nCount').textContent=S.N;$('speed').textContent=fx(S.stepsPerSec/1000,0);
  $('rung').textContent=S.rung?`${S.rung} · ${S.cycle}`:'—';for(const r of ['posture','footfalls','distance'])$('r_'+r).className='rung'+(S.rung===r?' on':'');
  const c=S.champion;$('best').textContent=fx(c?.quality,3);$('bestQ').textContent=fx(c?.meanQ,4);$('slide').textContent=fx(c?.slipCm,1);
  $('cells').textContent=S.archive?.cells.length??0;$('coverage').textContent=S.archive?pct(S.archive.coverage):'0%';
  $('modeBadge').textContent=S.hybrid?.stage==='learning'?`LEARNING ${S.hybrid.stageProgress}/${S.cfg.hybridLearnSteps} · ${S.hybrid.championCount} descendants`:`${S.mode.toUpperCase()}${S.rung?' • '+S.rung:''}`;$('status').textContent=S.note||'';$('log').textContent=S.log||'';
  if(S.audit)$('auditOut').textContent=S.audit;
  $('championStatus').textContent=c?`Champions: ${S.archive.pool.length} in the pool • top #${c.id} from generation ${c.generation} • ladder ${fx(c.quality,3)} • reward of record ${fx(c.meanQ,5)} m/s • walking trials ${pct(c.walk)} • passes posture ${pct(c.pass?.posture)} footfalls ${pct(c.pass?.footfalls)} distance ${pct(c.pass?.distance)} • pool wiring spread min ${S.archive.spread.min} / mean ${fx(S.archive.spread.mean,0)}`:'Champions: 0';
  
  if(S.selection==='distance'&&c)$('championStatus').textContent+=` • distance mode: cleanest walker, injury ${fx(c.injury,2)} at ${fx(c.distRate,4)} m/s • farthest brain ${fx(S.farthest?.distRate,4)} m/s, injury ${fx(S.farthest?.injury,2)}`;
  const tr=S.mode==='train';$('pause').disabled=!tr;$('resume').disabled=S.mode!=='paused';$('test').disabled=!S.generation;$('testTop').disabled=!c;$('continue').disabled=!c;$('loadTop').disabled=!c;
  drawHistory();drawArchive();drawSelfTuning();
}
// Stage indication uses the existing graphics, never replaces or resizes them.
function drawHybrid(){
  const H=S?.hybrid||{},learning=H.stage==='learning',evolution=H.stage==='evolution';
  const tag=$('learnState');tag.textContent=learning?'● LEARNING': '● EVOLUTION';tag.className=learning?'learning':'evolution';
  $('hCycle').textContent=H.cycle||0;
  $('hUpdates').textContent=`${H.stageProgress||0} / ${S.cfg.hybridLearnSteps}`;
  $('hAccept').textContent=H.accepted||0;$('hCount').textContent=H.championCount||0;
  $('hybridBarFill').style.width=(learning?Math.min(100,100*(H.stageProgress||0)/Math.max(1,S.cfg.hybridLearnSteps)):0)+'%';
  document.querySelector('#metaEvolution')?.classList.toggle('on',!learning);
  document.querySelector('#metaLearning')?.classList.toggle('on',learning);
  document.querySelector('#metaNursery')?.classList.toggle('on',!!H.counts?.nursery);
  $('mLineages').textContent=H.counts?.lineages||0;$('mNursery').textContent=H.counts?.nursery||0;
  $('mMature').textContent=H.counts?.nurseryMatured||0;$('mPromote').textContent=H.counts?.nurseryPromoted||0;
  drawMetamorphosis(H);
  const n=H.tracks?.length||0;
  $('hybridTrackRows').innerHTML=n?H.tracks.map((t,i)=>`<tr><td style="color:${i===H.active&&learning?'#7ee9cd':'#eaf3ff'}">#${t.id} / L${t.lineageId} · ${t.origin}</td><td>${t.updates}</td><td>${fx(t.original,3)}</td><td style="color:#7ee9cd">${fx(t.quality,3)}</td><td>${t.accepted}</td><td>${t.projection?fx(t.projection.quality,3)+(t.projection.admitted?' ✓':' –'):'not yet'}</td></tr>`).join(''):'<tr><td colspan="6" style="text-align:left;color:#91acbd">First evolve and validate at least one champion.</td></tr>';
  $('hybridStatus').textContent=learning?`Active: learning heir #${H.tracks?.[H.active]?.id??'—'} · next reward lens ${H.tracks?.[H.active]?.last?.lens||'mixed'} · training updates ${H.updates||0} · automatic switch-back at ${S.cfg.hybridLearnSteps} new updates.`:
    `Evolution continues on the original strictly ternary walker. ${H.auto?'Automatic transition planned at generation '+H.nextEvolutionAt+'.':'Automatic cycling disabled; manual stage buttons work.'} ${H.cycle?`Persistent learned lines ${H.counts?.lineages||0}, nursery offspring ${H.counts?.nursery||0}, nursery improvements ${H.counts?.nurseryMatured||0}.`:''}`;
  $('startLearn').disabled=learning||!S.champion;$('returnEvolution').disabled=!learning;
  $('testLearned').disabled=!n;$('saveHybrid').disabled=!n;$('loadHybrid').disabled=!S.generation;
}

function drawSelfTuning(){
  const b=S.bandit,g=S.governor,br=S.brain;
  $('bandit').innerHTML=b?Object.entries(b.dims).map(([d,a])=>`<div class="small" style="margin:4px 0"><b>${d}</b> ${a.map(x=>`<span class="pill">${x.arm}: <b>${(100*x.share).toFixed(0)}%</b> · ${x.wins}/${x.tried} won</span>`).join('')}</div>`).join(''):'<span class="small">Bandit off: the manual settings apply.</span>';
  $('governor').textContent=g?`${g.on?'ON':'OFF'} · a plateau is ${g.plateauGens} generations without a better champion · each trial runs ${g.trialGens}\n${g.trial?`now trying: ${g.trial.label} (since generation ${g.trial.start})`:`watching: champion ${fx(g.bestQ,4)}, last better at generation ${g.since}`}\nledger, wins of tries, kept across runs: ${Object.entries(g.ledger).map(([k,v])=>`${k} ${v.wins}/${v.tries}`).join(' · ')}\n\n${(g.log||[]).slice().reverse().map(x=>`g${x.generation}  ${x.text}`).join('\n')||'No plateau yet.'}`:'Start a run.';
  $('brainRoles').textContent=br?`Current brain: ${S.N} cells — ${br.io} sensor-motor, ${br.internal} internal, ${br.tonic} tonic · ${br.K} brain ticks per 20 ms step (${(20/br.K).toFixed(1)} ms each)${br.muscles?' · 16 motors (8 muscle pairs)':''}${S.frontier?` · basin search: frontier of ${S.frontier.size} brains, peaks of ${S.frontier.peaks.map(p=>p.n).join(' / ')} cells`:S.search==='champions'?' · champion climber':''}`:'';
  const T=S.tuner;$('tunerLog').textContent=T?`${T.pausedForCompare?'PAUSED while comparing (both arms keep identical settings)':T.on?'ON':'OFF'} · one setting at a time, its value against a neighbour, in 4 windows of ${T.windowGens} generations (old, new, new, old), scored per billion physics steps; adopted only if it wins by 10 %
adopted by the KG so far: ${Object.entries(T.adopted||{}).map(([k,v])=>`${k} ${v}`).join(' · ')||'nothing yet'}
now: ${T.current?Object.entries(T.current).map(([k,v])=>`${k} ${v}`).join(' · '):'—'}
${T.experiment?`testing ${T.experiment.setting}: ${T.experiment.old} against ${T.experiment.new} — window ${T.experiment.window} of ${T.experiment.of} (${T.experiment.arm} value) since generation ${T.experiment.since}`:'no test running'}
ledger, wins of tries: ${Object.entries(T.ledger||{}).map(([k,v])=>`${k} ${v.wins}/${v.tries}`).join(' · ')||'empty'}

${(T.log||[]).slice().reverse().map(x=>`g${x.generation}  ${x.text}`).join('\n')}`:'Start a run.';
  $('sizes').textContent=S.sizes?'Archive by size: '+Object.entries(S.sizes).map(([k,v])=>`${k} cells: ${v}`).join(' · '):'';
}

// ── validation history ─────────────────────────────────────────────────────
function drawHistory(){
  const svg=$('history'),W=860,H=260,p=34,ns='http://www.w3.org/2000/svg',h=S.history||[];while(svg.firstChild)svg.removeChild(svg.firstChild);
  const add=(t,a,txt)=>{const e=document.createElementNS(ns,t);for(const [k,v] of Object.entries(a))e.setAttribute(k,v);if(txt!==undefined)e.textContent=txt;svg.appendChild(e);return e};
  add('rect',{x:0,y:0,width:W,height:H,fill:'#081321'});
  const vk=S.selection==='distance'?'far':'curQ',ymax=3,qmax=Math.max(.01,...h.map(x=>num(x[vk],0)))*1.1;
  for(let i=0;i<=3;i++){const y=H-p-(i/3)*(H-p*1.45);add('line',{x1:p,y1:y,x2:W-40,y2:y,stroke:'#1b3048','stroke-dasharray':'4 6'});add('text',{x:6,y:y+4,fill:'#8fa4bd','font-size':11},String(i))}
  add('text',{x:W-38,y:p-6,fill:'#b9a0ff','font-size':10},qmax.toFixed(3));
  if(!h.length){add('text',{x:W/2-95,y:H/2,fill:'#9fb1c8','font-size':14},'No validation samples yet.');$('historyReadout').textContent='No samples yet.';return}
  const xa=i=>p+(W-p-44)*(i/Math.max(1,h.length-1)),ya=v=>H-p-(Math.max(0,Math.min(ymax,v))/ymax)*(H-p*1.45),yq=v=>H-p-(Math.max(0,v)/qmax)*(H-p*1.45);
  const band={posture:'#2b6cb0',footfalls:'#2f9e6b',distance:'#d4a72c'};
  h.forEach((x,i)=>add('rect',{x:xa(i)-1,y:H-p+4,width:Math.max(2,(W-p-44)/h.length),height:6,fill:band[x.rung]||'#334'}));
  for(const [key,col,f] of [['best','#ffd166',ya],['cur','#53d9ff',ya],[vk,'#b9a0ff',yq]]){let d='';h.forEach((x,i)=>{if(x[key]===null||x[key]===undefined)return;d+=(d?' L ':'M ')+xa(i)+' '+f(x[key])});add('path',{d,fill:'none',stroke:col,'stroke-width':2.2})}
  const last=h[h.length-1];$('historyReadout').textContent=`${h.length} samples • generation ${last.g} • best ladder ${fx(last.best,3)} • current ${fx(last.cur,3)} • current reward ${fx(last.curQ,5)} m/s • rung ${last.rung}`;
}

// ── behaviour archive (duty x coordination; number = cadence cells) ────────
function drawArchive(){
  const svg=$('archiveGrid'),W=430,H=330,ns='http://www.w3.org/2000/svg',A=S.archive,b=A?.bins||5;while(svg.firstChild)svg.removeChild(svg.firstChild);
  const add=(t,a,txt)=>{const e=document.createElementNS(ns,t);for(const [k,v] of Object.entries(a))e.setAttribute(k,v);if(txt!==undefined)e.textContent=txt;svg.appendChild(e);return e};
  add('rect',{x:0,y:0,width:W,height:H,fill:'#081321'});const px=56,py=18,pb=52,cw=(W-px-16)/b,ch=(H-py-pb)/b,cells=new Map();let mn=Infinity,mx=-Infinity;
  for(const e of A?.cells||[]){const k=e.cell[0]+'|'+e.cell[1];let c=cells.get(k);if(!c){c={count:0,best:-Infinity,top:null};cells.set(k,c)}c.count++;if(e.q>c.best){c.best=e.q;c.top=e}mn=Math.min(mn,e.q);mx=Math.max(mx,e.q)}
  for(let i=0;i<b;i++)for(let j=0;j<b;j++){const c=cells.get(i+'|'+j),x=px+i*cw,y=py+(b-1-j)*ch,t=c&&mx>mn?(c.best-mn)/(mx-mn):c?1:0;
    const r=add('rect',{x:x+1,y:y+1,width:cw-2,height:ch-2,rx:4,fill:c?`hsl(${(196-150*t).toFixed(0)},82%,${(26+26*t).toFixed(0)}%)`:'#0c1826',stroke:c?'#7fb6dd':'#1b3048'});
    if(c){r.style.cursor='pointer';r.onclick=()=>cmd('test',{which:'champion',id:c.top.id});const tt=document.createElementNS(ns,'title');tt.textContent=`#${c.top.id} ladder ${fx(c.best,3)} — click to replay`;r.appendChild(tt);
      add('text',{x:x+cw/2,y:y+ch/2+4,fill:'#06121d','font-size':Math.min(13,cw*.36),'text-anchor':'middle','font-weight':'700','pointer-events':'none'},String(c.count))}}
  const fr=k=>A?`${(100*A.ranges[k][0]).toFixed(0)} → ${(100*A.ranges[k][1]).toFixed(0)}%`:'';
  add('text',{x:px+b*cw/2,y:H-30,fill:'#9fb1c8','font-size':12,'text-anchor':'middle'},`duty factor  ${fr('duty')}`);
  const yl=add('text',{x:14,y:py+b*ch/2,fill:'#9fb1c8','font-size':12,'text-anchor':'middle'},`coordination (pace → trot)  ${fr('coordination')}`);yl.setAttribute('transform',`rotate(-90 14 ${py+b*ch/2})`);
  add('text',{x:px,y:H-10,fill:'#eaf3ff','font-size':12},`${A?.cells.length??0} cells • ${A?pct(A.coverage):'0%'} coverage • ladder ${mn===Infinity?'—':mn.toFixed(2)} → ${mx===-Infinity?'—':mx.toFixed(2)} • cadence ${fr('cadence')}`);
  const list=$('archiveList'),pool=new Set(A?.pool||[]),top=[...(A?.cells||[])].sort((a,b)=>b.q-a.q).slice(0,14);
  list.innerHTML=top.length?top.map(e=>`<span class="pill" data-id="${e.id}">${pool.has(e.id)?'pool':'cell'} #${e.id} • <b>${fx(e.q,3)}</b> • ${fx(e.meanQ,4)} m/s • duty ${pct(e.desc?.duty)} • coord ${fx(e.desc?.coordination,2)} • cadence ${fx(e.desc?.cadence,2)}</span>`).join(''):'<span class="small">No champions yet.</span>';
  for(const el of list.querySelectorAll('[data-id]'))el.onclick=()=>cmd('test',{which:'champion',id:Number(el.dataset.id)});
}

// ── 3D walker (the lab dashboard's way: capsules from frame body poses) ────
const arena=$('arena');let renderer,scene,camera,orbit,robot=null,bodyMeshes=[],robotSig='';
function makeMat(c){return new THREE.MeshStandardMaterial({color:c,roughness:.38,metalness:.18,emissive:new THREE.Color(c).multiplyScalar(.035)})}
function limb(L,r,c){const g=new THREE.CapsuleGeometry(r,L,7,14);g.rotateX(Math.PI/2);g.translate(0,0,-L/2);const m=new THREE.Mesh(g,makeMat(c));m.castShadow=true;return m}
function initScene(){
  scene=new THREE.Scene();scene.background=new THREE.Color(0x050b10);scene.fog=new THREE.Fog(0x050b10,5,18);
  camera=new THREE.PerspectiveCamera(44,1,.02,80);camera.up.set(0,0,1);camera.position.set(2.4,-3.5,1.55);
  renderer=new THREE.WebGLRenderer({antialias:true});renderer.setPixelRatio(Math.min(2,window.devicePixelRatio||1));renderer.shadowMap.enabled=true;arena.appendChild(renderer.domElement);
  orbit=new OrbitControls(camera,renderer.domElement);orbit.enableDamping=true;orbit.target.set(0,0,.3);
  scene.add(new THREE.HemisphereLight(0x9edbff,0x0b1218,1.4));const dl=new THREE.DirectionalLight(0xffffff,2);dl.position.set(-2,-3,6);dl.castShadow=true;scene.add(dl);
  const floor=new THREE.Mesh(new THREE.PlaneGeometry(60,60),new THREE.MeshStandardMaterial({color:0x0d1b26,roughness:.95}));floor.receiveShadow=true;scene.add(floor);
  const grid=new THREE.GridHelper(60,120,0x29415f,0x15283a);grid.rotation.x=Math.PI/2;grid.position.z=.001;scene.add(grid);
  new ResizeObserver(resize).observe(arena);resize();requestAnimationFrame(tick);
}
function resize(){if(!renderer)return;const w=arena.clientWidth,h=arena.clientHeight;if(!w||!h)return;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix()}
function buildRobot(g){
  const sig=[g.torsoLength,g.torsoWidth,g.torsoHeight,g.thighLength,g.thighRadius,g.shinLength,g.shinRadius,g.footRadius].join(',');if(robot&&sig===robotSig)return;robotSig=sig;
  if(robot)scene.remove(robot);robot=new THREE.Group();bodyMeshes=[];
  const torso=new THREE.Mesh(new THREE.BoxGeometry(g.torsoLength,g.torsoWidth,g.torsoHeight),makeMat(0x83c7ff));torso.castShadow=true;robot.add(torso);bodyMeshes.push(torso);
  const head=new THREE.Mesh(new THREE.SphereGeometry(.025,12,8),makeMat(0xffd166));head.position.set(g.torsoLength/2,0,0);torso.add(head);
  for(let i=0;i<4;i++){const t=limb(g.thighLength,g.thighRadius,0x72edc7);robot.add(t);bodyMeshes.push(t);
    const sh=limb(g.shinLength,g.shinRadius,0x5fc9e8),f=new THREE.Mesh(new THREE.SphereGeometry(g.footRadius,14,10),makeMat(0x8194a0));f.position.set(0,0,-g.shinLength);f.userData.isFoot=true;sh.add(f);robot.add(sh);bodyMeshes.push(sh)}
  scene.add(robot);
}
function applyFrame(fr){
  if(!fr||!bodyMeshes.length)return;
  fr.bodies.forEach((b,i)=>{const m=bodyMeshes[i];if(!m)return;m.position.set(b[0],b[1],b[2]);m.quaternion.set(b[4],b[5],b[6],b[3]);
    const foot=m.children.find(c=>c.userData?.isFoot);if(foot){const k=(i-1)>>1,on=num(fr.contacts?.[k])>.5;foot.material.color.setHex(on?0xffdf55:0x8194a0)}});
  const x=num(fr.x),y=num(fr.bodies?.[0]?.[1]);orbit.target.lerp(new THREE.Vector3(x+.4,y,.25),.08);
  if(playing){camera.position.x+=(x-camera.position.x+2.4)*.035;camera.position.y+=(y-camera.position.y-3.5)*.035}
}
function loadReplay(r){
  if(!r||!r.frames?.length)return;replay=r;frameIx=0;playing=true;buildRobot(r.geometry);$('networkCard').style.display='block';
  $('vizInfo').textContent=`${r.label} · validation case ${r.caseIndex+1}/${r.cases}\nladder ${fx(r.trial.ladder,3)} (${r.trial.rung}) · reward ${fx(r.trial.rewardOfRecord,5)} m/s\nforward ${fx(r.trial.forward==null?null:100*r.trial.forward,1)} cm/s · slide ${fx(r.trial.slipCm,1)} cm · floor contact ${pct(r.trial.floorContact)}${r.trial.learn?`\nlearning changed ${r.trial.learn} wires in this trial`:''}`;
  layout=null;
}
function tick(t){
  if(replay&&playing&&t-lastFrameT>40){lastFrameT=t;frameIx=(frameIx+1)%replay.frames.length}
  if(replay){applyFrame(replay.frames[frameIx]);drawBrain()}
  orbit.update();renderer.render(scene,camera);requestAnimationFrame(tick);
}

// ── live connectome ─────────────────────────────────────────────────────────
const net=$('netview'),nctx=net.getContext('2d');let layout=null;
function drawBrain(){
  const B=replay?.brain;if(!B)return;const N=B.N,W=net.width,H=net.height,h=replay.trace?.[Math.min(frameIx,(replay.trace.length||1)-1)]||'';
  const wt=replay.wtrace?.[Math.min(frameIx,(replay.wtrace.length||1)-1)]||null,wOf=x=>wt?(wt[x]==='+'?1:wt[x]==='-'?-1:0):B.w[x];   // v10.1.0: a learning brain's wires at this frame
  let learned=0,learnedSensor=0;if(wt)for(let x=0;x<3*N;x++)if(wOf(x)!==B.w[x]){learned++;if(B.src[x]<B.S)learnedSensor++}
  if(!layout||layout.length!==N){layout=new Array(N);const R=Math.min(W,H),cx=W*.5,cy=H*.54,role=B.role||new Array(N).fill(0);
    for(const [r,rad] of [[0,R*.36],[1,R*.2],[2,R*.05]]){const ids=[...Array(N).keys()].filter(i=>(role[i]||0)===r);ids.forEach((i,k)=>{const a=(k/Math.max(1,ids.length))*Math.PI*2+r*.4,rr=rad*(r===2?1:(.9+.1*((i*17)%7)/7));layout[i]={x:cx+Math.cos(a)*rr,y:cy+Math.sin(a)*rr}})}}
  const val=i=>h[i]==='+'?1:h[i]==='-'?-1:0;nctx.clearRect(0,0,W,H);
  for(let i=0;i<N;i++)for(let k=0;k<3;k++){const x=3*i+k,s=B.src[x],w=wOf(x),moved=wt&&w!==B.w[x];if(s<B.S)continue;const a=layout[s-B.S],b=layout[i],col=w>0?'#55e58b':w<0?'#ff6f7d':'#42546c',on=val(s-B.S)!==0;
    nctx.strokeStyle=moved?'#ffd166':col;nctx.globalAlpha=moved?.95:w===0?.12:(on?.75:.22);nctx.lineWidth=moved?3:on?1.8:1;nctx.beginPath();nctx.moveTo(a.x,a.y);nctx.lineTo(b.x,b.y);nctx.stroke();
    if(w!==0&&on){const f=(performance.now()/420+i*.071)%1;nctx.globalAlpha=.95;nctx.fillStyle=col;nctx.beginPath();nctx.arc(a.x+(b.x-a.x)*f,a.y+(b.y-a.y)*f,2.4,0,Math.PI*2);nctx.fill()}}
  nctx.globalAlpha=1;const mr=Math.min(W,H)*.42,cx=W*.5,cy=H*.54;
  for(let a=0;a<B.A;a++){const ang=-Math.PI/2+(a+.5)*(Math.PI*2/B.A),mx=cx+Math.cos(ang)*mr,my=cy+Math.sin(ang)*mr;let sum=0;
    for(let i=0;i<N;i++){const v=B.dec[a*N+i];if(!v)continue;sum+=v*val(i);nctx.strokeStyle=v>0?'#55e58b':'#ff6f7d';nctx.globalAlpha=.18;nctx.beginPath();nctx.moveTo(layout[i].x,layout[i].y);nctx.lineTo(mx,my);nctx.stroke()}
    nctx.globalAlpha=1;nctx.fillStyle=sum>0?'#55e58b':sum<0?'#ff6f7d':'#52647c';nctx.fillRect(mx-7,my-7,14,14);nctx.fillStyle='#d9e7f7';nctx.font='10px Segoe UI';nctx.fillText('M'+(a+1),mx+9,my+4)}
  for(let i=0;i<N;i++){const p=layout[i],v=val(i),rad=Math.min(6,Math.max(2.5,300/N));nctx.fillStyle=v>0?'#55e58b':v<0?'#ff6f7d':'#52647c';nctx.beginPath();nctx.arc(p.x,p.y,rad,0,Math.PI*2);nctx.fill();nctx.lineWidth=1.8;nctx.strokeStyle=['#53d9ff','#b9a0ff','#ffd166'][B.role?.[i]||0];nctx.stroke();
    if(B.learn?.[i]){nctx.lineWidth=1;nctx.strokeStyle='#ffffff';nctx.setLineDash([2,2]);nctx.beginPath();nctx.arc(p.x,p.y,rad+3.5,0,Math.PI*2);nctx.stroke();nctx.setLineDash([])}
    if(N<=96){nctx.fillStyle='#d9e7f7';nctx.font='9px Segoe UI';nctx.fillText(String(i+1),p.x+6,p.y+3)}}
  nctx.fillStyle='#eaf3ff';nctx.font='13px Segoe UI';
  const rc=[0,0,0];(B.role||[]).forEach(r=>rc[r]++);nctx.fillText(`${rc[0]} sensor-motor (cyan ring) • ${rc[1]} internal (violet) • ${rc[2]} tonic (gold, centre) • ${B.K||1} ticks per 20 ms step`,18,44);
  const nl=(B.learn||[]).filter(x=>x).length;if(nl||wt){nctx.fillStyle='#ffd166';nctx.fillText(`${nl} learning cells (dashed white ring) • ${learned} wires changed by learning so far this trial (gold)${learnedSensor?`, ${learnedSensor} of them from sensors (not drawn)`:''}`,18,64)}
  if(B.A===16){nctx.fillStyle='#9fb1c8';nctx.fillText('16 motors = 8 muscle pairs: M1-M8 pull each joint one way, M9-M16 the other way; both on = stiff',18,H-12)}
  nctx.fillText(`${N} cells • ${3*N} incoming slots • ${B.src.filter((s,x)=>s>=B.S&&B.w[x]!==0).length} live recurrent • ${B.S} ternary sensors • ${B.A} motors × ${B.V} votes • frame ${frameIx+1}/${replay.frames.length}`,18,24);
}

// ── buttons ─────────────────────────────────────────────────────────────────
const on=(id,f)=>{$(id).onclick=f};
on('activateHybrid',()=>cmd('hybridActivate'));on('startLearn',()=>cmd('hybridLearn'));on('returnEvolution',()=>cmd('hybridEvolve'));on('testLearned',()=>cmd('test',{which:'learned'}));on('saveHybrid',()=>cmd('hybridSave'));on('loadHybrid',()=>cmd('hybridLoad'));
on('start',()=>cmd('start',{keep:false}));on('startSave',()=>cmd('startFromSave'));on('continue',()=>cmd('start',{keep:true}));on('pause',()=>cmd('pause'));on('resume',()=>cmd('resume'));on('reset',()=>cmd('reset'));
on('test',()=>cmd('test',{which:'current'}));on('testTop',()=>cmd('test',{which:'champion'}));on('testFar',()=>cmd('test',{which:'farthest'}));on('eval',()=>cmd('eval'));on('play',()=>{playing=!playing});
on('crossval',()=>cmd('crossval'));on('audit',()=>cmd('audit'));on('rescore',()=>cmd('rescore'));on('revisit',()=>cmd('revisit'));on('loadTop',()=>cmd('loadTop'));on('clearArchive',()=>{if(confirm('Clear the champion pool and the archive?'))cmd('clearArchive')});
on('save',async()=>{await cmd('save');$('ioStatus').textContent=S?.note||'Saved.'});on('load',async()=>{await cmd('load');$('ioStatus').textContent=S?.note||''});
on('biopsy',async()=>{const t=await (await fetch('/api/biopsy')).text();try{await navigator.clipboard.writeText(t);$('status').textContent='Biopsy copied.'}catch{$('ioBox').value=t;$('status').textContent='Clipboard unavailable — the biopsy is in the box below.'}});
on('toBox',async()=>{const t=await (await fetch('/api/export')).text();$('ioBox').value=t;$('ioStatus').textContent=`Wrote ${(t.length/1024).toFixed(0)} KB to the box.`});
async function importText(t){const r=await fetch('/api/import',{method:'POST',body:t});const j=await r.json();$('ioStatus').textContent=r.ok?`Loaded ${j.cells} archive cells.`:(j.error||'could not load');poll()}
on('fromBox',()=>importText($('ioBox').value.trim()));
$('file').onchange=async e=>{const f=e.target.files?.[0];if(f)importText(await f.text())};
// ── the fitness landscape (basin search's map) ─────────────────────────────
let LS=null,lsDrawn=[];
async function pollLandscape(){if(!$('lsLive').checked||!S||!S.generation)return;try{LS=await (await fetch('/api/landscape',{cache:'no-store'})).json();drawLandscape()}catch{}}
setInterval(pollLandscape,3000);$('lsMap').onchange=$('lsColor').onchange=$('lsAx').onchange=$('lsAy').onchange=drawLandscape;
function drawLandscape(){
  const c=$('landscape'),g=c.getContext('2d'),W=c.width,H=c.height,pad=44;g.clearRect(0,0,W,H);g.fillStyle='#081321';g.fillRect(0,0,W,H);lsDrawn=[];
  const pts=LS?.points||[];if(!pts.length){g.fillStyle='#9fb1c8';g.font='14px Segoe UI';g.fillText('No map yet — start a run.',W/2-80,H/2);return}
  const geno=$('lsMap').value==='genotype',by=$('lsColor').value,val=p=>by==='sel'?p.sel:p.ladder;
  const nd=LS.dims||2,ax=$('lsAx'),ay=$('lsAy');if(ax.options.length!==nd){const o=[...Array(nd).keys()].map(d=>`<option value="${d}">D${d+1} (${(100*(LS.share?.[d]||0)).toFixed(0)}%)</option>`).join('');ax.innerHTML=o;ay.innerHTML=o;ax.value='0';ay.value='1'}
  else for(const sel of [ax,ay])[...sel.options].forEach((op,d)=>op.textContent=`D${d+1} (${(100*(LS.share?.[d]||0)).toFixed(0)}%)`);
  const dx=Number(ax.value)||0,dy=Number(ay.value)||(nd>1?1:0);
  const X=p=>geno?(p.c?.[dx]??p.x):(p.desc?.duty??NaN),Y=p=>geno?(p.c?.[dy]??p.y):(p.desc?.coordination??NaN),shown=pts.filter(p=>Number.isFinite(X(p))&&Number.isFinite(Y(p)));
  const xs=shown.map(X),ys=shown.map(Y),x0=Math.min(...xs),x1=Math.max(...xs),y0=Math.min(...ys),y1=Math.max(...ys),sx=Math.max(1e-9,x1-x0),sy=Math.max(1e-9,y1-y0);
  const px=v=>pad+(v-x0)/sx*(W-2*pad),py=v=>H-pad-(v-y0)/sy*(H-2*pad);
  const known=shown.filter(p=>Number.isFinite(val(p))),vs=known.map(val),lo=Math.min(...vs),hi=Math.max(...vs),span=Math.max(1e-9,hi-lo);
  const col=(t,a=1)=>`hsla(${(225-180*t).toFixed(0)},78%,${(16+42*t).toFixed(0)}%,${a})`;
  if(known.length){const G=10,P=known.map(p=>[px(X(p)),py(Y(p)),(val(p)-lo)/span]);
    for(let gx=0;gx<W;gx+=G)for(let gy=0;gy<H;gy+=G){let ws=0,v=0;for(const [qx,qy,t] of P){const d2=(qx-gx)**2+(qy-gy)**2+600,w=1/(d2*d2);ws+=w;v+=w*t}g.fillStyle=col(v/ws,.55);g.fillRect(gx,gy,G,G)}}
  const order={elite:0,frontier:1,candidate:2,escape:3,peak:4},kindOf=p=>p.kinds.reduce((a,k)=>order[k]>order[a]?k:a,p.kinds[0]);
  for(const p of [...shown].sort((a,b)=>order[kindOf(a)]-order[kindOf(b)])){const x=px(X(p)),y=py(Y(p)),k=kindOf(p),t=Number.isFinite(val(p))?(val(p)-lo)/span:0;lsDrawn.push({x,y,p});
    g.lineWidth=2;
    if(k==='elite'){g.fillStyle='#8fa4bd';g.fillRect(x-5,y-5,10,10);g.strokeStyle='#06121d';g.strokeRect(x-5,y-5,10,10)}
    else if(k==='candidate'){g.fillStyle='#eaf3ff';g.beginPath();g.arc(x,y,3,0,7);g.fill()}
    else if(k==='escape'){g.fillStyle='#b9a0ff';g.beginPath();g.arc(x,y,5,0,7);g.fill()}
    else if(k==='frontier'){g.fillStyle=col(t);g.beginPath();g.arc(x,y,7,0,7);g.fill();g.strokeStyle='#53d9ff';g.stroke()}
    else{g.fillStyle=col(t);g.beginPath();g.arc(x,y,9,0,7);g.fill();g.strokeStyle='#ffd166';g.lineWidth=3;g.beginPath();g.arc(x,y,13,0,7);g.stroke();g.fillStyle='#ffd166';g.font='bold 13px Segoe UI';g.fillText('#'+(p.peak+1),x+15,y-10)}}
  g.fillStyle='#9fb1c8';g.font='11px Segoe UI';g.fillText(geno?`wiring map, dimension ${dx+1}`:'duty factor',W/2-50,H-12);g.save();g.translate(14,H/2+40);g.rotate(-Math.PI/2);g.fillText(geno?`wiring map, dimension ${dy+1}`:'coordination (pace → trot)',0,0);g.restore();
  const n=k=>pts.filter(p=>p.kinds.includes(k)).length,sizes=[...new Set(pts.filter(p=>p.kinds.includes('peak')).map(p=>p.n))];
  $('lsStatus').textContent=`generation ${LS.generation} · rung ${LS.rung} · ${n('peak')} peaks (${sizes.join(' / ')} cells) · ${n('frontier')} other frontier brains · ${n('candidate')} local candidates · ${n('escape')} escape probes · ${n('elite')} elites · colour ${by==='sel'?`training fitness ${lo.toFixed(3)} → ${hi.toFixed(3)}`:`ladder ${lo.toFixed(3)} → ${hi.toFixed(3)}`}${LS.search!=='basin'?' · champion climber: no frontier':''}`;
}
$('landscape').onclick=e=>{const r=$('landscape').getBoundingClientRect(),sx=$('landscape').width/r.width,x=(e.clientX-r.left)*sx,y=(e.clientY-r.top)*sx;let best=null,bd=18*18;
  for(const q of lsDrawn){const d=(q.x-x)**2+(q.y-y)**2;if(d<bd){bd=d;best=q}}if(best)cmd('test',{which:'landscape',id:best.p.i})};
initScene();poll();
