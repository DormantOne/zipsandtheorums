/* rig/plants/walker_pool.mjs — worker-thread pool for walker rollouts (engine/eval_pool.mjs's design). */
import {Worker} from 'node:worker_threads';
import os from 'node:os';
export function poolSize(requested=0){
  const cores=Math.max(1,typeof os.availableParallelism==='function'?os.availableParallelism():os.cpus().length);
  const want=Number(requested)>0?Number(requested):(cores<=2?cores:cores-1);return Math.max(1,Math.min(32,Math.trunc(want)));
}
export class WalkerPool{
  constructor({size=0}={}){this.size=poolSize(size);this.workers=[];this.idle=[];this.queue=[];this.pending=new Map();this.nextId=1;this.closed=false;this.failed=null;
    this.stats={jobs:0,rollouts:0,busyMs:0};this._ready=null}
  ready(){if(this._ready)return this._ready;
    this._ready=Promise.all(Array.from({length:this.size},()=>new Promise((resolve,reject)=>{
      const w=new Worker(new URL('./walker_worker.mjs',import.meta.url),{execArgv:process.execArgv.filter(a=>!a.startsWith('--input-type'))});
      const onReady=m=>{if(m?.type==='ready'){w.off('message',onReady);this._attach(w);resolve()}
        else if(m?.type==='error'){w.off('message',onReady);w.terminate();reject(new Error(`a walker thread could not start MuJoCo: ${String(m.error).split('\n')[0]}`))}};
      w.on('message',onReady);w.once('error',reject);w.postMessage({type:'init'})})));
    this._ready.catch(()=>this.close());return this._ready}
  _attach(w){this.workers.push(w);this.idle.push(w);
    w.on('message',m=>{if(m?.type!=='result'&&m?.type!=='error')return;const p=this.pending.get(m.id);this.pending.delete(m.id);this.idle.push(w);
      if(p){if(m.type==='error')p.reject(new Error(`walker worker failed: ${m.error}`));else{this.stats.jobs++;this.stats.rollouts+=m.results.length;this.stats.busyMs+=m.ms||0;p.resolve(m.results)}}
      this._pump()});
    w.on('error',e=>this._fail(e));w.on('exit',code=>{if(!this.closed&&code!==0)this._fail(new Error(`walker worker exited with code ${code}`))})}
  _fail(e){if(this.failed)return;this.failed=e;for(const [,p] of this.pending)p.reject(e);this.pending.clear();for(const q of this.queue)q.reject(e);this.queue=[];this.close()}
  _pump(){while(this.idle.length&&this.queue.length){const w=this.idle.pop(),q=this.queue.shift(),id=this.nextId++;this.pending.set(id,q);w.postMessage({type:'job',id,job:q.job})}}
  run(job){if(this.closed||this.failed)return Promise.reject(this.failed||new Error('pool closed'));return new Promise((resolve,reject)=>{this.queue.push({job,resolve,reject});this._pump()})}
  async evaluate(jobs){await this.ready();return Promise.all(jobs.map(j=>this.run(j)))}
  async close(){if(this.closed)return;this.closed=true;await Promise.allSettled(this.workers.map(w=>w.terminate()));this.workers=[];this.idle=[]}
}
