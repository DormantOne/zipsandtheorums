/* rig/plants/walker_worker.mjs — one evaluation thread for the rig's walker plant.
 *
 * MuJoCo loading and runtime construction are engine/eval_worker.mjs verbatim
 * (same plant options, calibrateStanding + probe, same run configuration), so a
 * rollout here is the same rollout the lab runs. The only addition is a thin
 * wrapper around the ternary controller that records the four foot-contact
 * sensors the controller already reads each 20 ms step, from which the gait
 * descriptors are computed. engine/plant.js is not touched (reward fence).
 */
import {parentPort} from 'node:worker_threads';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {WalkerPlant,PLANT} from '../../engine/plant.js';
import {makeTernaryController} from '../../engine/ternary.mjs';
import {isRigGenome,makeRigController} from '../brain.mjs';
import {isContinuous,makeContinuousController} from '../continuous.mjs';

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const ROOT=path.resolve(__dirname,'..','..');
let mujoco=null;
const runtimes=new Map();

export async function loadMujoco(){
  if(mujoco)return mujoco;
  const mod=await import('@mujoco/mujoco'),load=mod.default||mod,require=createRequire(import.meta.url);
  let opts={};
  try{
    const entry=require.resolve('@mujoco/mujoco'),dir=path.dirname(entry),localWasm=path.join(ROOT,'engine','vendor','mujoco.wasm');
    opts={locateFile:p=>(String(p).endsWith('.wasm')&&fs.existsSync(localWasm))?localWasm:path.join(dir,p)};
  }catch{}
  try{mujoco=await load(opts)}catch(e){mujoco=await load()}
  return mujoco;
}
function runtimeFor(spec){
  const friction=spec.friction==='legacy'?{frictionCone:'pyramidal',impratio:1}:{frictionCone:'elliptic',impratio:10};   // v10.0.2 (FRICTION_MODES in walker.mjs)
  const key=JSON.stringify([spec.legScale,spec.frictionMu,friction,spec.run]);
  let rt=runtimes.get(key);if(rt)return rt;
  const s=spec.legScale;
  const plant=new WalkerPlant(mujoco,{frictionMu:spec.frictionMu,thighLength:PLANT.thighLength*s,shinLength:PLANT.shinLength*s,...friction});
  const evalData=new mujoco.MjData(plant.model),passiveData=new mujoco.MjData(plant.model);
  plant.calibrateStanding(evalData);plant.probe(evalData);plant.configure(spec.run);
  rt={plant,evalData,passiveData};runtimes.set(key,rt);
  while(runtimes.size>6){const [k,old]=runtimes.entries().next().value;for(const h of [old.evalData,old.passiveData,old.plant.model])try{h.delete?.()}catch{};runtimes.delete(k)}
  return rt;
}
const FEET=['fl','fr','rl','rr'],CONTROL_DT=PLANT.dt*PLANT.frameSkip;
/* Gait descriptors, each in [0,1]:
 *   duty          mean fraction of the run each foot is on the ground (plant's own contact time)
 *   coordination  trot <-> pace: 1 = diagonal feet move together, 0 = same-side feet do,
 *                 0.5 = neither (phi correlation of the contact sensors, diagonal minus lateral)
 *   cadence       genuine steps per second / 8 */
export function gaitDescriptors(row,bits,T){
  const secs=Math.max(CONTROL_DT,T*CONTROL_DT),bf=row?.footSlip?.byFoot||{};
  const duty=FEET.reduce((s,f)=>s+Math.min(1,(bf[f]?.contactSeconds||0)/secs),0)/4;
  const phi=(a,b)=>{let n11=0,n10=0,n01=0,n00=0;for(let t=0;t<T;t++){const x=bits[4*t+a],y=bits[4*t+b];if(x&&y)n11++;else if(x)n10++;else if(y)n01++;else n00++}
    const d=Math.sqrt((n11+n10)*(n01+n00)*(n11+n01)*(n10+n00));return d>0?(n11*n00-n10*n01)/d:0};
  const diag=(phi(0,3)+phi(1,2))/2,lat=(phi(0,2)+phi(1,3))/2;
  const coordination=Math.max(0,Math.min(1,(diag-lat)/4+.5));
  const cadence=Math.max(0,Math.min(1,(row?.gait?.genuineSteps||0)/secs/8));
  return {duty,coordination,cadence};
}
function slimRow(r){
  const o={};for(const [k,v] of Object.entries(r)){if(v===null||typeof v!=='object')o[k]=v}
  o.gait={...r.gait};o.sustainedGait=r.sustainedGait;
  o.contactHealth=r.contactHealth?{health:r.contactHealth.health,contactFraction:r.contactHealth.contactFraction,contactFree:r.contactHealth.contactFree}:null;
  o.footSlip=r.footSlip?{maxSlipM:r.footSlip.maxSlipM,health:r.footSlip.health,slideFree:r.footSlip.slideFree,
    byFoot:Object.fromEntries(FEET.map(f=>[f,{contactSeconds:r.footSlip.byFoot?.[f]?.contactSeconds??0,slipM:r.footSlip.byFoot?.[f]?.slipM??0}]))}:null;
  if(r.earlyExit)o.earlyExit={chargedTicks:r.earlyExit.chargedTicks,atSeconds:r.earlyExit.atSeconds};
  return o;
}
export function runJob(job){
  const rt=runtimeFor(job.physics),out=[],stride=Math.max(1,job.stride|0||2);
  for(const scenario of job.scenarios){
    const c=isContinuous(job.genome)?makeContinuousController(job.genome,{tone:!!job.tone}):isRigGenome(job.genome)?makeRigController(job.genome):makeTernaryController(job.genome),steps=job.steps,bits=new Uint8Array(4*steps),trace=job.trace?[]:null;let t=0;
    const wtrace=trace&&c.weights&&c.stats&&c.stats().learning?[]:null;   // v10.1.0: a learning brain's wires, frame by frame, for the replay's connectome
    const control=obs=>{if(t<steps)for(let f=0;f<4;f++)bits[4*t+f]=obs[28+f]>.5?1:0;const o=c.control(obs);
      if(trace&&t%stride===0){const h=c.hidden();let s='';for(let i=0;i<c.N;i++)s+=h[i]>0?'+':h[i]<0?'-':'0';trace.push(s)
        if(wtrace){const w=c.weights();let q='';for(let x=0;x<w.length;x++)q+=w[x]>0?'+':w[x]<0?'-':'0';wtrace.push(q)}}t++;return o};
    const r=rt.plant.rollout({control,hidden:null,steps,scenario,data:rt.evalData,passiveData:rt.passiveData,record:!!job.record,recordStride:stride,earlyExit:job.earlyExit||null});
    const res={row:slimRow(r),desc:gaitDescriptors(r,bits,Math.min(t,steps))};
    if(c.stats)res.learn=c.stats().flips;   // v10.1.0: how many wire changes a plastic brain made in this trial
    if(job.record){res.frames=(r.frames||[]).map(f=>({t:f.t,bodies:f.bodies,x:f.x,contacts:f.contacts,torques:f.torques,footSlip:f.footSlip}));res.geometry=rt.plant.geometryReport()}
    if(trace)res.trace=trace;
    if(wtrace)res.wtrace=wtrace;
    out.push(res);
  }
  return out;
}
if(parentPort)parentPort.on('message',async msg=>{
  try{
    if(msg?.type==='init'){await loadMujoco();parentPort.postMessage({type:'ready'});return}
    if(msg?.type==='job'){await loadMujoco();const t0=performance.now(),results=runJob(msg.job);parentPort.postMessage({type:'result',id:msg.id,results,ms:performance.now()-t0});return}
  }catch(e){parentPort.postMessage({type:'error',id:msg?.id??null,error:String(e?.stack||e)})}
});
