#!/usr/bin/env node
/* rig/server.mjs — serves the Walker Ternary Rig at http://127.0.0.1:8793
 *   node rig/server.mjs [--port 8793] [--workers 15]
 * One lab, one run at a time. The page polls /api/status and posts commands to
 * /api/cmd. Stopping the server (STOP_MAC.command, Ctrl-C) saves the champions. */
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {fileURLToPath} from 'node:url';
import {Lab,BUILD} from './lab.mjs';
import {makeWalkerPlant} from './plants/walker.mjs';

const here=path.dirname(fileURLToPath(import.meta.url)),ROOT=path.resolve(here,'..');
const args=process.argv.slice(2),opt=(k,d)=>{const i=args.indexOf(k);return i>=0?args[i+1]:d};
const PORT=Number(opt('--port',process.env.RIG_PORT||8793));
const cores=Math.max(1,typeof os.availableParallelism==='function'?os.availableParallelism():os.cpus().length);
const WORKERS=Number(opt('--workers',process.env.RIG_WORKERS||Math.max(1,cores-1)));
const DATA=path.resolve(process.env.RIG_DATA_DIR||path.join(ROOT,'data'));
const lab=new Lab({dataDir:DATA,makePlant:()=>makeWalkerPlant({workers:WORKERS,backend:process.env.RIG_WALKER_BACKEND||undefined})});

const TYPES={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.wasm':'application/wasm','.svg':'image/svg+xml'};
function sendFile(res,file){
  fs.readFile(file,(e,buf)=>{if(e){res.writeHead(404);return res.end('not found')}
    res.writeHead(200,{'Content-Type':TYPES[path.extname(file)]||'application/octet-stream','Cache-Control':'no-cache'});res.end(buf)});
}
function safeJoin(base,rel){const p=path.resolve(base,'.'+path.sep+rel);return p.startsWith(base)?p:null}
const json=(res,code,obj)=>{res.writeHead(code,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(obj))};
function body(req,limit=64*1024*1024){return new Promise((ok,bad)=>{let n=0,chunks=[];req.on('data',c=>{n+=c.length;if(n>limit){bad(new Error('too large'));req.destroy()}else chunks.push(c)});req.on('end',()=>ok(Buffer.concat(chunks).toString('utf8')));req.on('error',bad)})}

const server=http.createServer(async(req,res)=>{
  try{
    const u=new URL(req.url,'http://x'),p=decodeURIComponent(u.pathname);
    if(req.method==='GET'&&(p==='/'||p==='/index.html'))return sendFile(res,path.join(here,'gui','index.html'));
    if(req.method==='GET'&&p.startsWith('/gui/')){const f=safeJoin(path.join(here,'gui'),p.slice(5));return f?sendFile(res,f):json(res,403,{error:'forbidden'})}
    if(req.method==='GET'&&p.startsWith('/vendor/three/')){const f=safeJoin(path.join(ROOT,'node_modules','three'),p.slice('/vendor/three/'.length));return f?sendFile(res,f):json(res,403,{error:'forbidden'})}
    if(req.method==='GET'&&p==='/api/status')return json(res,200,lab.status());
    if(req.method==='GET'&&p==='/api/landscape')return json(res,200,lab.landscape());
    if(req.method==='GET'&&p==='/api/replay')return json(res,200,lab.lastReplay||{id:0});
    if(req.method==='GET'&&p==='/api/biopsy'){res.writeHead(200,{'Content-Type':'text/plain; charset=utf-8'});return res.end(lab.biopsy())}
    if(req.method==='GET'&&p==='/api/hybrid/export'){res.writeHead(200,{'Content-Type':'application/json','Content-Disposition':'attachment; filename=walker-metamorphosis-checkpoint.json'});return res.end(JSON.stringify(lab.hybridPayload()))}
    if(req.method==='GET'&&p==='/api/export'){res.writeHead(200,{'Content-Type':'application/json','Content-Disposition':`attachment; filename="walker-rig-champions-${lab.cfg.seed}.json"`});return res.end(JSON.stringify(lab.exportPayload()))}
    if(req.method==='POST'&&p==='/api/import'){const r=await lab.importMatched(JSON.parse(await body(req)));lab.say(`Loaded ${r.cells} archive cells from the payload${r.rescored?', rescored for this run':''}.`);return json(res,200,{ok:true,...r})}
    if(req.method==='POST'&&p==='/api/cmd'){const {cmd,args:a}=JSON.parse(await body(req)||'{}');
      if(cmd==='shutdown'){json(res,200,{ok:true});setTimeout(()=>shutdown('stop requested'),50);return}
      try{return json(res,200,await lab.command(cmd,a||{}))}catch(e){lab.say(e.message);return json(res,400,{error:e.message})}}
    if(req.method==='GET'&&p==='/api/build')return json(res,200,{build:BUILD,workers:WORKERS,cores});
    json(res,404,{error:'not found'});
  }catch(e){json(res,500,{error:String(e?.message||e)})}
});

const pidFile=path.join(DATA,'server.pid');
async function shutdown(sig){
  console.log(`[rig] ${sig}: saving champions and stopping`);
  try{await lab.close()}catch(e){console.error(e)}
  try{fs.rmSync(pidFile,{force:true})}catch{}
  server.close(()=>process.exit(0));setTimeout(()=>process.exit(0),3000).unref();
}
for(const s of ['SIGTERM','SIGINT','SIGHUP'])process.on(s,()=>shutdown(s));
server.on('error',e=>{if(e.code==='EADDRINUSE'){console.error(`[rig] port ${PORT} is already in use: is the rig already running? Open http://127.0.0.1:${PORT}`);process.exit(3)}throw e});
server.listen(PORT,'127.0.0.1',()=>{fs.mkdirSync(DATA,{recursive:true});fs.writeFileSync(pidFile,String(process.pid));
  console.log(`[rig] ${BUILD} at http://127.0.0.1:${PORT}  (${WORKERS} MuJoCo workers, data in ${DATA})`)});
