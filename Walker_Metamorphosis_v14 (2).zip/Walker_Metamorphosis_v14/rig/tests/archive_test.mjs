import assert from 'node:assert/strict';
import {Archive} from '../core/archive.mjs';
import {Rng} from '../core/rng.mjs';
const dist=(a,b)=>{let d=0;for(let i=0;i<a.length;i++)if(a[i]!==b[i])d++;return d};
const A=new Archive({axes:['x','y'],ranges:{x:[.4,.6],y:[.4,.6]},bins:4,cap:10,poolSize:3,poolMinDiff:2,distance:dist});
// same cell: better replaces, worse rejected
assert.equal(A.tryAdd({genome:[0,0,0],quality:1,desc:{x:.5,y:.5}}),'new');
assert.equal(A.tryAdd({genome:[0,0,1],quality:.5,desc:{x:.5,y:.5}}),false);
assert.equal(A.tryAdd({genome:[0,0,1],quality:2,desc:{x:.5,y:.5}}),'improved');
assert.equal(A.cells.size,1);
// widening the axis rebins; two elites that land in one cell keep the better
A.tryAdd({genome:[1,1,1],quality:3,desc:{x:.1,y:.5}});
assert.ok(A.ranges.x[0]<=.1);
// pool: best first, skipping functional near-copies (distance < 2), then backfill
const B=new Archive({axes:['x'],ranges:{x:[0,1]},bins:5,cap:10,poolSize:3,poolMinDiff:2,distance:dist});
B.tryAdd({genome:[0,0,0,0],quality:5,desc:{x:.05}});
B.tryAdd({genome:[0,0,0,1],quality:4,desc:{x:.25}});   // 1 difference from the best -> skipped first pass
B.tryAdd({genome:[1,1,0,0],quality:3,desc:{x:.45}});   // 2 differences -> admitted
B.tryAdd({genome:[1,1,1,1],quality:2,desc:{x:.65}});
const pool=B.derivePool();
assert.deepEqual(pool.map(e=>e.quality),[5,3,2]);
const C=new Archive({axes:['x'],ranges:{x:[0,1]},bins:5,cap:10,poolSize:4,poolMinDiff:9,distance:dist});
for(const [q,x] of [[5,.05],[4,.25],[3,.45]])C.tryAdd({genome:[q,0,0,0],quality:q,desc:{x}});
assert.equal(C.derivePool().length,3,'backfill keeps the pool full even when everything is "too close"');
// cap prunes the lowest quality
const D=new Archive({axes:['x'],ranges:{x:[0,1]},bins:10,cap:3,poolSize:2,poolMinDiff:0,distance:dist});
for(let i=0;i<6;i++)D.tryAdd({genome:[i],quality:i,desc:{x:i/10+.05}});
assert.equal(D.cells.size,3);assert.deepEqual(D.ranked().map(e=>e.quality),[5,4,3]);
// round trip
const E=Archive.fromJSON(JSON.parse(JSON.stringify(B.toJSON())),{distance:dist});
assert.equal(E.cells.size,B.cells.size);assert.deepEqual(E.pool.map(e=>e.id),B.pool.map(e=>e.id));
const r=new Rng(7);let hits=0;for(let i=0;i<1000;i++)if(B.pickPool(r).quality===5)hits++;
assert.ok(hits>400,'selection exponent favours the best pool member');
console.log('archive_test ok');
