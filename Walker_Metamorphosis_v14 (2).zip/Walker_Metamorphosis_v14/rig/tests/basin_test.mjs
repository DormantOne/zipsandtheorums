/* v9.1 basin search on the mock walker, and the climber's corrected bandit credit. */
import assert from 'node:assert/strict';
import {makeWalkerPlant} from '../plants/walker.mjs';
import {ChampionRun} from '../core/evolve.mjs';
import {Governor} from '../core/governor.mjs';
const P=await makeWalkerPlant({backend:'mock'});
let trainEvals=0;const ev=P.evaluate.bind(P);P.evaluate=async(g,s,o={})=>{if(o.train)trainEvals+=g.length;return ev(g,s,o)};
const base={N:24,lambda:12,trainCases:2,valCases:4,holdCases:4,yardstickN:2,valEvery:4,founders:8,founderSizes:[12,24,48],bandit:true,rotate:20,maxCells:96,internalShare:.5,tonicShare:.08,passShare:2};
const run=await new ChampionRun({plant:P,cfg:{...base,search:'basin',peaks:4,escapePct:20},seed:9}).init();
await run.advanceTo(Infinity,{maxGenerations:3});
// 1. frontier and peaks; exactly lambda training candidates per generation, plus re-scoring
let t0=trainEvals,r0=run.rescored||0,b0=run.bandit.events,g0=run.generation,mono=true,last=null;
for(let i=0;i<14;i++){await run.step();const k=`${run.epoch}|${run.cfg.rung??''}`,best=Math.max(...run.frontier.filter(f=>f.key===k).map(f=>f.train.selection));
  if(last&&last.k===k&&best<last.best-1e-12)mono=false;last={k,best};assert.ok(run.frontier.length<=16&&run.lastPeaks.length>=1&&run.lastPeaks.length<=4)}
const gens=run.generation-g0;
assert.equal(trainEvals-t0,gens*12+((run.rescored||0)-r0),'training evaluations = 12 per generation + re-scoring');
assert.equal(run.bandit.events-b0,gens*10,'the bandit is credited once per local sample (12 minus 2 escape probes)');
assert.ok(mono,'the best brain on the current trials is never dropped');
console.log(`basin: frontier ${run.frontier.length} brains, peaks of ${run.lastPeaks.map(p=>p.n).join('/')} cells; ${gens} generations = ${gens}x12 candidates + ${(run.rescored||0)-r0} re-scorings; bandit credited ${gens*10} times`);
// 2. rotating the training trials re-scores the frontier
const rs=run.rescored;while(run.generation%20!==0)await run.step();await run.step();assert.ok(run.rescored>rs,'re-scored after the trials rotated');
console.log(`trials rotated at generation ${run.generation-1}: the frontier was re-scored (${run.rescored-rs} brains)`);
// 3. adopt, restart from the best, governor moves on the frontier
const n0=run.frontier.length;run.restartFromBest();assert.ok(run.frontier.some(f=>f.genome===run.archive.best().genome));
const G=new Governor();const n1=run.frontier.length;G.apply('switch',run,P);G.apply('grow',run,P);assert.ok(run.frontier.length>=n1+1);
const undo=G.apply('explore',run,P);assert.equal(run.cfg.escapePct,40);undo();assert.equal(run.cfg.escapePct,20);
const undo2=G.apply('refine',run,P);assert.equal(run.cfg.escapePct,0);undo2();assert.equal(run.cfg.escapePct,20);
await run.step();
console.log(`restart-from-best and the governor's switch/grow bring brains into the frontier (${n0} -> ${run.frontier.length} after the next step); explore and refine change escape probes and are undone`);
// 4. the champion climber now credits each child against its own parent
const cl=await new ChampionRun({plant:P,cfg:{...base,search:'champions',revisitPct:80,archivePct:50},seed:4}).init();
await cl.advanceTo(Infinity,{maxGenerations:30});
assert.ok(cl.parentsScored>0,'pool and archive parents were scored');
console.log(`champion climber: ${cl.parentsScored} pool/archive parents scored on the training trials for fair credit`);
// 5. peaks that must differ in gait, or in both
for(const sep of ['gait','both']){const rb=await new ChampionRun({plant:P,cfg:{...base,search:'basin',peaks:4,escapePct:20,separation:sep},seed:13}).init();await rb.advanceTo(Infinity,{maxGenerations:12});
  assert.ok(rb.lastPeaks.length>=1&&rb.frontier.length>=1);console.log(`separation "${sep}": ${rb.lastPeaks.length} peaks, frontier ${rb.frontier.length}`)}
// 6. v9.4 distance mode on the basin search: the farthest brain is tracked and is what the KG counts as progress
{const rd=await new ChampionRun({plant:P,cfg:{...base,search:'basin',peaks:4,escapePct:20,selection:'distance',distanceFloor:.01},seed:21}).init();await rd.advanceTo(Infinity,{maxGenerations:60});
 assert.ok(rd.farthest&&rd.farthest.val.distRate>0,'a farthest brain was found');assert.equal(rd.progress(),rd.farthest.val.distRate);
 assert.ok(rd.history.at(-1).far===rd.farthest.val.distRate&&rd.cfg.rung===undefined||rd.cfg.rung===null||rd.cfg.rung==='posture','no curriculum rungs in distance mode');
 const tiers=new Set(rd.frontier.map(f=>{const v=f.train?.injury??9;return v<=.5?0:v<=1.25?1:v<=2.5?2:3}));
 console.log(`distance mode: farthest brain ${rd.farthest.val.distRate.toFixed(4)} m/s (injury ${rd.farthest.val.injury.toFixed(2)}); frontier spans ${tiers.size} injury tier(s); cleanest walker ${rd.archive.best().quality.toFixed(3)}`)}
console.log('basin_test ok');
