/* The v9 brain: the lab's brain as a special case, roles that stay put, neutral growth, ticks. */
import assert from 'node:assert/strict';
import {birthTernary,makeTernaryController,T_SENS} from '../../engine/ternary.mjs';
import {PRNG} from '../core/rng.mjs';
import {ROLE,birthRig,mutateRig,growRig,shrinkRig,crossRig,rigDistance,makeRigController,rigAudit,unpackRig,fromLabGenome,isRigGenome} from '../brain.mjs';
const R=s=>{const f=PRNG(s);return {next:f}};
const obsSeq=(n,seed)=>{const r=R(seed),a=[];for(let t=0;t<n;t++){const o=new Float64Array(64);for(let i=0;i<64;i++)o[i]=2*r.next()-1;a.push(o)}return a};
const run=(c,obs)=>obs.map(o=>Array.from(c.control(o)));
// 1. all cells sensor-motor + 1 tick == the lab's brain, bit for bit
for(const N of [12,24,48]){const lab=birthTernary(R(N),{N,V:6}),obs=obsSeq(300,N);
  assert.deepEqual(run(makeRigController(fromLabGenome(lab)),obs),run(makeTernaryController(lab),obs))}
console.log('the lab brain as a rig brain (all sensor-motor, 1 tick): identical motor outputs over 300 steps, 12/24/48 cells');
// 2. birth: roles, shares and wiring rules
for(const N of [8,12,24,48,96,192]){const g=birthRig(R(N+1),{N,K:10,internalShare:.5,tonicShare:.08}),a=rigAudit(g);
  assert.ok(a.ok,a.text);assert.ok(a.internal>=Math.min(Math.ceil(.5*N),N-6)-1&&a.tonic>=1,a.text);assert.equal(a.K,10)}
console.log('birth: at least half internal (at most N - 6, since each motor needs 6 voters), a tonic minority, internal cells read cells only and never vote, 6 votes per motor (8 to 192 cells)');
// 3. 3000 random operations keep every rule, and roles never change
{const r=R(7);let g=birthRig(r,{N:24});const roles0=Array.from(unpackRig(g).role);let N0=24;
 for(let i=0;i<3000;i++){const u=r.next();let h=u<.7?mutateRig(g,r,{count:1+Math.floor(4*r.next()),strong:r.next()<.1}):u<.8?growRig(g,r,{count:1}):u<.9?shrinkRig(g,r,{}):crossRig(g,birthRig(r,{N:12+Math.floor(r.next()*60)}),r);
   if(!h)continue;const a=rigAudit(h);assert.ok(a.ok,`op ${i}: ${a.text}`);assert.ok(a.internal/a.N>=.45,`internal share ${a.internal}/${a.N}`);g=h}
 const b=unpackRig(g);console.log(`3000 operations (mutation, growth, shrink, crossover with other sizes): every rule held; now ${b.N} cells, ${rigAudit(g).internal} internal`)}
// 4. growth is neutral; shrinking an unread cell is neutral
{const r=R(11),g=birthRig(r,{N:24,K:5}),obs=obsSeq(200,3),before=run(makeRigController(g),obs);
 const gg=growRig(g,r,{count:5});assert.equal(unpackRig(gg).N,29);assert.deepEqual(run(makeRigController(gg),obs),before);
 const back=shrinkRig(gg,r,{internalShare:0});assert.ok(back);assert.deepEqual(run(makeRigController(back),obs),before)}
console.log('growth by 5 cells leaves every motor output unchanged; removing an unread cell does too');
// 5. ticks and tonic cells
{const r=R(5),g=birthRig(r,{N:16,K:10,tonicShare:.15}),c=makeRigController(g),b=unpackRig(g);c.control(obsSeq(1,9)[0]);const h=c.hidden();
 for(let i=0;i<b.N;i++)if(b.role[i]===ROLE.TONIC)assert.equal(h[i],1);
 const g1=birthRig(R(5),{N:16,K:1,tonicShare:.15});assert.notDeepEqual(run(makeRigController(g1),obsSeq(50,2)),run(c,obsSeq(50,2)))}
console.log('tonic cells are +1 on every tick; ticks change the dynamics');
// 6. distance
{const r=R(3),g=birthRig(r,{N:24});assert.equal(rigDistance(g,g),0);assert.ok(rigDistance(g,mutateRig(g,r,{count:3}))>=0);assert.equal(rigDistance(g,birthRig(r,{N:12})),Infinity);assert.ok(isRigGenome(g))}
console.log('distance: 0 to itself, Infinity across sizes');
// v10: the pulse brain
{const {packRig,PULSE_HZ}=await import('../brain.mjs'),{T_SENS,T_ACT}=await import('../../engine/ternary.mjs');
 const r=R(41),g=birthRig(r,{N:24,K:10,kind:1});assert.equal(g[6],1);assert.ok(rigAudit(g).ok,rigAudit(g).text);
 let x=g;for(let k=0;k<300;k++){x=mutateRig(x,r,{count:2});if(k%50===0)x=growRig(x,r);if(k%70===0){const y=shrinkRig(x,r);if(y)x=y}}
 assert.ok(rigAudit(x).ok,rigAudit(x).text);assert.equal(x[6],1);assert.match(rigAudit(x).text,/PULSE brain/);
 const O=obsSeq(3,60);assert.deepEqual(run(makeRigController(x),O),run(makeRigController(x),O),'deterministic');
 const outs=run(makeRigController(x),O).flat();assert.ok(outs.every(Number.isFinite)&&new Set(outs.map(v=>v.toFixed(3))).size>10,'the motors move');
 assert.equal(crossRig(x,birthRig(R(2),{N:24,K:10}),r),null,'pulse and ternary never cross');assert.equal(rigDistance(x,birthRig(R(2),{N:x[1],K:10})),Infinity);
 // the two coordination tests: two cells at the same rate (2 Hz), each reading the other's pulses
 const pair=(wt,p0,p1)=>{const N=2,b={N,S:T_SENS,A:T_ACT,V:1,K:10,kind:1,role:Int8Array.from([1,1]),src:Int32Array.from([T_SENS+1,T_SENS+1,T_SENS+1,T_SENS,T_SENS,T_SENS]),
     w:Int8Array.from([wt,0,0,wt,0,0]),bias:Float64Array.from([4,4]),gain:Float64Array.from([p0,p1]),fb:new Float64Array(6),dec:new Int8Array(T_ACT*N)};
   const c=makeRigController(packRig(b)),o=obsSeq(5,1)[0];for(let s=0;s<1500;s++)c.control(o);const [a,bb]=c.phases(),d=((bb-a)%1+1)%1;return Math.min(d,1-d)};
 const free=pair(0,.1,.35),exc=pair(1,.1,.35),inh=pair(-1,.1,.2);
 assert.ok(Math.abs(free-.25)<.01,`uncoupled cells keep their gap (${free})`);assert.ok(exc<.03,`excitatory pair locks in step (gap ${exc})`);assert.ok(Math.abs(inh-.5)<.03,`inhibitory pair locks in anti-phase (gap ${inh})`);
 console.log(`pulse brain: valid after 300 mutations with growth and shrinkage; uncoupled pair keeps its gap ${free.toFixed(3)}; exciting pair locks in step (gap ${exc.toFixed(3)}); inhibiting pair locks in anti-phase (gap ${inh.toFixed(3)} of a cycle)`)}
// v10.0.2: the paced brain
{const {packRig,PULSE_HZ,KIND}=await import('../brain.mjs');
 // a paced brain whose tonic cells are all steady is the ternary brain, bit for bit
 for(const N of [16,48]){const t=birthRig(R(N+3),{N,K:10,tonicShare:.15}),b=unpackRig(t),O=obsSeq(300,N);
   const p=packRig({...b,kind:KIND.PACED});assert.deepEqual(run(makeRigController(p),O),run(makeRigController(t),O))}
 // birth: half the tonic cells pace at 0.75-1.5 Hz; the rest of the birth is the ternary birth
 const r=R(77),g=birthRig(r,{N:48,K:10,tonicShare:.15,kind:2}),b=unpackRig(g),a=rigAudit(g);assert.equal(g[6],2);assert.ok(a.ok,a.text);assert.match(a.text,/PACED brain/);
 const t0=birthRig(R(77),{N:48,K:10,tonicShare:.15}),b0=unpackRig(t0);assert.deepEqual(Array.from(b.src),Array.from(b0.src));assert.deepEqual(Array.from(b.dec),Array.from(b0.dec));
 const T=[...b.role.keys()].filter(i=>b.role[i]===ROLE.TONIC),P=T.filter(i=>b.bias[i]>0);assert.ok(P.length>=1&&P.every(i=>[1,1.5,.75].includes(PULSE_HZ[b.bias[i]-1])),'born pacemakers at 0.75-1.5 Hz');
 // a pacemaker is a three-level wave at its own rate: +1, 0, -1, 0, ... (+1 for a third of each cycle)
 {const c=makeRigController(g),o=obsSeq(1,5)[0],i=P[0],hz=PULSE_HZ[b.bias[i]-1],seq=[];for(let s=0;s<Math.round(4/hz/.02);s++){c.control(o);seq.push(c.hidden()[i])}
  const plus=seq.filter(v=>v===1).length/seq.length,minus=seq.filter(v=>v===-1).length/seq.length;assert.ok(Math.abs(plus-1/3)<.03&&Math.abs(minus-1/3)<.03,`pacemaker duty ${plus.toFixed(3)} / ${minus.toFixed(3)}`);
  let flips=0;for(let s=1;s<seq.length;s++)if(seq[s]===1&&seq[s-1]!==1)flips++;assert.ok(flips>=3&&flips<=5,`4 cycles at ${hz} Hz gave ${flips} rises`)}
 // mutations keep every rule, reach the pacemakers, and never cross kinds; growth stays neutral
 let x=g,paced=0;for(let k=0;k<3000;k++){const y=mutateRig(x,r,{count:1+Math.floor(3*r.next())});assert.ok(rigAudit(y).ok,rigAudit(y).text);const by=unpackRig(y),bx=unpackRig(x);
   if(by.N===bx.N)for(let i=0;i<by.N;i++)if(by.role[i]===ROLE.TONIC&&(by.bias[i]!==bx.bias[i]||by.gain[i]!==bx.gain[i]))paced++;x=y}
 assert.ok(paced>50,`pace moves reached the tonic cells (${paced})`);assert.equal(x[6],2);
 assert.equal(crossRig(x,birthRig(R(2),{N:48,K:10,tonicShare:.15}),r),null,'paced and ternary never cross');
 const O=obsSeq(200,8),gg=growRig(x,r,{count:4,tonicShare:.3});assert.deepEqual(run(makeRigController(gg),O),run(makeRigController(x),O),'growth is neutral in a paced brain');
 assert.ok(rigDistance(x,x)===0);const x2=(()=>{const bb=unpackRig(x),j=[...bb.role.keys()].find(i=>bb.role[i]===ROLE.TONIC);bb.bias[j]=bb.bias[j]>0?0:3;return packRig(bb)})();assert.equal(rigDistance(x,x2),1,'a pacemaker rate counts as a difference');
 console.log(`paced brain: all-steady equals ternary bit for bit; ${P.length} of ${T.length} tonic cells born pacing at 0.75-1.5 Hz as a three-level wave; 3000 mutations kept every rule (${paced} reached a pacemaker); growth neutral`)}
// v10.1.0: the plastic brain and muscle brains
{const {packRig,KIND,adaptRig,LEARN_RATES}=await import('../brain.mjs'),{T_ACT}=await import('../../engine/ternary.mjs');
 // born with every learning rate 0, a plastic brain is the ternary newborn, bit for bit
 for(const N of [16,48]){const t=birthRig(R(N+9),{N,K:10}),p=birthRig(R(N+9),{N,K:10,kind:KIND.PLASTIC}),O=obsSeq(300,N);
   assert.equal(p[6],KIND.PLASTIC);assert.ok(rigAudit(p).ok,rigAudit(p).text);assert.match(rigAudit(p).text,/PLASTIC brain, ternary cells, 0 of them learning/);
   assert.deepEqual(run(makeRigController(p),O),run(makeRigController(t),O));assert.deepEqual(run(makeRigController(adaptRig(t,{kind:KIND.PLASTIC})),O),run(makeRigController(t),O))}
 // learning: a few learning cells change wires only while the forward-speed sense is on, weights stay ternary, and each trial starts from the genome
 const base=birthRig(R(91),{N:32,K:10,kind:KIND.PLASTIC}),b=unpackRig(base),L=[...b.role.keys()].filter(i=>b.role[i]!==ROLE.TONIC).slice(0,12);
 for(const i of L){b.eta[i]=i%2?3:-3;b.fade[i]=1}const g=packRig(b);assert.ok(rigAudit(g).ok);assert.equal(rigAudit(g).learners,12);
 const moving=obsSeq(400,5).map(o=>{o[7]=.5;return o}),still=obsSeq(400,5).map(o=>{o[7]=0;return o});
 const c1=makeRigController(g);for(const o of moving)c1.control(o);const st=c1.stats(),w1=c1.weights();
 assert.ok(st.flips>0,`learning changed ${st.flips} wires`);assert.ok(w1.every(v=>v===-1||v===0||v===1),'weights stay ternary');
 const c0=makeRigController(g);for(const o of still)c0.control(o);assert.equal(c0.stats().flips,0,'no learning while the body is still');
 assert.deepEqual(Array.from(makeRigController(g).weights()),Array.from(unpackRig(g).w),'a new trial starts from the genome');
 c1.reset();assert.deepEqual(Array.from(c1.weights()),Array.from(unpackRig(g).w),'reset restores the genome weights');
 // mutation reaches the learning genes, keeps every rule, never crosses kinds; growth stays neutral even while cells learn
 const r=R(17);let x=g,moved=0;for(let k=0;k<3000;k++){const y=mutateRig(x,r,{count:1+Math.floor(3*r.next())});assert.ok(rigAudit(y).ok,rigAudit(y).text);
   const by=unpackRig(y),bx=unpackRig(x);if(by.N===bx.N)for(let i=0;i<by.N;i++)if(by.eta[i]!==bx.eta[i]||by.fade[i]!==bx.fade[i])moved++;x=y}
 assert.ok(moved>100,`learning-gene moves (${moved})`);assert.equal(x[6],KIND.PLASTIC);
 assert.equal(crossRig(x,birthRig(R(3),{N:32,K:10}),r),null,'plastic and ternary never cross');assert.ok(crossRig(x,birthRig(R(3),{N:32,K:10,kind:KIND.PLASTIC}),r)!==undefined);
 const gr=growRig(x,r,{count:3}),M=obsSeq(200,7).map(o=>{o[7]=.5;return o});assert.equal(gr[6],KIND.PLASTIC);assert.ok(rigAudit(gr).ok);assert.deepEqual(run(makeRigController(gr),M),run(makeRigController(x),M),'growth neutral in a learning brain');
 const sh=shrinkRig(gr,r,{internalShare:0});if(sh)assert.ok(rigAudit(sh).ok,rigAudit(sh).text);
 assert.ok(rigDistance(x,adaptRig(adaptRig(x,{kind:KIND.TERNARY}),{kind:KIND.PLASTIC}))>0,'dropping the learning genes counts as a difference');
 // muscle brains: 16 motors; each minus muscle votes like its plus muscle with the sign flipped; the plus half is the 8-motor newborn exactly
 const s8=birthRig(R(55),{N:48,K:10}),s16=birthRig(R(55),{N:48,K:10,A:16}),u8=unpackRig(s8),u16=unpackRig(s16);
 assert.equal(u16.A,16);assert.ok(rigAudit(s16).ok,rigAudit(s16).text);assert.match(rigAudit(s16).text,/16 motors \(8 muscle pairs\)/);
 assert.deepEqual(Array.from(u16.dec.slice(0,8*48)),Array.from(u8.dec));for(let q=0;q<8*48;q++)assert.equal(u16.dec[8*48+q],-u8.dec[q]||0);
 assert.deepEqual(Array.from(u16.src),Array.from(u8.src));
 const m16=adaptRig(s8,{motors:16});assert.deepEqual(Array.from(m16),Array.from(s16),'8 -> 16 motors gives the reciprocal muscle brain');
 assert.deepEqual(Array.from(adaptRig(m16,{motors:8})),Array.from(s8),'16 -> 8 motors keeps the plus muscles');
 const O2=obsSeq(100,4),o8=run(makeRigController(s8),O2),o16=run(makeRigController(s16),O2);assert.ok(o16.every((v,t)=>v.slice(0,8).every((y,a)=>Object.is(y,o8[t][a])&&Object.is(v[8+a],-y)||(y===0&&v[8+a]===0))),'minus commands are the plus commands negated');
 let y16=s16;for(let k=0;k<500;k++){y16=mutateRig(y16,r,{count:2});if(k%100===0)y16=growRig(y16,r)}assert.ok(rigAudit(y16).ok,rigAudit(y16).text);assert.equal(unpackRig(y16).A,16);
 const pm=birthRig(R(56),{N:24,K:10,A:16,kind:KIND.PLASTIC});assert.ok(rigAudit(pm).ok&&unpackRig(pm).A===16&&pm[6]===KIND.PLASTIC,'a plastic muscle brain');
 console.log(`plastic brain: newborn equals ternary bit for bit; 12 learning cells changed ${st.flips} wires in 8 s of forward motion and none while still; weights stay ternary; ${moved} learning-gene moves in 3000 mutations; growth neutral while learning`);
 console.log('muscle brains: 16 motors in reciprocal pairs at birth (the servo brain exactly); 8 <-> 16 conversion; rules hold under mutation and growth')}
console.log('brain_test ok');
