// HTTP integration: two reversible stages, progress, replay, download and restore.
// This uses mock rolls on purpose: it validates coordination, not actual walking.
import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {spawn} from 'node:child_process';import {fileURLToPath} from 'node:url';
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'hybrid_srv_'));
const port=19200+Math.floor(Math.random()*400),here=path.dirname(fileURLToPath(import.meta.url));
const srv=spawn(process.execPath,[path.join(here,'..','server.mjs'),'--port',String(port)],{env:{...process.env,RIG_WALKER_BACKEND:'mock',RIG_START_STRICT:'1',RIG_DATA_DIR:dir},stdio:['ignore','pipe','pipe']});
let output='';srv.stdout.on('data',x=>output+=x.toString());srv.stderr.on('data',x=>output+=x.toString());
const sleep=ms=>new Promise(r=>setTimeout(r,ms)),base=`http://127.0.0.1:${port}`;
async function api(route){const r=await fetch(base+route);assert.equal(r.status,200,route);return r.json()}
async function cmd(c,args={}){const r=await fetch(base+'/api/cmd',{method:'POST',body:JSON.stringify({cmd:c,args})});const b=await r.json();if(!r.ok)throw Error(`command ${c}: ${JSON.stringify(b)}`);return b}
try{
  for(let k=0;k<80&&!output.includes('at http');k++)await sleep(50);
  assert.match(output,/at http/,'mock walker HTTP startup');
  await cmd('set',{cfg:{brain:'strictFixed',compare:false,N:24,mixedSizes:false,maxCells:24,founders:6,lambda:2,trainCases:1,valCases:4,holdCases:4,valEvery:1,hybridEvoGens:3,hybridLearnSteps:6,hybridTracks:2,hybridCases:1,hybridValEvery:2,hybridAuto:true,governor:false,tuner:false,liveView:false,basin:false}});
  await cmd('start');
  let st;let sawLearning=false,sawEvolutionAgain=false,sawCheckpoints=false;
  for(let k=0;k<350;k++){
    await sleep(30);st=await api('/api/status');
    if(st.hybrid.events?.some(e=>e.kind==='enter')&&st.hybrid.championCount>=1)sawLearning=true;
    if(st.hybrid.events?.some(e=>e.kind==='leave'))sawEvolutionAgain=true;
    if(st.hybrid.cycle>=2){sawCheckpoints=true;break}
  }
  assert.ok(sawLearning,'automatic train stage reached');assert.ok(sawEvolutionAgain,'learner returned to strict evolution');
  await cmd('pause');st=await api('/api/status');assert.equal(st.mode,'paused');assert.ok(st.hybrid.cycle>=1);
  const x=await api('/api/hybrid/export');assert.equal(x.format,'WALKER_EVOLVE_LEARN_CHECKPOINT');assert.ok(x.tracks.length>=1);
  const replay=await cmd('test',{which:'learned',caseIndex:0});assert.ok(replay.id);
  const rs=await api('/api/replay');assert.equal(rs.brain.kind,6);assert.equal(rs.brain.A,16);assert.ok(rs.frames.length>10);
  await cmd('hybridSave');assert.ok(fs.existsSync(path.join(dir,'evolve-learn-checkpoint.json')));
  const restore=await cmd('hybridLoad');assert.ok(restore.ok);
  const e=await cmd('hybridEvolve');assert.ok(e.ok);st=await api('/api/status');assert.equal(st.hybrid.stage,'evolution');
  const pub=await api('/api/export');assert.ok(pub.cells.every(c=>c.genome[6]===4));
  await cmd('resume');await sleep(100);await cmd('pause');
  console.log('HTTP mock hybrid cycles: learning observed',sawLearning,'return to evolution',sawEvolutionAgain,'multiple cycles',sawCheckpoints,'replay frames',rs.frames.length);
  console.log('HTTP: checkpoint round-trip, status, real GUI routes, learned replay, strict archive PASS');
}finally{
  srv.kill('SIGTERM');for(let k=0;k<60&&srv.exitCode===null;k++)await sleep(100);
  fs.rmSync(dir,{recursive:true,force:true});
}
console.log('hybrid_server_test ok');
