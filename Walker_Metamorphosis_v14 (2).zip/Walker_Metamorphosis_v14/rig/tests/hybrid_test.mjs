import assert from 'node:assert/strict';
import fs from 'node:fs';import os from 'node:os';import path from 'node:path';
import {birthRig,makeRigController,rigAudit,KIND,isRigGenome,unpackRig} from '../brain.mjs';
import {toHeir,projectHeir,isHeir,topologyFingerprint,paramGroups,assertFrozen,HybridLearning} from '../core/hybrid.mjs';
import {Rng} from '../core/rng.mjs';
import {Lab} from '../lab.mjs';
import {makeWalkerPlant} from '../plants/walker.mjs';
const rr=new Rng(81742);
for(const n of [24,192,512,1024])for(const kind of [KIND.STRICT_FIXED,KIND.STRICT_PLASTIC]){
  const src=birthRig(rr,{N:n,K:3,V:5,A:16,kind});assert.ok(rigAudit(src).ok);
  const heir=toHeir(src),g=unpackRig(heir);assert.ok(isRigGenome(heir)&&isHeir(heir));
  assert.ok(g.w instanceof Float64Array);assert.ok(g.dec instanceof Float64Array);assert.ok(assertFrozen(src,heir));
  assert.equal(topologyFingerprint(src),topologyFingerprint(heir));
  const params=paramGroups(heir,{bias:true});assert.ok(params.wire.length>20&&params.motor.length>10&&params.bias.length>2);
  const ctrl=makeRigController(heir),obs=new Float64Array(36);for(let k=0;k<8;k++){obs[0]=k/2-2;const v=ctrl.control(obs);assert.equal(v.length,16);assert.ok(v.every(x=>Number.isFinite(x)&&Math.abs(x)<=1))}
  const mutated=heir.slice();mutated[params.motor[0]]=2.45;mutated[params.wire[0]]=-.65;mutated[params.bias[0]]=.23;
  assert.ok(assertFrozen(src,mutated));assert.ok(rigAudit(mutated).ok);
  const projected=projectHeir(mutated,src);assert.ok(rigAudit(projected).ok);assert.equal(projected[6],kind);
  assert.equal(topologyFingerprint(src),topologyFingerprint(projected));
  const good=unpackRig(projected);assert.ok([...good.w].every(x=>[-1,0,1].includes(x)));assert.ok([...good.dec].every(x=>[-1,0,1].includes(x)));
  const broken=mutated.slice();broken[8+1]=mutated[8+1]+1;assert.equal(assertFrozen(src,broken),false);
  console.log('brain '+n+' kind '+kind+': continuous controller, topology mask, projection, strict re-audit PASS');
}
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'walker_hybrid_'));
const L=new Lab({makePlant:()=>makeWalkerPlant({backend:'mock'}),dataDir:dir,quiet:true});
try{
  await L.cmd_set({cfg:{brain:'strictFixed',compare:false,N:24,maxCells:24,mixedSizes:false,founders:7,lambda:3,trainCases:1,trainSeconds:2,valCases:4,holdCases:4,hybridAuto:false,hybridTracks:3,hybridCases:1,hybridValEvery:2,hybridLearnSteps:4,hybridRate:.09,hybridSigma:.15,liveView:false,governor:false,tuner:false,basin:false,valEvery:1}});
  await L.cmd_start();for(let j=0;j<100&&!L.run.archive.best();j++)await new Promise(r=>setTimeout(r,10));
  assert.ok(L.run.archive.best(),'evolution produces a champion');await L.cmd_pause();
  const initialGen=L.run.generation,source0=L.run.archive.best().genome.slice(),count0=L.run.archive.cells.size;
  let result=await L.cmd_hybridLearn();assert.ok(result.tracks>=1&&result.tracks<=3);assert.equal(L.hybrid.stage,'learning');
  assert.ok(L.hybrid.tracks.every(t=>assertFrozen(t.source,t.genome)));
  for(let j=0;j<12;j++){let z=await L.hybrid.step();assert.ok(Number.isFinite(z.base)&&Number.isFinite(z.plus)&&Number.isFinite(z.minus));}
  assert.ok(L.hybrid.tracks.every(t=>t.updates>=3));assert.ok(L.hybrid.tracks.every(t=>assertFrozen(t.source,t.genome)));
  const snap=L.hybridPayload();assert.equal(snap.tracks.length,result.tracks);assert.ok(snap.stepCount>=12);
  assert.ok(fs.existsSync(L.saveHybrid()));
  const restart=new HybridLearning(L.run,{seed:1,config:L.cfg});restart.restore(snap);assert.equal(restart.stepCount,L.hybrid.stepCount);
  assert.equal(restart.rng.rngState,L.hybrid.rng.rngState);
  assert.ok(restart.tracks.every(t=>assertFrozen(t.source,t.best)));
  await L.cmd_test({which:'learned',caseIndex:0});assert.equal(L.lastReplay.brain.kind,6);assert.ok(L.lastReplay.frames.length);
  const finish=await L.cmd_hybridEvolve();assert.ok(finish.projected>=1);assert.equal(L.hybrid.stage,'evolution');
  assert.ok([...L.run.archive.cells.values()].every(e=>rigAudit(e.genome).ok),'archive never gets continuous genome');
  assert.ok(L.run.generation>=initialGen&&L.run.archive.cells.size>=1);
  assert.ok(rigAudit(source0).ok); // Saved source is never mutated.
  await L.cmd_resume();for(let k=0;k<200&&L.run.generation<=initialGen+1;k++)await new Promise(r=>setTimeout(r,10));await L.cmd_pause();assert.ok(L.run.generation>initialGen);
  console.log(`mock end-to-end: ${initialGen}→${L.run.generation} evol gens; ${snap.stepCount} learning updates; ${snap.tracks.length} genuinely distinct tracks; projections ${finish.projected} admissions ${finish.admitted}; preserved archive ${count0}→${L.run.archive.cells.size}`);
}finally{await L.close();fs.rmSync(dir,{recursive:true,force:true})}
console.log('hybrid_test ok');
