/* The lab: the pendulum v12 command set on the mock walker; v10.1.0 compare mode. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {Lab,decodeGenomeB64} from '../lab.mjs';
import {makeWalkerPlant} from '../plants/walker.mjs';
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'rig_lab_'));
const lab=new Lab({dataDir:dir,quiet:true,makePlant:()=>makeWalkerPlant({backend:'mock'})});
await lab.command('set',{cfg:{N:12,mixedSizes:false,founders:6,lambda:4,trainCases:2,valCases:4,holdCases:4,valEvery:2,passShare:10,compare:false}});   // single runs first; compare mode at the end
await lab.command('start',{keep:false});
await new Promise(r=>setTimeout(r,1500));
await lab.command('pause');
let s=lab.status();assert.equal(s.mode,'paused');assert.ok(s.generation>5,`generations ${s.generation}`);assert.ok(s.archive.cells.length>=2);assert.ok(s.history.length>2);assert.ok(s.champion);
console.log(`ran ${s.generation} generations: ${s.archive.cells.length} archive cells, rung ${s.rung} (cycle ${s.cycle}), champion ladder ${s.champion.quality.toFixed(3)}`);
await lab.command('set',{cfg:{mutations:1,lambda:6}});assert.equal(lab.run.cfg.mutations,1);assert.equal(lab.run.cfg.lambda,6);
await lab.command('test',{which:'current'});assert.ok(lab.lastReplay.frames.length>10&&lab.lastReplay.trace.length===lab.lastReplay.frames.length&&lab.lastReplay.trace[0].length===lab.lastReplay.brain.N&&lab.lastReplay.brain.role.length===lab.lastReplay.brain.N);
assert.ok(lab.status().bandit&&lab.status().governor&&lab.status().brain.internal>=1,'self-tuning state in the status');
await lab.command('test',{which:'champion'});assert.match(lab.lastReplay.label,/champion/);
for(const c of ['eval','crossval','audit','revisit','loadTop','rescore'])await lab.command(c);
assert.match(lab.auditText,/PASS/);
const payload=lab.exportPayload(),cells=payload.cells.length;await lab.command('clearArchive');assert.equal(lab.status().archive.cells.length,0);
lab.importPayload(JSON.parse(JSON.stringify(payload)));assert.equal(lab.status().archive.cells.length,cells);
await lab.command('save');assert.ok(fs.readdirSync(dir).some(f=>f.startsWith('champions-')));
await lab.command('clearArchive');await lab.command('load');assert.equal(lab.status().archive.cells.length,cells);
await lab.command('resume');await new Promise(r=>setTimeout(r,400));await lab.command('start',{keep:true});await new Promise(r=>setTimeout(r,400));await lab.command('pause');
assert.ok(lab.status().archive.cells.length>=cells,'continue keeps the archive');
assert.match(lab.biopsy(),/CURRENT BRAIN[\s\S]*MOTOR VOTES/);assert.match(lab.biopsy(),/KG SETTINGS TESTS  live settings:/);
{const L=lab.landscape();assert.ok(L.points.length>=3&&L.points.every(p=>Number.isFinite(p.x)&&Number.isFinite(p.y)),'landscape map');
 await lab.command('test',{which:'landscape',id:L.points.length-1});assert.match(lab.lastReplay.label,/map point/);
 console.log(`landscape: ${L.points.length} points placed; a map point replays`)}
{const L=lab.landscape();assert.equal(L.dims,8);assert.equal(L.points[0].c.length,8);assert.ok(L.share.every(x=>x>=0&&x<=1.0001));console.log(`map: ${L.dims} dimensions, first two hold ${(100*(L.share[0]+L.share[1])).toFixed(0)}% of the spread`)}
await lab.command('save');await lab.command('reset');await lab.command('set',{cfg:{liveEvery:.2}});await lab.command('startFromSave');await new Promise(r=>setTimeout(r,900));
{const s=lab.status();assert.ok(s.archive.cells.length>=2&&s.mode==='train');assert.ok(lab.lastReplay&&lab.lastReplay.live,'a live replay arrived while training');await lab.command('pause');
 console.log(`start from saved champions: ${s.archive.cells.length} cells loaded; live replay "${lab.lastReplay.label}" recorded while training ran`)}
await lab.command('reset');await lab.command('set',{cfg:{selection:'distance'}});await lab.command('start');await new Promise(r=>setTimeout(r,1500));await lab.command('pause');
{const s=lab.status();assert.equal(s.selection,'distance');assert.ok(s.farthest&&s.farthest.distRate>=0,'farthest in the status');await lab.command('test',{which:'farthest'});assert.match(lab.lastReplay.label,/farthest/);
 assert.match(lab.biopsy(),/selection=distance/);console.log(`distance mode in the lab: farthest ${s.farthest.distRate.toFixed(4)} m/s replayed; biopsy reports it`)}
await lab.command('reset');await lab.command('set',{cfg:{brain:'pulse',selection:'curriculum'}});await lab.command('start');await new Promise(r=>setTimeout(r,1500));await lab.command('pause');
{const bio=lab.biopsy();assert.match(bio,/PULSE brain/);assert.match(bio,/oscillator [0-9.]+ Hz/);await lab.command('test',{which:'champion'});assert.ok(lab.lastReplay.frames.length>0);
 console.log(`pulse brain in the lab: a run trained, the biopsy lists oscillators, and the champion replays (${lab.status().generation} generations)`)}
await lab.command('reset');await lab.command('set',{cfg:{brain:'paced',selection:'curriculum',tonicPct:15}});await lab.command('start');await new Promise(r=>setTimeout(r,1200));await lab.command('pause');
{const bio=lab.biopsy();assert.match(bio,/PACED brain/);assert.match(bio,/pacemaker [0-9.]+ Hz, phase/);assert.equal(lab.run.current[6],2);await lab.command('test',{which:'champion'});assert.ok(lab.lastReplay.frames.length>0);
 await lab.command('set',{cfg:{tonicPct:8}});console.log(`paced brain in the lab: a run trained, the biopsy lists its pacemakers, and the champion replays (${lab.status().generation} generations)`)}
// v10.0.1: joints run end to end, payloads record them, a mismatch is rescored, and the biopsy carries exact genomes
{const said=[],say0=lab.say.bind(lab);lab.say=t=>{said.push(t);say0(t)};
 await lab.command('reset');await lab.command('set',{cfg:{brain:'ternary',selection:'curriculum',joints:'servo'}});await lab.command('start');await new Promise(r=>setTimeout(r,1200));await lab.command('pause');
 assert.equal(lab.run.cfg.joints,'servo');assert.equal(lab.plant.joints(),'servo');assert.equal(lab.status().joints,'servo');
 const bio=lab.biopsy();assert.match(bio,/joints=servo/);assert.match(bio,/rngState=\d+ seed=\d+/);
 const m=bio.match(/CHAMPION GENOME  #(\d+)[^\n]*\n([A-Za-z0-9+/=]+)/);assert.ok(m,'champion genome in the biopsy');
 const best=lab.run.archive.best(),g=decodeGenomeB64(m[2]);assert.equal(+m[1],best.id);assert.ok(g.length===best.genome.length&&g.every((v,i)=>Object.is(v,best.genome[i])),'the genome round-trips exactly');
 const cur=bio.match(/CURRENT GENOME[^\n]*\n([A-Za-z0-9+/=]+)/);assert.ok(cur&&decodeGenomeB64(cur[1]).every((v,i)=>Object.is(v,lab.run.current[i])),'current genome exact');
 const p=lab.exportPayload();assert.equal(p.joints,'servo');
 await lab.command('save');await lab.command('reset');await lab.command('set',{cfg:{joints:'torque'}});await lab.command('startFromSave');await new Promise(r=>setTimeout(r,600));await lab.command('pause');
 assert.equal(lab.run.cfg.joints,'torque');assert.equal(lab.plant.joints(),'torque');assert.ok(said.some(t=>/Rescoring the loaded champions/.test(t)),'servo champions rescored for a torque run');
 const r=await lab.importMatched(JSON.parse(JSON.stringify(p)));assert.ok(r.rescored,'an imported servo payload is rescored for a torque run');
 const r2=await lab.importMatched(lab.exportPayload());assert.ok(!r2.rescored,'a matching payload is not rescored');
 lab.say=say0;console.log(`joints: a servo run trained; its biopsy carries champion #${best.id}'s exact genome (${g.length} values); a torque run rescored the servo champions on load`)}
// v10.0.2: friction is firm by default, reaches the plant and the biopsy, payloads record it, and older saves (no friction field) count as legacy
{const said=[],say0=lab.say.bind(lab);lab.say=t=>{said.push(t);say0(t)};
 await lab.command('reset');await lab.command('set',{cfg:{joints:'servo'}});assert.equal(lab.cfg.friction,'firm','firm friction by default');
 await lab.command('start');await new Promise(r=>setTimeout(r,800));await lab.command('pause');
 assert.equal(lab.run.cfg.friction,'firm');assert.equal(lab.plant.friction(),'firm');assert.equal(lab.status().friction,'firm');assert.match(lab.biopsy(),/friction=firm \(elliptic friction cone, impratio 10/);
 const p=lab.exportPayload();assert.equal(p.friction,'firm');
 const old=JSON.parse(JSON.stringify(p));delete old.friction;delete old.cfg.friction;
 const r=await lab.importMatched(old);assert.ok(r.rescored&&said.some(t=>/friction legacy -> firm/.test(t)),'a save from before v10.0.2 is rescored under firm friction');
 const r2=await lab.importMatched(lab.exportPayload());assert.ok(!r2.rescored,'a matching payload is not rescored');
 await lab.command('reset');await lab.command('set',{cfg:{friction:'legacy'}});await lab.command('start');await new Promise(r=>setTimeout(r,500));await lab.command('pause');
 assert.equal(lab.plant.friction(),'legacy');assert.equal(lab.plant.physics.friction,'legacy');assert.match(lab.biopsy(),/friction=legacy/);
 await lab.command('set',{cfg:{friction:'firm'}});lab.say=say0;
 console.log('friction: firm by default and in the biopsy; a pre-v10.0.2 save is rescored; legacy reaches the plant')}
// v14 retires the old two-arm Hebbian comparison from the public interface.
assert.equal(lab.cfg.compare,false,'new Metamorphosis experiments are single-arm by default');
await lab.close();fs.rmSync(dir,{recursive:true,force:true});
console.log('commands: test current and champion, eval, cross-validate, audit, revisit, load top, rescore, save/load, export/import, continue, biopsy');
console.log('lab_test ok');
