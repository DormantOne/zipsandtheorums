/* Real MuJoCo smoke for v14. Does not claim learning has improved walking. */
import assert from 'node:assert/strict';
import {makeWalkerPlant} from '../plants/walker.mjs';
import {birthRig,KIND,rigAudit} from '../brain.mjs';
import {Rng} from '../core/rng.mjs';
import {toHeir,projectHeir,assertFrozen} from '../core/hybrid.mjs';
const plant=await makeWalkerPlant({workers:1,backend:'inprocess'});
try {
  assert.equal(plant.setJoints('muscles'),'muscles');plant.setFriction('firm');
  const strict=birthRig(new Rng(47017),{N:24,K:3,V:6,A:16,kind:KIND.STRICT_FIXED});
  const heir=toHeir(strict);assert.ok(assertFrozen(strict,heir));
  const suite=plant.trainingSuite(47017,0,{trainCases:1,trainSeconds:2,difficulty:1});
  const result=await plant.evaluate([strict,heir],suite,{cfg:{rung:'posture'},train:true});
  assert.equal(result.length,2);
  for(const r of result){assert.equal(r.length,1);assert.ok(Number.isFinite(r[0].L)&&r[0].steps>0)}
  const projected=projectHeir(heir,strict);assert.ok(rigAudit(projected).ok);
  const replay=await plant.replay(heir,suite[0],{stride:10});
  assert.ok(replay.frames?.length>0);
  console.log('REAL MUJOCO v14 smoke PASS — strict & continuous 24-cell trials, ternary projection and replay;',result[0][0].steps,'physics steps');
} finally {await plant.close()}
