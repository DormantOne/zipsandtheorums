/* v14 lineage / nursery / shadow / checkpoint integration with mock physics.
   These tests do not claim demonstrated physical walking; real MuJoCo is separately smoke-tested on the host. */
import assert from 'node:assert/strict';
import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path';
import {Lab} from '../lab.mjs';
import {makeWalkerPlant} from '../plants/walker.mjs';
import {HybridLearning,assertFrozen,transferShadow} from '../core/hybrid.mjs';
import {rigAudit,unpackRig} from '../brain.mjs';
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'v14_meta_'));
const L=new Lab({makePlant:()=>makeWalkerPlant({backend:'mock'}),dataDir:dir,quiet:true});
try {
  await L.cmd_set({cfg:{brain:'strictFixed',compare:false,N:24,maxCells:24,mixedSizes:false,
      founders:6,lambda:2,trainCases:1,trainSeconds:2,valCases:4,holdCases:4,
      hybridAuto:false,hybridTracks:2,hybridLearnSteps:5,hybridCases:1,hybridValEvery:2,
      hybridNurseryCap:9,hybridNurseryTrials:3,hybridLineageCap:8,
      liveView:false,governor:false,tuner:false,basin:false,valEvery:1}});
  await L.cmd_start();for(let k=0;k<200&&!L.run?.archive.best();k++)await new Promise(r=>setTimeout(r,10));
  assert.ok(L.run.archive.best());await L.cmd_pause();
  await L.cmd_hybridLearn();const H=L.hybrid;
  assert.equal(H.stage,'learning');
  for(let k=0;k<8;k++)await H.step();
  const old=H.tracks.map(t=>({lineageId:t.lineageId,best:t.best.slice(),bestScore:t.bestVal.quality}));
  const release=await L.cmd_hybridEvolve();
  assert.equal(H.stage,'evolution');assert.ok(release.projected>=2);
  assert.ok(H.nursery.length>0,'at least one projected ternary baby survives independent of elite admission');
  for(const n of H.nursery){assert.ok(rigAudit(n.genome).ok,'nursery genomes are strictly ternary');assert.ok(assertFrozen(n.genome,n.shadow),'offspring carry matching continuous shadow');}
  const babyIds=new Set(H.nursery.map(n=>n.id));const initialAttempts=H.nurseryAttempts;
  for(let k=0;k<7;k++)await H.evolveNursery();
  assert.ok(H.nurseryAttempts>initialAttempts,'nursery gets mutation evaluations');
  assert.ok(H.events.some(e=>e.kind==='nursery-birth'),'offspring births recorded');
  assert.ok(H.events.some(e=>e.kind==='nursery-trial'),'nursery trials have an audit trail');
  // A learned weight is inherited only for identical endpoints, signs, roles and masks.
  const source=old.length&&H.lineages.find(t=>t.lineageId===old[0].lineageId);
  assert.ok(source); const shadow=transferShadow(source.source,source.source,source.best);
  const a=unpackRig(shadow),b=unpackRig(source.best);
  assert.deepEqual([...a.w],[...b.w]);assert.deepEqual([...a.dec],[...b.dec]);
  const serialized=H.serialize();assert.equal(serialized.version,2);
  const clone=new HybridLearning(L.run,{seed:55,config:L.cfg});clone.restore(JSON.parse(JSON.stringify(serialized)));
  assert.equal(clone.lineages.length,H.lineages.length);assert.equal(clone.nursery.length,H.nursery.length);
  assert.equal(clone.nurseryAttempts,H.nurseryAttempts);assert.equal(clone.stepCount,H.stepCount);
  assert.ok(clone.lineages.every(t=>assertFrozen(t.source,t.best)));
  const previous=new Set(old.map(x=>x.lineageId));
  await H.enter({count:2});assert.equal(H.stage,'learning');assert.ok(H.lineages.some(t=>previous.has(t.lineageId)),'original learner persists into the next cycle');
  assert.ok(H.tracks.some(t=>previous.has(t.lineageId)),'one prior champion is chosen to continue learning');
  const persistent=H.tracks.find(t=>previous.has(t.lineageId));
  assert.ok(persistent.updates>=4&&persistent.visits>=1,'learning updates and visits survive round-trip');
  await H.step(); await H.leave();assert.equal(H.stage,'evolution');assert.ok(H.cycle>=2);
  assert.ok([...L.run.archive.cells.values()].every(e=>rigAudit(e.genome).ok),'elite archive never acquires continuous parameters');
  console.log(`metamorphosis_test ok: 2 learning cycles; nursery births ${H.nurserySerial}; attempts ${H.nurseryAttempts}; lineages ${H.lineages.length}; strict archive safe`);
} finally {await L.close();fs.rmSync(dir,{recursive:true,force:true})}
