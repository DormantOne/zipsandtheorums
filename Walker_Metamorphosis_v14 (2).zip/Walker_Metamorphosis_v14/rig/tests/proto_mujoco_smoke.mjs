/* REAL MuJoCo v11 smoke (not a training-success claim). Run after npm install.
 * Uses the existing physical walker and original scoring in process.
 */
import assert from 'node:assert/strict';
import {makeWalkerPlant} from '../plants/walker.mjs';
import {makeContinuous} from '../continuous.mjs';
const plant=await makeWalkerPlant({workers:1,backend:'inprocess'});
try{
  assert.equal(plant.setJoints('muscles'),'muscles');plant.setFriction('firm');
  const genome=makeContinuous(47017),suite=plant.trainingSuite(47017,0,{trainCases:1,trainSeconds:2,difficulty:1});
  const result=await plant.evaluate([genome],suite,{cfg:{rung:'posture',tone:false},train:true});
  assert.equal(result.length,1);assert.equal(result[0].length,1);
  const t=result[0][0];assert.ok(Number.isFinite(t.L)&&Number.isFinite(t.rs.posture)&&t.steps>0,'real MuJoCo continuous controller returned valid scored trial');
  const replay=await plant.replay(genome,suite[0],{stride:10,tone:false});
  assert.ok(replay.frames?.length>0,'real MuJoCo replay frames');
  console.log('REAL MUJOCO proto smoke PASS · physics steps',t.steps,'ladder',t.L.toFixed(3),'frames',replay.frames.length);
}finally{await plant.close()}
