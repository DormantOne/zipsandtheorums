/* v11 plumbing-only deterministic tests: fake plant, NEVER a MuJoCo result. */
import assert from 'node:assert/strict';
import os from 'node:os';import fs from 'node:fs';import path from 'node:path';
import {makeContinuous,makeContinuousController,isContinuous,rewireContinuous,trainableIndices,C_LAYOUT,inspectContinuous,prng} from '../continuous.mjs';
import {RewardWalker} from '../core/reward_learner.mjs';
const obs=new Float64Array(36);obs[0]=.05;obs[1]=-.1;obs[12]=.2;obs[20]=-.3;
const seed=makeContinuous(1234),a=makeContinuousController(seed),b=makeContinuousController(seed);
assert.ok(isContinuous(seed));assert.equal(seed.length,770);assert.equal(inspectContinuous(seed).cells,100);assert.equal(trainableIndices().length,152);
for(let t=0;t<10;t++){let x=a.control(obs),y=b.control(obs);assert.deepEqual(Array.from(x),Array.from(y));assert.equal(x.length,16);for(let i=0;i<8;i++)assert.ok(Math.abs(x[i]+x[i+8])<1e-12)}
a.reset();b.reset();assert.deepEqual(Array.from(a.control(obs)),Array.from(b.control(obs)));
const tone=seed.slice();tone[C_LAYOUT.direct+6*8]=1;
const z=makeContinuousController(tone,{tone:true}).control(obs);assert.ok(Math.abs(z[0]+z[8])>1e-5,'tone adds nonreciprocal muscle activation');
const rng=prng(111),mut=rewireContinuous(seed,rng);assert.ok(isContinuous(mut.genome));assert.notDeepEqual(Array.from(seed),Array.from(mut.genome));
assert.throws(()=>makeContinuousController(new Float64Array([1,2,3])));
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'walker-v11-test-'));
const fakePlant=()=>({setJoints(){},setFriction(){},trainingSuite(n,e,c){return Array.from({length:c.trainCases},(_,j)=>({seed:n+e+j,steps:40}))},suites(seed,c){const vals=Array.from({length:c.valCases},(_,j)=>({seed:seed+j,steps:40}));return{val:vals,hold:vals}},
 async evaluate(genomes,cases){return genomes.map(g=>cases.map(({seed,steps})=>{const ob=obs.slice();ob[0]+=(seed%17)/100;const out=makeContinuousController(g).control(ob),quality=1-Math.abs(out[0]-.6),t={posture:quality,footfalls:quality*.7,distance:quality*.2};return{steps,rs:t,pass:{posture:quality>.75,footfalls:quality>.9,distance:false},L:quality,rate:out[0]*.03,desc:{duty:.6+out[0]*.1,coordination:.5,cadence:.1},row:{}}}))},async close(){} });
const run=new RewardWalker({dataDir:tmp,plantFactory:async()=>fakePlant()});run.fresh({seed:777,rounds:20,dirs:2,starts:1,rewiring:false,gate:1});
run.start();await run.promise;const st=run.status();assert.equal(st.round,20);assert.ok(st.spent>0&&st.rollouts>0);assert.ok(st.archive.length>=1);assert.equal(st.busy,false);assert.equal(st.block,1);assert.ok(fs.existsSync(run.file));
const clone=new RewardWalker({dataDir:tmp,plantFactory:async()=>fakePlant()});assert.equal(clone.status().round,20);const old=clone.state.brain.slice();clone.fuel(5);clone.start();await clone.promise;assert.equal(clone.status().round,25);assert.equal(clone.status().cfg.rounds,25);
const saved=clone.serialize(),c2=new RewardWalker({dataDir:fs.mkdtempSync(path.join(os.tmpdir(),'proto-import-')),plantFactory:async()=>fakePlant()});c2.restore(saved);assert.equal(c2.status().round,25);assert.ok(isContinuous(c2.state.brain));assert.ok(old.length===c2.state.brain.length);
await run.close();await clone.close();await c2.close();fs.rmSync(tmp,{recursive:true,force:true});console.log('protoneuron_test ok (controller, v11 reward loop, save/load, refill; fake plant only)');
