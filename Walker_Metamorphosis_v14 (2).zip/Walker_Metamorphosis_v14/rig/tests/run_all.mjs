import {readdirSync} from 'node:fs';import {spawnSync} from 'node:child_process';import path from 'node:path';import {fileURLToPath} from 'node:url';
// Individual legacy suites must start with legacy defaults even when invoked by
// the strict launcher. strict_server_test.mjs explicitly opts into strict mode.
const dir=path.dirname(fileURLToPath(import.meta.url));let failed=0;const files=readdirSync(dir).filter(f=>f.endsWith('_test.mjs')).sort();
for(const f of files){const r=spawnSync(process.execPath,[path.join(dir,f)],{stdio:'inherit',env:{...process.env,RIG_WALKER_BACKEND:'',RIG_START_STRICT:''}});if(r.status!==0){failed++;console.error(`${f} FAILED`)}}
if(failed){console.error(`${failed} of ${files.length} test files failed`);process.exit(1)}console.log(`ALL ${files.length} RIG TEST FILES PASS`);
