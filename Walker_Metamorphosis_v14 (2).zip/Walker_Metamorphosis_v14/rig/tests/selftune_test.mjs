/* The bandit and the plateau governor. */
import assert from 'node:assert/strict';
import {PRNG} from '../core/rng.mjs';
import {Bandit} from '../core/bandit.mjs';
import {Governor} from '../core/governor.mjs';
import {makeWalkerPlant} from '../plants/walker.mjs';
import {ChampionRun} from '../core/evolve.mjs';
const R=s=>{const f=PRNG(s);return {next:f}};
// 1. the bandit moves candidates toward what pays, keeps a floor, honours pins
{const b=new Bandit(),r=R(1);for(let i=0;i<4000;i++){const c=b.sample(r);b.credit(c,c.mutations===1&&r.next()<.3?1:r.next()<.05?1:0)}
 const m=b.snapshot().dims.mutations;assert.ok(m[0].share>.45,`share of 1 mutation ${m[0].share}`);assert.ok(m.every(x=>x.share>=.05-1e-9));
 const c=b.sample(r,{mutations:8});assert.equal(c.mutations,8);
 console.log(`bandit: 1 mutation paid 6x more often and now gets ${(100*m[0].share).toFixed(0)}% of candidates; no option below 5%; pins respected`)}
// 2. the governor: plateau -> audit -> one intervention -> outcome in the ledger
{const P=await makeWalkerPlant({backend:'mock'});
 const run=await new ChampionRun({plant:P,cfg:{N:24,lambda:6,trainCases:2,valCases:4,holdCases:4,yardstickN:2,valEvery:2,founders:4,bandit:true,internalShare:.5,tonicShare:.08},seed:2}).init();
 await run.advanceTo(Infinity,{maxGenerations:40});
 const G=new Governor({plateauGens:20,trialGens:10,eps:1e9});   // eps huge: nothing ever counts as an improvement
 for(let g=0;g<6;g++){run.generation+=10;await G.onRow(run,P)}
 const s=G.snapshot(),tries=Object.values(s.ledger).reduce((a,x)=>a+x.tries,0);
 assert.ok(s.plateaus>=1&&tries>=1,JSON.stringify(s));assert.ok(s.log.some(x=>/holdout audit/.test(x.text))&&s.log.some(x=>/plateau 1/.test(x.text)));
 console.log(`governor: ${s.plateaus} plateau(s), ${tries} trial(s) recorded; last: ${s.log.at(-1).text.slice(0,90)}…`)}
// 3. Thompson choice follows the ledger
{const G=new Governor({ledger:{grow:{tries:20,wins:12},switch:{tries:20,wins:1},explore:{tries:20,wins:1},refine:{tries:20,wins:1}}}),r=R(4),n={};
 for(let i=0;i<400;i++){const t=G.choose(r);n[t]=(n[t]||0)+1}assert.ok(n.grow>300,JSON.stringify(n));
 console.log(`governor choice: an intervention that broke 12 of 20 plateaus is chosen ${n.grow} times in 400`)}
// 4. the KG's settings tuner: ABBA windows per billion steps; adopts a clear winner; the ledger records it
{const {Tuner}=await import('../core/tuner.mjs');const r=R(8),cells=new Map([['a',{quality:1}]]);
 const run={cfg:{search:'champions',lambda:12,trainCases:6},generation:0,spent:0,rng:r,epoch:0,archive:{cells,best:()=>cells.get('a'),ranked:()=>[...cells.values()]}};
 const T=new Tuner({windowGens:100});
 for(let g=0;g<80000&&!(T.ledger['lambda=16']?.wins>=1&&!T.exp);g+=4){run.generation=g;run.spent+=4*run.cfg.lambda*1e5;cells.get('a').quality+=run.cfg.lambda===16?2e-4:5e-5;T.onRow(run)}  // per step, 16 candidates pay three times more
 const s=T.snapshot();assert.equal(run.cfg.lambda,16,'the paying value was adopted');assert.ok(s.ledger['lambda=16'].wins>=1);
 console.log(`tuner: ${T.log.filter(x=>/WON|did not win/.test(x.text)).length} decisions; lambda now ${run.cfg.lambda}; ledger ${JSON.stringify(s.ledger)}`);
 const T2=new Tuner({windowGens:100});T2.onRow(run);T2.abort(run,'test');assert.equal(T2.exp,null);}
// 5. v9.3.1: a due plateau trial waits for a running settings test; the tuner keeps its adoptions and reads both saved formats
{const P2=await makeWalkerPlant({backend:'mock'});const run2=await new ChampionRun({plant:P2,cfg:{N:12,lambda:4,trainCases:2,valCases:4,holdCases:4,yardstickN:2,valEvery:2,founders:2},seed:5}).init();await run2.advanceTo(Infinity,{maxGenerations:6});
 const G=new Governor({plateauGens:10,trialGens:5,eps:1e9});await G.onRow(run2,P2);run2.generation+=12;
 await G.onRow(run2,P2,{defer:true});assert.ok(G.due(run2.generation)&&!G.trial,'due but deferred');await G.onRow(run2,P2,{defer:false});assert.ok(G.trial,'starts once the test is over');
 const {Tuner}=await import('../core/tuner.mjs');const T3=new Tuner({ledger:{ledger:{'lambda=16':{tries:1,wins:1}},adopted:{lambda:16}}});assert.equal(T3.adopted.lambda,16);
 const fake={cfg:{lambda:20},generation:0};assert.deepEqual(T3.applyAdopted(fake),['lambda 16']);assert.equal(fake.cfg.lambda,16);
 const T4=new Tuner({ledger:{'peaks=6':{tries:1,wins:0}}});assert.equal(T4.ledger['peaks=6'].tries,1);
 console.log('plateau trial deferred while a settings test runs, then started; the KG\'s adoptions are applied to a new run; both saved ledger formats load')}
// 6. v10.0.1: one lucky improvement in one window no longer carries a test; a steep climb defers testing
{const {Tuner}=await import('../core/tuner.mjs');const cell={quality:2};
 const mk=()=>({cfg:{search:'champions',lambda:12,trainCases:6,earlyExit:true},generation:0,spent:0,rng:R(11),epoch:0,archive:{best:()=>cell,ranked:()=>[cell]}});
 const favour={'lambda=16':{tries:60,wins:60},'earlyExit=false':{tries:60,wins:0},'trainCases=8':{tries:60,wins:0}};   // Thompson picks lambda 16
 {const run=mk(),T=new Tuner({ledger:{...favour},windowGens:100});cell.quality=2;let jumped=false;
  for(let g=0;g<2000&&!T.log.some(x=>/did not win|WON/.test(x.text));g+=4){run.generation=g;run.spent+=4*run.cfg.lambda*1e5;
    if(T.exp&&T.exp.w===1&&!jumped&&run.generation-T.exp.start.gen>=40){cell.quality+=.01;jumped=true}   // one improvement, in the first "new" window only
    T.onRow(run)}
  const d=T.log.find(x=>/did not win|WON/.test(x.text));assert.ok(d,'a decision was made');assert.equal(run.cfg.lambda,12,'a one-window jump is not adopted');assert.match(d.text,/only 1 of 2 halves/);
  console.log(`tuner noise rule: a single lucky jump in one window -> "${d.text.slice(0,70)}…"`)}
 {const run=mk(),T=new Tuner({ledger:{...favour},windowGens:100});cell.quality=1;
  for(let g=0;g<1200;g+=4){run.generation=g;run.spent+=1e6;cell.quality*=1.0015;T.onRow(run)}   // ~4 % per window: a steep climb
  assert.equal(T.exp,null,'no test during a steep climb');assert.ok(T.log.some(x=>/still climbing/.test(x.text)));
  for(let g=1200;g<1600;g+=4){run.generation=g;run.spent+=1e6;T.onRow(run)}                      // flat: the test starts
  assert.ok(T.exp,'a test starts once the climb flattens');console.log('tuner climb guard: no test while the champion climbs 4 % per window; one starts once it is flat')}
 {const run=mk(),T=new Tuner({ledger:{...favour},windowGens:100});cell.quality=1;   // a value that pays in every window is still adopted
  for(let g=0;g<4000&&!T.log.some(x=>/WON|did not win/.test(x.text));g+=4){run.generation=g;run.spent+=4*run.cfg.lambda*1e5;if(T.exp)cell.quality+=run.cfg.lambda===16?4e-5:1e-5;T.onRow(run)}
  assert.equal(run.cfg.lambda,16);assert.match(T.log.at(-1).text,/won both halves/);console.log('tuner: a value that pays in both halves is adopted')}}
console.log('selftune_test ok');
