import assert from 'node:assert/strict';
import {PRNG} from '../core/rng.mjs';
import {KIND,ROLE,birthRig,packRig,unpackRig,isRigGenome,makeRigController,mutateRig,rigAudit,rigView,growRig,shrinkRig,crossRig,adaptRig,rigDistance} from '../brain.mjs';
import {T_SENS} from '../../engine/ternary.mjs';
const R=seed=>({next:PRNG(seed)});
const obs=new Float64Array(64); obs[7]=.5;
const run=(g,n=80)=>{const c=makeRigController(g);const out=[];for(let i=0;i<n;i++){const x=c.control(obs);assert.ok(x.every(Number.isFinite));assert.ok(Array.from(c.hidden().slice(0,c.N)).every(t=>t===-1||t===0||t===1));out.push(Array.from(x))}return out};
const checkStrict=g=>{const b=unpackRig(g);assert.ok(isRigGenome(g));const a=rigAudit(g);assert.ok(a.ok,a.text);for(let i=0;i<b.N;i++){assert.equal(b.bias[i],0);assert.equal(b.gain[i],1);for(let j=0;j<3;j++){assert.equal(b.fb[3*i+j],0);assert.ok([-1,0,1].includes(b.w[3*i+j]))}}return b};
for(const n of [64,192,512,1024])for(const k of [KIND.STRICT_FIXED,KIND.STRICT_PLASTIC]){const g=birthRig(R(n+k),{N:n,K:10,kind:k,A:16}),b=checkStrict(g);assert.equal(b.N,n);assert.equal(b.A,16);if(n<=192)run(g,4)}
console.log('Strict birth and audit pass for 64/192/512/1024 cells, 16 muscles, 3 ternary weights per cell.');
const g=birthRig(R(100),{N:48,K:10,kind:KIND.STRICT_FIXED,A:16}),p=birthRig(R(100),{N:48,K:10,kind:KIND.STRICT_PLASTIC,A:16});
assert.deepEqual(run(g),run(p),'zero-rate strict plastic birth behaves identically to strict fixed');
assert.deepEqual(Array.from(adaptRig(g,{kind:KIND.STRICT_PLASTIC})),Array.from(p));
assert.deepEqual(Array.from(adaptRig(p,{kind:KIND.STRICT_FIXED})),Array.from(g));
assert.equal(crossRig(g,p,R(90)),null,'fixed and plastic cannot cross');
const corrupted=unpackRig(g);corrupted.bias[2]=.25;corrupted.gain[4]=2;corrupted.fb[10]=1;const bad=packRig(corrupted);assert.ok(!rigAudit(bad).ok,'audit rejects hidden firing parameters');
assert.deepEqual(run(g),run(bad),'strict controller ignores hidden firing fields even in malformed genome');
console.log('Zero-bias / unit-gain / zero-preference enforced; hidden fields cannot affect neural decisions.');
// Synthetic neuron: three fixed +1 tonic inputs or 0, exact sign(sum).
let b=unpackRig(birthRig(R(21),{N:16,K:2,kind:KIND.STRICT_FIXED,A:8}));
const cell=b.role.findIndex(r=>r===ROLE.IO),tonic=b.role.findIndex(r=>r===ROLE.TONIC),S=b.S;
assert.ok(cell>=0&&tonic>=0);
for(let i=0;i<3;i++){b.src[3*cell+i]=S+tonic;b.w[3*cell+i]=0}
for(const [w,y] of [[[1,0,0],1],[[-1,0,0],-1],[[1,-1,0],0],[[1,1,-1],1]]){
  for(let j=0;j<3;j++)b.w[3*cell+j]=w[j];const c=makeRigController(packRig(b));c.control(obs);assert.equal(c.hidden()[cell],y,'sign(sum) exact '+w);}
console.log('Exact sign(sum) firing tested for −1, 0, +1 with ternary weights.');
let pp=unpackRig(p);const eligible=[...pp.role.keys()].filter(i=>pp.role[i]!==ROLE.TONIC).slice(0,12);for(const i of eligible){pp.eta[i]=i%2?-3:3;pp.fade[i]=1}const active=packRig(pp);checkStrict(active);
const c=makeRigController(active);for(let i=0;i<400;i++)c.control(obs);assert.ok(c.stats().flips>0,'plastic weights flip during forward movement');assert.ok(Array.from(c.weights()).every(v=>[-1,0,1].includes(v)));
c.reset();assert.equal(c.stats().flips,0);assert.deepEqual(Array.from(c.weights()),Array.from(pp.w),'trial reset restores inherited weights');
const still=new Float64Array(obs);still[7]=0;const d=makeRigController(active);for(let i=0;i<400;i++)d.control(still);assert.equal(d.stats().flips,0);
console.log('Strict plastic learning changes only ternary synapses; resets per trial; no forward sensor means no learning.');
const r=R(719);let x=active,changed=0;
for(let i=0;i<1200;i++){const old=unpackRig(x);const y=mutateRig(x,r,{count:2+Math.floor(3*r.next()),strong:i%40===0});const nb=checkStrict(y);for(let j=0;j<nb.N;j++)if(nb.eta[j]!==old.eta[j])changed++;x=y;}
assert.ok(changed>0,'plastic rule evolves');const gr=growRig(x,r,{count:4}),sh=shrinkRig(gr,r,{});checkStrict(gr);if(sh)checkStrict(sh);run(gr,20);
const f=adaptRig(x,{kind:KIND.STRICT_FIXED});checkStrict(f);assert.ok(rigDistance(f,x)===Infinity);assert.ok(crossRig(x,birthRig(R(808),{N:48,kind:KIND.STRICT_PLASTIC}),r)!==null);
console.log(`1200 mutations preserve strict invariant and evolve learning genes (${changed} rate changes); growth, shrink, crossover pass.`);
console.log('strict_test ok');
