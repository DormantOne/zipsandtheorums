# Walker v16.1 — Precision + Diverse Champions

The simplified version of v16. **No ecosystem, no four protected gait niches.** The existing behavioral-cell archive, champion pool, differentiated basin peaks, immigrants, and Metamorphosis nursery retain diversity as before.

- One smooth-gated locomotion reward in **evolution, learning, nursery, validation** (Fitness selection = `smooth`). Posture/footfalls gradually activate the forward-distance reward, with penalties for falling, drag and injury.
- ACBA-**inspired**, evolution-only paired high-precision latent probes. MuJoCo always evaluates strict ternary controllers. Ordinary mutation, crossover, and escape remain.
- Metamorphosis alternates 30 evolution generations with **24 continuous learning updates** across 3 champions; nursery and lineages unchanged.
- The same physical MuJoCo muscles/friction, and existing multi-peak diverse-champions search.

## Start

On Mac double-click **`START_WALKER_V16_1_MAC.command`**, or on Windows launch `START_WALKER_V16_1_WINDOWS.bat`. Requires Node.js 22+, installs MuJoCo and Three.js on first run. Open **http://127.0.0.1:8799** and click **START METAMORPHOSIS**.

The data folder is `data_precision_champions_v16_1` and the port is 8799; these are separate from v14/v15/v16. Do not overwrite the older experiment archives. Stop on Mac with `STOP_WALKER_V16_1_MAC.command` or export both champion archive and hybrid learning checkpoint.

## Why this is a separate experiment

The combination has **not yet demonstrated improved walking**. The previous v14 breakout at ~11,000 generations cannot be attributed to v15/v16 methods. Evaluate against v14 and smooth v15 at matched physics budgets, using previously unseen holdouts and actual net displacement/distance success.

### ACBA caveat

ACBA's source MNIST model uses continuous latent weights evaluated through a binary sign projection and exact bit kernels. This walker adapts the **latent-state idea** to fitness-difference evolutionary probes. It is not the original ACBA algorithm and does not use its bit kernels. Reference code is retained under `reference_acba_mnist/`.
