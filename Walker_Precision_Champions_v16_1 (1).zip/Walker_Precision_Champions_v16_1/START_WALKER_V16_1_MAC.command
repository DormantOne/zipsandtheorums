#!/bin/bash
# Independent v16.1 Walker launcher; never touches v14 / v15 / v16 data.
cd "$(dirname "$0")" || exit 1
PORT=8799
DIR="$(pwd)/data_precision_champions_v16_1"
URL="http://127.0.0.1:$PORT"
export RIG_PORT="$PORT" RIG_DATA_DIR="$DIR" RIG_WORKERS=4
unset RIG_START_STRICT
pause_close(){ read -r -p "Press Enter to close this window." _; }
echo '=== WALKER v16.1 · SMOOTH FITNESS + ACBA + DIVERSE CHAMPIONS ==='
command -v node >/dev/null 2>&1 || { echo 'Node.js 22+ is required: https://nodejs.org'; pause_close; exit 1; }
node -e "process.exit(Number(process.versions.node.split('.')[0])>=22?0:1)" || { echo 'Node.js 22+ required.'; pause_close; exit 1; }
mkdir -p "$DIR"
if curl -fsS -m 2 "$URL/api/status" >/dev/null 2>&1; then
  echo 'Walker v16.1 is already running. Opening it.'; open "$URL"; exit 0
fi
if [ ! -d node_modules/@mujoco/mujoco ] || [ ! -d node_modules/three ]; then
  echo 'Installing MuJoCo and Three.js (internet required first run)...'
  npm install --no-audit --no-fund || { echo 'Dependency install failed. No training started.'; pause_close; exit 1; }
fi
if [ ! -f "$DIR/.verified_v16_1" ]; then
  echo 'Running regression tests...'
  node rig/tests/run_all.mjs || { echo 'Tests failed. No server started.'; pause_close; exit 1; }
  echo 'Checking the real MuJoCo plant...'
  node rig/tests/metamorphosis_mujoco_smoke.mjs || { echo 'MuJoCo smoke failed. No server started.'; pause_close; exit 1; }
  date > "$DIR/.verified_v16_1"
fi
rm -f "$DIR/server.pid"
RIG_START_STRICT=0 nohup node rig/server.mjs >> "$DIR/server.log" 2>&1 &
PID=$!
command -v caffeinate >/dev/null && caffeinate -is -w "$PID" >/dev/null 2>&1 &
for i in $(seq 1 80); do
  [ "$(cat "$DIR/server.pid" 2>/dev/null)" = "$PID" ] && break
  kill -0 "$PID" 2>/dev/null || break
  sleep 0.2
done
if ! kill -0 "$PID" 2>/dev/null; then
  echo 'Server failed to start:'; tail -30 "$DIR/server.log"; pause_close; exit 1
fi
open "$URL"
echo "Walker v16.1 running: $URL"
echo 'Press START METAMORPHOSIS · EVOLVE / LEARN / NURSERY in the page.'
