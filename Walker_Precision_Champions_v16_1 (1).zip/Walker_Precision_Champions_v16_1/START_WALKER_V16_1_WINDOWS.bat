@echo off
cd /d "%~dp0"
set "RIG_PORT=8799"
set "RIG_DATA_DIR=%CD%\data_precision_champions_v16_1"
set "RIG_WORKERS=4"
set "RIG_START_STRICT="
echo === WALKER v16.1 SMOOTH + ACBA + DIVERSE CHAMPIONS ===
where node >nul 2>&1
if errorlevel 1 (echo Node.js 22+ is needed. & goto :fail)
if not exist data_precision_champions_v16_1 mkdir data_precision_champions_v16_1
if not exist node_modules\@mujoco\mujoco (
 call npm install --no-audit --no-fund
 if errorlevel 1 goto :fail
)
if not exist node_modules\three (
 call npm install --no-audit --no-fund
 if errorlevel 1 goto :fail
)
if not exist data_precision_champions_v16_1\.verified_v16_1 (
 node rig\tests\run_all.mjs
 if errorlevel 1 goto :fail
 node rig\tests\metamorphosis_mujoco_smoke.mjs
 if errorlevel 1 goto :fail
 echo verified>data_precision_champions_v16_1\.verified_v16_1
)
set "RIG_START_STRICT=0"
start "Walker v16.1" /min cmd /c "node rig\server.mjs >> data_precision_champions_v16_1\server.log 2>&1"
timeout /t 3 >nul
start "" http://127.0.0.1:8799
exit /b 0
:fail
echo Setup/tests failed; server was not started.
pause
exit /b 1
