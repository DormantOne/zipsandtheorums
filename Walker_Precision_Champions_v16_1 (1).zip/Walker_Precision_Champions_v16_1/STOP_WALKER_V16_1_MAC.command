#!/bin/bash
cd "$(dirname "$0")" || exit 1
DIR="$(pwd)/data_precision_champions_v16_1"
PID="$(cat "$DIR/server.pid" 2>/dev/null)"
if [ -n "$PID" ] && kill -0 "$PID" 2>/dev/null; then
  echo "Saving and stopping Walker v16.1 ($PID)..."
  curl -fsS -m 5 -X POST -H 'Content-Type: application/json' -d '{"cmd":"shutdown"}' http://127.0.0.1:8799/api/cmd >/dev/null 2>&1 || kill -TERM "$PID" 2>/dev/null
else
  echo 'No running Walker v16.1 server found.'
fi
