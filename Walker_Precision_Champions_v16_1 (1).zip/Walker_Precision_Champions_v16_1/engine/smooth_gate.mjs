/* Walker v15: continuously gated, per-physical-trial locomotion objective.
   All quantities come from the SAME rollout. No global curriculum clock is used.
   x: 0..1 survival/posture; y: 0..1 coordinated footfalls;
   z: net forward cm/s (not foot cycling, absolute distance, or impulses).

   G(x,y) = sigmoid((x-.80)/.08) * sigmoid((y-.75)/.10)
   R = .6(1-exp(-4x)) + .6(1-exp(-4y))
       + (.15+3 G) log(1 + max(0,z)/6) - P

   Gentle-contact and reverse-motion terms are always active. No conditional
   tier cutoff or qFitness multiplier erases the velocity gradient.
   Scores reported separately: this is the training/selection objective; actual
   clean speed, raw forward rate, footfalls, injury, and distance pass are kept.
*/
const snum=(v,d=0)=>Number.isFinite(Number(v))?Number(v):d;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const sigmoid=v=>v>=0?1/(1+Math.exp(-v)):Math.exp(v)/(1+Math.exp(v));
const softplus=(v,k=4)=>Math.max(0,v)+Math.log1p(Math.exp(-k*Math.abs(v)))/k;
export const SMOOTH_GATE_VERSION='smooth-intrinsic-gate-v1';
export const SMOOTH_GATE_PARAMETERS=Object.freeze({standCenter:.80,standWidth:.08,feetCenter:.75,feetWidth:.10,
  standWeight:.60,feetWeight:.60,forwardBase:.15,forwardBonus:3,forwardScaleCmps:6});
export function smoothGaitReward(o,raw={}){
  // All terms are same-trial; nonfoot contact and slide penalized even after mastery.
  const x=clamp(snum(o.survival)*Math.exp(-.07*softplus(snum(o.harm)-.8,5)),0,1);
  const y=clamp(snum(o.footfall??o.footQuality),0,1);
  const gate=sigmoid((x-.8)/.08)*sigmoid((y-.75)/.10);
  const z=Math.max(0,snum(raw.forwardSpeedMps))*100; // original physics net torso displacement
  const posture=.6*(-Math.expm1(-4*x));
  const feet=.6*(-Math.expm1(-4*y));
  const weight=.15+3*gate;
  const forward=weight*Math.log1p(z/6);  // unsaturated log: speed keeps paying above 6 cm/s
  const secs=Math.max(.01,snum(raw.fullEpisodeSeconds,1));
  const backwardCmps=Math.max(0,-snum(raw.gait?.signedAutonomousDistanceM))/secs*100;
  const harmPenalty=.22*softplus(snum(o.harm)-.55,4);
  const slidePenalty=.10*softplus(snum(o.slide)-.50,4);
  const fallPenalty=.6*(1-clamp(snum(o.survival),0,1));
  const backwardsPenalty=.24*Math.log1p(backwardCmps/6);
  const penalty=harmPenalty+slidePenalty+fallPenalty+backwardsPenalty;
  const score=posture+feet+forward-penalty;
  return {score,x,y,z,gate,weight,posture,feet,forward,penalty,harmPenalty,slidePenalty,fallPenalty,backwardsPenalty};
}
