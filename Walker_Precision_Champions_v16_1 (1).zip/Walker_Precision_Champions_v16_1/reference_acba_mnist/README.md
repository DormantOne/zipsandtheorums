# acba: exact bit kernels for binary neural nets

`acba.py` is the library (one file). `mnist_compare.py` races it against a usual float network on MNIST.

## Run it

- **Mac:** double-click `run_mac.command`. The first time, right-click it and choose Open.
- **Windows:** double-click `run_windows.bat`.
- **By hand:** `pip install numpy numba`, then `python mnist_compare.py`. Add `--quick` for a 2-epoch smoke test.

The first run sets up a private `.venv`, installs numpy and numba, downloads MNIST (11 MB), and compiles the kernels. Later runs skip all of that. Results land in `results.md` and `results.json`.

## What it compares

Both networks are 784 → 1024 → 1024 → 10, trained for the same number of epochs.

1. **Usual float MLP**: float32 weights, ReLU, Adam.
2. **Binary MLP**: ±1 weights and ±1 activations. It trains with ordinary float math, using sign weights and straight-through gradients. It is then compiled so that each hidden unit is a single integer threshold.

The binary MLP is then run three ways:
- the usual way, with dense float32 matmuls;
- on acba's packed popcount kernel;
- on whatever kernel acba's dispatcher picks for each layer.

All three must give bit-for-bit identical results, and the script checks that they do.

## The kernels

Every kernel computes the same integer for each image `b` and output unit `o`. That integer is the sum of the ±1 weights `w[o, i]` over the inputs `i` that are 1.

| kernel | idea from the framework | cost per image |
|---|---|---|
| `packed` | AND + popcount on 64-bit words | outputs × words |
| `sparse` | add the weight rows of the 1 bits | outputs × ones |
| `runs` | run-length input + weight prefix sums (RSBE, integer form) | outputs × runs × 2 |
| `lut` | Four-Russians byte tables; all-zero bytes are skipped | outputs × nonzero bytes |

The dispatcher works through each layer in four steps. It inspects the layer's real inputs, checks each kernel against the float32 matmul, times it at each batch size, and keeps the fastest exact one for that batch size. Kernels within 10% of the fastest count as tied, and the tie goes to the smaller weight encoding. `predict()` uses the picks for the nearest calibrated batch size.

## Using the library

```python
import acba
params = acba.train_binary_mlp(train_images, train_labels)   # uint8 images, shape (N, 784)
net = acba.compile_binary_mlp(params, train_images)
net.calibrate(train_images[:10000])     # fastest exact kernel per layer, for batches of 1 and 1000
labels = net.predict(images)
```
