"""acba - Adaptive Compressed Binary Algebra, applied to binary neural nets.

What's in here
  * Bit-packed 0/1 data: uint64 words, little-endian, zero padded.
  * Four exact integer kernels for a binary linear layer. With weights
    w = +1/-1 (stored as bit 1/0), every kernel computes the same masked sum

        S[b, o] = sum of w[o, i] over the positions i where x[b, i] == 1

        packed  AND + popcount on machine words           (the core engine)
        sparse  add up the weight rows of the 1 bits       (sparse row selection)
        runs    run-length input + weight prefix sums      (the RSBE idea, integer form)
        lut     Four-Russians byte tables, zero bytes skipped

    A +-1 input gets its dot product back as  x.w = 2*S - sum(w).
  * A dispatcher that looks at a layer's real inputs, checks every kernel
    against the dense float32 matmul, times them at each batch size, and
    keeps the fastest exact one per batch size.
  * A binary MLP: trained with ordinary float math (sign weights, sign
    activations, straight-through gradients), then compiled so each hidden
    unit's batch norm + sign becomes one integer threshold on S.

"Exact" means bit-for-bit. The dense float32 path is exact here too, because
every partial sum is an integer far below 2**24, so it doubles as the
independent reference every kernel is checked against.

Threads: every compiled function is plain single-threaded machine code that
releases the GIL. A big batch is split into blocks of rows that run on a pool
of Python threads, one core each; a small batch runs on the calling thread.
(Numba's own thread team falls back to a slow pool on machines without
OpenMP, Macs included, and made single images 20x slower there.)
"""
import math
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor

import numpy as np
from llvmlite import ir
from numba import njit, types
from numba.extending import intrinsic

assert sys.byteorder == "little", "acba packs bits little-endian (x86 and Apple Silicon are)"

KERNELS = ("packed", "sparse", "runs", "lut")
PARALLEL_ROWS = 64        # batches at least this big are split across cores
_ONE = np.uint64(1)
_jit = njit(cache=True, nogil=True)
_pool = None


def _workers():
    return os.cpu_count() or 1


def for_row_blocks(rows, fn):
    """Run fn(lo, hi) over blocks of rows: directly for small batches, otherwise
    about two blocks per core on a thread pool (blocks never share rows)."""
    global _pool
    if rows < PARALLEL_ROWS or _workers() == 1:
        fn(0, rows)
        return
    if _pool is None:
        _pool = ThreadPoolExecutor(max_workers=_workers())
    size = max(32, -(-rows // (2 * _workers())))
    for job in [_pool.submit(fn, lo, min(rows, lo + size)) for lo in range(0, rows, size)]:
        job.result()


# ------------------------------------------------------------------ bit intrinsics
@intrinsic
def _popcnt(typingctx, x):
    """Number of 1 bits in a uint64: POPCNT on x86, CNT on ARM."""
    def codegen(context, builder, sig, args):
        fn = builder.module.declare_intrinsic("llvm.ctpop", [ir.IntType(64)])
        return builder.call(fn, args)
    return types.int64(types.uint64), codegen


@intrinsic
def _ctz(typingctx, x):
    """Index of the lowest 1 bit of a nonzero uint64: TZCNT on x86, RBIT+CLZ on ARM."""
    def codegen(context, builder, sig, args):
        i64 = ir.IntType(64)
        fn = builder.module.declare_intrinsic(
            "llvm.cttz", [i64], ir.FunctionType(i64, [i64, ir.IntType(1)]))
        return builder.call(fn, [args[0], ir.Constant(ir.IntType(1), 1)])
    return types.int64(types.uint64), codegen


# ------------------------------------------------------------------ representations
def words(n):
    """uint64 words needed for n bits."""
    return (n + 63) // 64


def pack_bits(bits):
    """(B, n) array of 0/1 -> (B, words(n)) uint64. Bit i of a row is bit i % 64 of word i // 64."""
    bits = np.asarray(bits)
    B, n = bits.shape
    out = np.zeros((B, words(n) * 8), np.uint8)
    out[:, : (n + 7) // 8] = np.packbits(bits != 0, axis=1, bitorder="little")
    return out.view(np.uint64)


def unpack_bits(Xp, n):
    """Inverse of pack_bits: (B, K) uint64 -> (B, n) uint8 of 0/1."""
    return np.unpackbits(np.ascontiguousarray(Xp).view(np.uint8), axis=1, count=n, bitorder="little")


@_jit
def _binarize_pack(img, cut, out):
    B, n = img.shape
    for b in range(B):
        for k in range(out.shape[1]):
            w = np.uint64(0)
            base = k * 64
            for j in range(min(64, n - base)):
                if img[b, base + j] > cut:
                    w |= _ONE << np.uint64(j)
            out[b, k] = w


@_jit
def _threshold_pack(S, thr, flip, out):
    B, O = S.shape
    for b in range(B):
        for k in range(out.shape[1]):
            w = np.uint64(0)
            base = k * 64
            for j in range(min(64, O - base)):
                o = base + j
                if (S[b, o] >= thr[o]) != flip[o]:
                    w |= _ONE << np.uint64(j)
            out[b, k] = w


@_jit
def _count_ones(Xp, cnt):
    for b in range(Xp.shape[0]):
        c = 0
        for k in range(Xp.shape[1]):
            c += _popcnt(Xp[b, k])
        cnt[b] = c


@_jit
def _count_runs(Xp, cnt):
    for b in range(Xp.shape[0]):
        c = 0
        carry = np.uint64(0)
        for k in range(Xp.shape[1]):
            x = Xp[b, k]
            c += _popcnt(x & ~((x << _ONE) | carry))   # 1s whose previous bit is 0
            carry = x >> np.uint64(63)
        cnt[b] = c


@_jit
def _fill_ones(Xp, ptr, idx):
    for b in range(Xp.shape[0]):
        p = ptr[b]
        for k in range(Xp.shape[1]):
            x = Xp[b, k]
            while x:
                idx[p] = k * 64 + _ctz(x)
                p += 1
                x &= x - _ONE


@_jit
def _fill_runs(Xp, ptr, rs, re):
    K = Xp.shape[1]
    for b in range(Xp.shape[0]):
        ps = ptr[b]
        pe = ptr[b]
        carry = np.uint64(0)
        for k in range(K):
            x = Xp[b, k]
            prev = (x << _ONE) | carry      # bit j holds the bit before position j
            st = x & ~prev                  # a run starts here
            en = ~x & prev                  # a run ended just before here
            while st:
                rs[ps] = k * 64 + _ctz(st)
                ps += 1
                st &= st - _ONE
            while en:
                re[pe] = k * 64 + _ctz(en)
                pe += 1
                en &= en - _ONE
            carry = x >> np.uint64(63)
        if carry:                           # run reaches the very last bit
            re[pe] = K * 64


def _csr_counts(counter, Xp):
    cnt = np.empty(Xp.shape[0], np.int64)
    counter(Xp, cnt)
    ptr = np.zeros(Xp.shape[0] + 1, np.int64)
    np.cumsum(cnt, out=ptr[1:])
    return ptr


def encode_ones(Xp):
    """Positions of the 1 bits in each row, CSR style: (idx, ptr)."""
    ptr = _csr_counts(_count_ones, Xp)
    idx = np.empty(ptr[-1], np.int32)
    _fill_ones(Xp, ptr, idx)
    return idx, ptr


def encode_runs(Xp):
    """Runs of 1s in each row as half-open [start, end) pairs, CSR style: (starts, ends, ptr)."""
    ptr = _csr_counts(_count_runs, Xp)
    rs = np.empty(ptr[-1], np.int32)
    re = np.empty(ptr[-1], np.int32)
    _fill_runs(Xp, ptr, rs, re)
    return rs, re, ptr


def inspect(Xp, n):
    """The structure the dispatcher reports for a batch of packed inputs."""
    ones = np.empty(Xp.shape[0], np.int64)
    runs = np.empty(Xp.shape[0], np.int64)
    _count_ones(Xp, ones)
    _count_runs(Xp, runs)
    nbytes = (n + 7) // 8
    nonzero = np.count_nonzero(np.ascontiguousarray(Xp).view(np.uint8)[:, :nbytes], axis=1)
    return {"n": n, "density": float(ones.mean() / n), "ones": float(ones.mean()),
            "runs": float(runs.mean()), "nonzero_bytes": float(nonzero.mean()), "bytes": nbytes}


# ------------------------------------------------------------------ kernels
@_jit
def _k_packed(Xp, Wp, out):
    B, K = Xp.shape
    O = Wp.shape[0]
    for b in range(B):
        xc = 0
        for k in range(K):
            xc += _popcnt(Xp[b, k])
        for o in range(O):
            acc = 0
            for k in range(K):
                acc += _popcnt(Xp[b, k] & Wp[o, k])
            out[b, o] = 2 * acc - xc            # (+1 matches) - (-1 matches)


@_jit
def _k_sparse(idx, ptr, Wt, out):
    O = Wt.shape[1]
    for b in range(ptr.shape[0] - 1):
        acc = np.zeros(O, np.int32)
        for p in range(ptr[b], ptr[b + 1]):
            row = Wt[idx[p]]
            for o in range(O):
                acc[o] += row[o]
        out[b] = acc


@_jit
def _k_runs(rs, re, ptr, P, out):
    O = P.shape[1]
    for b in range(ptr.shape[0] - 1):
        acc = np.zeros(O, np.int32)
        for p in range(ptr[b], ptr[b + 1]):
            hi = P[re[p]]
            lo = P[rs[p]]
            for o in range(O):
                acc[o] += hi[o] - lo[o]         # whole run in two lookups
        out[b] = acc


@_jit
def _k_lut(Xb, T, out):
    C = T.shape[0]
    O = T.shape[2]
    for b in range(Xb.shape[0]):
        acc = np.zeros(O, np.int32)
        for c in range(C):
            v = Xb[b, c]
            if v:                               # an all-zero byte adds nothing
                t = T[c, v]
                for o in range(O):
                    acc[o] += t[o]
        out[b] = acc


@_jit
def _build_lut(Wt, T):
    n, O = Wt.shape
    for c in range(T.shape[0]):
        for o in range(O):
            T[c, 0, o] = 0
        for v in range(1, 256):
            j = 0
            while not (v >> j) & 1:
                j += 1
            prev = v & (v - 1)                  # v without its lowest bit: already filled
            i = c * 8 + j
            if i < n:
                for o in range(O):
                    T[c, v, o] = T[c, prev, o] + Wt[i, o]
            else:
                for o in range(O):
                    T[c, v, o] = T[c, prev, o]


# ------------------------------------------------------------------ one binary layer
class BinaryLayer:
    """Binary linear layer with O outputs and n inputs; weights +1/-1 stored as bits.

    run(Xp, kernel) takes packed 0/1 inputs and returns S, the (B, O) int32 masked
    sums, computed on the calling thread. Each kernel's weight encoding is built
    the first time it is used.
    """

    def __init__(self, wbits):
        self.wbits = np.ascontiguousarray(np.asarray(wbits) != 0, dtype=np.uint8)
        self.O, self.n = self.wbits.shape
        assert self.n < 2 ** 15, "int16 tables need fewer than 32768 inputs"
        self.wsum = (2 * self.wbits.astype(np.int64) - 1).sum(1)
        self._enc = {}

    def nbytes(self, kernel):
        """Bytes of weight data the kernel reads at inference."""
        n, O = self.n, self.O
        return {"packed": O * words(n) * 8, "sparse": n * O, "runs": (n + 1) * O * 2,
                "lut": (n + 7) // 8 * 256 * O * 2, "usual": O * n * 4}[kernel]

    def encoding(self, kernel):
        if kernel not in self._enc:
            pm = 2 * self.wbits.astype(np.int8) - 1                       # (O, n) of +-1
            if kernel == "packed":
                enc = pack_bits(self.wbits)
            elif kernel == "sparse":
                enc = np.ascontiguousarray(pm.T)                           # (n, O) int8
            elif kernel == "runs":
                enc = np.zeros((self.n + 1, self.O), np.int16)             # prefix sums
                np.cumsum(pm.T, axis=0, dtype=np.int16, out=enc[1:])
            elif kernel == "lut":
                enc = np.empty(((self.n + 7) // 8, 256, self.O), np.int16)
                _build_lut(np.ascontiguousarray(pm.T), enc)
            elif kernel == "usual":
                enc = pm.astype(np.float32)                                 # dense floats
            else:
                raise ValueError(f"unknown kernel {kernel!r}")
            self._enc[kernel] = enc
        return self._enc[kernel]

    def run(self, Xp, kernel="packed", out=None):
        Xp = np.ascontiguousarray(Xp)
        assert Xp.shape[1] == words(self.n), "input width does not match the layer"
        enc = self.encoding(kernel)
        if out is None:
            out = np.empty((Xp.shape[0], self.O), np.int32)
        if kernel == "usual":
            out[:] = unpack_bits(Xp, self.n).astype(np.float32) @ enc.T
        elif kernel == "packed":
            _k_packed(Xp, enc, out)
        elif kernel == "sparse":
            idx, ptr = encode_ones(Xp)
            _k_sparse(idx, ptr, enc, out)
        elif kernel == "runs":
            rs, re, ptr = encode_runs(Xp)
            _k_runs(rs, re, ptr, enc, out)
        else:
            _k_lut(Xp.view(np.uint8), enc, out)
        return out

    def run_blocks(self, Xp, kernel="packed"):
        """run(), with a big batch split across cores the way the network runs it."""
        Xp = np.ascontiguousarray(Xp)
        out = np.empty((Xp.shape[0], self.O), np.int32)
        for_row_blocks(len(Xp), lambda lo, hi: self.run(Xp[lo:hi], kernel, out[lo:hi]))
        return out


def _best_time(fn, repeats):
    best = float("inf")
    for _ in range(repeats):
        t = time.perf_counter()
        fn()
        best = min(best, time.perf_counter() - t)
    return best


def _us_per_row(fn, X, batch, repeats):
    """Best time per row, in microseconds, to run fn over X in chunks of `batch` rows."""
    rows = min(len(X), max(1000, 10 * batch))
    chunks = [X[i:i + batch] for i in range(0, rows, batch)]

    def run():
        for chunk in chunks:
            fn(chunk)
    run()
    return _best_time(run, repeats) / rows * 1e6


# ------------------------------------------------------------------ compiled network
class BinaryNet:
    """A compiled binary MLP: 0/1 pixels in, hidden layers as bits, logits out.

    Hidden unit o of layer L fires when (S >= thr[L][o]) != flip[L][o].
    The output layer's logits are out_scale * S + out_bias.
    """

    def __init__(self, layers, thr, flip, out_scale, out_bias, cut=127):
        self.layers, self.thr, self.flip = layers, thr, flip
        self.out_scale, self.out_bias, self.cut = out_scale, out_bias, cut
        self.picks = {}          # batch size -> kernel per layer, filled in by calibrate()

    def _kernels(self, kernels, rows):
        if kernels is None:      # the dispatcher's picks for the nearest calibrated batch size
            if not self.picks:
                return ["packed"] * len(self.layers)
            size = min(self.picks, key=lambda b: abs(math.log(b) - math.log(max(rows, 1))))
            return self.picks[size]
        return [kernels] * len(self.layers) if isinstance(kernels, str) else list(kernels)

    def encode(self, images):
        images = np.ascontiguousarray(images, dtype=np.uint8)
        Xp = np.empty((images.shape[0], words(images.shape[1])), np.uint64)
        _binarize_pack(images, self.cut, Xp)
        return Xp

    def _fire(self, S, L):
        Xp = np.empty((S.shape[0], words(S.shape[1])), np.uint64)
        _threshold_pack(S, self.thr[L], self.flip[L], Xp)
        return Xp

    def _forward(self, images, kernels, outs):
        """One block of images through the whole net; outs[L] (if given) receives layer L's sums."""
        Xp = self.encode(images)
        for L, (layer, k) in enumerate(zip(self.layers, kernels)):
            S = layer.run(Xp, k, outs[L])
            if L < len(self.layers) - 1:
                Xp = self._fire(S, L)

    def sums(self, images, kernels=None, last_only=False):
        """Per-layer masked sums S (just the output layer's if last_only), running
        each layer on the given kernel. Big batches are split across cores."""
        images = np.ascontiguousarray(images, dtype=np.uint8)
        B, n = len(images), len(self.layers)
        kernels = self._kernels(kernels, B)
        outs = [np.empty((B, layer.O), np.int32) if L == n - 1 or not last_only else None
                for L, layer in enumerate(self.layers)]
        for_row_blocks(B, lambda lo, hi: self._forward(
            images[lo:hi], kernels, [None if o is None else o[lo:hi] for o in outs]))
        return [o for o in outs if o is not None]

    def logits(self, images, kernels=None):
        return self.sums(images, kernels, last_only=True)[-1] * self.out_scale + self.out_bias

    def predict(self, images, kernels=None):
        return self.logits(images, kernels).argmax(1)

    # the same network run the usual way: dense float32 matmuls, no bits anywhere
    def usual_sums(self, images):
        H, out = (np.asarray(images) > self.cut).astype(np.float32), []
        for L, layer in enumerate(self.layers):
            out.append(H @ layer.encoding("usual").T)
            if L < len(self.layers) - 1:
                H = ((out[-1] >= self.thr[L]) != self.flip[L]).astype(np.float32)
        return out

    def usual_predict(self, images):
        return (self.usual_sums(images)[-1] * self.out_scale + self.out_bias).argmax(1)

    def nbytes(self, kernels=None):
        """Bytes the network reads at inference with these kernels ("usual" for dense
        floats). With no kernels given: every encoding the dispatcher's picks keep loaded."""
        if kernels is None:
            per_layer = [{p[L] for p in self.picks.values()} or {"packed"} for L in range(len(self.layers))]
        else:
            per_layer = [{k} for k in self._kernels(kernels, 0)]
        size = sum(layer.nbytes(k) for layer, ks in zip(self.layers, per_layer) for k in ks)
        size += sum(t.nbytes + f.nbytes for t, f in zip(self.thr, self.flip))
        return size + self.out_scale.nbytes + self.out_bias.nbytes

    def calibrate(self, images, batch_sizes=(1, 1000), kernels=KERNELS, repeats=3, max_bytes=None,
                  tolerance=0.10):
        """Inspect -> verify -> time -> choose, per layer and per batch size, on real inputs.

        Every kernel's output is compared bit-for-bit with the dense float32
        matmul; only exact kernels within the memory budget can be chosen.
        Times are per image, measured the way the network runs (one core for a
        small batch, split across cores for a big one), and include each
        kernel's own input encoding. Kernels within `tolerance` of the fastest
        count as tied, and the tie goes to the smallest weight encoding, so a
        noise-level speedup never costs megabytes. predict() uses the picks for
        the nearest calibrated batch size.
        """
        Xp, report = self.encode(images), []
        for L, layer in enumerate(self.layers):
            ref = layer.run(Xp, "usual")
            allowed = [k for k in kernels if max_bytes is None or layer.nbytes(k) <= max_bytes]
            exact = {k: bool(np.array_equal(layer.run(Xp, k), ref)) for k in allowed}
            if not any(exact.values()):
                raise RuntimeError(f"no exact kernel for layer {L}")
            entry = {"layer": L, "shape": [layer.n, layer.O], "input": inspect(Xp, layer.n), "exact": exact,
                     "bytes": {k: layer.nbytes(k) for k in ("usual", *kernels)}, "us": {}, "chosen": {}}
            for bs in batch_sizes:
                us = {k: _us_per_row(lambda X: layer.run_blocks(X, k), Xp, bs, repeats) for k in allowed}
                ok = [k for k in allowed if exact[k]]
                fastest = min(us[k] for k in ok)
                pick = min((k for k in ok if us[k] <= fastest * (1 + tolerance)),
                           key=lambda k: (layer.nbytes(k), us[k]))
                entry["us"][bs], entry["chosen"][bs] = us, pick
                self.picks.setdefault(bs, ["packed"] * len(self.layers))[L] = pick
            report.append(entry)
            if L < len(self.layers) - 1:
                Xp = self._fire(ref, L)
        return report

    def verify(self, images, kernels=KERNELS):
        """For each kernel: does running the whole net on it reproduce the dense
        float32 path's sums at every layer, for every image?"""
        ref = self.usual_sums(images)
        return {k: all(np.array_equal(got, want) for got, want in zip(self.sums(images, k), ref))
                for k in kernels}


# ------------------------------------------------------------------ training (float math)
@_jit
def _adam_step(p, g, m, v, step, b1, b2, c2, eps, clip):
    for i in range(p.size):
        mi = b1 * m[i] + (1 - b1) * g[i]
        vi = b2 * v[i] + (1 - b2) * g[i] * g[i]
        m[i] = mi
        v[i] = vi
        x = p[i] - step * mi / (math.sqrt(vi / c2) + eps)
        if clip > 0:
            x = min(max(x, -clip), clip)
        p[i] = x


class Adam:
    """Adam in one fused pass per array; clip > 0 keeps that array inside [-clip, clip]."""

    def __init__(self, params, clip=None, b1=0.9, b2=0.999, eps=1e-8):
        self.params, self.b1, self.b2, self.eps, self.t = params, b1, b2, eps, 0
        self.clip = clip or [0.0] * len(params)
        self.m = [np.zeros_like(p) for p in params]
        self.v = [np.zeros_like(p) for p in params]

    def step(self, grads, lr):
        self.t += 1
        c1, c2 = 1 - self.b1 ** self.t, 1 - self.b2 ** self.t
        for p, g, m, v, clip in zip(self.params, grads, self.m, self.v, self.clip):
            _adam_step(p.reshape(-1), np.ascontiguousarray(g, np.float32).reshape(-1),
                       m.reshape(-1), v.reshape(-1), lr / c1, self.b1, self.b2, c2, self.eps, clip)


def cosine_lr(lr0, lr1, step, total):
    return lr1 + 0.5 * (lr0 - lr1) * (1 + math.cos(math.pi * step / total))


def softmax_xent(z, y):
    """Mean cross-entropy of logits z against labels y, and its gradient."""
    z = z - z.max(1, keepdims=True)
    p = np.exp(z)
    p /= p.sum(1, keepdims=True)
    rows = np.arange(len(y))
    loss = float(-np.log(p[rows, y] + 1e-12).mean())
    p[rows, y] -= 1
    return loss, p / len(y)


@_jit
def _sign_into(x, out):
    for i in range(x.size):
        out[i] = 1.0 if x[i] >= 0 else -1.0


def _sign(x):
    """+1 where x >= 0, else -1, as float32 (the same rule compile uses for weight bits)."""
    out = np.empty(x.shape, np.float32)
    _sign_into(np.ascontiguousarray(x).reshape(-1), out.reshape(-1))
    return out


def _bn(a, g, b, eps=1e-5):
    mu, var = a.mean(0), a.var(0)
    inv = 1 / np.sqrt(var + eps)
    xh = (a - mu) * inv
    return g * xh + b, (xh, inv), mu, var


def _bn_back(d, g, cache):
    xh, inv = cache
    dx = d * g
    return inv * (dx - dx.mean(0) - xh * (dx * xh).mean(0)), (d * xh).sum(0), d.sum(0)


def _float_sim(params, images, eps=1e-5):
    """The binary net in float math with batch norm's running statistics."""
    h = (images > params["cut"]).astype(np.float32)
    n = len(params["W"])
    for L in range(n):
        a = h @ _sign(params["W"][L]).T
        z = params["gamma"][L] * (a - params["mu"][L]) / np.sqrt(params["var"][L] + eps) + params["beta"][L]
        h = _sign(z) if L < n - 1 else z
    return h


def train_binary_mlp(images, labels, hidden=(1024, 1024), epochs=15, batch=100, lr=(3e-3, 3e-5),
                     seed=0, cut=127, val=None, log=print):
    """Train a binary MLP with float math.

    Weights are the signs of latent floats clipped to [-1, 1]; activations are
    signs, with a straight-through gradient where |z| <= 1; batch norm follows
    every layer. Inputs are pixels > cut, as 0/1. Returns raw parameters for
    compile_binary_mlp().
    """
    rng = np.random.default_rng(seed)
    X = (images > cut).astype(np.float32)
    sizes = [X.shape[1], *hidden, 10]
    W = [(rng.uniform(-1, 1, (o, i)) * math.sqrt(6 / (i + o))).astype(np.float32)
         for i, o in zip(sizes, sizes[1:])]
    G = [np.ones(o, np.float32) for o in sizes[1:]]
    Bt = [np.zeros(o, np.float32) for o in sizes[1:]]
    params = {"W": W, "gamma": G, "beta": Bt, "cut": cut,
              "mu": [np.zeros(o, np.float32) for o in sizes[1:]],
              "var": [np.ones(o, np.float32) for o in sizes[1:]]}
    nl = len(W)
    opt = Adam(W + G + Bt, clip=[1.0] * nl + [0.0] * (2 * nl))
    steps = len(X) // batch
    total, step = epochs * steps, 0
    for ep in range(epochs):
        t0, perm, losses = time.perf_counter(), rng.permutation(len(X)), []
        for s in range(steps):
            idx = perm[s * batch:(s + 1) * batch]
            h, cache = X[idx], []
            for L in range(nl):
                Wb = _sign(W[L])
                z, bc, mu, var = _bn(h @ Wb.T, G[L], Bt[L])
                params["mu"][L] = 0.9 * params["mu"][L] + 0.1 * mu
                params["var"][L] = 0.9 * params["var"][L] + 0.1 * var
                cache.append((h, Wb, bc, z))
                if L < nl - 1:
                    h = _sign(z)
            loss, d = softmax_xent(z, labels[idx])
            losses.append(loss)
            gW, gG, gB = [None] * nl, [None] * nl, [None] * nl
            for L in reversed(range(nl)):
                h_in, Wb, bc, zL = cache[L]
                if L < nl - 1:
                    d = d * (np.abs(zL) <= 1)          # straight-through sign
                da, gG[L], gB[L] = _bn_back(d, G[L], bc)
                gW[L] = da.T @ h_in
                if L:
                    d = da @ Wb
            opt.step(gW + gG + gB, cosine_lr(lr[0], lr[1], step, total))
            step += 1
        msg = f"  epoch {ep + 1:2d}/{epochs}  loss {np.mean(losses):.3f}"
        if val is not None:
            acc = (_float_sim(params, val[0]).argmax(1) == val[1]).mean()
            msg += f"  test {acc:.2%}"
        log(msg + f"  ({time.perf_counter() - t0:.1f} s)")
    return params


def compile_binary_mlp(params, images, eps=1e-5):
    """Freeze a trained binary MLP into integer form.

    Batch norm statistics are recomputed over `images` (use the training set)
    with the final binary weights and the network's own integer activations.
    Each hidden unit's batch norm + sign then collapses to one integer
    threshold on S, and the output layer to a per-class scale and bias.
    """
    cut, W, n = params["cut"], params["W"], len(params["W"])
    h = (np.asarray(images) > cut).astype(np.float32)          # 0/1 pixels
    layers, thr, flip = [], [], []
    for L, w in enumerate(W):
        layer = BinaryLayer(w >= 0)
        layers.append(layer)
        a = h @ _sign(w).T                                       # exact integers
        mu = a.mean(0, dtype=np.float64)
        sd = np.sqrt(a.var(0, dtype=np.float64) + eps)
        g = params["gamma"][L].astype(np.float64)
        be = params["beta"][L].astype(np.float64)
        # a in terms of S: inputs are 0/1 in layer 0 (a = S), +-1 after (a = 2S - sum w)
        m, c = (1.0, 0.0) if L == 0 else (2.0, -layer.wsum.astype(np.float64))
        if L == n - 1:
            out_scale = g / sd * m
            out_bias = be + g / sd * (c - mu)
            break
        with np.errstate(divide="ignore", invalid="ignore"):
            tau = (mu - be * sd / g - c) / m       # BN(a) >= 0  <=>  S >= tau (g > 0) or S <= tau (g < 0)
        t = np.where(g > 0, np.ceil(tau), np.floor(tau) + 1)
        t = np.where(g == 0, -2 ** 30, t)          # g == 0: the unit is constant
        f = np.where(g == 0, be < 0, g < 0)
        thr.append(np.clip(np.nan_to_num(t), -2 ** 30, 2 ** 30).astype(np.int32))
        flip.append(f.astype(np.bool_))
        S = (a - np.float32(c)) / np.float32(m)    # exact: a - c is even when m == 2
        h = np.where((S >= thr[-1]) != flip[-1], np.float32(1), np.float32(-1))
    return BinaryNet(layers, thr, flip, out_scale, out_bias, cut)


# ------------------------------------------------------------------ self-test
def selftest(seed=0):
    """Check every kernel, encoder and the block-parallel forward pass against plain math."""
    rng = np.random.default_rng(seed)
    cases = [(1, 3, 5, .5), (63, 7, 9, .3), (64, 5, 4, 1.0), (65, 9, 11, .05), (128, 3, 2, 1.0),
             (200, 17, 13, .5), (130, 4, 6, 0.0), (784, 33, 40, .15), (1024, 10, 8, .5)]
    for n, O, B, p in cases:
        wbits = rng.random((O, n)) < 0.5
        X = rng.random((B, n)) < p
        want = X.astype(np.int64) @ (2 * wbits.astype(np.int64) - 1).T
        layer, Xp = BinaryLayer(wbits), pack_bits(X)
        assert np.array_equal(unpack_bits(Xp, n), X)
        for k in KERNELS + ("usual",):
            assert np.array_equal(layer.run(Xp, k), want), f"kernel {k} wrong at n={n}, density={p}"
        rs, re, ptr = encode_runs(Xp)
        back = np.zeros((B, n), bool)
        for b in range(B):
            for s, e in zip(rs[ptr[b]:ptr[b + 1]], re[ptr[b]:ptr[b + 1]]):
                back[b, s:e] = True
        assert np.array_equal(back, X), "run encoding does not round-trip"
        thr = rng.integers(-6, 6, O).astype(np.int32)
        flip = rng.random(O) < 0.5
        fired = np.empty((B, words(O)), np.uint64)
        _threshold_pack(want.astype(np.int32), thr, flip, fired)
        assert np.array_equal(unpack_bits(fired, O), (want >= thr) != flip)
    img = rng.integers(0, 256, (7, 100), dtype=np.uint8)
    got = np.empty((7, words(100)), np.uint64)
    _binarize_pack(img, 127, got)
    assert np.array_equal(got, pack_bits(img > 127))
    # a small random net, run on one block and on many blocks across threads
    net = BinaryNet([BinaryLayer(rng.random((70, 100)) < .5), BinaryLayer(rng.random((10, 70)) < .5)],
                    [rng.integers(-5, 5, 70).astype(np.int32)], [rng.random(70) < .5],
                    np.ones(10), np.zeros(10))
    for rows in (3, 3 * PARALLEL_ROWS + 5):
        imgs = rng.integers(0, 256, (rows, 100), dtype=np.uint8)
        want = net.usual_sums(imgs)
        for k in KERNELS:
            assert all(np.array_equal(g, w) for g, w in zip(net.sums(imgs, k), want)), f"net on {k}, {rows} rows"
    return True
