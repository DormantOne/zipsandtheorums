"""One button: a usual float MLP vs a binary MLP running on acba's exact bit kernels.

    python mnist_compare.py            full run (5-10 minutes)
    python mnist_compare.py --quick    2 epochs each, a 2-minute smoke test

Both networks have the same shape (784 -> 1024 -> 1024 -> 10) and the same
training budget. The binary one is then run two ways: the usual way (dense
float32 matmuls) and on acba's packed kernels, which must agree bit-for-bit.
Writes results.md and results.json next to this file.
"""
import argparse
import gzip
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import time
import urllib.request

import numpy as np

import acba
import numba

HERE = os.path.dirname(os.path.abspath(__file__))
FILES = [("train-images-idx3-ubyte.gz", "f68b3c2dcbeaaa9fbdd348bbdeb94873"),
         ("train-labels-idx1-ubyte.gz", "d53e105ee54ea40749a09fcbcd1e9432"),
         ("t10k-images-idx3-ubyte.gz", "9fb629c4189551a2d022fa330f9573f3"),
         ("t10k-labels-idx1-ubyte.gz", "ec29112dd5afa0611ce80d1b7f02629c")]
MIRRORS = ["https://ossci-datasets.s3.amazonaws.com/mnist/",
           "https://storage.googleapis.com/cvdf-datasets/mnist/",
           "https://raw.githubusercontent.com/fgnt/mnist/master/"]


# ------------------------------------------------------------------ data
def _md5(path):
    with open(path, "rb") as f:
        return hashlib.md5(f.read()).hexdigest()


def _download(name, path, md5):
    errors = []
    for base in MIRRORS:
        for how in ("python", "curl"):
            try:
                if how == "python":
                    with urllib.request.urlopen(base + name, timeout=60) as r, open(path, "wb") as f:
                        shutil.copyfileobj(r, f)
                elif shutil.which("curl"):        # fallback when Python lacks SSL certificates
                    subprocess.run(["curl", "-fsSL", "--max-time", "300", "-o", path, base + name], check=True)
                else:
                    continue
                if _md5(path) == md5:
                    return
                errors.append(f"{base}{name}: checksum mismatch")
            except Exception as e:  # try the next mirror
                errors.append(f"{base}{name} via {how}: {e}")
    raise SystemExit("Could not download MNIST.\n  " + "\n  ".join(errors) +
                     f"\nPut the four .gz files in {os.path.dirname(path)} and run again.")


def load_mnist(folder):
    os.makedirs(folder, exist_ok=True)
    arrays = []
    for name, md5 in FILES:
        path = os.path.join(folder, name)
        if not os.path.exists(path) or _md5(path) != md5:
            print(f"  downloading {name}")
            _download(name, path, md5)
        with gzip.open(path, "rb") as f:
            raw = f.read()
        if "images" in name:
            arrays.append(np.frombuffer(raw, np.uint8, offset=16).reshape(-1, 784))
        else:
            arrays.append(np.frombuffer(raw, np.uint8, offset=8).astype(np.int64))
    return arrays


# ------------------------------------------------------------------ the usual float MLP
def train_float_mlp(images, labels, hidden, epochs, batch=100, lr=(1e-3, 1e-5), seed=0, val=None):
    """784 -> hidden -> 10 with ReLU, He init, Adam, cross-entropy. Plain float32."""
    rng = np.random.default_rng(seed)
    X = images.astype(np.float32) / 255
    sizes = [X.shape[1], *hidden, 10]
    W = [(rng.standard_normal((o, i)) * np.sqrt(2 / i)).astype(np.float32) for i, o in zip(sizes, sizes[1:])]
    b = [np.zeros(o, np.float32) for o in sizes[1:]]
    opt, nl = acba.Adam(W + b), len(W)
    steps = len(X) // batch
    for ep in range(epochs):
        t0, perm, losses = time.perf_counter(), rng.permutation(len(X)), []
        for s in range(steps):
            idx = perm[s * batch:(s + 1) * batch]
            hs = [X[idx]]
            for L in range(nl):
                z = hs[-1] @ W[L].T + b[L]
                hs.append(np.maximum(z, 0) if L < nl - 1 else z)
            loss, d = acba.softmax_xent(hs[-1], labels[idx])
            losses.append(loss)
            gW, gb = [None] * nl, [None] * nl
            for L in reversed(range(nl)):
                gW[L], gb[L] = d.T @ hs[L], d.sum(0)
                if L:
                    d = (d @ W[L]) * (hs[L] > 0)
            opt.step(gW + gb, acba.cosine_lr(lr[0], lr[1], ep * steps + s, epochs * steps))
        msg = f"  epoch {ep + 1:2d}/{epochs}  loss {np.mean(losses):.3f}"
        if val is not None:
            msg += f"  test {(float_predict((W, b), val[0]) == val[1]).mean():.2%}"
        print(msg + f"  ({time.perf_counter() - t0:.1f} s)", flush=True)
    return W, b


def float_predict(model, images):
    W, b = model
    h = images.astype(np.float32) / 255
    for L in range(len(W)):
        h = h @ W[L].T + b[L]
        if L < len(W) - 1:
            np.maximum(h, 0, out=h)
    return h.argmax(1)


# ------------------------------------------------------------------ timing
def _seconds(fn):
    t = time.perf_counter()
    fn()
    return time.perf_counter() - t


def throughput_seconds(predict, images, batch=1000, repeats=3):
    """Best wall time to classify all images in batches."""
    def run():
        for i in range(0, len(images), batch):
            predict(images[i:i + batch])
    run()
    return min(_seconds(run) for _ in range(repeats))


def latency_seconds(predict, images, n=1000):
    """Median wall time to classify one image on its own."""
    for i in range(50):
        predict(images[i:i + 1])
    return float(np.median([_seconds(lambda: predict(images[i:i + 1])) for i in range(n)]))


def mb(nbytes):
    return f"{nbytes / 1e6:.2f} MB" if nbytes >= 1e5 else f"{nbytes / 1e3:.0f} KB"


def us(seconds):
    return f"{seconds * 1e6:,.0f} us" if seconds < 0.01 else f"{seconds * 1e3:,.0f} ms"


def table(header, rows):
    widths = [max(len(str(r[i])) for r in [header] + rows) for i in range(len(header))]
    line = lambda r: "  " + "  ".join(str(c).ljust(w) if i == 0 else str(c).rjust(w)
                                      for i, (c, w) in enumerate(zip(r, widths)))
    return "\n".join([line(header), "  " + "  ".join("-" * w for w in widths)] + [line(r) for r in rows])


def md_table(header, rows):
    return "\n".join(["| " + " | ".join(map(str, header)) + " |", "|" + "---|" * len(header)] +
                     ["| " + " | ".join(map(str, r)) + " |" for r in rows])


# ------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--hidden", type=int, default=1024, help="units per hidden layer (default 1024)")
    ap.add_argument("--epochs", type=int, default=15, help="training epochs for each net (default 15)")
    ap.add_argument("--quick", action="store_true", help="2 epochs each, for a smoke test")
    ap.add_argument("--data", default=os.path.join(HERE, "data"), help="folder for the MNIST files")
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    epochs, hidden = (2 if args.quick else args.epochs), (args.hidden, args.hidden)
    shape = " -> ".join(map(str, (784, *hidden, 10)))
    env = {"python": platform.python_version(), "numpy": np.__version__, "numba": numba.__version__,
           "cores": os.cpu_count(), "machine": platform.machine(), "system": platform.system(),
           "processor": platform.processor() or platform.machine()}
    print(f"acba MNIST comparison | {shape} | {epochs} epochs | numpy {env['numpy']}, "
          f"numba {env['numba']}, {env['cores']} cores\n")

    print("self-test (the first run also compiles the kernels, about 30 s)...", end=" ", flush=True)
    t = time.perf_counter()
    acba.selftest()
    print(f"all 4 kernels exact on 9 awkward shapes ({time.perf_counter() - t:.1f} s)")
    Xtr, ytr, Xte, yte = load_mnist(args.data)
    print(f"data: {len(Xtr):,} training and {len(Xte):,} test images\n")

    print("[1/4] usual float MLP (float32 weights, ReLU, Adam)")
    t = time.perf_counter()
    fmodel = train_float_mlp(Xtr, ytr, hidden, epochs, seed=args.seed, val=(Xte, yte))
    f_train = time.perf_counter() - t

    print("\n[2/4] binary MLP (+-1 weights and activations, trained with straight-through gradients)")
    t = time.perf_counter()
    params = acba.train_binary_mlp(Xtr, ytr, hidden=hidden, epochs=epochs, seed=args.seed, val=(Xte, yte))
    b_train = time.perf_counter() - t
    net = acba.compile_binary_mlp(params, Xtr)
    print("  compiled: batch norm + sign folded into one integer threshold per hidden unit")

    print("\n[3/4] dispatcher: inspect each layer's real inputs, check every kernel, time it, pick")
    batch_sizes = (1000, 1)
    report = net.calibrate(Xtr[:10000], batch_sizes=batch_sizes)
    names = list(acba.KERNELS)
    rows = []
    for r in report:
        n_in, n_out, s = *r["shape"], r["input"]
        print(f"\n  layer {r['layer'] + 1}: {n_in} -> {n_out}   input: {s['density']:.1%} ones, "
              f"{s['runs']:.0f} runs, {s['nonzero_bytes']:.0f} of {s['bytes']} bytes nonzero")
        lines = [[f"batch {bs}"] + [f"{r['us'][bs][k]:.2f}" + ("*" if k == r["chosen"][bs] else " ") for k in names]
                 for bs in batch_sizes]
        lines.append(["weights"] + [mb(r["bytes"][k]) + " " for k in names])
        print(table(["us per image"] + names, lines))
        label = f"{r['layer'] + 1}: {n_in}→{n_out}"
        shape_txt = f"{s['density']:.0%} ones, {s['runs']:.0f} runs, {s['nonzero_bytes']:.0f}/{s['bytes']} bytes nonzero"
        for i, bs in enumerate(batch_sizes):
            rows.append([label if i == 0 else "", shape_txt if i == 0 else "", f"batch {bs}"] +
                        [f"**{r['us'][bs][k]:.2f} µs** ✓" if k == r["chosen"][bs] else f"{r['us'][bs][k]:.2f} µs"
                         for k in names])
        rows.append(["", "", "weights"] + [mb(r["bytes"][k]) for k in names])
    print("\n  (* = chosen: fastest exact kernel, except that anything within 10% of it counts as a tie"
          "\n   and the tie goes to the smaller weight encoding)")
    picks_txt = "; ".join(f"batch {bs}: {', '.join(net.picks[bs])}" for bs in batch_sizes)
    print(f"  picks by layer -- {picks_txt}")
    print("  verifying every kernel on all 10,000 test images...", end=" ", flush=True)
    exact = net.verify(Xte)
    print("all bit-for-bit equal to the float32 path" if all(exact.values()) else f"MISMATCH: {exact}")

    print("\n[4/4] head to head on the 10,000 test images")
    contenders = [
        ("usual float MLP", lambda x: float_predict(fmodel, x),
         sum(w.nbytes + v.nbytes for w, v in zip(*fmodel))),
        ("binary MLP, usual way (float32 matmul)", net.usual_predict, net.nbytes("usual")),
        ("binary MLP on acba, packed kernel only", lambda x: net.predict(x, "packed"), net.nbytes("packed")),
        ("binary MLP on acba, dispatcher's picks", net.predict, net.nbytes()),
    ]
    results, out_rows, md_rows = [], [], []
    base_tp = base_lat = None
    for name, predict, nbytes in contenders:
        time.sleep(0.2)                      # let the previous contender's worker threads go idle
        pred = predict(Xte)
        acc = float((pred == yte).mean())
        tp = throughput_seconds(predict, Xte)
        lat = latency_seconds(predict, Xte)
        base_tp, base_lat = base_tp or tp, base_lat or lat
        results.append({"model": name, "accuracy": acc, "bytes": nbytes, "seconds_10k": tp,
                        "latency_seconds": lat, "predictions": pred})
        out_rows.append([name, f"{acc:.2%}", mb(nbytes), us(tp), f"{base_tp / tp:.1f}x", us(lat), f"{base_lat / lat:.1f}x"])
        md_rows.append([name, f"{acc:.2%}", mb(nbytes), f"{tp * 1e3:,.0f} ms", f"{base_tp / tp:.1f}×",
                        f"{lat * 1e6:,.0f} µs", f"{base_lat / lat:.1f}×"])
    same = all(np.array_equal(results[1]["predictions"], r["predictions"]) for r in results[2:])
    header = ["", "test acc", "weights", "10k images", "speedup", "1 image", "speedup"]
    print(table(header, out_rows))
    print(f"\n  binary MLP predictions identical across all three ways of running it: {'yes' if same else 'NO'}")
    print(f"  training time: float {f_train:.0f} s, binary {b_train:.0f} s")

    md = [f"# acba on MNIST: binary MLP vs usual float MLP\n",
          f"Network {shape}, {epochs} epochs each, same optimizer budget. "
          f"Machine: {env['system']} {env['machine']}, {env['cores']} cores, numpy {env['numpy']}, numba {env['numba']}.\n",
          "## Head to head (10,000 test images)\n", md_table(header, md_rows), "",
          f"Binary MLP predictions identical whether run the usual way or on acba: **{'yes' if same else 'NO'}**. "
          f"Every kernel matched the float32 path bit-for-bit at every layer: **{'yes' if all(exact.values()) else 'NO'}**. "
          f"Speedups are relative to the usual float MLP. \"10k images\" runs batches of 1,000; \"1 image\" is the median single-image time.\n",
          "## Dispatcher, per layer (timed on 10,000 training images, µs per image)\n",
          md_table(["layer", "input structure", ""] + names, rows), "",
          f"Picks by layer: {picks_txt}.\n",
          "✓ = chosen for that batch size: the fastest kernel that matched the float32 matmul exactly, "
          "except that kernels within 10% of the fastest count as tied and the tie goes to the smaller weight encoding. "
          "Times are measured the way the network runs (batch 1 on one core, batch 1000 split across all cores) "
          "and include each kernel's own input encoding. \"weights\" is the memory each kernel's weight encoding needs. "
          "The dispatcher row in the head-to-head keeps every chosen encoding loaded and uses the picks for the nearest batch size.\n"]
    with open(os.path.join(HERE, "results.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(md))
    for r in results:
        r.pop("predictions")
    with open(os.path.join(HERE, "results.json"), "w", encoding="utf-8") as f:
        json.dump({"config": {"shape": shape, "epochs": epochs, "seed": args.seed}, "environment": env,
                   "training_seconds": {"float": f_train, "binary": b_train}, "head_to_head": results,
                   "dispatcher": report, "kernels_exact": exact, "predictions_identical": same}, f, indent=1)
    print(f"\nwrote results.md and results.json in {HERE}")


if __name__ == "__main__":
    main()
