#!/bin/bash
# One button: set up a private Python environment the first time, then run the MNIST race.
cd "$(dirname "$0")" || exit 1
if [ ! -x .venv/bin/python ]; then
    echo "Setting up a local Python environment, first run only..."
    python3 -m venv .venv || { echo "Could not set up Python. Install Python 3.10+ from python.org."; read -r; exit 1; }
fi
.venv/bin/python -m pip install --quiet --disable-pip-version-check numpy numba
.venv/bin/python mnist_compare.py "$@"
echo
read -r -p "Done. Press Return to close."
