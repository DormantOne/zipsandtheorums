@echo off
rem One button: set up a private Python environment the first time, then run the MNIST race.
cd /d "%~dp0"
set PY=python
where py >nul 2>nul && set PY=py -3
if not exist ".venv\Scripts\python.exe" (
    echo Setting up a local Python environment, first run only...
    %PY% -m venv .venv || goto :fail
)
".venv\Scripts\python.exe" -m pip install --quiet --disable-pip-version-check numpy numba || goto :fail
".venv\Scripts\python.exe" mnist_compare.py %*
pause
exit /b

:fail
echo.
echo Could not set up Python. Install Python 3.10 or newer from python.org and try again.
pause
