/* v16 — ACBA-inspired quantization-aware evolution.
 * acba_mnist trains floating shadow weights but EVALUATES a binary projection.
 * Our recurrent strict ternary walker has neither supervised targets nor a
 * differentiable loss, so we use fitness-difference evolutionary probes in
 * place of ACBA's Adam/backprop. No non-ternary genotype reaches MuJoCo.
 *
 * Mirrored probes share an evolved parent, loci and high-resolution latent
 * mutations, but take opposite signs. The better result nudges the parent's
 * shadow toward that direction, *within the bin of its actual discrete genes*.
 * Children inherit their own latent shadows on the selection frontier. A
 * structural mutation/crossover makes a new shadow from the projected genes.
 */
import {isRigGenome,rigAudit,KIND} from '../brain.mjs';
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const loc=(g)=>{
  const n=g[1]|0,a=g[3]|0,o=8+12*n,indices=[];
  for(let i=0;i<n;i++){
    const j=8+12*i;
    if(g[j]!==2)for(let k=4;k<=6;k++)indices.push(j+k);
  }
  // Keep the number of active votes in every motor unchanged. ACBA probes
  // change their signs, never their presence or motor/voter topology.
  for(let i=0;i<a*n;i++)if(g[o+i])indices.push(o+i);
  return indices;
};
const isVote=(g,i)=>i>=8+12*(g[1]|0);
const projection=(value,vote)=>vote?(value<0?-1:1):(value>.5?1:value<-.5?-1:0);
const center=(value,vote)=>vote?(value>0?.55:-.55):value*.85;
const sameSign=(a,b)=>a===b;
const safeBin=(x,sign,vote)=>vote?(sign===1?clamp(x,.001,2):clamp(x,-2,-.001)):
  sign===1?clamp(x,.5001,2):sign===-1?clamp(x,-2,-.5001):clamp(x,-.4999,.4999);
export class AcbaTernary{
  constructor(){this.shadows=new WeakMap();this.stats={pairs:0,preferPlus:0,preferMinus:0,ties:0,mutated:0,shadowAdjustments:0,restarts:0};}
  eligible(g){return isRigGenome(g)&&g[6]===KIND.STRICT_FIXED;}
  shadow(g){if(!this.eligible(g))return null;
    let s=this.shadows.get(g);if(!s){s=new Float32Array(g.length);for(const j of loc(g))s[j]=center(g[j],isVote(g,j));this.shadows.set(g,s)}return s;}
  // The archive checkpoint stores only non-default fractional offsets, so
  // large mostly-silent decoder arrays do not inflate the JSON unnecessarily.
  export(g){const s=this.shadows.get(g);if(!s)return null;const v=[];for(const j of loc(g)){const d=s[j]-center(g[j],isVote(g,j));if(Math.abs(d)>.0005)v.push([j,Math.round(s[j]*1e5)/1e5])}return v.length?v:null;}
  import(g,values){if(!this.eligible(g)||!Array.isArray(values))return;const s=this.shadow(g);
    for(const entry of values){if(!Array.isArray(entry)||entry.length!==2)continue;const [i,v]=entry;
      if(!Number.isInteger(i)||i<0||i>=g.length||!Number.isFinite(v))continue;
      const vote=isVote(g,i);if(vote){if(!g[i])continue}else if(i<8||i>=8+12*(g[1]|0)||[4,5,6].indexOf((i-8)%12)<0||g[8+12*Math.floor((i-8)/12)]===2)continue;
      if(projection(v,vote)===g[i])s[i]=v;
    }
  }
  // Two evaluated children; same strict ternary controller format, no latent
  // weights passed to physics. Each direction probes the SAME loci.
  pair(parent,rng,{moves=4,step=.57}={}){
    if(!this.eligible(parent))return null;
    const slots=loc(parent);if(!slots.length)return null;
    const s=this.shadow(parent),plus=new Float32Array(s),minus=new Float32Array(s);
    const gp=parent.slice(),gm=parent.slice(),chosen=[];
    const take=Math.max(1,Math.min(slots.length,Math.round(moves)));
    const used=new Set();for(let k=0;k<take;k++){
      let pick=slots[Math.floor(rng.next()*slots.length)],tries=0;
      while(used.has(pick)&&tries++<15)pick=slots[Math.floor(rng.next()*slots.length)];
      if(used.has(pick))continue;used.add(pick);
      const dir=rng.next()<.5?-1:1,amount=step*(.8+.65*rng.next()),vote=isVote(parent,pick);
      plus[pick]=clamp(s[pick]+dir*amount,-1.9,1.9);
      minus[pick]=clamp(s[pick]-dir*amount,-1.9,1.9);
      gp[pick]=projection(plus[pick],vote);gm[pick]=projection(minus[pick],vote);
      chosen.push({i:pick,dir,vote});
    }
    // An exact duplicate pair wastes two expensive MuJoCo candidate slots.
    // A last-resort categorical flip permits a useful strict candidate even
    // if all sampled floating perturbations stay inside one quantization bin.
    if(chosen.length&&chosen.every(({i})=>gp[i]===parent[i]&&gm[i]===parent[i])){
      const {i,dir,vote}=chosen[0],v=parent[i];
      if(vote){gp[i]=-v;plus[i]=-center(v,true)}
      else {gp[i]=v===1?0:v===-1?0:dir;plus[i]=center(gp[i],false)}
    }
    if(!rigAudit(gp).ok||!rigAudit(gm).ok)throw Error('ACBA evolution produced invalid strict genome');
    this.shadows.set(gp,plus);this.shadows.set(gm,minus);this.stats.mutated+=2;
    return {parent,plus:gp,minus:gm,chosen};
  }
  // The two scores are from SAME training bank. Bounded normalized fitness
  // difference is a zeroth-order, straight-through-style update of the latent
  // mutation state, not a claimed analytic gradient through MuJoCo.
  credit(pair,plusScore,minusScore){
    if(!pair||!Number.isFinite(plusScore)||!Number.isFinite(minusScore))return;
    this.stats.pairs++;const d=plusScore-minusScore;
    if(Math.abs(d)<1e-10){this.stats.ties++;return}
    if(d>0)this.stats.preferPlus++;else this.stats.preferMinus++;
    const s=this.shadow(pair.parent),delta=Math.sign(d)*clamp(Math.abs(d)/(.03+Math.max(Math.abs(plusScore),Math.abs(minusScore))*.08),0,1)*.20;
    for(const {i,dir,vote} of pair.chosen){s[i]=safeBin(s[i]+dir*delta,pair.parent[i],vote);this.stats.shadowAdjustments++}
  }
}
