/* Evolve ↔ learn: freeze the strict ternary connectome and train a differentiable
 * descendant against the SAME MuJoCo walker's reward. MuJoCo JS has no reverse-
 * mode derivatives: symmetric SPSA is a two-sided stochastic gradient estimator
 * (not backpropagation). All measurements are real plant.evaluate rollouts.
 * The learned kind-6 genome never enters the strictly ternary archive.
 */
import {KIND,ROLE,isRigGenome,unpackRig,packRig,rigAudit} from '../brain.mjs';
import {Rng,hash32} from './rng.mjs';
const clamp=(x,lo,hi)=>Math.max(lo,Math.min(hi,x));
const sign=x=>x<0?-1:x>0?1:0;
export const isHeir=g=>isRigGenome(g)&&(g[6]|0)===KIND.HEIR;
export function toHeir(original){
  if(!isRigGenome(original)||![KIND.STRICT_FIXED,KIND.STRICT_PLASTIC,KIND.TERNARY,KIND.PLASTIC].includes(original[6]|0))throw Error('Learning requires a fixed/ternary or plastic rig champion');
  const b=unpackRig(original);b.kind=KIND.HEIR;b.w=Float64Array.from(b.w);b.dec=Float64Array.from(b.dec);
  // The source genes, roles, active-edge/vote masks, and tick count are unchanged.
  delete b.eta;delete b.fade;const g=packRig(b);if(!rigAudit(g).ok)throw Error('Invalid continuous descendant: '+rigAudit(g).text);return g;
}
export function projectHeir(heir,source){
  if(!isHeir(heir)||!isRigGenome(source))throw Error('Cannot project unrelated brains');
  const b=unpackRig(heir),p=unpackRig(source);if(b.N!==p.N||b.A!==p.A||b.K!==p.K)throw Error('Topology dimensions changed');
  for(let i=0;i<b.src.length;i++)if(b.src[i]!==p.src[i]||(b.w[i]===0)!==(p.w[i]===0))throw Error('Input mask/source changed');
  for(let i=0;i<b.dec.length;i++)if((b.dec[i]===0)!==(p.dec[i]===0))throw Error('Motor-vote mask changed');
  b.kind=p.kind;b.w=Int8Array.from(b.w,sign);b.dec=Int8Array.from(b.dec,sign);
  b.bias=p.bias;b.gain=p.gain;b.fb=p.fb;b.eta=p.eta;b.fade=p.fade;
  const out=packRig(b);if(!rigAudit(out).ok)throw Error('Invalid projected strict ancestor: '+rigAudit(out).text);
  return out;
}
// A learned small-magnitude synapse can be safely suggested for removal at
// the moment the discrete topology is UNLOCKED. Unlike the frozen continuous
// stage, evolution is allowed to change active wire masks. Motor voter count
// and positions are NEVER pruned, so the 16-muscle decoder still audits.
export function guidedProjectHeir(heir,source,threshold=.8){
  const out=projectHeir(heir,source),b=unpackRig(heir),p=unpackRig(source);
  const t=clamp(Number(threshold),.05,.99);
  for(let i=0;i<b.N;i++)if(p.role[i]!==ROLE.TONIC)for(let k=0;k<3;k++){
    const j=3*i+k;if(p.w[j]!==0&&Math.abs(b.w[j])<t)out[8+12*i+4+k]=0;
  }
  if(!rigAudit(out).ok)throw Error('Guided projection failed ternary audit');return out;
}
export function topologyFingerprint(g){
  const b=unpackRig(g);let h=2166136261>>>0;
  const add=v=>{h=Math.imul(h^((v+1)|0),16777619)>>>0};
  add(b.N);add(b.K);add(b.A);for(const r of b.role)add(r);
  for(let k=0;k<b.src.length;k++){add(b.src[k]);add(b.w[k]===0?0:1)}
  for(const d of b.dec)add(d===0?0:1);
  return h.toString(16).padStart(8,'0');
}
export function paramGroups(g,{bias=false}={}){
  if(!isHeir(g))throw Error('Not a continuous heir');const b=unpackRig(g),wire=[],motor=[],offset=8+12*b.N,cellBias=[];
  for(let i=0;i<b.N;i++){
    if(b.role[i]!==ROLE.TONIC){for(let k=0;k<3;k++)if(b.w[3*i+k]!==0)wire.push(8+12*i+4+k);if(bias)cellBias.push(8+12*i+7)}
  }
  for(let a=0;a<b.A;a++)for(let i=0;i<b.N;i++)if(b.dec[a*b.N+i]!==0)motor.push(offset+a*b.N+i);
  return {motor,wire,bias:cellBias};
}
export function assertFrozen(source,g){
  if(!isHeir(g)||!isRigGenome(source))return false;
  const a=unpackRig(source),b=unpackRig(g);
  if(a.N!==b.N||a.A!==b.A||a.S!==b.S||a.K!==b.K||a.V!==b.V)return false;
  return a.src.every((x,i)=>x===b.src[i]&&(a.w[i]===0)===(b.w[i]===0))&&a.role.every((x,i)=>x===b.role[i])&&a.dec.every((x,i)=>(x===0)===(b.dec[i]===0));
}
function diverseParents(run,count,old=[]){
  const ranked=run.archive.ranked(),selected=[],minD=Math.max(2,Math.min(40,run.cfg.poolMinDiff??8));
  // First retain the best distinct source, then greedily reward BEHAVIOURAL
  // separation AND wiring distance. Large size differences aren't mistaken
  // for proof of distinct gaits.
  const candidates=[...ranked];
  for(let n=0;n<count&&candidates.length;n++){
    const topQ=ranked[0]?.quality??0;
    const order=candidates.map(e=>{
      const novelty=selected.length?Math.min(...selected.map(p=>{
        const d=run.plant.distance(e.genome,p.genome),w=Number.isFinite(d)?clamp(d/Math.max(minD,1),0,2):2;
        const keys=['duty','coordination','cadence'];let gait=0;
        for(const k of keys)gait+=(Number(e.desc?.[k]??0)-Number(p.desc?.[k]??0))**2;
        return .55*Math.sqrt(gait)+.45*clamp(w/2,0,1);
      })):0;
      return {e,score:(!n?0:.8*novelty)+.2*(e.quality-(topQ-1))};
    }).sort((a,b)=>b.score-a.score);
    const chosen=n===0?ranked[0]:order[0].e;selected.push(chosen);candidates.splice(candidates.indexOf(chosen),1);
  }
  return selected;
}

export function transferShadow(newStrict,previousStrict,continuous){
  // Neural parameters can be passed between a strict offspring and its
  // continuously learned parent ONLY when endpoint, role, sign and mask agree.
  if(!rigAudit(newStrict).ok)throw Error('Only audited discrete offspring may receive shadow memory');
  const fresh=toHeir(newStrict),n=unpackRig(newStrict),old=unpackRig(previousStrict),learn=unpackRig(continuous);
  if(n.A!==old.A||n.K!==old.K||n.S!==old.S)return fresh;
  const dst=unpackRig(fresh),count=Math.min(n.N,old.N);
  for(let i=0;i<count;i++){
    if(n.role[i]!==old.role[i])continue;
    for(let k=0;k<3;k++){
      const j=i*3+k;
      if(n.src[j]===old.src[j]&&n.w[j]!==0&&n.w[j]===old.w[j])dst.w[j]=learn.w[j];
    }
    // Never inherit a bias that is disallowed by the current learner config.
  }
  for(let a=0;a<n.A;a++)for(let i=0;i<count;i++){
    const j=a*n.N+i,k=a*old.N+i;
    if(n.role[i]===old.role[i]&&n.dec[j]!==0&&n.dec[j]===old.dec[k])dst.dec[j]=learn.dec[k];
  }
  const g=packRig(dst);if(!assertFrozen(newStrict,g)||!rigAudit(g).ok)throw Error('Shadow inheritance invalid');return g;
}
export function strictGenomeKey(g){const b=unpackRig(g);let h=2166136261>>>0;const x=v=>{h=Math.imul((h^(Math.round(v)|0)),16777619)>>>0};
  x(b.N);x(b.A);for(const v of b.role)x(v);for(const v of b.src)x(v);for(const v of b.w)x(v);for(const v of b.dec)x(v);return h.toString(16).padStart(8,'0');
}

export class HybridLearning {
  constructor(run,{seed=1,config={}}={}){
    this.run=run;this.rng=new Rng(hash32(seed^0xE701AE51));this.config=config;
    this.tracks=[];this.lineages=[];this.nursery=[];this.history=[];this.events=[];
    this.stage='evolution';this.cycle=0;this.stepCount=0;this.accepted=0;this.proposed=0;this.active=0;
    this.startedAtGen=0;this.stageStart=0;this.valCases=0;this.lineageSerial=0;this.nurserySerial=0;
    this.nurseryAttempts=0;this.nurseryMatured=0;this.nurseryPromoted=0;this.nurseryRetired=0;
    this.lastTransfer=null;
  }
  get track(){return this.tracks[this.active%Math.max(1,this.tracks.length)]||null}
  event(kind,extra={}){this.events.push({kind,cycle:this.cycle,generation:this.run.generation,atUpdate:this.stepCount,offspringBorn:this.nurserySerial,offspringImproved:this.nurseryMatured,offspringPromoted:this.nurseryPromoted,...extra});if(this.events.length>400)this.events.shift()}
  fingerprintOf(g){return topologyFingerprint(g)+'-'+strictGenomeKey(g)}
  chooseLens(t){
    if(this.run.cfg.selection==='smooth')return 'distance';  // one intrinsic objective, no conflicting reward lenses
    const arms=['distance','posture','footfalls'],st=t.lensStats||{};
    for(const lens of arms)if(!st[lens]?.n)return lens;
    const total=arms.reduce((a,k)=>a+st[k].n,0);let best=arms[0],score=-Infinity;
    for(const lens of arms){const a=st[lens],x=a.w/a.n+.45*Math.sqrt(Math.log(total+1)/a.n);if(x>score){score=x;best=lens}}return best;
  }
  async createTrack(strict,{id=null,origin='archive',shadow=null,ancestor=null,root=null,depth=0}={}){
    if(!rigAudit(strict).ok)throw Error('Non-ternary lineage founder');
    const source=Float64Array.from(strict),genome=shadow?Float64Array.from(shadow):toHeir(source);
    if(!assertFrozen(source,genome))throw Error('Inherited shadow has different topology');
    const [val]=await this.run.score([genome],this.run.suites.val);
    const seq=++this.lineageSerial,fp=this.fingerprintOf(source);
    return {id:id??seq,lineageId:seq,root:root??(id??seq),origin,depth,ancestor,gen:this.run.generation,
      fingerprint:fp,source,genome,best:genome.slice(),bestVal:val,initialVal:val,
      accepted:0,updates:0,visits:0,adaptiveSigma:1,noGainStreak:0,lastLens:'distance',lastGain:0,recent:null,
      lensStats:{distance:{n:0,w:0},posture:{n:0,w:0},footfalls:{n:0,w:0}},lastProjection:null};
  }
  chooseCandidates(count){
    const run=this.run,cap=Math.max(1,Math.min(8,count)),candidates=[],used=new Set();
    // Reserve capacity for successful old learners and for new nursery-born phenotypes.
    const add=(o)=>{if(o&&!used.has(o.key)){used.add(o.key);candidates.push(o)}};
    const previous=[...this.lineages].sort((a,b)=>((b.bestVal?.quality??0)-(a.bestVal?.quality??0)));
    if(previous.length)add({type:'old',record:previous[0],key:previous[0].fingerprint});
    const babies=[...this.nursery].filter(n=>n.attempts>=2).sort((a,b)=>b.quality-a.quality);
    if(babies.length)add({type:'nursery',record:babies[0],key:this.fingerprintOf(babies[0].genome)});
    for(const e of diverseParents(run,Math.max(cap*2,3))){add({type:'elite',record:e,key:this.fingerprintOf(e.genome)});if(candidates.length>=cap)break}
    for(const n of babies){if(candidates.length>=cap)break;add({type:'nursery',record:n,key:this.fingerprintOf(n.genome)})}
    for(const t of previous){if(candidates.length>=cap)break;add({type:'old',record:t,key:t.fingerprint})}
    return candidates.slice(0,cap);
  }
  async enter({count=3}={}){
    if(!this.run.archive.best())throw Error('No champion yet');
    const candidates=this.chooseCandidates(count),tracks=[];
    for(const item of candidates){
      if(item.type==='old'){
        const t=item.record;
        // Parent persists, its protected best cannot be overwritten by exploratory mutation.
        t.genome=t.best.slice();t.visits=(t.visits||0)+1;
        const indices=[...paramGroups(t.genome,{bias:!!this.config.hybridBias}).motor,...paramGroups(t.genome).wire];
        // Tiny mutations in full precision, no rewiring, then SPSA learning continues.
        const n=Math.min(10,Math.max(1,Math.floor(indices.length*.025)));
        for(let j=0;j<n;j++){const k=indices[Math.floor(this.rng.next()*indices.length)];
          t.genome[k]=clamp(t.genome[k]+(this.rng.next()-.5)*.15,-4,4);
          if(Math.abs(t.genome[k])<.02)t.genome[k]=Math.sign(t.best[k]||1)*.02;
        }
        if(!assertFrozen(t.source,t.genome))throw Error('Continuous mutation changed a protected mask');
        tracks.push(t);continue;
      }
      const e=item.record;
      const strict=Float64Array.from(e.genome);
      let donor=null,shadow=null;
      if(item.type==='nursery'){
        donor=this.lineages.find(x=>x.lineageId===e.lineageId);
        shadow=e.shadow&&assertFrozen(strict,e.shadow)?e.shadow:
          donor?transferShadow(strict,donor.source,donor.best):null;
      }else{
        donor=this.lineages.find(t=>this.fingerprintOf(strict)===t.fingerprint);
        if(donor){tracks.push(donor);continue}
      }
      tracks.push(await this.createTrack(strict,{id:e.id,origin:item.type,shadow,ancestor:donor?.lineageId??null,
        root:donor?.root??e.id,depth:(donor?.depth??0)+Number(item.type==='nursery')}));
      this.event('lineage-birth',{lineageId:tracks.at(-1).lineageId,from:item.type});
    }
    if(!tracks.length)throw Error('No learners available');
    const byId=new Map(this.lineages.map(t=>[t.lineageId,t]));
    for(const t of tracks)byId.set(t.lineageId,t);
    this.lineages=[...byId.values()];
    const cap=Math.max(8,Math.round(+this.config.hybridLineageCap||16));
    // Keep active tracks and highly validated prior lines; no loss of learning during switching.
    if(this.lineages.length>cap){const active=new Set(tracks.map(t=>t.lineageId));this.lineages=this.lineages.filter(t=>active.has(t.lineageId)).concat(this.lineages.filter(t=>!active.has(t.lineageId)).sort((a,b)=>b.bestVal.quality-a.bestVal.quality).slice(0,Math.max(0,cap-tracks.length)))}
    this.tracks=tracks;this.stage='learning';this.stageStart=this.stepCount;this.startedAtGen=this.run.generation;this.active=0;this.cycle++;
    for(const t of tracks)t.entryQuality=t.bestVal.quality;
    this.event('enter',{lineages:tracks.map(t=>t.lineageId),sources:tracks.map(t=>t.origin)});
    return tracks.length;
  }
  makeSuite(t){
    const r=this.run,epoch=Math.floor(t.updates/Math.max(1,+this.config.hybridRotate||8));
    return r.plant.trainingSuite(r.seed^hash32(t.id),epoch,{...r.cfg,trainCases:Math.max(1,Math.min(4,Math.round(this.config.hybridCases||2))),trainSeconds:Math.min(6,r.cfg.trainSeconds)});
  }
  async measures(genomes,suite,lens){const r=this.run,cfg=this.run.cfg.selection==='smooth'?{...r.cfg,selection:'smooth'}:{...r.cfg,selection:'curriculum',rung:lens};
    const out=await r.plant.evaluate(genomes,suite,{cfg,train:true});r.charge(out,genomes);return out.map(rows=>r.plant.summarize(rows,{cfg}));}
  async step(){
    if(this.stage!=='learning'||!this.tracks.length)throw Error('Learning stage not active');
    const t=this.track,opts=this.config,lens=this.chooseLens(t),groups=paramGroups(t.genome,{bias:!!opts.hybridBias});
    const ix=t.updates%10,group=ix<3?'motor':ix<7?'wire':ix<9?'all':'bias';
    let indices=group==='motor'?groups.motor:group==='wire'?groups.wire:group==='bias'?(groups.bias.length?groups.bias:groups.motor):[...groups.motor,...groups.wire];
    if(!indices.length)indices=groups.motor;
    const sig=clamp((+opts.hybridSigma||.12)*(t.adaptiveSigma||1),.005,.8),rate=clamp(+opts.hybridRate||.07,.001,.5),N=indices.length;
    const p=t.genome.slice(),m=t.genome.slice(),direction=new Int8Array(N);
    for(let k=0;k<N;k++){
      const d=this.rng.next()<.5?-1:1,v=indices[k],lo=group==='bias'?-2:-4,hi=group==='bias'?2:4;
      direction[k]=d;p[v]=clamp(p[v]+sig*d,lo,hi);m[v]=clamp(m[v]-sig*d,lo,hi);
      if(group!=='bias'){if(Math.abs(p[v])<.02)p[v]=Math.sign(t.genome[v]||1)*.02;if(Math.abs(m[v])<.02)m[v]=Math.sign(t.genome[v]||1)*.02}
    }
    const suite=this.makeSuite(t),[base,plus,minus]=await this.measures([t.genome,p,m],suite,lens);
    const slope=(plus.selection-minus.selection)/(2*sig),scale=rate*clamp(slope/(Math.sqrt(N)*Math.max(.03,Math.abs(base.selection)*.2)),-.35,.35);
    let accepted=false,gain=0,candidate=null,score=null;
    const probes=[{g:p,s:plus},{g:m,s:minus}];
    if(Number.isFinite(scale)&&Math.abs(scale)>1e-8){
      candidate=t.genome.slice();for(let k=0;k<N;k++){
        const j=indices[k],old=candidate[j];candidate[j]=clamp(old+scale*direction[k],group==='bias'?-2:-4,group==='bias'?2:4);
        if(group!=='bias'&&Math.abs(candidate[j])<.02)candidate[j]=Math.sign(old||1)*.02;
      }
      if(!assertFrozen(t.source,candidate))throw Error('SPSA changed a frozen endpoint');
      [score]=await this.measures([candidate],suite,lens);probes.push({g:candidate,s:score});
    }
    const winner=probes.filter(q=>assertFrozen(t.source,q.g)&&Number.isFinite(q.s.selection)).sort((a,b)=>b.s.selection-a.s.selection)[0];
    if(winner&&winner.s.selection>base.selection+1e-8){t.genome=winner.g;accepted=true;gain=winner.s.selection-base.selection;t.accepted++;this.accepted++}
    const state=t.lensStats[lens];state.n++;if(accepted)state.w++;
    t.noGainStreak=accepted?0:t.noGainStreak+1;t.adaptiveSigma=clamp(t.adaptiveSigma*(accepted?.96:t.noGainStreak%5===0?1.18:1),.5,2.5);
    t.updates++;this.stepCount++;this.proposed++;t.lastLens=lens;t.lastGain=gain;
    t.recent={lens,group,base:base.selection,plus:plus.selection,minus:minus.selection,accepted,gain,slope};
    if(t.updates%Math.max(1,Math.round(opts.hybridValEvery||6))===0){
      const [v]=await this.run.score([t.genome],this.run.suites.val);this.valCases++;
      if(v.quality>t.bestVal.quality+1e-9){t.best=t.genome.slice();t.bestVal=v;this.event('new-best',{lineageId:t.lineageId,quality:v.quality})}
    }
    this.active=(this.active+1)%this.tracks.length;return t.recent;
  }
  // A fixed strict genome is never rejected merely because a fitter elite has
  // already occupied its behaviour cell. Such offspring enter the nursery.
  async leave(){
    if(this.stage!=='learning')return {projected:0,admitted:0,nursery:0};
    const r=this.run;let projected=0,admitted=0,born=0;
    for(const t of this.tracks){
      if(!assertFrozen(t.source,t.best))throw Error('Topology drift');
      const [latest]=await r.score([t.genome],r.suites.val);this.valCases++;
      if(latest.quality>t.bestVal.quality+1e-9){t.best=t.genome.slice();t.bestVal=latest}
      const proposed=[projectHeir(t.best,t.source),guidedProjectHeir(t.best,t.source,.8),guidedProjectHeir(t.best,t.source,.65)];
      const seen=new Set(),variants=[];
      for(const g of proposed){const k=strictGenomeKey(g);if(!seen.has(k)){seen.add(k);variants.push(g)}}
      // Even a sign-preserving continuous improvement now gets a newborn,
      // through one carefully bounded STRICT mutation of its projection.
      const base=variants[0];
      for(let i=0;i<2;i++){
        const g=r.plant.mutate(base,r.rng,{cfg:r.cfg,count:i+1});
        if(rigAudit(g).ok){const key=strictGenomeKey(g);if(!seen.has(key)){seen.add(key);variants.push(g)}}
      }
      const scored=await r.score(variants,r.suites.val);projected+=variants.length;
      let bestJ=0,trackAdmitted=0;
      for(let j=0;j<variants.length;j++){
        const g=variants[j],v=scored[j];if(v.quality>scored[bestJ].quality)bestJ=j;
        // Immediate elite admission is permitted but not required for survival.
        const result=r.archive.tryAdd({genome:g,quality:v.quality,record:v.record,guard:v.guard,desc:v.desc,stats:v,
          generation:r.generation,source:'metamorphosis',learnCycle:this.cycle,lineageId:t.lineageId});
        if(result){admitted++;trackAdmitted++;}
        const newborn=this.birthNursery(g,v,t,{shadow:transferShadow(g,t.source,t.best),origin:j<proposed.length?'projection':'mutated-projection'});
        if(newborn)born++;
      }
      const [holdContinuous,holdStrict]=await r.score([t.best,variants[bestJ]],r.suites.hold);
      t.lastProjection={quality:scored[bestJ].quality,admitted:trackAdmitted>0,source:t.initialVal.quality,
        continuous:t.bestVal.quality,variants:variants.length,holdContinuous:holdContinuous.quality,holdStrict:holdStrict.quality,
        nurseryBorn:born,validatedGain:t.bestVal.quality-(t.entryQuality??t.initialVal.quality)};
      this.history.push({cycle:this.cycle,generation:r.generation,lineageId:t.lineageId,id:t.id,
        before:t.entryQuality??t.initialVal.quality,after:t.bestVal.quality,strict:scored[bestJ].quality,
        holdContinuous:holdContinuous.quality,holdStrict:holdStrict.quality,projected:variants.length,admitted:trackAdmitted});
    }
    if(admitted)r.archive.derivePool();this.stage='evolution';this.event('leave',{projected,admitted,nurseryBorn:born});
    this.lastTransfer={projected,admitted,nurseryBorn:born};return {projected,admitted,nursery:born};
  }
  birthNursery(genome,score,t,{shadow=null,origin='projection'}={}){
    if(!rigAudit(genome).ok)throw Error('Nursery candidate violates strict ternary');
    const key=strictGenomeKey(genome);
    if(this.nursery.some(n=>strictGenomeKey(n.genome)===key))return null;
    const cap=Math.max(3,Math.min(48,Math.round(+this.config.hybridNurseryCap||18)));
    if(this.nursery.length>=cap){const oldest=this.nursery.slice().sort((a,b)=>a.quality-b.quality||b.attempts-a.attempts)[0];
      this.nursery.splice(this.nursery.indexOf(oldest),1);this.nurseryRetired++;this.event('nursery-retire',{id:oldest.id,reason:'capacity'})}
    const n={id:++this.nurserySerial,origin,lineageId:t.lineageId,root:t.root,depth:t.depth+1,
      genome:Float64Array.from(genome),shadow:shadow?Float64Array.from(shadow):toHeir(genome),quality:score.quality,
      initialQuality:score.quality,desc:score.desc,attempts:0,wins:0,bornCycle:this.cycle,bornGeneration:this.run.generation,
      lastGain:0};
    if(!assertFrozen(n.genome,n.shadow))throw Error('Invalid nursery shadow');
    this.nursery.push(n);this.event('nursery-birth',{id:n.id,lineageId:n.lineageId,quality:n.quality});return n;
  }
  async evolveNursery(){
    if(this.stage!=='evolution'||!this.nursery.length)return null;
    // One extra validated strict mutation per ordinary evolution generation:
    // explicit compute cost, never an unbounded hidden second evolution engine.
    const budget=Math.max(2,Math.min(200,Math.round(+this.config.hybridNurseryTrials||24)));
    const viable=this.nursery.filter(n=>n.attempts<budget);
    if(!viable.length)return null;
    viable.sort((a,b)=>a.attempts-b.attempts||b.quality-a.quality);
    const parent=viable[0],run=this.run;
    const child=run.plant.mutate(parent.genome,run.rng,{cfg:run.cfg,count:1+(parent.attempts%3)});
    if(!rigAudit(child).ok)throw Error('Nursery mutation violated strict ternary');
    const [v]=await run.score([child],run.suites.val);
    const improved=v.quality>parent.quality+1e-10;
    parent.attempts++;this.nurseryAttempts++;
    if(improved){
      const prior=parent.genome,oldShadow=parent.shadow;
      parent.genome=Float64Array.from(child);parent.shadow=transferShadow(child,prior,oldShadow);
      parent.lastGain=v.quality-parent.quality;parent.quality=v.quality;parent.desc=v.desc;parent.wins++;this.nurseryMatured++;
      const admitted=run.archive.tryAdd({genome:parent.genome.slice(),quality:v.quality,record:v.record,guard:v.guard,
        desc:v.desc,stats:v,generation:run.generation,source:'nursery-matured',learnCycle:this.cycle,lineageId:parent.lineageId});
      if(admitted){this.nurseryPromoted++;run.archive.derivePool();this.event('nursery-promote',{id:parent.id,lineageId:parent.lineageId,quality:v.quality})}
      else this.event('nursery-improve',{id:parent.id,quality:v.quality});
    }
    if(parent.attempts>=budget){
      this.nursery.splice(this.nursery.indexOf(parent),1);this.nurseryRetired++;
      // Even retiring offspring can have made a useful learner; persist a
      // learning invitation as part of the pool rather than losing their shadow.
      if(parent.wins>0){
        const t=await this.createTrack(parent.genome,{origin:'nursery-retired',shadow:parent.shadow,
          ancestor:parent.lineageId,root:parent.root,depth:parent.depth});
        this.lineages.push(t);
      }
      this.event('nursery-retire',{id:parent.id,attempts:parent.attempts,wins:parent.wins});
    }
    this.event('nursery-trial',{id:parent.id,lineageId:parent.lineageId,attempts:parent.attempts,improved,quality:parent.quality});
    return {id:parent.id,improved,quality:parent.quality,attempts:parent.attempts};
  }
  // A v14/v13 checkpoint stores *scores* from the ladder objective. Under
  // the new smooth objective, re-evaluate its genomes before choosing heirs,
  // promoting offspring or comparing validation scores. Never compare old 0–3
  // scores directly to v15 smooth scores, or the lineages will appear frozen.
  async migrateFitness(oldVersion='legacy-ladder'){
    const run=this.run;
    if(run.cfg.selection!=='smooth')return false;
    this.legacyHistory=[...(this.legacyHistory||[]),...this.history.map(h=>({...h,fitnessVersion:oldVersion}))].slice(-300);
    this.history=[];
    for(const t of this.lineages){
      const [initial,best]=await run.score([toHeir(t.source),t.best],run.suites.val);
      t.initialVal=initial;t.bestVal=best;t.entryQuality=best.quality;
      // Preserve both learned weights and accumulated update history; only
      // invalidate objective-dependent scores and lens-specific success counts.
      t.recent=null;t.lastProjection=null;t.noGainStreak=0;
      t.lensStats={distance:{n:0,w:0},posture:{n:0,w:0},footfalls:{n:0,w:0}};
    }
    for(const n of this.nursery){
      const [v]=await run.score([n.genome],run.suites.val);
      n.preMigrationQuality=n.quality;n.quality=v.quality;n.initialQuality=v.quality;n.desc=v.desc;
      n.lastGain=0;
    }
    this.stageStart=this.stepCount;this.event('fitness-rescored',{oldVersion,fitnessVersion:'smooth-intrinsic-gate-v1',lineages:this.lineages.length,nursery:this.nursery.length});
    return true;
  }
  status(){
    const tracks=this.tracks.map(t=>({id:t.id,lineageId:t.lineageId,origin:t.origin,ancestor:t.ancestor,depth:t.depth,
      updates:t.updates,accepted:t.accepted,quality:t.bestVal?.quality,original:t.initialVal?.quality,
      entry:t.entryQuality,fingerprint:t.fingerprint,last:t.recent,lenses:t.lensStats,projection:t.lastProjection||null}));
    const recent=this.history.slice(-100);
    return {stage:this.stage,cycle:this.cycle,updates:this.stepCount,accepted:this.accepted,proposed:this.proposed,
      active:this.active,championCount:this.tracks.length,startedAtGen:this.startedAtGen,tracks,
      lineages:this.lineages.map(t=>({id:t.id,lineageId:t.lineageId,origin:t.origin,ancestor:t.ancestor,depth:t.depth,
        quality:t.bestVal.quality,entry:t.entryQuality,updates:t.updates,visits:t.visits||0})),
      nursery:this.nursery.map(n=>({id:n.id,lineageId:n.lineageId,origin:n.origin,quality:n.quality,
        initial:n.initialQuality,attempts:n.attempts,wins:n.wins,depth:n.depth})),
      counts:{lineages:this.lineages.length,nursery:this.nursery.length,nurseryBorn:this.nurserySerial,nurseryAttempts:this.nurseryAttempts,
        nurseryMatured:this.nurseryMatured,nurseryPromoted:this.nurseryPromoted,nurseryRetired:this.nurseryRetired},
      history:recent,lastTransfer:this.lastTransfer,events:this.events.slice(-150)};
  }
  serialize(){const pack=t=>({...t,source:Array.from(t.source),genome:Array.from(t.genome),best:Array.from(t.best)});
    return {format:'WALKER_EVOLVE_LEARN_CHECKPOINT',version:2,fitnessVersion:this.run.cfg.selection==='smooth'?'smooth-intrinsic-gate-v1':this.run.cfg.selection,stage:this.stage,cycle:this.cycle,stepCount:this.stepCount,
      accepted:this.accepted,proposed:this.proposed,active:this.active,seed:this.rng.rngState,startedAtGen:this.startedAtGen,
      stageStart:this.stageStart,checks:{joints:this.run.cfg.joints,friction:this.run.cfg.friction,brainKind:this.run.cfg.brainKind,
        seed:this.run.seed,baseN:this.run.cfg.N},lineageSerial:this.lineageSerial,nurserySerial:this.nurserySerial,
      counts:{nurseryAttempts:this.nurseryAttempts,nurseryMatured:this.nurseryMatured,nurseryPromoted:this.nurseryPromoted,nurseryRetired:this.nurseryRetired},
      tracks:this.tracks.map(t=>t.lineageId),lineages:this.lineages.map(pack),nursery:this.nursery.map(n=>({...n,genome:Array.from(n.genome),shadow:Array.from(n.shadow)})),
      history:this.history.slice(-300),legacyHistory:(this.legacyHistory||[]).slice(-300),events:this.events.slice(-400),lastTransfer:this.lastTransfer};}
  restore(x){
    if(x?.format!=='WALKER_EVOLVE_LEARN_CHECKPOINT'||![1,2].includes(x.version))throw Error('Unsupported learning checkpoint');
    const c=x.checks,r=this.run.cfg;
    if(c.joints!==r.joints||c.friction!==r.friction||c.brainKind!==r.brainKind||c.seed!==this.run.seed||c.baseN!==r.N)throw Error('Learning checkpoint physics/brain mismatch');
    if(x.version===1){
      this.lineages=x.tracks.map((t,i)=>({...t,id:t.id,lineageId:i+1,root:t.id,origin:'v13-import',depth:0,
        source:Float64Array.from(t.source),genome:Float64Array.from(t.genome),best:Float64Array.from(t.best),
        visits:0,fingerprint:this.fingerprintOf(Float64Array.from(t.source))}));
      this.tracks=[...this.lineages];this.lineageSerial=this.lineages.length;
      this.events=[...(x.events||[])];this.event('v13-migrated',{lineages:this.lineages.length});
    }else{
      this.lineages=(x.lineages||[]).map(t=>({...t,source:Float64Array.from(t.source),genome:Float64Array.from(t.genome),best:Float64Array.from(t.best)}));
      const m=new Map(this.lineages.map(t=>[t.lineageId,t]));this.tracks=(x.tracks||[]).map(id=>m.get(id)).filter(Boolean);
      this.nursery=(x.nursery||[]).map(n=>({...n,genome:Float64Array.from(n.genome),shadow:Float64Array.from(n.shadow)}));
      this.history=x.history||[];this.legacyHistory=x.legacyHistory||[];this.events=x.events||[];this.lastTransfer=x.lastTransfer||null;
      this.lineageSerial=x.lineageSerial||this.lineages.length;this.nurserySerial=x.nurserySerial||this.nursery.length;
      const z=x.counts||{};this.nurseryAttempts=z.nurseryAttempts||0;this.nurseryMatured=z.nurseryMatured||0;
      this.nurseryPromoted=z.nurseryPromoted||0;this.nurseryRetired=z.nurseryRetired||0;
    }
    for(const t of this.lineages)if(!assertFrozen(t.source,t.best)||!assertFrozen(t.source,t.genome))throw Error('Corrupt continuous lineage');
    for(const n of this.nursery)if(!rigAudit(n.genome).ok||!assertFrozen(n.genome,n.shadow))throw Error('Corrupt ternary nursery');
    this.rng.rngState=x.seed>>>0;this.stage=x.stage;this.cycle=x.cycle;this.stepCount=x.stepCount;this.accepted=x.accepted;
    this.proposed=x.proposed;this.active=x.active;this.startedAtGen=x.startedAtGen;this.stageStart=x.stageStart??this.stepCount;
  }
}
