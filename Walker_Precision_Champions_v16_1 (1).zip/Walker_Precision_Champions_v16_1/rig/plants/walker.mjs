/* rig/plants/walker.mjs — the MuJoCo quadruped as a rig plant. Ternary only.
 *
 * BRAIN        engine/ternary.mjs, unchanged: birth wiring optimizer, the lab's
 *              operator with the walker amendments, unit-block crossover, growth.
 * BODY/REWARD  engine/plant.js rollouts, unchanged and still fenced. Per trial,
 *              the reward of record is aggregateDifficultyGait([row]) -- the bank
 *              formula applied to one trial -- so it is exactly the lab's number.
 * THE SPLIT    selection and archive quality: mean over trials of a per-trial
 *              LADDER score (below); guard: Q25 of per-trial reward of record;
 *              record: the bank statistic, on the lab's own 7-scenario 8 s
 *              yardstick, so rig records are comparable with the lab's.
 * THE LADDER   (walker-ladder-v2) each trial is placed on the lab's own rungs,
 *              using the lab's own definitions (engine/gait_curriculum.mjs)
 *              applied to that trial:
 *                0 + posture progress   posture not held (fell, floor contact, or
 *                                       harm > 1.25 -- a slide over 6.25 cm)
 *                1 + footfall progress  upright, but footfall quality < 0.72
 *                2 + walking progress   upright and stepping: ordered by the
 *                                       per-trial reward of record Q (m/s)
 *              So a trial that falls or skates costs a whole rung, and among
 *              trials that walk the order is the reward of record. No rung
 *              schedule, no cycles: every trial carries its own rung.
 *              v2 (7.1.1): progress inside a rung never has a flat floor. v1
 *              clamped the lab's posture score at zero, and a fallen newborn's
 *              posture score is strongly negative, so every fallen brain scored
 *              exactly 0 and a from-birth run had nothing to climb (the first
 *              real smoke run showed it). Rung 0 now squashes the lab's own,
 *              unclamped posture score through a logistic, exactly order-
 *              preserving, and rungs 1 and 2 carry small tie-breakers so a
 *              standing brain that does not step, or a stepping brain with no
 *              clean progress, still has a slope.
 * DESCRIPTORS  duty factor, coordination (trot <-> pace), cadence: how it moves,
 *              not how good it is.
 */
import fs from 'node:fs';
import zlib from 'node:zlib';
import {birthTernary,mutateTernary,crossoverTernary,growTernary,baseMutationCount,unpackTernary,ternaryHeader,isTernaryGenome,TERNARY_RULE} from '../../engine/ternary.mjs';
import {isRigGenome,rigSize,unpackRig,birthRig,mutateRig,crossRig,growRig,shrinkRig,rigDistance} from '../brain.mjs';
import {isContinuous} from '../continuous.mjs';
import {makeScenario,PLANT} from '../../engine/plant.js';
import {applyTaskScenario} from '../../engine/task_curriculum.mjs';
import {aggregateDifficultyGait} from '../../engine/difficulty_gait.mjs';
import {summarizeRollouts} from '../../engine/phenotype.js';
import {curriculumObservation,RUNGS,footfallQuality,FOOTFALL_PASS} from '../../engine/gait_curriculum.mjs';
import {hash32,seedFor} from '../core/rng.mjs';
import {smoothGaitReward,SMOOTH_GATE_VERSION} from '../../engine/smooth_gate.mjs';
import {mean,quantile,median} from '../core/stats.mjs';

const clamp=(x,a,b)=>Math.max(a,Math.min(b,x)),num=(v,d=0)=>Number.isFinite(Number(v))?Number(v):d;
const CONTROL_DT=PLANT.dt*PLANT.frameSkip;
export const LADDER_QREF=0.1;
export const WALKER_SCORING_VERSION='walker-ladder-v2+smooth-intrinsic-gate-v1';
/* The search itself, separately from the scoring: v2 = founders, immigrants and
 * early exit for fallen training trials (v7.1.3). Experiments run with another
 * search version are moved aside, never resumed or mixed. */
export const WALKER_SEARCH_VERSION='walker-search-v2';
const logistic=x=>1/(1+Math.exp(-x));
export const WALKER_PHYSICS=Object.freeze({legScale:.72,frictionMu:1.1,friction:'firm',run:{difficulty:1,actuation:'torque',kp:55,kd:5,tauCap:32,hpBudget:800}});
/* v10.0.2 FRICTION. 'firm' (default): MuJoCo's elliptic friction cone with impratio 10,
 * so a planted foot grips instead of creeping. 'legacy': the Foundry's soft friction
 * (pyramidal cone, impratio 1), under which a loaded foot creeps 7-15 mm/s and an
 * honest 7 cm/s trot is scored as harm on 22 of 24 validation trials (see README). */
export const FRICTION_MODES=Object.freeze({firm:{frictionCone:'elliptic',impratio:10},legacy:{frictionCone:'pyramidal',impratio:1}});
export const frictionOf=physics=>physics?.friction==='legacy'?'legacy':'firm';
/* v10.0.1 JOINTS. 'torque' (the lab's contract, v10.0.0): each motor command is a
 * raw torque, held for the 20 ms control step. 'servo': each command is a joint
 * target (rest + 25 % of the joint's range per unit) tracked by the plant's PD
 * servo (kp 55, kd 5), recomputed every 4 ms physics step and capped at the same
 * motor limits. With a servo a zero command holds the standing pose. */
/* v10.1.0 'muscles': two muscles per joint (sixteen commands), so the brain sets
 * each joint's stiffness as well as its angle; half tone in both is the servo
 * (engine/plant.js, torquesFrom). */
export const JOINT_MODES=Object.freeze({torque:'torque',servo:'pd',muscles:'muscle'});
export const jointsOf=run=>run?.actuation==='muscle'?'muscles':run?.actuation==='pd'||run?.actuation==='servo'?'servo':'torque';
/* how many motor outputs a brain needs for these joints */
export const motorsFor=joints=>joints==='muscles'?16:8;

export function walkerSearchDefaults(N){
  return {lambda:12,mutations:baseMutationCount(N),strongEvery:20,revisitPct:35,archivePct:45,crossPct:20,selExp:1.8,
    poolSize:8,poolMinDiff:8,bins:5,archiveCap:125,trainCases:6,trainSeconds:6,rotate:20,valCases:24,valSeconds:8,holdCases:32,valEvery:4,threshold:60,
    voters:6,pacemaker:0,focus:TERNARY_RULE.focus,sensorBias:TERNARY_RULE.sensorBias,silenceOdds:TERNARY_RULE.silenceOdds,
    /* v8: selection is the lab's CYCLED RUNG CURRICULUM, scored pendulum-style:
     * per trial the active rung's own score, then mean + worstWeight x worst.
     * posture -> footfalls when >= passShare of validation trials pass posture,
     * footfalls -> distance likewise; after distanceGens on distance the cycle
     * restarts at posture (skills that were kept pass again within a validation). */
    selection:'smooth',rung:'posture',worstWeight:.5,passShare:.75,distanceGens:400,
    brain:'rig',ticks:10,internalShare:.5,tonicShare:.08,          // v9: the rig's brain (rig/brain.mjs)
    difficulty:1,suiteSeed:1,labRunSeed:1,yardstickN:7,earlyExit:null,
    /* v7.1.3 (walker-search-v2): varied champions and cheaper falls */
    founders:24,                 // independent newborns scored first (a seeded run: the fossil + strong mutants)
    immigrants:2,immigrantEvery:40,   // new lineages offered to the archive every 40 generations
    trainEarlyExit:{nonfootSeconds:1,mode:'cumulative'}};   // the lab's warm-up rule, TRAINING trials only
}
// ── per-trial scoring ──────────────────────────────────────────────────────
function evenness(row){const per=row?.gait?.stepsPerFoot;if(!Array.isArray(per)||!per.length)return 0;const c=per.map(x=>Math.max(0,num(x))),tot=c.reduce((a,b)=>a+b,0);if(tot<=0)return 0;
  let h=0;for(const x of c){const p=x/tot;if(p>0)h-=p*Math.log(p)}return c.length>1?clamp(h/Math.log(c.length),0,1):0}
/* One trial in the shape curriculumObservation() reads, built exactly as the
 * engine's aggregate() builds it from a panel -- here a panel of one. */
export function trialStats(row){
  const dg=aggregateDifficultyGait([row]),p=summarizeRollouts([row]);
  return {survival:clamp(num(row.survival),0,1),nonfootContactFraction:dg.contactMean,footDragIndex:dg.dragMax,contactHealth:dg.contactHealthMin,footSlipHealth:dg.footSlipHealthMin,
    cleanWalkSpeedMps:dg.walkSpeedQ25,forwardSpeed:dg.forwardSpeedQ25,lateAutonomousDistanceQ25:dg.lateAutonomousDistanceQ25,qFitness:dg.fitness,
    gait:{footRelocationQ25:p.footRelocationQ25,genuineStepsQ25:p.genuineStepsQ25,steppingFeetQ25:p.steppingFeetQ25,positiveSegmentsQ25:p.positiveSegmentsQ25,
      stepEvennessQ25:evenness(row),nonfootGeometricContactMean:dg.contactMean,footDragIndex:dg.dragMean}};
}
export function ladder(o,q){
  const posture=logistic(num(RUNGS.posture.score(o),-50)),fq=clamp(num(footfallQuality(o)),0,1);
  // rung 0: the lab's posture score (survival + 0.6 liveliness - 0.5 slam), unclamped, squashed
  if(!RUNGS.posture.constraintsHeld(o))return {tier:0,L:.999*posture};
  // rung 1: footfall quality first; the posture score (liveliness: feet moving) breaks ties
  if(!RUNGS.footfalls.constraintsHeld(o))return {tier:1,L:1+.999*(.9*clamp(fq/FOOTFALL_PASS,0,1)+.1*posture)};
  // rung 2: the per-trial reward of record first; footfall quality only breaks ties
  return {tier:2,L:2+.999*(.998*(1-Math.exp(-Math.max(0,q)/LADDER_QREF))+.002*fq)};
}
/* The lab's rungs on ONE trial. A later rung also demands the constraints of
 * every earlier one (engine/gait_curriculum.mjs, rung promotion). Small
 * tie-breakers keep a rung from having a flat floor (the v7.1.1 lesson). */
export const RUNG_ORDER=['posture','footfalls','distance'];
export function rungScores(o,q){
  const p=num(RUNGS.posture.score(o),-50),{tier,L}=ladder(o,q);
  /* v9.3.1: distance credit only for a trial that stayed upright AND stepping
   * (ladder tier 2). Any other trial scores below every stepping trial, ordered
   * by the ladder (0.01 x (L - 2), so -0.02 to 0), so a brain that crawls
   * forward can never outrank one that walks, and fallers still have a gradient. */
  const distance=tier>=2?num(RUNGS.distance.score(o,{qFitness:q},'cumulative'))+1e-5*num(footfallQuality(o)):.01*(L-2);
  return {posture:p,footfalls:num(RUNGS.footfalls.score(o),-50)+.01*p,distance};
}
export function rungPasses(o){
  const ph=RUNGS.posture.constraintsHeld(o),fh=RUNGS.footfalls.constraintsHeld(o);
  return {posture:RUNGS.posture.passed(o),footfalls:RUNGS.footfalls.passed(o)&&ph,distance:RUNGS.distance.passed(o)&&ph&&fh};
}
export function scoreTrial(row,desc){
  const st=trialStats(row),q=st.qFitness,o=curriculumObservation(st),{tier,L}=ladder(o,q);
  const smooth=smoothGaitReward({...o,footfall:footfallQuality(o)},row);
  /* v9.4 distance mode: raw forward distance (forward speed x time actually simulated, so a trial
   * stopped early keeps only the ground it covered) and the lab's own harm as injury */
  const secs=Math.max(1e-9,num(row.physicsSteps)*PLANT.dt),fwd=num(st.forwardSpeed);
  return {q,L,tier,desc,smooth,dist:fwd*secs,rate:fwd,injury:num(o.harm),rs:rungScores(o,q),pass:rungPasses(o),steps:num(row.physicsSteps),speed:num(row.cleanWalkSpeedMps),slipM:num(row.footSlip?.maxSlipM),contact:num(row.nonfootGroundContactFraction),row};
}
export function summarizeWalker(trials,{cfg={}}={}){
  const qs=trials.map(t=>t.q),Ls=trials.map(t=>t.L),n=Math.max(1,trials.length);
  let selection;
  if(cfg.selection==='smooth'){const a=trials.map(t=>t.smooth?.score??0);selection=mean(a)+(cfg.worstWeight??.5)*Math.min(...a)}
  else if(cfg.selection==='walk')selection=mean(qs);
  else if(cfg.selection==='ladder')selection=mean(Ls);
  else if(cfg.selection==='distance'){const d=trials.map(t=>t.dist??0);selection=mean(d)+(cfg.worstWeight??.5)*Math.min(...d)}   // v9.4: distance only, no rungs
  else{const r=cfg.rung||'posture',s=trials.map(t=>t.rs?.[r]??-50);selection=mean(s)+(cfg.worstWeight??.5)*Math.min(...s)}
  const pass={};for(const r of RUNG_ORDER)pass[r]=trials.filter(t=>t.pass?.[r]).length/n;
  const avg=k=>clamp(trials.reduce((s,t)=>s+num(t.desc?.[k]),0)/n,0,1);
  /* quality (archive, validation) stays the rung-independent ladder, so elites
   * scored at different rungs of the cycle are always comparable */
  /* distance mode: the archive keeps the LEAST INJURIOUS brain per gait cell among those moving at
   * least distanceFloor (1 cm/s): movers score 1 + 1/(1 + injury), ties broken by speed (+0.01 at
   * 0.1 m/s); a brain below the floor scores its speed / floor (below 1), so a still brain never wins */
  const rate=mean(trials.map(t=>t.rate??0)),inj=mean(trials.map(t=>t.injury??0)),floor=cfg.distanceFloor??.01;
  const cleanQ=rate<floor?Math.max(0,rate)/floor:1+1/(1+inj)+.01*Math.min(1,rate/.1);
  const smoothMean=mean(trials.map(t=>t.smooth?.score??0));
  const aveSmooth=k=>mean(trials.map(t=>t.smooth?.[k]??0));
  return {selection,quality:cfg.selection==='smooth'?smoothMean:cfg.selection==='walk'?mean(qs):cfg.selection==='distance'?cleanQ:mean(Ls),smoothScore:smoothMean,gate:aveSmooth('gate'),standAbility:aveSmooth('x'),footAbility:aveSmooth('y'),forwardCmps:aveSmooth('z'),forwardTerm:aveSmooth('forward'),postureTerm:aveSmooth('posture'),footfallTerm:aveSmooth('feet'),penaltyTerm:aveSmooth('penalty'),forwardWeight:aveSmooth('weight'),distRate:rate,injury:inj,distM:mean(trials.map(t=>t.dist??0)),pass,record:aggregateDifficultyGait(trials.map(t=>t.row)).fitness,guard:quantile(qs,.25),meanQ:mean(qs),
    meanL:mean(Ls),tierWalk:trials.filter(t=>t.tier===2).length/n,tierStand:trials.filter(t=>t.tier===1).length/n,tierFall:trials.filter(t=>t.tier===0).length/n,
    speed:mean(trials.map(t=>t.speed)),slipMedianCm:100*median(trials.map(t=>t.slipM)),contact:mean(trials.map(t=>t.contact)),learnFlips:mean(trials.map(t=>num(t.learn))),
    desc:{duty:avg('duty'),coordination:avg('coordination'),cadence:avg('cadence')}};
}
// ── genome helpers ─────────────────────────────────────────────────────────
const unpackCache=new WeakMap();
const unpack=g=>{let b=unpackCache.get(g);if(!b){b=isRigGenome(g)?unpackRig(g):unpackTernary(g);unpackCache.set(g,b)}return b};
/* size descriptor: one archive bin per octave, 8-15, 16-31, 32-63, 64-127, 128+ cells */
export const sizeDescriptor=N=>Math.max(0,Math.min(1,(Math.log2(Math.max(1,N))-3)/5));
/* Functional differences between two brains: sign changes, rewires of slots
 * that are live in both, and moved or re-signed votes. Thresholds stay
 * meaningful from 12 units to 256 (it is a count, not a fraction). */
export function functionalDistance(a,b){
  const A=unpack(a),B=unpack(b);if(A.N!==B.N||A.V!==B.V||A.A!==B.A)return Infinity;let d=0;
  for(let x=0;x<A.w.length;x++){if(A.w[x]!==B.w[x])d++;else if(A.w[x]&&A.src[x]!==B.src[x])d++}
  for(let x=0;x<A.dec.length;x++)if(A.dec[x]!==B.dec[x])d++;return d;
}
export function readFossil(file){
  const o=JSON.parse(zlib.gunzipSync(fs.readFileSync(file)).toString('utf8')),g=Float64Array.from(o.genome||[]);
  if(!isTernaryGenome(g))throw new Error(`${file} is not a ternary fossil`);
  /* The fossil file keeps the lab's yardstick result under `yardstick`, the
   * full lab config, and the leg scale it was measured at. */
  const y=o.yardstick||{},c=o.config||{};
  return {genome:g,meta:{qFitness:y.qFitness??o.qFitness??null,generation:o.lane?.generation??o.generation??null,created:o.created??null,N:ternaryHeader(g).N,role:o.role??null,
    legScale:o.difficulty?.legScale??o.lane?.homeLegScale??null,
    labConfig:{runSeed:c.runSeed,yardstickN:c.yardstickN,valSeconds:c.valSeconds,difficulty:c.difficulty,friction:c.friction,actuation:c.actuation,kp:c.kp,kd:c.kd,tauCap:c.tauCap,hpBudget:c.hpBudget,taskMode:c.taskMode}}};
}
export function loadFossilGenome(file){
  const o=JSON.parse(zlib.gunzipSync(fs.readFileSync(file)).toString('utf8')),g=Float64Array.from(o.genome||[]);
  if(!isTernaryGenome(g))throw new Error(`${file} is not a ternary fossil (kind ${o?.lane?.kind})`);return g;
}
// ── scenarios ──────────────────────────────────────────────────────────────
const stepsFor=s=>Math.max(10,Math.round(s/CONTROL_DT));
const bank=(base,n,difficulty,seconds)=>Array.from({length:n},(_,i)=>applyTaskScenario(makeScenario(hash32(base+Math.imul(i+1,7919)),difficulty,stepsFor(seconds)),{mode:'walk'}));
/* The lab's yardstick bank, reproduced from FoundryEngine.makeBank/yardstickBank. */
export function labYardstick({runSeed=1,n=7,difficulty=1,seconds=8}={}){
  const root=hash32(0x1EDCBA57^hash32(runSeed)),base=hash32((root>>>0)^0xC001D00D^0);return bank(base,n,difficulty,seconds);
}

export async function makeWalkerPlant(options={}){
  const physics={...WALKER_PHYSICS,...(options.physics||{}),run:{...WALKER_PHYSICS.run,...(options.physics?.run||{})}};
  /* RIG_WALKER_BACKEND=mock is for testing plan files without MuJoCo; never set it for real runs. */
  let backend=options.backend||process.env.RIG_WALKER_BACKEND||((options.workers??0)===1?'inprocess':'pool');
  /* ONE pool per plant, however many runs ask for it at the same moment.
   * v7.1.1 checked "no pool yet?" and then awaited the module before creating
   * one, so every run of a round that asked concurrently made its own pool:
   * 4 runs -> 60 MuJoCo threads, a 20-run sweep -> 300. The pool is now a
   * memoised promise, created by the first caller and shared by all. */
  const makePool=options.poolFactory||(async()=>{const {WalkerPool}=await import('./walker_pool.mjs');return new WalkerPool({size:options.workers||0})});
  let poolP=null,localP=null,poolsCreated=0;
  const getPool=()=>poolP??=Promise.resolve().then(makePool).then(p=>{poolsCreated++;return p});
  const getLocal=()=>localP??=import('./walker_worker.mjs').then(async m=>{await m.loadMujoco();return m});
  async function runJobs(jobs){
    if(backend==='mock')return jobs.map(j=>j.scenarios.map(sc=>mockRollout(j.genome,sc,j.steps,options.mockSeed??1)));
    if(backend==='pool')return (await getPool()).evaluate(jobs);
    const local=await getLocal();return jobs.map(j=>local.runJob(j));
  }
  const plant={
    name:'walker',costUnit:'physicsSteps',options,physics,scoringVersion:WALKER_SCORING_VERSION,searchVersion:WALKER_SEARCH_VERSION,
    /* v10.0.1: the run's joints, set when a run starts (every later rollout uses them) */
    setJoints(mode){physics.run={...physics.run,actuation:JOINT_MODES[mode]||'torque'};return jointsOf(physics.run)},
    joints:()=>jointsOf(physics.run),
    /* v10.0.2: the run's friction, set when a run starts (the workers build a body per friction) */
    setFriction(mode){physics.friction=mode==='legacy'?'legacy':'firm';return frictionOf(physics)},
    friction:()=>frictionOf(physics),
    axes:['duty','coordination','cadence','size'],ranges:{duty:[.6,1],coordination:[.4,.6],cadence:[0,.25],size:[0,1]},
    searchDefaults:walkerSearchDefaults,
    criterion:null,materialGain:.001,
    birth:(rng,cfg)=>cfg.brain==='lab'?birthTernary(rng,{N:cfg.N,V:Math.min(cfg.voters??6,cfg.N),pacemaker:cfg.pacemaker??0,taskMode:'walk'})
      :birthRig(rng,{kind:cfg.brainKind|0,A:cfg.motors||8,N:cfg.N,V:Math.min(cfg.voters??6,cfg.N),K:cfg.ticks??10,internalShare:cfg.internalShare??.5,tonicShare:cfg.tonicShare??.08}),
    mutate:(g,rng,{strong=false,cfg,count=null})=>isRigGenome(g)?mutateRig(g,rng,{count:count??cfg.mutations??2,strong,focus:cfg.focus??.85,sensorBias:cfg.sensorBias??.5,silenceOdds:cfg.silenceOdds??.1})
      :mutateTernary(g,rng,{count:count??cfg.mutations??baseMutationCount(ternaryHeader(g).N),heat:strong?2.5:1,
      focus:cfg.focus,sensorBias:cfg.sensorBias,silenceOdds:cfg.silenceOdds,taskMode:'walk'}).genome,
    crossover:(a,b,rng)=>{if(isRigGenome(a)||isRigGenome(b))return isRigGenome(a)&&isRigGenome(b)?crossRig(a,b,rng):null;const x=crossoverTernary(a,b,rng,{taskMode:'walk'});return x.crossed?x.genome:null},
    /* grow and shrink move one cell each (a fair random walk in size, capped at
     * maxCells); the plateau governor's deliberate growth passes growCount */
    grow:(g,rng,cfg={})=>!isRigGenome(g)||rigSize(g)>=(cfg.maxCells??192)?null:growRig(g,rng,{count:Math.min(cfg.growCount??1,(cfg.maxCells??192)-rigSize(g)),internalShare:cfg.internalShare??.5,tonicShare:cfg.tonicShare??.08,sensorBias:cfg.sensorBias??.5}),
    shrink:(g,rng,cfg={})=>isRigGenome(g)?shrinkRig(g,rng,{internalShare:cfg.internalShare??.5,sensorBias:cfg.sensorBias??.5}):null,
    sizeDescriptor:g=>sizeDescriptor(isRigGenome(g)?rigSize(g):ternaryHeader(g).N),
    distance:(a,b)=>isRigGenome(a)||isRigGenome(b)?(isRigGenome(a)&&isRigGenome(b)?rigDistance(a,b):Infinity):functionalDistance(a,b),
    sizeOf:g=>isRigGenome(g)?rigSize(g):ternaryHeader(g).N,
    encode:g=>g,decode:g=>g instanceof Float64Array?g:Float64Array.from(g),readFossil,
    /* spec: {fossil: file} or {bestFossilIn: dir, fossilN?: units}, plus an optional
     * growth: growTo (absolute), growBy (units added) or growFactor (x size).
     * New units are born silent, so a grown brain starts out behaving exactly
     * like its source. */
    async seedGenome(spec,cfg,rng){let g=spec.fossil?loadFossilGenome(spec.fossil):null;
      if(!g&&spec.bestFossilIn){let best=null;for(const f of fs.readdirSync(spec.bestFossilIn).filter(f=>f.endsWith('.json.gz'))){
          try{const r=readFossil(spec.bestFossilIn+'/'+f);if(spec.fossilN&&r.meta.N!==spec.fossilN)continue;if(!best||num(r.meta.qFitness,-1)>num(best.meta.qFitness,-1))best=r}catch{}}
        g=best?.genome||null}
      if(!g)throw new Error('seed needs {fossil} or {bestFossilIn}');
      const N0=ternaryHeader(g).N,N1=spec.growTo??(spec.growBy?N0+spec.growBy:spec.growFactor?Math.round(N0*spec.growFactor):N0);
      if(N1>N0)g=growTernary(g,N1,rng,{taskMode:'walk'});return g},
    trainingSuite:(runSeed,epoch,cfg)=>bank(seedFor(runSeed,'rig-train',epoch),cfg.trainCases,cfg.difficulty,cfg.trainSeconds),
    suites:(runSeed,cfg)=>({val:bank(seedFor(cfg.suiteSeed,'rig-val'),cfg.valCases,cfg.difficulty,cfg.valSeconds),
      hold:bank(seedFor(cfg.suiteSeed,'rig-hold'),cfg.holdCases,cfg.difficulty,cfg.valSeconds),
      cert:labYardstick({runSeed:cfg.labRunSeed,n:cfg.yardstickN,difficulty:cfg.difficulty,seconds:cfg.valSeconds})}),
    auditPanel:(n,cfg)=>bank(seedFor(cfg.suiteSeed,'rig-audit'),n,cfg.difficulty,cfg.valSeconds),
    async evaluate(genomes,suite,{cfg={},train=false}={}){
      /* A training trial stops once the body has been on the floor for 1 s in
       * total, with the rest charged as floor contact, as the lab does on its
       * warm-up rungs. Such a trial is on rung 0 whether or not it is stopped
       * (1 s of contact in a 6 s trial is already above the 10 % posture bar),
       * so this can never cost a trial a rung; it only stops paying for falls.
       * Validation, holdout and certification trials always run in full. */
      const exit=train&&cfg.trainEarlyExit?cfg.trainEarlyExit:(cfg.earlyExit||null);
      const jobs=[],slots=[];
      genomes.forEach((g,i)=>suite.forEach((sc,j)=>{jobs.push({physics,genome:g,scenarios:[sc],steps:sc.steps,earlyExit:exit,tone:!!cfg.tone});slots.push([i,j])}));
      const res=await runJobs(jobs),out=genomes.map(()=>new Array(suite.length));
      res.forEach((r,k)=>{const [i,j]=slots[k];const t=scoreTrial(r[0].row,r[0].desc);t.learn=num(r[0].learn);out[i][j]=t});return out;   // v10.1.0: learn = wire changes a plastic brain made in the trial
    },
    summarize:summarizeWalker,
    /* the cycled curriculum, advanced on each validation of the current brain */
    onValidated(run,vs){
      if(run.cfg.selection!=='curriculum')return;
      const C=run.curriculum||(run.curriculum={rung:run.cfg.rung||'posture',cycle:0,since:0,transitions:[]});
      const go=(rung,why)=>{C.transitions.push({generation:run.generation,from:C.rung,to:rung,why});if(C.transitions.length>200)C.transitions.shift();
        if(rung==='posture'&&C.rung==='distance'){C.cycle++;run.restartFromBest?.()}C.rung=rung;C.since=run.generation;run.cfg.rung=rung;run.currentTrain=null;
        run.events.push({generation:run.generation,kind:'rung',to:rung,why})};
      const share=vs.pass||{},need=run.cfg.passShare??.75;
      if(C.rung==='posture'&&share.posture>=need)go('footfalls',`posture passed on ${(100*share.posture).toFixed(0)}% of validation trials`);
      else if(C.rung==='footfalls'&&share.footfalls>=need)go('distance',`footfalls passed on ${(100*share.footfalls).toFixed(0)}% of validation trials`);
      else if(C.rung==='distance'&&run.generation-C.since>=(run.cfg.distanceGens??400))go('posture',`${run.generation-C.since} generations on distance: the cycle restarts`);
    },
    /* one recorded rollout for the GUI: frames for the 3D view and every cell's
     * state each control step for the brain view */
    async replay(genome,scenario,{stride=2,tone=false}={}){
      if(backend==='mock')return mockReplay(genome,scenario,stride);
      const job={physics,genome,scenarios:[scenario],steps:scenario.steps,earlyExit:null,record:true,trace:true,stride,tone};
      const r=(await runJobs([job]))[0][0];return {...r,trial:scoreTrial(r.row,r.desc)};
    },
    perTrial:t=>t.q,trialKey:t=>`${t.q}|${t.L}|${t.steps}`,
    cost(trialsList,genomes){let rollouts=0,ps=0,nu=0;trialsList.forEach((tr,i)=>{const N=isContinuous(genomes[i])?100:ternaryHeader(genomes[i]).N;for(const t of tr){rollouts++;ps+=t.steps;nu+=(t.steps/PLANT.frameSkip)*N}});
      return {rollouts,physicsSteps:ps,steps:ps,neuronUpdates:nu}},
    async close(){if(poolP){const p=await poolP.catch(()=>null);await p?.close?.()}},
    stats:()=>({poolsCreated,backend}),
  };
  return plant;
}

/* ── mock rollouts: plumbing tests only, no physics ─────────────────────────
 * A deterministic toy landscape over the genome's vote signs, shaped like a
 * real slim row so every scorer runs on it. */
export function mockRollout(genome,sc,steps,mockSeed=1){
  const b=unpack(genome),N=b.N;let match=0,tot=0;
  for(let a=0;a<8;a++)for(let i=0;i<N;i++){const v=b.dec[a*N+i];if(!v)continue;tot++;const want=((hash32(mockSeed^(a*977+i*131))&1)?1:-1)*(a%2?-1:1);if(v===want)match++}
  let live=0;for(let x=0;x<b.w.length;x++)if(b.w[x]&&b.src[x]<b.S)live++;
  const s=tot?match/tot:0,noise=((hash32(sc.seed^0xABCD)&1023)/1023-.5)*.1,secs=steps*CONTROL_DT;
  const cf=clamp(.5-s+noise*.5,0,1),v=Math.max(0,.12*(s-.45)+noise*.02),slip=clamp(.09-.06*s+noise*.02+.0002*live/N,0,.2);
  const stepsN=Math.round(8*s),feet=Math.min(4,Math.round(5*s));
  const row={taskMode:'walk',survival:1,cleanWalkSpeedMps:v,cleanWalkDistanceM:v*secs,forwardSpeedMps:v,forwardDistanceM:v*secs,targetGoalScore:0,targetDistanceM:0,
    nonfootGroundContactFraction:cf,footDragIndex:slip/.05,signedAutonomousDistanceM:v*secs*.6,lateAutonomousDistanceM:v*secs*.25,distance:v*secs,noninjury:1,weakestPart:'mock',
    physicsSteps:steps*PLANT.frameSkip,fullEpisodeSeconds:secs,
    gait:{genuineSteps:stepsN,steppingFeet:feet,stepsPerFoot:[1,2,3,4].map(k=>Math.round(stepsN*k/10)),positiveProgressSegments:Math.min(4,Math.round(4*s)),signedAutonomousDistanceM:v*secs*.6,
      lateAutonomousDistanceM:v*secs*.25,maxFootRelocationM:.06*s,footDistanceGateOpen:s>.3,nonfootContactFraction:cf,torsoContactFraction:0,peakNonfootForceBW:0,catastrophic:false,nonfootGeometricContactFraction:cf},
    footSlip:{maxSlipM:slip,health:Math.exp(-slip/.05),slideFree:slip===0,byFoot:Object.fromEntries(['fl','fr','rl','rr'].map((f,k)=>[f,{contactSeconds:secs*clamp(.95-.3*s+.05*k,0,1),slipM:slip*(.5+k/8)}]))},
    contactHealth:{health:1-cf,contactFraction:cf,contactFree:cf===0}};
  return {row,desc:{duty:clamp(.95-.3*s,0,1),coordination:clamp(.5+.3*(s-.5)+noise,0,1),cadence:clamp(stepsN/secs/8,0,1)}};
}

/* mock replay: a standing, slowly walking pose, so the GUI and its tests run
 * without MuJoCo */
function mockReplay(genome,scenario,stride){
  const r=mockRollout(genome,scenario,scenario.steps,1),b=unpack(genome),N=b.N,frames=[],trace=[],s=PLANT.legScale??.72;
  const g={torsoLength:PLANT.torsoLength,torsoWidth:PLANT.torsoWidth,torsoHeight:PLANT.torsoHeight,thighLength:.18,thighRadius:.035,shinLength:.18,shinRadius:.03,footRadius:.035,bodyOrder:['torso','fl_thigh','fl_shin','fr_thigh','fr_shin','rl_thigh','rl_shin','rr_thigh','rr_shin']};
  for(let t=0;t<scenario.steps;t+=stride){const x=.002*t,ph=t*.12;const bodies=[[x,0,.38,1,0,0,0]];
    for(const [i,[sx,sy]] of [[.25,.12],[.25,-.12],[-.25,.12],[-.25,-.12]].entries()){const sw=.25*Math.sin(ph+(i%3?Math.PI:0)),c=Math.cos(sw/2),sn=Math.sin(sw/2);
      bodies.push([x+sx,sy,.34,c,0,sn,0]);bodies.push([x+sx+.18*Math.sin(sw),sy,.34-.18*Math.cos(sw),1,0,0,0])}
    frames.push({t,bodies,x,contacts:[1,0,1,0].map((v,k)=>(Math.floor(t/20)+k)%2),torques:[]});
    let h='';for(let i=0;i<N;i++){const u=Math.sin(t*.07+i*1.3);h+=u>.4?'+':u<-.4?'-':'0'}trace.push(h)}
  return {row:r.row,desc:r.desc,frames,trace,geometry:g,trial:scoreTrial(r.row,r.desc)};
}
