/* v16: genuine ternary-on-physics, latent fitness-difference probes in evolution only. */
import assert from 'node:assert/strict';
import {AcbaTernary} from '../core/acba_ternary.mjs';
import {birthRig,rigAudit,KIND} from '../brain.mjs';
import {Rng} from '../core/rng.mjs';
import {makeWalkerPlant} from '../plants/walker.mjs';
import {ChampionRun} from '../core/evolve.mjs';
const rng=new Rng(24012),acba=new AcbaTernary();
for(const N of [24,192,512]){
 const g=birthRig(rng,{N,V:6,K:10,A:16,kind:KIND.STRICT_FIXED});
 const old=g.slice(),trial=acba.pair(g,rng,{moves:6,step:.65});
 assert.ok(trial&&rigAudit(trial.plus).ok&&rigAudit(trial.minus).ok,'both evolutionary probes strictly ternary');
 assert.equal(trial.plus[6],KIND.STRICT_FIXED);
 assert.deepEqual([...g],[...old],'no mutation of source genotype');
 assert.ok(trial.chosen.length>0);
 acba.credit(trial,1.45,1.02);
 const v=acba.export(g),copy=g.slice();acba.import(copy,v);
 assert.deepEqual(acba.export(copy),v,'fractional genome shadow survives compact checkpoint serialization');
 const voteOff=8+12*N;for(let i=voteOff;i<g.length;i++)if(g[i]){
   assert.ok(trial.plus[i]===1||trial.plus[i]===-1,'vote count may not change');
   assert.ok(trial.minus[i]===1||trial.minus[i]===-1);
 }
}
const plant=await makeWalkerPlant({backend:'mock',mockSeed:25});
try{
 const cfg={...plant.searchDefaults(24),N:24,brain:'rig',brainKind:KIND.STRICT_FIXED,motors:16,selection:'smooth',search:'basin',peaks:3,lambda:12,bandit:false,founders:4,founderSizes:null,acbaEvolution:true,acbaShare:.34,acbaMoves:5,acbaStep:.6,trainCases:1,trainSeconds:2,valCases:4,holdCases:4,valSeconds:2,rotate:5,valEvery:2,immigrants:0};
 const run=new ChampionRun({plant,cfg,seed:47017});await run.init();
 for(let i=0;i<8;i++)await run.step();
 assert.ok(run.acba.stats.pairs>0,'paired probes MUST actually run during ternary evolution');
 assert.ok(run.archive.cells.size>1,'original diversity archive remains populated');
 assert.ok(run.archive.pool.length>0,'original champion pool remains available');
 assert.ok(run.frontier.length>1,'original separated multi-peak frontier remains populated');
 assert.ok(run.frontier.every(f=>rigAudit(f.genome).ok),'every evaluated frontier brain is strictly ternary');
 assert.ok([...run.archive.cells.values()].every(e=>rigAudit(e.genome).ok));
 assert.ok(run.compute.physicsSteps>0);
 const backup=run.acba.stats.pairs;
 cfg.acbaEvolution=false;run.cfg.acbaEvolution=false;
 await run.step();assert.equal(run.acba.stats.pairs,backup,'turning off ACBA stops paired probes');
 // The second evolution engine (non-basin champion climb) must also honor
 // the precise probes rather than silently disabling them when basin is OFF.
 const climb=new ChampionRun({plant,cfg:{...cfg,search:'champions',acbaEvolution:true},seed:47018});await climb.init();
 for(let i=0;i<5;i++)await climb.step();
 assert.ok(climb.acba.stats.pairs>0,'non-basin ternary evolution uses precision probes');
 assert.ok(rigAudit(climb.current).ok);
 console.log(`acba_evolution_test ok: ${backup} basin paired probes, ${climb.acba.stats.pairs} climbing pairs, ${run.compute.physicsSteps} physics steps; all evaluated brains strict ternary`);
}finally{await plant.close()}
