/* The server end to end on the mock walker: page, three.js route, API, save on stop. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url)),dir=fs.mkdtempSync(path.join(os.tmpdir(),'rig_srv_')),port=18790+Math.floor(Math.random()*500);
const srv=spawn(process.execPath,[path.join(here,'..','server.mjs'),'--port',String(port)],{env:{...process.env,RIG_WALKER_BACKEND:'mock',RIG_DATA_DIR:dir},stdio:['ignore','pipe','pipe']});
let out='';srv.stdout.on('data',d=>out+=d);srv.stderr.on('data',d=>out+=d);
const base=`http://127.0.0.1:${port}`,wait=ms=>new Promise(r=>setTimeout(r,ms));
for(let i=0;i<50&&!out.includes('at http');i++)await wait(100);
const get=async p=>{const r=await fetch(base+p);return {r,t:await r.text()}};
const cmd=async(c,a={})=>(await fetch(base+'/api/cmd',{method:'POST',body:JSON.stringify({cmd:c,args:a})})).json();
try{
  let x=await get('/');assert.equal(x.r.status,200);assert.match(x.t,/Walker Rig v16/);
  x=await get('/gui/app.js');assert.equal(x.r.status,200);
  x=await get('/gui/../server.mjs');assert.notEqual(x.r.status,200,'no path escape');
  let s=JSON.parse((await get('/api/status')).t);assert.equal(s.mode,'idle');assert.ok(s.defaults.N);
  await cmd('set',{cfg:{N:12,mixedSizes:false,founders:4,lambda:4,trainCases:2,valCases:4,holdCases:4,valEvery:2}});await cmd('start');await wait(1200);await cmd('test');
  s=JSON.parse((await get('/api/status')).t);assert.ok(s.generation>0&&s.replayId>0);assert.equal(s.compare.on,false,'v14 defaults to one ternary evolutionary arm');
  const rp=JSON.parse((await get('/api/replay')).t);assert.ok(rp.frames.length>0&&rp.trace[0].length===rp.brain.N&&rp.brain.role.length===rp.brain.N);
  x=await get('/api/export');const payload=JSON.parse(x.t);assert.ok(payload.cells.length>0);
  const imp=await (await fetch(base+'/api/import',{method:'POST',body:x.t})).json();assert.equal(imp.cells,payload.cells.length);
  {const L=JSON.parse((await get('/api/landscape')).t);assert.ok(L.points.length>0,'landscape route')}
  x=await get('/api/biopsy');assert.match(x.t,/WALKER TERNARY RIG BIOPSY/);
  const bad=await fetch(base+'/api/cmd',{method:'POST',body:JSON.stringify({cmd:'nonsense'})});assert.equal(bad.status,400);
  console.log(`server: page, app, API, replay (${rp.frames.length} frames), export/import (${payload.cells.length} cells), biopsy`);
}finally{srv.kill('SIGTERM');for(let i=0;i<40&&srv.exitCode===null;i++)await wait(100)}
assert.ok(fs.readdirSync(dir).some(f=>f.startsWith('champions-')),'champions saved on stop');assert.ok(!fs.existsSync(path.join(dir,'server.pid')));
fs.rmSync(dir,{recursive:true,force:true});console.log('server stopped cleanly and saved the champions');console.log('server_test ok');
