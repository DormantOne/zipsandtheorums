/* Walker plant: the reward of record per trial, the cycled curriculum, replays. No MuJoCo needed. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {fileURLToPath} from 'node:url';
import {aggregateDifficultyGait} from '../../engine/difficulty_gait.mjs';
import {curriculumObservation} from '../../engine/gait_curriculum.mjs';
import {makeWalkerPlant,rungScores,rungPasses,ladder} from '../plants/walker.mjs';
import {ChampionRun} from '../core/evolve.mjs';
const here=fileURLToPath(new URL('.',import.meta.url));
// 1. per-trial reward of record == the lab's own recorded per-trial values
const recs=JSON.parse(fs.readFileSync(here+'fixtures_trials.json','utf8'));let err=0;
for(const r of recs)err=Math.max(err,Math.abs(aggregateDifficultyGait([r]).fitness-r.qFitness));
assert.ok(recs.length>=10&&err<1e-12);console.log(`reward of record: ${recs.length} lab trials reproduced (max error ${err.toExponential(1)})`);
// 2. rung scores have no flat floor; passes follow the lab's rules
const base={survival:1,footDragIndex:1,gait:{footRelocationQ25:.01,genuineStepsQ25:0,steppingFeetQ25:0,positiveSegmentsQ25:0,stepEvennessQ25:0}};
let prev=-Infinity;for(const c of [.9,.6,.3,.12]){const s=rungScores(curriculumObservation({...base,nonfootContactFraction:c}),0).posture;assert.ok(s>prev);prev=s}
const walker=curriculumObservation({survival:1,footDragIndex:.4,nonfootContactFraction:0,cleanWalkSpeedMps:.08,gait:{footRelocationQ25:.08,genuineStepsQ25:8,steppingFeetQ25:4,positiveSegmentsQ25:4,stepEvennessQ25:1}});
const ps=rungPasses(walker);assert.ok(ps.posture&&ps.footfalls,'a stepping upright trial passes posture and footfalls');
assert.ok(ladder(walker,.02).L>ladder(curriculumObservation({...base,nonfootContactFraction:.6}),0).L);
console.log('rungs: posture score rises as floor contact falls; a stepping trial passes posture and footfalls');
{const crawl=curriculumObservation({survival:1,footDragIndex:.4,nonfootContactFraction:.5,cleanWalkSpeedMps:.1,gait:{footRelocationQ25:.08,genuineStepsQ25:8,steppingFeetQ25:4,positiveSegmentsQ25:4,stepEvennessQ25:1}});
 const dc=rungScores(crawl,.03).distance,dw=rungScores(walker,.001).distance;assert.ok(dc<0&&dw>=0&&dw>dc,`crawler ${dc} walker ${dw}`);
 console.log(`distance rung: a fast crawler scores ${dc.toFixed(4)}, below a slow walker at ${dw.toFixed(5)}`)}
// 3. the cycle: posture -> footfalls -> distance -> posture
const P=await makeWalkerPlant({backend:'mock'});
const run=await new ChampionRun({plant:P,cfg:{N:12,lambda:4,trainCases:2,valCases:4,holdCases:4,yardstickN:2,valEvery:2,founders:4,selection:'curriculum',passShare:0,distanceGens:6},seed:3}).init();
await run.advanceTo(Infinity,{maxGenerations:20});
const path=run.curriculum.transitions.map(t=>t.to);
assert.deepEqual(path.slice(0,4),['footfalls','distance','posture','footfalls']);assert.ok(run.curriculum.cycle>=1);
const row=run.history.at(-1);assert.ok(row.rung&&row.current&&row.current.pass);
console.log(`cycled curriculum: ${run.curriculum.transitions.map(t=>`${t.from}>${t.to}@${t.generation}`).join(' ')}`);
// 4. the fitness follows the active rung
const tr=(await P.evaluate([run.current],run.suites.val,{cfg:run.cfg}))[0];
const fp=P.summarize(tr,{cfg:{...run.cfg,rung:'posture'}}).selection,fd=P.summarize(tr,{cfg:{...run.cfg,rung:'distance'}}).selection;
assert.ok(Number.isFinite(fp)&&Number.isFinite(fd)&&fp!==fd);
const s=tr.map(t=>t.rs.posture),m=s.reduce((a,b)=>a+b,0)/s.length;assert.ok(Math.abs(fp-(m+.5*Math.min(...s)))<1e-12,'fitness = mean + 0.5 x worst');
console.log('fitness: the active rung\'s score per trial, mean + 0.5 x worst');
// 5. a replay for the GUI
const rp=await P.replay(run.current,run.suites.val[0]);assert.equal(rp.frames.length,rp.trace.length);assert.equal(rp.trace[0].length,12);assert.equal(rp.frames[0].bodies.length,9);
console.log(`replay: ${rp.frames.length} frames of 9 bodies and the state of all 12 cells at each`);
// 6. v9.4 distance mode: the fitness is distance only; the archive prefers the least injurious mover
{const P2=await makeWalkerPlant({backend:'mock'}),cfg={selection:'distance',worstWeight:.5,distanceFloor:.01};
 const mk=(dist,rate,injury)=>({q:0,L:1,tier:1,desc:{duty:.5,coordination:.5,cadence:.1},dist,rate,injury,rs:{},pass:{},speed:0,slipM:0,contact:0,row:{}});
 const s=P2.summarize([mk(.30,.05,2),mk(.10,.017,2)],{cfg});assert.ok(Math.abs(s.selection-(.2+.5*.1))<1e-12,'mean + 0.5 x worst distance');
 const clean=P2.summarize([mk(.06,.01,.2),mk(.06,.012,.2)],{cfg}).quality,sloppy=P2.summarize([mk(.6,.1,3),mk(.6,.1,3)],{cfg}).quality,still=P2.summarize([mk(0,0,0),mk(0,0,0)],{cfg}).quality;
 assert.ok(clean>sloppy&&sloppy>still&&still<1,`clean ${clean} sloppy ${sloppy} still ${still}`);
 console.log(`distance mode: fitness = mean + 0.5 x worst distance; archive: a clean slow mover ${clean.toFixed(3)} > a fast sloppy one ${sloppy.toFixed(3)} > a still brain ${still.toFixed(3)}`)}
console.log('walker_test ok');
