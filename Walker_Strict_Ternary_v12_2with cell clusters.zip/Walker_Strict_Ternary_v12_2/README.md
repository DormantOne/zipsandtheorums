# Walker v12 — strict ternary scaling experiment (NEW)

**Start here:** [README_STRICT_v12.md](README_STRICT_v12.md) or `OPEN_THIS_FIRST.txt`.

Double-click `START_STRICT_MAC.command` on Mac. This uses its own port **8794** and folder **data_strict/**, keeping the earlier 8793 Protoneuron and original ternary/plastic labs undisturbed.

---

# Walker Ternary Rig v10.1.0

## What's new in v10.1.0: opposing muscles, brains that learn, and one button to compare them

**One button.** Start the rig with START_MAC.command (the page opens at http://127.0.0.1:8793) and press **Start fresh run**. With **Compare** on (the new default), that one Start runs two arms side by side:
- **regular**: ternary brains, wiring fixed for life (the brains you have now);
- **plastic**: the same brains, except that evolution can also give a cell a *learning rate*, so its wires change during a trial. Evolve, then learn, then evolve again.

Both arms use the same seed, the same settings, the same physics and the same founders, and they take one generation each in turn, so they always get equal compute. The new **comparison panel** shows both champions side by side (ladder, walking trials, distance passes, forward speed, slide, how many cells learn and how many wires they change), plus a chart of both arms' best ladder over generations. **Show regular** / **Show plastic** switches the rest of the page (walker view, log, archive, map, connectome) between the arms; both keep training.

### Muscles (Joints ⟲, new default *muscles*)
- Each of the 8 joints has two opposing muscles, a flexor and an extensor: 16 motor commands instead of 8.
- A command c in −1..+1 sets the muscle's activation a = (1 + c) / 2. The joint is pulled toward rest + span · (a⁺ − a⁻) / (a⁺ + a⁻), with stiffness kp · (a⁺ + a⁻) and damping kd · (a⁺ + a⁻), recomputed every 4 ms physics step and capped at the same motor limits.
- So the brain sets each joint's angle **and** its stiffness: both muscles at half tone is exactly the servo (the body stands); both relaxed is a limp joint (it falls); both contracted is a joint twice as stiff.
- Muscle brains are born **reciprocal**: each extensor votes like its flexor with the signs flipped, which makes a newborn muscle brain behave exactly like a servo brain. After that the 16 vote sets mutate independently, so co-contraction (stiffening a joint on landing, say) can evolve.
- **Checked on MuJoCo** (first launch runs it): half tone stands (slide 0.1 cm); relaxed falls; the reference trot driven through reciprocal pairs steps on 24 of 24 validation scenarios and passes distance on 24 of 24, the same as the servo.
- **Your walker carries over exactly.** Champion #1035 from your v10.0.2 run, converted to muscles, scores ladder 2.5293 and walks at 16.2 cm/s, as on servo joints, in both arms.
- *servo* and *torque* are still there. Saves record their joints, and champions are converted (8 ↔ 16 motors) and rescored when a run uses other joints.

### The plastic brain (Brain model *plastic*; the second arm of the comparison)
- **Two new genes per cell:** a learning rate (−3..+3: 0, ±0.05, ±0.1 or ±0.2 per step; + is Hebbian, − anti-Hebbian) and a trace fade (0, 0.5, 0.8 or 0.95).
- **During a trial**, each learning cell keeps a fading trace of its own activity, from −1 to +1, so being driven off counts as much as being on. Every 20 ms step, for each of its 3 incoming wires, it adds rate × move × input × trace to a counter. *input* is the sensor's value, or the source cell's trace; *move* is the forward-speed sense (+1 moving forward, −1 backward, 0 still), so learning runs only while the body moves and reverses if it goes backwards. When the counter reaches ±1, the weight steps one notch (−1 → 0 → +1) and the counter resets. Weights stay −1, 0 or +1.
- **Every trial starts again from the genome** (the Baldwin effect): learned wiring is never inherited, only the ability to learn. Evolution keeps brains that learn well.
- **Born with every rate 0**, so a newborn plastic brain is the ternary brain bit for bit (tested). Learning appears only where evolution finds it useful: on top of the usual mutation move, 15 % of moves also nudge a learning gene. Tonic cells never learn.
- In the connectome view, learning cells wear a dashed white ring, and in a replay the wires that learning has changed so far in that trial turn gold.

### What to expect (measured here, on 2 CPU cores)
- **Both arms from your walker** (*Start from saved champions*, 6 minutes, 19 generations each, 4.1 M physics steps each): the regular arm found a slightly better walker (#1038, ladder 2.5304); the plastic arm kept #1035 on top and archived 3 learning brains in other gait cells, changing 1.7 to 9.2 wires per trial.
- **Learning added to a tuned walker mostly hurts**, like any other mutation of a champion. On your walker, 24 random single learning cells gave 6 identical results, 18 worse and none better; 16 of the 24 still walked. Learning has to earn its place, cell by cell.
- **So the fairer race is from scratch:** *Start fresh run* and watch which arm reaches walking first, and which walks better after many thousands of generations. That is the experiment; this build doesn't know the answer yet.
- Comparing gives each arm half the machine. To give one brain the whole machine, turn **Compare** off (⟲) and pick the Brain model.

### Settings, saves and the biopsy
- **Compare** (⟲, on by default). The Brain model setting applies only when Compare is off.
- The KG's settings tests pause while comparing, so the two arms always run identical settings. Each arm has its own archive, curriculum, bandit and plateau governor.
- **Saves:** each arm saves its own file (`champions-<seed>-<cells>-regular.json` and `-plastic.json`). *Start from saved champions* gives each arm its own file, or, if there are none yet, starts both from your latest save, converted and rescored (about a minute). Champion numbers are kept through a rescore.
- **The biopsy** (Copy biopsy) now carries the comparison: both arms side by side, their history, and both champions' exact genomes, plus everything it had before for the arm shown.
- **Keep your champions:** copy the `data` folder from v10.0.2 into this folder before the first start, then press *Start from saved champions* to start both arms from your walker.
- **Port 8793** (http://127.0.0.1:8793), so v10.1.0 can run beside v10.0.2 on 8792. Each folder's START and STOP scripts use their own port. Running both at once splits the machine between them.


## What's new in v10.0.2: firm friction, so walking is no longer scored as injury

**The finding.** Every version from v9.3 to v10.0.1 tops out at stepping in place, whichever joints or brain it uses. The cause is foot slide, not the brains or the joints.

- The rig counts a trial as harmed, the same rung as a fall, when the worst foot slides more than 6.25 cm in total.
- MuJoCo's default friction (a pyramidal cone with impratio 1) is soft. A planted, loaded foot creeps at 7–15 mm/s, where the slide meter forgives only 2 mm/s. That uses about 2.5 cm of the 6.25 cm allowance before the walker does anything.
- So the margin left for real stepping was too small, and an honest trot was scored as harm.

**The fix.** Friction is now *firm*: an elliptic friction cone with impratio 10, which is MuJoCo's own remedy for creep.
- The friction coefficient stays 1.10, and nothing in the fitness, the rungs or the harm rule changed.
- A planted foot now creeps at 0.6–2.7 mm/s.
- Simulation speed is unchanged.

**The evidence, on the rig's own 24 validation scenarios** (8 s each, with pushes, payload, sensor noise and lag):

| | legacy friction | firm friction |
|---|---|---|
| reference trot (open loop, servo joints): trials stepping | 2 of 24 | **24 of 24** |
| trials scored as harm | 22 of 24 | 0 of 24 |
| distance rung passed (6 cm/s, footfalls and posture held) | 2 of 24 | **24 of 24** |
| speed / worst-foot slide | 6.8 cm/s / 7.1 cm | 7.1 cm/s / 4.5 cm |

- **The reference trot** is 13 numbers: frequency, leg phases, and hip and knee amplitudes and offsets. CMA-ES found it in 70 rounds (about 4,000 rollouts) on servo joints and firm friction.
- On the 32 holdout scenarios it walks at 6.9 cm/s and passes the distance rung on 29.
- Its reward of record is 29 mm/s, about 30 times that of the best brain from a 13,000-generation v10.0.0 run (0.96 mm/s).
- **So the body can walk under the rig's rules.** Before this fix, the physics would not let it.

**The rig's own search, same seed and settings as your v10.0.1 servo run:**
- With firm friction, a ternary brain passed posture by generation 8 and footfalls by generation 28, and reached the distance rung.
- With legacy friction, that run was still on the footfalls rung at generation 462.
- **What is still open:** on the distance rung, the ternary champion then stepped in place for the 72 generations I could run here (0.04 cm/s forward). Walking forward is the next thing that has to evolve, and the *paced* brain below is meant to make it reachable.

**A new brain option: *paced*** (Brain model ⟲; *ternary* stays the default).
- The paced brain is the ternary brain, except that a tonic cell may be a **pacemaker**: a three-level wave (+1, 0, −1, 0) at 0.5–4 Hz with its own phase. Half the tonic cells are born pacing at 0.75–1.5 Hz.
- A mutation move (6 % of moves) can start a steady tonic cell pacing, move a pacemaker's rate one step (down to steady again), or shift or redraw its phase.
- Everything else is the ternary brain: it is born quiet, uses the same sensors and thresholds, and votes the same way. With every tonic cell steady, it is the ternary brain bit for bit (tested).
- **Tested here:** a paced run passed posture at generation 12 and was stepping on 38 % of validation trials by generation 32. That is slower through the early rungs than ternary, and the test ended before it reached the distance rung, so whether it walks forward sooner is not yet known.
- **Why:** the reference trot is a 0.8 Hz rhythm. A ternary brain has no slow clock: its cells update every 2 ms, so a loop inside it cycles in milliseconds, not over a 1.25 s stride, and a slow rhythm can only come through the body. Evolved ternary champions take about 4–5 steps per 8-second trial, the minimum for footfall credit, where a trot takes about 25. The pulse brain does have rhythm, but every cell oscillates, so its newborns flail, slide and fail posture; in tests here it had not passed posture after 20 generations. Paced brains keep the ternary brain's quiet start and add the rhythm the trot needs.

**Settings and saves**
- **Friction** (new setting ⟲, default *firm*). *legacy* restores the Foundry's soft friction exactly, for A/B runs.
- Saves record their friction. Saves from before v10.0.2 count as legacy, and they are rescored when loaded into a firm run (load, import, start from saved champions, continue).
- **The biopsy** shows the friction.
- **First launch** adds a walking check. The reference trot must step on at least 20, and pass the distance rung on at least 18, of the 24 validation scenarios. If the physics ever stops allowing walking, the rig won't start.
- **Port 8792, as in v10.0.1.** Stop v10.0.1 before starting this one; the launcher tells you if it is still running.
- **Keep your champions:** copy the `data` folder from v10.0.1 into this folder before the first start. *Start from saved champions* rescores them under firm friction.


## What's new in v10.0.1: servo joints, an exact biopsy, a stricter KG

- **Joints** (new setting ⟲, default *servo*):
  - *torque* is v10.0.0: each motor command is a raw torque, held for the 20 ms body step. A zero command lets the knees fold and the body collapse, so standing costs a constant push on every knee.
  - *servo*: each command is a joint target (rest ± 25 % of the joint's range per unit), tracked by a PD servo (kp 55, kd 5) recomputed every 4 ms physics step and capped at the same motor limits (28 N·m hip, 20 N·m knee). A zero command holds the standing pose. Actuator lag delays the command; the do-nothing body that distance is measured against holds the pose too.
  - Why: on the rig's own 24 validation scenarios, a plain open-loop trot (hips ±0.07 rad, knees flexing on the swing, 1 Hz) steps upright on 23 of 24 with servo joints and falls on all 24 with torque joints. Lightly tuned, it reaches ladder 2.007, stepping on 24 of 24: where a 13,000-generation torque run plateaued. None of 1,080 simple rhythms stepped as raw torque.
  - Champions evolved under one kind of joints are rescored when a run uses the other (start from save, load, import, continue). Saves now record their joints; saves from before v10.0.1 count as torque.
  - Compare the two on matched seeds before trusting either.
- **The PD option is fixed.** engine/plant.js's `pd` actuation held one PD torque for the whole 20 ms step, which is unstable at kd 5: asked to hold still, the body skated 46 cm and fell. It is now recomputed every physics step, and that is the servo. The torque path is untouched: 24 full rollouts are bit-identical to v10.0.0, and the parity check passes.
- **The biopsy can be replayed.** It carries the champion's and the current brain's genomes exactly (Float64Array, little-endian, deflate, base64), plus the joints, the RNG state, the seed and the suite seed.
- **The KG adopts less noise.** A new value must win both halves of its old-new-new-old test (window 2 against 1, window 3 against 4) as well as the total, so one lucky improvement no longer carries a test. No test starts while the champion is still climbing steeply (more than 2 % over the last window), so the opening climb can't decide one. Adoptions made before v10.0.1 stay applied; delete `data/tuner_ledger.json` to clear them.
- **First launch** runs the tests, the parity check and a new servo check: a zero command must hold the standing pose.
- **Port 8792** (http://127.0.0.1:8792), so v10.0.1 can run beside v10.0.0 on 8791. Each folder's START and STOP scripts use their own port.
- **Keep your champions and ledgers:** copy the `data` folder from v10.0.0 into this folder before the first start.


## What's new in v10: the pulse brain

Set **Brain model** to *pulse* before **Start fresh run**; *ternary* is the v9 brain. The server still runs at http://127.0.0.1:8791.

- **Every cell is an oscillator.** A 16-bit phase advances each brain tick and wraps around, emitting one pulse each time.
  - **Sensor slots set the rate:** their summed drive (−3 to +3) picks from a 7-entry table, from half to double the cell's base rate.
  - **Cell slots carry pulses:** each pulse from a source nudges the phase through a 256-entry phase-response table. Weight +1 pulls two cells toward firing together, −1 pushes them toward alternating.
  - **Tonic cells become pacemakers:** no inputs, pulsing at their base rate.
  - **Motors** average a 256-entry sine wave of their voters' phases, so the joints get rhythmic drive.
  - **The maths** is integer adds and table reads only.
- **Two new per-cell genes:** the base rate (0.5, 0.75, 1, 1.5, 2, 2.5, 3 or 4 Hz) and the starting phase. Mutation moves the rate one step, or shifts or redraws the phase, including on pacemakers. Growth adds 1–2 Hz oscillators. Pulse and ternary brains never cross, and a different base rate counts as a wiring difference.
- **Coordination is in the substrate, the gait is not.** The brain tests check that two cells coupled by excitation lock in step (gap 0.002 of a cycle), that two coupled by inhibition lock in anti-phase (0.499), and that an uncoupled pair keeps its gap (0.250). Which cells drive which legs, their phase relationships, and how sensors shape the timing all still have to evolve.
- **Everything else is unchanged:** roles, ternary weights and votes, basin search, the archive, both fitness modes (curriculum and distance), the KG and the live view. The genome layout is the same: header slot 6 marks a pulse brain, and its base rate and phase occupy the bias and gain fields, so saving and loading work unchanged.


v9.4.1 runs on port **8791** (http://127.0.0.1:8791), so it can't collide with older versions on 8790. Otherwise it is v9.4.0.

## What's new in v9.4: distance mode

Set **Fitness** to *distance* before **Start fresh run** or **Start from saved champions**; *curriculum* is the v9.3.1 behaviour.

- **The search optimises distance and nothing else.** Each training trial scores the forward distance the walker covered, whatever its posture: forward speed times the time actually simulated, so a trial stopped early keeps only the ground it covered. A brain's fitness is the mean plus half the worst trial. There are no rungs and no cycle, so the search may pass through clumsy, injurious gaits on its way somewhere better.
- **The archive keeps the least injurious walker of each gait.** In every gait cell, the elite is the brain with the least injury among those moving at least *Cleanest-walker floor* (1 cm/s), with ties broken by speed. A brain below the floor always ranks below one above it, so a still brain never wins a cell. Injury is the lab's own harm: the larger of body floor contact and foot slide, each relative to its limit.
- **The frontier keeps clean lineages in play.** Besides its peaks, it holds the farthest brain of every injury tier (harm up to 0.5, 1.25, 2.5, and beyond).
- **The farthest brain** is tracked separately on the fixed validation scenarios. **Test farthest** replays it, and the validation history's violet line shows its speed. It is raw forward speed, with no slip or contact penalty, so it reads higher than the reward of record.
- **The KG in distance mode** counts progress as the farthest brain's speed, plus the top-8 archive elites' quality. It can now also test *stop fallen trials early* (on or off), which matters more here: a dragging trial that is stopped after 1 s cannot show how far it would have got.
- **Loading an archive built under the other fitness re-scores it first,** so archive scores always match the current fitness. That takes about 1–2 minutes.


## What's new in v9.3.1: fixes from the first v9.3 run

- **No credit for crawling on the distance rung.** A trial earns distance credit only if it stayed upright and stepping. Any other trial scores below every stepping trial, ordered by the ladder, so fallers still have something to climb. In v9.3.0, brains that moved forward at about 1 cm/s while touching the floor outranked upright walkers at 0.4 cm/s.
- **The governor and the KG's settings tests no longer interrupt each other.** In v9.3.0, 8 of 12 tests were cut off by plateau trials. Now a due plateau trial waits for a running test to finish, and no test starts during a plateau trial or while one is due.
- **Tests are scored by walking quality:** the champion's gain, otherwise the average of the top 8 elites. v9.3.0 used the whole archive's quality, which rewarded filling new cells rather than walking better.
- **The KG keeps what it adopts.** Adoptions are saved with its ledger (`data/tuner_ledger.json`) and applied to every new run. The new defaults start from its first two adoptions: 30 % escape probes, and peaks that must differ in both gait and wiring.
- **The biopsy shows the KG's settings tests:** its log, its ledger, what it adopted, and the run's live settings, which the tuner changes.
- **The pool's wiring spread** no longer reads "Infinity": pairs of different sizes are counted separately.


## What's new in v9.3: the KG tunes the search, peaks must differ in gait

- **New starting point (defaults):**
  - base 48 cells;
  - **20 candidates per generation**: 4 peaks × 4 local children, plus 4 escape probes;
  - **peaks that must differ in gait** (duty × coordination × cadence, at least one archive bin apart), so the frontier works on different ways of walking at once. *Wiring* (v9.1's rule) and *both* are the other options.
- **The KG tunes settings over time** (*KG tunes settings*, on by default):
  - It takes one setting at a time and tests its value against a neighbouring one. The settings are candidates per generation (12/16/20/24), peaks (3/4/6), escape probes (10/20/30 %), training trials (6/8/12) and what peaks must differ in.
  - Each test runs in four windows of 500 generations in the order old, new, new, old, so a run that slows down as it matures biases neither value.
  - Each window is scored **per billion physics steps**, so a costlier setting has to pay for itself. The score is the champion's ladder gain or, when the champion does not move, the archive's total gain.
  - A new value is adopted only if it wins by 10 %. Every outcome goes into a ledger (`data/tuner_ledger.json`) that carries over between runs.
  - A plateau trial of the governor takes precedence: the tuner stops and restores the old value.
- **The live walker view.** While training runs, the champion is replayed every minute and whenever a new champion appears, without pausing. *Test top champion* and archive clicks no longer pause either; only *Test paused current* does.
- **Start from saved champions** starts a run in one step from the latest save in the `data` folder, with no founders. The frontier is seeded from the loaded champions.
- **The map has 8 dimensions** (*Map dimensions*). Pick any two as axes; each shows its share of the spread. The map is computed at most once per generation, and only while the page asks for it.


## What's new in v9.2: the fitness landscape

A map of what the basin search is doing, live, every 3 s.

- **The genotype map** places every brain the search holds or just tried, plus the top 24 archive elites, by multidimensional scaling of their wiring differences. Brains with similar wiring sit close together; brains of different sizes are always apart, more so the more their sizes differ.
- **The behaviour map** places the same brains by gait instead: duty factor against coordination.
- **A colour field** spreads fitness between the points: training fitness on the current rung, or the validation ladder for elites.
- **The points:** this generation's peaks are gold rings with their numbers, the rest of the frontier is cyan, local candidates are white, escape probes violet, elites grey.
- **Click any point** to replay that brain in the 3D view and the connectome.


## What's new in v9.1: basin search

On the pendulum's fair A/B (6 seeds, 600 generations), searching several peaks at once balanced the pendulum on 5 of 6 seeds, against 2 of 6 for the champion climber. v9.0 on the walker then showed the climber's weakness directly: its current brain sat far below its own champion (validation ladder 0.7–1.9 against 2.10), and the bandit rewarded re-deriving champions rather than improving on them. v9.1 changes three things.

- **Basin search is the default search** (setting: *Basin search*; off = the v9.0 champion climber). It ports the pendulum's winning method:
  - a frontier of up to 4K brains (K = 4 peaks, so 16 brains);
  - each generation, K separated peaks are chosen from it, and a different size always counts as separated;
  - about 80 % of candidates are local mutants of the peaks;
  - *Escape probes %* (default 20) are bigger jumps (4–6 mutations) from founders, archive elites or the best brain.

  Peaks are re-ranked by their basin score: half the peak's own fitness, plus 0.3 × its children's mean (less 0.15 × their spread), plus 0.2 × its best child. That favours peaks whose neighbourhoods are good, not narrow spikes. The best brain on the current trials is never dropped. The whole frontier is re-scored whenever the training trials rotate or the curriculum changes rung, so no fitness goes stale.
- **The bandit's credit is fair.** Each child is credited against **its own parent's** fitness on the same trials. In basin mode the parent is its peak; in the climber, pool and archive parents are scored once per trial set and rung. Re-deriving a champion from a weak current brain no longer earns credit. In basin mode the bandit chooses mutation count, crossover between peaks, and grow or shrink.
- **Each curriculum cycle restarts from the best brains.** In basin mode the champion and the pool join the frontier; in the climber, the champion becomes the current brain. Kept skills pass again at once, instead of a wandering lineage re-learning them.

The plateau governor's moves act on the frontier. *Grow* and *switch* bring a brain into it; *explore* doubles the escape probes for a while; *refine* turns them off for a while. Everything else is as in v9.0: internal and tonic cells, faster thinking, mixed sizes, the cycled curriculum, the archive and the page.


The protoneuron pendulum lab's method on the MuJoCo quadruped, with a brain that can make its own dynamics, and a run that tunes itself. Ternary brains only, one page, one run at a time.

## What's new in v9

- **Internal cells.** At least half the cells are internal: they read only other cells, never a sensor, and never vote on a motor. That gives the brain a network the body doesn't drive, where patterns of its own can form. No rhythm is built in, and there is no clock.
  - Each motor needs 6 voters, so a brain keeps at least 6 sensor-motor or tonic cells, which caps internal cells at N − 6. An 8-cell brain has only 2.
- **Tonic cells.** A small minority (default 8 %) output +1 on every tick. Any cell can read them, and they can vote, so they can hold a steady push on a leg.
- **Permanent roles.** Mutation, growth, shrinking and crossover all respect roles, so an internal cell stays internal.
- **The brain thinks faster than the body.** Sensors are read, and torques set, every 20 ms as in the lab. In between, every cell updates K times (default 10, a 2 ms tick: twice the 4 ms physics rate), and each motor takes the average of its K vote counts. A chain from sensor to interneuron to motor now acts within one body step, and torque has finer steps.
  - With every cell sensor-motor and K = 1, this is exactly the lab's brain; the tests check that bit for bit.
- **Mixed sizes in one population.**
  - Founders span half to four times the base size: 12, 24, 48 and 96 cells.
  - Grow and shrink are mutations of one cell each. Growth is exactly neutral: a new cell is read by nobody until later mutations wire it in.
  - Size is an axis of the archive, one bin per octave (8–15, 16–31, 32–63, 64–127, 128+). Over the cap, the archive drops the weakest elite of the most crowded size class, so fast-improving small brains can't crowd big ones out.
  - Crossover works across sizes, swapping whole cells of the same role.
  - Max cells (default 192) caps growth.
- **The bandit** chooses, for every candidate, the mutation count (1, 2, 4 or 8), the parent (current brain, pool or archive), crossover or not, and grow, shrink or neither.
  - Each option is credited with the size of the gains its candidates make over the current brain, as a decaying average, so the shares follow the landscape as it changes.
  - No option drops below 5 %.
  - The page shows the live shares, and turning the bandit off returns to the manual settings.
- **The plateau governor, a scaled-back KG.** After a plateau (default 3,000 generations without a better champion):
  1. It checks the champion on the 32 holdout scenarios, and demotes it if it scores more than 0.3 lower there than on validation.
  2. It tries one intervention for a trial window (default 1,500 generations): grow the current brain by internal cells; switch to a different archive elite, of another size if possible; explore harder for a while; or refine locally for a while.
  3. Interventions are chosen by Thompson sampling on a ledger of wins and tries, which is saved in `data/governor_ledger.json` and carries over between runs.

  Every decision is logged in plain words on the page and in the biopsy.
- **The clock is gone,** and v8.0.x champions still load.

## Run it

- **Start:** double-click **START_MAC.command** (Windows: START_HERE.bat), and the page opens at http://127.0.0.1:8793.
  - The first launch installs MuJoCo and three.js, runs the tests (seconds), and runs the MuJoCo parity check against the lab's own evaluator (about a minute).
  - Nothing starts unless both pass.
- **Stop:** **STOP_MAC.command** saves the champions, then stops the rig.
- **While it runs,** the Mac is kept awake.

## The page

It is the pendulum lab's layout: walker view, metrics, the three rungs, settings, validation history, run log, the behaviour archive (click a cell to replay it), and save and load. Two things are new:

- **Self-tuning panels:** the bandit's shares, with wins out of tries, and the governor's log and ledger.
- **The live connectome by role:**
  - sensor-motor cells on the outer cyan ring;
  - internal cells on the inner violet ring;
  - tonic cells in gold at the centre.

  Each node lights with its output at the frame shown.

Settings marked ⟲ apply on the next **Start fresh run**: cells, votes, brain ticks, internal %, tonic %, mixed sizes, seed, founders and the trial suites. Everything else applies from the next generation.

## The fitness and the cycled curriculum (unchanged)

Each training trial is scored by the active rung's own score, using the lab's definitions in `engine/gait_curriculum.mjs`:

| rung | score per trial | passed when |
|---|---|---|
| posture | survival + 0.6 × liveliness − 0.5 × slam | upright the whole trial, feet moving, harm ≤ 1.25 |
| footfalls | footfall quality − 0.35 × slam (+ 0.01 × posture score) | footfall quality ≥ 0.72, posture held |
| distance | the WALK reward of record × posture and footfall retention | 6 cm/s, footfalls and posture held |

A brain's fitness is the mean over its trials plus 0.5 × its worst trial.

The rung order is posture → footfalls → distance. A rung advances when at least 75 % of the validation trials pass it. After 400 generations on distance, the cycle restarts at posture.

The archive scores brains with the rung-independent **ladder**, on 24 fixed validation scenarios:
- **0 + posture progress** if posture is not held;
- **1 + footfall progress** if upright but not yet stepping;
- **2 + 1 − e^(−Q / 0.1 m/s)** if stepping, where Q is the per-trial reward of record.

## Files

```
START_MAC.command  STOP_MAC.command  START_HERE.bat  STOP_HERE.bat
rig/brain.mjs          the v9 brain: roles, tonic cells, ticks, birth, operator, growth, controller
rig/lab.mjs            the lab: one run, the pendulum lab's commands, governor, save/load, biopsy
rig/server.mjs         the page and its API (Node only)
rig/core/              champion evolution, archive, bandit, plateau governor, statistics
rig/plants/            the walker: fitness, curriculum, descriptors, MuJoCo worker threads
rig/gui/               the page: three.js walker, connectome, self-tuning panels
rig/check_parity.mjs   the MuJoCo parity check (first launch)
rig/tests/             tests, no MuJoCo needed (npm test)
engine/                the lab's physics, reward, sensors and curriculum, unchanged
data/                  your runs: champions, the governor's ledger, the server log
```

## What was tested where

- **In the build container,** with Node 22 and no MuJoCo, all 7 test files pass. v9.1's `basin_test` checks:
  - exactly λ training candidates per generation, plus re-scoring only when trials rotate or the rung changes;
  - the bandit credited once per local sample, against that sample's own peak;
  - the best brain never dropped;
  - re-scoring after rotation;
  - restart-from-best, adopt and the governor's moves reaching the frontier;
  - the climber's parents scored for fair credit.

  The earlier v9.0 tests still pass:
  - **The new brain:**
    - it equals the lab's brain bit for bit when reduced to it (300 steps, 12, 24 and 48 cells);
    - birth follows the role rules from 8 to 192 cells;
    - 3,000 random mutations, growths, shrinks and crossovers with other sizes kept every rule;
    - growth by 5 cells left every motor output unchanged;
    - tonic cells are +1 on every tick.
  - **The bandit** shifts candidates toward an option that pays 6 times more.
  - **The governor** finds a plateau, audits the champion, runs a trial and records it, and chooses by its ledger.
  - **The rest:** the reward against 40 of the lab's recorded trials, the curriculum's cycle, every page command, and the server end to end, all on a mock walker.
- **On your Mac:** the first launch's parity check verifies the physics and the reward through the rig's worker.
- **Never tested:**
  - the new brain on real MuJoCo;
  - the page in a browser.
