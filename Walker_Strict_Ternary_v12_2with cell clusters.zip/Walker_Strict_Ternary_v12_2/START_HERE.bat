@echo off
cd /d "%~dp0"
if not exist "rig\server.mjs" (echo Extract the zip first: right-click it, "Extract All...", then run this from the extracted folder. & pause & exit /b 1)
echo === Walker Ternary Rig v10.1.0 - regular vs plastic brains on the MuJoCo walker ===
where node >nul 2>&1
if errorlevel 1 (echo Node.js 22 or newer is required: https://nodejs.org & goto :fail)
if not exist data mkdir data
if not exist node_modules\@mujoco\mujoco (
  echo Installing MuJoCo and three.js, once...
  call npm install --no-audit --no-fund
  if errorlevel 1 goto :fail
  if exist data\.verified_v10_1_0 del data\.verified_v10_1_0
)
if not exist data\.verified_v10_1_0 (
  echo First launch: the rig tests, then the MuJoCo parity check...
  node rig\tests\run_all.mjs
  if errorlevel 1 goto :fail
  node rig\check_parity.mjs --workers 8
  if errorlevel 1 goto :fail
  node rig\tests\proto_mujoco_smoke.mjs
  if errorlevel 1 goto :fail
  echo verified>data\.verified_v10_1_0
)
start "Walker Ternary Rig" /min cmd /c "node rig\server.mjs >> data\server.log 2>&1"
timeout /t 3 >nul
start "" http://127.0.0.1:8793
echo The rig is running at http://127.0.0.1:8793 - STOP_HERE.bat stops it and saves the champions.
exit /b 0
:fail
echo.
echo SETUP OR VERIFICATION FAILED. The rig was not started.
pause
exit /b 1
