@echo off
setlocal EnableExtensions
title Walker v12.2 - strict ternary walker
rem ------------------------------------------------------------------------
rem  Walker v12.2 strict ternary lab - Windows launcher (one double-click).
rem  Port 8794, saves in data_strict. Never touches the old 8793 walker.
rem ------------------------------------------------------------------------
cd /d "%~dp0"
set "URL=http://127.0.0.1:8794"
echo === Walker v12.2 STRICT ternary lab: 192 cells by default, up to 2,500 ===
echo Folder: "%CD%"
echo.

if not exist "rig\server.mjs" goto :notextracted

where node >nul 2>&1
if errorlevel 1 goto :nonode
node -e "process.exit(Number(process.versions.node.split('.')[0])>=22?0:1)"
if errorlevel 1 goto :oldnode

if not exist "data_strict" mkdir "data_strict"

rem Already running? Just open the page.
where curl >nul 2>&1
if errorlevel 1 goto :checked
curl -fsS -m 2 %URL%/api/build >nul 2>&1
if errorlevel 1 goto :checked
echo The strict walker is already running. Opening it.
start "" %URL%
goto :done
:checked

rem One-time install of MuJoCo (WebAssembly) and three.js.
if not exist "node_modules\@mujoco\mujoco\package.json" goto :install
if not exist "node_modules\three\package.json" goto :install
goto :installed
:install
echo Installing MuJoCo and three.js, one time only (needs internet)...
call npm install --no-audit --no-fund
if errorlevel 1 goto :npmfail
if exist "data_strict\.verified_strict_v12_2" del "data_strict\.verified_strict_v12_2"
:installed

rem MuJoCo threads: one per core, leaving one free for Windows (at most 12).
set /a RIG_WORKERS=%NUMBER_OF_PROCESSORS%-1
if %RIG_WORKERS% LSS 1 set RIG_WORKERS=1
if %RIG_WORKERS% GTR 12 set RIG_WORKERS=12

rem First launch only: checks. The real-physics ones must pass.
set "RIG_START_STRICT="
set "RIG_PORT="
set "RIG_DATA_DIR="
if exist "data_strict\.verified_strict_v12_2" goto :verified
echo First launch: checking the brain, the superneurons and real MuJoCo physics...
node rig\tests\strict_test.mjs
if errorlevel 1 goto :testfail
node rig\tests\superneuron_test.mjs
if errorlevel 1 goto :testfail
node rig\tests\proto_mujoco_smoke.mjs
if errorlevel 1 goto :testfail
node rig\tests\strict_mujoco_smoke.mjs
if errorlevel 1 goto :testfail
echo Running the full regression suite (advisory; a failure here is logged, not fatal)...
node rig\tests\run_all.mjs > "data_strict\regression_tests.log" 2>&1
if errorlevel 1 echo   NOTE: some regression tests failed - see data_strict\regression_tests.log
echo verified> "data_strict\.verified_strict_v12_2"
:verified

rem Launch the server minimised. Closing that window stops it (champions are saved).
set "RIG_PORT=8794"
set "RIG_DATA_DIR=%CD%\data_strict"
set "RIG_START_STRICT=1"
echo Starting the strict walker with %RIG_WORKERS% MuJoCo threads...
start "Walker strict server - close to stop" /min cmd /c "node rig\server.mjs >> data_strict\server.log 2>&1"

rem Wait until it answers (up to ~40 s), then open the browser.
where curl >nul 2>&1
if errorlevel 1 goto :blindwait
set /a TRIES=0
:waitloop
curl -fsS -m 1 %URL%/api/build >nul 2>&1
if not errorlevel 1 goto :up
set /a TRIES+=1
if %TRIES% GEQ 40 goto :serverfail
ping -n 2 127.0.0.1 >nul
goto :waitloop
:blindwait
ping -n 6 127.0.0.1 >nul
:up
start "" %URL%
echo.
echo Running at %URL%
echo Stop it with STOP_STRICT_WINDOWS.bat (saves the champions). This window can be closed.
goto :done

:notextracted
echo This folder does not contain the walker files.
echo If you opened the zip by double-clicking it, Windows is only showing you the
echo inside of the zip. Right-click the zip, choose "Extract All...", open the
echo extracted folder and double-click START_STRICT_WINDOWS.bat there.
goto :fail
:nonode
echo Node.js is not installed (or not on PATH).
echo Install the LTS version from https://nodejs.org (22 or newer), then run this again.
goto :fail
:oldnode
echo Node.js 22 or newer is needed. You have:
node -v
echo Install the current LTS from https://nodejs.org, then run this again.
goto :fail
:npmfail
echo npm install failed. Check the internet connection (and any company proxy), then run this again.
goto :fail
:testfail
echo.
echo A required check failed, so the walker was NOT started. The messages above say which.
goto :fail
:serverfail
echo The server did not answer within 40 seconds. Last lines of data_strict\server.log:
powershell -NoProfile -Command "Get-Content -Tail 30 'data_strict\server.log'"
goto :fail
:fail
echo.
pause
exit /b 1
:done
endlocal
exit /b 0
