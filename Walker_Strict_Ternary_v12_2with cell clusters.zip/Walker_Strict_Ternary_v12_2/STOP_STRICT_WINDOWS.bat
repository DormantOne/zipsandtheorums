@echo off
setlocal
cd /d "%~dp0"
echo Asking the strict walker on port 8794 to save its champions and stop...
where curl >nul 2>&1
if errorlevel 1 goto :ps
curl -s --max-time 10 -X POST -H "Content-Type: application/json" -d "{\"cmd\":\"shutdown\"}" http://127.0.0.1:8794/api/cmd
if errorlevel 1 echo It did not answer - it is probably not running.
goto :end
:ps
powershell -NoProfile -Command "try{Invoke-RestMethod -Method Post -ContentType 'application/json' -Body '{\"cmd\":\"shutdown\"}' -Uri http://127.0.0.1:8794/api/cmd | Out-Null; 'Stop requested.'}catch{'It did not answer - it is probably not running.'}"
:end
echo.
echo The legacy walker on port 8793 is not affected.
ping -n 4 127.0.0.1 >nul
endlocal
