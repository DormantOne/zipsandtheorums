/* rig/brain.mjs — the v9 protoneuron brain.
 *
 * Each cell is the lab's ternary protoneuron, unchanged: exactly 3 incoming
 * slots, weights in {-1, 0, +1}, output in {-1, 0, +1} by the lab's firing
 * rule (bias, gain, three fire-biases, decision temperature DECT). Two things
 * are new, both permanent parts of a brain:
 *
 *   roles   IO       reads sensors and other cells, may vote on motors
 *           INTERNAL reads other cells only (never a sensor), never votes
 *           TONIC    always outputs +1; any cell may read it; may vote
 *           Mutations respect roles, so an internal cell stays internal.
 *   ticks   K brain ticks per 20 ms control step. Sensors are read once per
 *           step and torques set once per step, exactly as in the lab; in
 *           between all cells update K times (each tick synchronous: every
 *           cell reads the previous tick), and each motor takes the average of
 *           its K vote counts. K = 5 is the physics rate (4 ms), K = 10 twice it.
 *
 * With every cell IO and K = 1 this is the lab's brain, bit for bit
 * (rig/tests/brain_test.mjs checks it against engine/ternary.mjs).
 *
 * v10: the PULSE brain (header [6] = 1), same genome layout, same roles,
 * slots, ternary weights and motor votes. Every cell is an oscillator: a
 * 16-bit phase that wraps and emits one pulse each time it does.
 *   sensor slots  their summed drive (-3..+3) sets the rate, from half to
 *                 double the cell's base rate (a 7-entry table per cell)
 *   cell slots    a pulse from the source nudges the phase by weight x the
 *                 phase-response table (256 entries): +1 pulls toward firing
 *                 together, -1 pushes toward firing in alternation
 *   tonic cells   pacemakers: no inputs, they pulse at their base rate
 *   motors        each the mean over its voters of vote x a 256-entry sine
 *                 wave of the voter's phase, averaged over the K ticks
 * Per cell, bias holds the base-rate index into PULSE_HZ (0.5..4 Hz) and
 * gain the starting phase (0..1); the fire-biases are unused. Integer adds
 * and table reads only.
 *
 * Genome (Float64Array):
 * v10.0.2: the PACED brain (header [6] = 2) is the ternary brain, cell for cell,
 * except that a tonic cell may be a pacemaker. A tonic cell's bias, unused in a
 * ternary brain, holds its rate: 0 = a steady +1 as before, 1..8 = PULSE_HZ
 * (0.5..4 Hz) as a three-level wave (+1 while sin > 0.5, -1 while sin < -0.5,
 * else 0), and its gain holds the phase (0..1). Half the tonic cells are born
 * pacemakers at 0.75-1.5 Hz; a mutation move (6 % of moves) turns a steady
 * tonic cell into a pacemaker, moves a rate one step (to 0 = steady again), or
 * shifts or redraws a phase. Everything else is the ternary brain: quiet when
 * born, sensors and thresholds, and the same votes. The rhythm is available;
 * which legs it drives, and when, still has to evolve.
 *
 * v10.1.0: the PLASTIC brain (header [6] = 3) is the ternary brain plus two
 * genes per cell, appended after the decoder: a learning rate (-3..3; 0 = the
 * cell's wires never change) and a fade (0..3, how long its activity trace
 * lasts). During a trial every learning cell keeps a fading trace of its own
 * output; each of its three wires keeps a hidden counter, filled by
 * rate x modulator x (source activity) x (cell trace). When a counter reaches
 * +1 the wire's weight steps one notch toward +1 (-1 -> 0 -> +1); at -1 it
 * steps toward -1; the counter then starts again. So weights stay -1, 0 or +1,
 * and a cut wire can grow back. The modulator is the brain's own forward-speed
 * sense: learning runs while the body moves forward, reverses while it moves
 * backward, and stops while it stands. Learned changes last one trial; each
 * trial starts again from the genome (evolution keeps what learns well).
 * Born with every rate 0, a plastic brain is the ternary brain, bit for bit.
 *
 * v10.1.0 muscles: a brain for muscle joints has A = 16 motors (a "plus" and a
 * "minus" muscle per joint, commands 0-7 and 8-15). At birth each minus muscle
 * gets its plus muscle's votes with the sign flipped, so a newborn drives each
 * pair in reciprocity and behaves exactly like a servo brain; votes then evolve
 * per muscle. adaptRig converts brains between 8 and 16 motors and between the
 * ternary and plastic kinds.
 *
 *   [0] RIG_MAGIC [1] N [2] S [3] A [4] V votes per motor [5] K ticks [6] kind (0 ternary, 1 pulse, 2 paced, 3 plastic) [7] 0
 *   cell i at 8+12i: role, src x3, w x3, bias, gain, fireBias x3
 *   then the decoder, A x N votes in {-1,0,1}: exactly V per motor, on IO or TONIC cells
 *   plastic only: N learning rates, then N fades
 */
import {T_SENS,T_ACT,DECT,T_LIMITS,KEY_SENSORS,encodeTernary,deadSensorSet,unpackTernary,TERNARY_SENSORS} from '../engine/ternary.mjs';

export const RIG_MAGIC=9.0625;
export const ROLE=Object.freeze({IO:0,INTERNAL:1,TONIC:2});
export const ROLE_NAMES=['sensor-motor','internal','tonic'];
export const RIG_MAX_N=2500;
const H=8,CS=12,MIN_N=8,MAX_N=RIG_MAX_N;
export const KIND=Object.freeze({TERNARY:0,PULSE:1,PACED:2,PLASTIC:3,STRICT_FIXED:4,STRICT_PLASTIC:5});
export const isStrictKind=k=>k===KIND.STRICT_FIXED||k===KIND.STRICT_PLASTIC;
export const isPlasticKind=k=>k===KIND.PLASTIC||k===KIND.STRICT_PLASTIC;
/* plastic brain: learning rate by |gene| (sign = Hebbian or anti-Hebbian), trace fade by gene */
export const LEARN_RATES=Object.freeze([0,.05,.1,.2]),LEARN_FADES=Object.freeze([0,.5,.8,.95]);
const FWD_SENSOR=TERNARY_SENSORS.findIndex(x=>x.label==='fwd vel');
const PLASTIC_MOVE_ODDS=.15;   // after each ordinary mutation move, a plastic brain also gets a learning-gene move this often
export const PULSE_HZ=Object.freeze([.5,.75,1,1.5,2,2.5,3,4]);
const PULSE_NUDGE=.06,WAVE=new Float64Array(256),NUDGE=new Int32Array(256);   // a weighted pulse moves the phase by up to 6 % of a cycle
for(let p=0;p<256;p++){const s=Math.sin(2*Math.PI*(p+.5)/256);WAVE[p]=s;NUDGE[p]=Math.round(-PULSE_NUDGE*65536*s)}
export const rigKind=g=>g[6]|0;
const LIVE_SENSORS=(()=>{const dead=deadSensorSet('walk',0),a=[];for(let i=0;i<T_SENS;i++)if(!dead.has(i))a.push(i);return a})();
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x)),pick=(rng,a)=>a[Math.floor(rng.next()*a.length)];

export const isRigGenome=g=>g instanceof Float64Array&&g.length>=H&&g[0]===RIG_MAGIC&&g.length===H+(CS+g[3])*g[1]+(isPlasticKind(g[6]|0)?2*g[1]:0);
export const rigSize=g=>g[1]|0;
export function unpackRig(g){
  const N=g[1]|0,S=g[2]|0,A=g[3]|0,V=g[4]|0,K=Math.max(1,g[5]|0);
  const b={N,S,A,V,K,kind:g[6]|0,role:new Int8Array(N),src:new Int32Array(3*N),w:new Int8Array(3*N),bias:new Float64Array(N),gain:new Float64Array(N),fb:new Float64Array(3*N),dec:new Int8Array(A*N)};
  for(let i=0;i<N;i++){const o=H+CS*i;b.role[i]=g[o];for(let k=0;k<3;k++){b.src[3*i+k]=g[o+1+k];b.w[3*i+k]=g[o+4+k];b.fb[3*i+k]=g[o+9+k]}b.bias[i]=g[o+7];b.gain[i]=g[o+8]}
  const d=H+CS*N;for(let x=0;x<A*N;x++)b.dec[x]=g[d+x];
  if(isPlasticKind(b.kind)){const e=d+A*N;b.eta=new Int8Array(N);b.fade=new Int8Array(N);for(let i=0;i<N;i++){b.eta[i]=g[e+i];b.fade[i]=g[e+N+i]}}
  return b;
}
export function packRig(b){
  const {N,S,A,V,K}=b,pl=isPlasticKind(b.kind|0),g=new Float64Array(H+(CS+A)*N+(pl?2*N:0));g[0]=RIG_MAGIC;g[1]=N;g[2]=S;g[3]=A;g[4]=V;g[5]=K;g[6]=b.kind|0;
  for(let i=0;i<N;i++){const o=H+CS*i;g[o]=b.role[i];for(let k=0;k<3;k++){g[o+1+k]=b.src[3*i+k];g[o+4+k]=b.w[3*i+k];g[o+9+k]=b.fb[3*i+k]}g[o+7]=b.bias[i];g[o+8]=b.gain[i]}
  const d=H+CS*N;for(let x=0;x<A*N;x++)g[d+x]=b.dec[x];
  if(pl){const e=d+A*N;for(let i=0;i<N;i++){g[e+i]=b.eta?.[i]|0;g[e+N+i]=b.fade?b.fade[i]|0:1}}
  return g;
}
const cloneB=b=>({...b,role:b.role.slice(),src:b.src.slice(),w:b.w.slice(),bias:b.bias.slice(),gain:b.gain.slice(),fb:b.fb.slice(),dec:b.dec.slice(),...(b.eta?{eta:b.eta.slice(),fade:b.fade.slice()}:{})});
const cache=new WeakMap();
const view=g=>{let b=cache.get(g);if(!b){b=unpackRig(g);cache.set(g,b)}return b};

/* the lab's brain as a rig brain: every cell sensor-and-motor, one tick */
export function fromLabGenome(g){
  const t=unpackTernary(g),N=t.N;
  return packRig({N,S:t.S,A:t.A,V:t.V,K:1,role:new Int8Array(N),src:Int32Array.from(t.src),w:Int8Array.from(t.w),bias:Float64Array.from(t.bias),gain:Float64Array.from(t.gain),fb:Float64Array.from(t.fireBias),dec:Int8Array.from(t.dec)});
}

// ── roles ───────────────────────────────────────────────────────────────────
export function roleCounts(N,{internalShare=.5,tonicShare=.08,V=6}={}){
  let T=tonicShare>0?Math.max(1,Math.round(tonicShare*N)):0,I=Math.ceil(clamp(internalShare,0,1)*N);
  if(T+I>N-1)I=Math.max(0,N-1-T);
  while(N-T-I+T<V&&I>0)I--;                 // the motors need V eligible voters (sensor-motor or tonic)
  return {T,I,IO:N-T-I};
}
const allowedSource=(role,src,S)=>role===ROLE.INTERNAL?src>=S:true;

// ── birth: the lab's wiring rule, per role ─────────────────────────────────
export function birthRig(rng,{N=24,V=6,K=10,internalShare=.5,tonicShare=.08,kind=0,A:motors=T_ACT}={}){
  N=clamp(Math.trunc(N),MIN_N,MAX_N);const S=T_SENS,pairs=motors===2*T_ACT,A=T_ACT;V=clamp(Math.trunc(V),1,N);   // muscle brains: votes drawn for the 8 plus muscles, mirrored below
  const {T,I}=roleCounts(N,{internalShare,tonicShare,V});
  const role=new Int8Array(N),order=[...Array(N).keys()];
  for(let i=N-1;i>0;i--){const j=Math.floor(rng.next()*(i+1));[order[i],order[j]]=[order[j],order[i]]}
  order.forEach((c,k)=>{role[c]=k<T?ROLE.TONIC:k<T+I?ROLE.INTERNAL:ROLE.IO});
  const b={N,S,A,V,K:Math.max(1,Math.trunc(K)),role,src:new Int32Array(3*N),w:new Int8Array(3*N),bias:new Float64Array(N),gain:new Float64Array(N).fill(T_LIMITS.gainInit),fb:new Float64Array(3*N),dec:new Int8Array(A*N)};
  const readCount=new Int32Array(N),tonic=[...Array(N).keys()].filter(i=>role[i]===ROLE.TONIC);
  const leastRead=(exclude,self)=>{let best=Infinity,c=[];for(let j=0;j<N;j++){if(exclude.has(j))continue;const v=readCount[j]+(j===self?.5:0);if(v<best){best=v;c=[j]}else if(v===best)c.push(j)}return c.length?pick(rng,c):-1};
  const keys=KEY_SENSORS.filter(k=>LIVE_SENSORS.includes(k));let keyCursor=Math.floor(rng.next()*Math.max(1,Math.min(4,keys.length)));
  const fresh=used=>{let s,t=0;do{s=pick(rng,LIVE_SENSORS)}while(used.has(s)&&t++<64);return s};
  for(const i of order){
    if(role[i]===ROLE.TONIC){for(let k=0;k<3;k++){b.src[3*i+k]=S+i;b.w[3*i+k]=0}continue}
    const used=new Set(),cellsUsed=new Set(),slots=[];
    const cell=()=>{const j=leastRead(cellsUsed,i);if(j<0)return -1;cellsUsed.add(j);readCount[j]++;return S+j};
    if(role[i]===ROLE.IO){
      const s0=keys.length?keys[keyCursor++%keys.length]:pick(rng,LIVE_SENSORS);used.add(s0);slots.push(s0);
      let s1=rng.next()<.5?fresh(used):cell();if(s1<0)s1=fresh(used);used.add(s1);slots.push(s1);
      let s2=cell();if(s2<0)s2=fresh(used);slots.push(s2);
    }else{                                   // internal: tonic drive first if there is any, then cells
      if(tonic.length){const t=pick(rng,tonic);cellsUsed.add(t);readCount[t]++;slots.push(S+t)}else slots.push(cell());
      slots.push(cell());slots.push(cell());
      for(let k=0;k<3;k++)if(slots[k]<0)slots[k]=S+i;
    }
    for(let k=0;k<3;k++){b.src[3*i+k]=slots[k];b.w[3*i+k]=rng.next()<.5?-1:1}
  }
  const voteCount=new Int32Array(N),io=[...Array(N).keys()].filter(i=>role[i]===ROLE.IO),eligible=io.length>=V?io:[...io,...tonic];
  for(let a=0;a<A;a++){const chosen=new Set();
    for(let v=0;v<V;v++){let best=Infinity,c=[];for(const i of eligible){if(chosen.has(i))continue;const x=voteCount[i]*4+(readCount[i]>0?0:-1);if(x<best){best=x;c=[i]}else if(x===best)c.push(i)}
      const i=pick(rng,c);chosen.add(i);voteCount[i]++;b.dec[a*N+i]=rng.next()<.5?-1:1}}
  /* muscles: each minus muscle votes like its plus muscle with the sign flipped (reciprocal pairs, a servo at birth; no draws) */
  if(pairs)mirrorMuscles(b);
  /* a pulse brain: the same wiring, plus a random base rate and starting phase per cell (drawn last, so ternary births are unchanged) */
  if(kind===KIND.PULSE){b.kind=KIND.PULSE;b.fb.fill(0);for(let i=0;i<N;i++){b.bias[i]=Math.floor(rng.next()*PULSE_HZ.length);b.gain[i]=rng.next()}}
  /* a paced brain: the same wiring; half its tonic cells pace at 0.75-1.5 Hz (bias = rate index + 1), drawn last */
  else if(kind===KIND.PACED){b.kind=KIND.PACED;for(const i of tonic)if(rng.next()<.5){b.bias[i]=2+Math.floor(rng.next()*3);b.gain[i]=rng.next()}}
  /* a plastic brain: the same wiring, every learning rate 0 (no draws: it is the ternary newborn, bit for bit) */
  else if(isStrictKind(kind)){
    b.kind=kind;b.bias.fill(0);b.gain.fill(1);b.fb.fill(0);
    if(isPlasticKind(kind)){b.eta=new Int8Array(N);b.fade=new Int8Array(N).fill(1)}
  }
  else if(kind===KIND.PLASTIC){b.kind=KIND.PLASTIC;b.eta=new Int8Array(N);b.fade=new Int8Array(N).fill(1)}
  return packRig(b);
}

// ── the operator: the lab's mix of moves, respecting roles ─────────────────
function relevant(b){
  const S=b.S,set=new Set();for(let a=0;a<b.A;a++)for(let i=0;i<b.N;i++)if(b.dec[a*b.N+i])set.add(i);
  for(let lvl=0;lvl<2;lvl++)for(const i of [...set])for(let k=0;k<3;k++){const s=b.src[3*i+k];if(s>=S&&b.w[3*i+k])set.add(s-S)}
  return [...set].filter(i=>b.role[i]!==ROLE.TONIC);
}
function newSource(b,i,rng,sensorBias){return b.role[i]===ROLE.INTERNAL||rng.next()>=sensorBias?b.S+Math.floor(rng.next()*b.N):pick(rng,LIVE_SENSORS)}
export function mutateRig(g,rng,{count=2,strong=false,focus=.85,sensorBias=.5,silenceOdds=.1}={}){
  const b=cloneB(view(g)),N=b.N,L=T_LIMITS,work=[...Array(N).keys()].filter(i=>b.role[i]!==ROLE.TONIC);
  if(!work.length)return g;const rel=relevant(b);
  const target=()=>rel.length&&rng.next()<focus?pick(rng,rel):pick(rng,work);
  for(let z=0;z<count;z++){
    const u=rng.next(),i=target(),k=Math.floor(rng.next()*3),x=3*i+k;
    if(u<.26){if(b.w[x]){b.w[x]=rng.next()<silenceOdds?0:-b.w[x]}else{b.w[x]=rng.next()<.5?-1:1;if(rng.next()<.5)b.src[x]=newSource(b,i,rng,sensorBias)}}
    else if(u<(isStrictKind(b.kind)?.62:.50))b.src[x]=newSource(b,i,rng,sensorBias);
    else if(isStrictKind(b.kind))voteMove(b,rng);
    else if(b.kind===KIND.PULSE&&u<.78){const j=Math.floor(rng.next()*N);          // pulse brain: any cell, pacemakers included
      if(u<.66)b.bias[j]=clamp(b.bias[j]+(rng.next()<.5?-1:1),0,PULSE_HZ.length-1);   // base rate one step up or down
      else if(u<.74)b.gain[j]=((b.gain[j]+(rng.next()-.5)*.25)%1+1)%1;                  // starting phase shifted
      else b.gain[j]=rng.next()}                                                           // starting phase redrawn
    else if(u<.62)b.bias[i]=clamp(b.bias[i]+(rng.next()<.5?-1:1)*L.biasStep,-L.bias,L.bias);
    else if(u<.72){const c=3*i+Math.floor(rng.next()*3);b.fb[c]=clamp(b.fb[c]+(rng.next()<.5?-1:1)*L.fireBiasStep,-L.fireBias,L.fireBias)}
    else if(u<.78)b.gain[i]=clamp(b.gain[i]*(rng.next()<.5?L.gainDown:L.gainUp),L.gainMin,L.gainMax);
    else if(b.kind===KIND.PACED&&u<.84)paceMove(b,rng);
    else voteMove(b,rng);
    /* plastic brain: on top of the ordinary move (whose odds are unchanged), sometimes a learning-gene move */
    if(isPlasticKind(b.kind)&&rng.next()<PLASTIC_MOVE_ODDS)learnMove(b,rng,target());
  }
  if(strong){const extra=Math.max(2,Math.round(count*1.5));for(let z=0;z<extra;z++){const i=target(),x=3*i+Math.floor(rng.next()*3);b.src[x]=newSource(b,i,rng,sensorBias);b.w[x]=[-1,0,1][Math.floor(rng.next()*3)]}}
  return packRig(b);
}
/* plastic brain: a cell's learning rate moves one step (-3..3, through 0 = fixed wiring), or its fade does (0..3) */
function learnMove(b,rng,i){
  if(rng.next()<.7)b.eta[i]=clamp(b.eta[i]+(rng.next()<.5?-1:1),-(LEARN_RATES.length-1),LEARN_RATES.length-1);
  else b.fade[i]=clamp(b.fade[i]+(rng.next()<.5?-1:1),0,LEARN_FADES.length-1);
}
/* muscle brains: the minus muscles take the plus muscles' votes with the sign flipped */
function mirrorMuscles(b){const N=b.N,A=b.A,d=new Int8Array(2*A*N);d.set(b.dec);for(let x=0;x<A*N;x++)d[A*N+x]=-b.dec[x];b.dec=d;b.A=2*A}
/* convert a brain for other joints or another kind:
 *   motors 8 -> 16: reciprocal muscle pairs (exactly the servo brain's behaviour);
 *   motors 16 -> 8: the plus muscles' votes (co-contraction is lost);
 *   kind ternary -> plastic: every learning rate 0 (identical behaviour);
 *   kind plastic -> ternary: the learning genes are dropped.
 * Other kinds (pulse, paced) keep their kind. */
export function adaptRig(g,{motors=null,kind=null}={}){
  if(!isRigGenome(g))return g;let b=null;const B=view(g);
  if(motors&&motors!==B.A){b=cloneB(B);if(motors===2*B.A)mirrorMuscles(b);else if(2*motors===B.A){b.dec=b.dec.slice(0,motors*b.N);b.A=motors}else return g}
  if(kind!==null&&kind!==(B.kind|0)){
    if(kind===KIND.STRICT_PLASTIC&&(B.kind|0)===KIND.STRICT_FIXED){b=b||cloneB(B);b.kind=KIND.STRICT_PLASTIC;b.eta=new Int8Array(b.N);b.fade=new Int8Array(b.N).fill(1)}
    else if(kind===KIND.STRICT_FIXED&&(B.kind|0)===KIND.STRICT_PLASTIC){b=b||cloneB(B);b.kind=KIND.STRICT_FIXED;delete b.eta;delete b.fade}
    else if(kind===KIND.PLASTIC&&(B.kind|0)===KIND.TERNARY){b=b||cloneB(B);b.kind=KIND.PLASTIC;b.eta=new Int8Array(b.N);b.fade=new Int8Array(b.N).fill(1)}
    else if(kind===KIND.TERNARY&&(B.kind|0)===KIND.PLASTIC){b=b||cloneB(B);b.kind=KIND.TERNARY;delete b.eta;delete b.fade}
  }
  return b?packRig(b):g;
}
/* paced brain: a steady tonic cell starts pacing (any rate, any phase), or a pacemaker's rate moves one step (0 = steady again), or its phase shifts or is redrawn */
function paceMove(b,rng){
  const T=[];for(let i=0;i<b.N;i++)if(b.role[i]===ROLE.TONIC)T.push(i);
  if(!T.length)return voteMove(b,rng);
  const j=pick(rng,T),v=rng.next();
  if(!(b.bias[j]>0)){b.bias[j]=1+Math.floor(rng.next()*PULSE_HZ.length);b.gain[j]=rng.next()}
  else if(v<.4)b.bias[j]=clamp(Math.round(b.bias[j])+(rng.next()<.5?-1:1),0,PULSE_HZ.length);
  else if(v<.8)b.gain[j]=((b.gain[j]+(rng.next()-.5)*.25)%1+1)%1;
  else b.gain[j]=rng.next();
}
function voteMove(b,rng){
  const a=Math.floor(rng.next()*b.A),N=b.N,voters=[],free=[];
  for(let i=0;i<N;i++){if(b.dec[a*N+i])voters.push(i);else if(b.role[i]!==ROLE.INTERNAL)free.push(i)}
  if(!voters.length)return;const u=pick(rng,voters);
  if(rng.next()<.5||!free.length){b.dec[a*N+u]=-b.dec[a*N+u];return}
  const n=pick(rng,free);b.dec[a*N+n]=b.dec[a*N+u];b.dec[a*N+u]=0;
}

/* growth: new cells nobody reads and no motor counts, so the brain behaves
 * exactly as before until later mutations wire them in. The role keeps the
 * internal and tonic shares at or above their targets. */
export function growRig(g,rng,{count=1,internalShare=.5,tonicShare=.08,sensorBias=.5}={}){
  let b=cloneB(view(g));
  for(let c=0;c<count&&b.N<MAX_N;c++){
    const N=b.N,nI=b.role.filter(r=>r===ROLE.INTERNAL).length,nT=b.role.filter(r=>r===ROLE.TONIC).length;
    const role=nI<Math.ceil(internalShare*(N+1))?ROLE.INTERNAL:(tonicShare>0&&nT<Math.round(tonicShare*(N+1)))?ROLE.TONIC:ROLE.IO;
    const nb={...b,N:N+1,role:new Int8Array(N+1),src:new Int32Array(3*(N+1)),w:new Int8Array(3*(N+1)),bias:new Float64Array(N+1),gain:new Float64Array(N+1).fill(T_LIMITS.gainInit),fb:new Float64Array(3*(N+1)),dec:new Int8Array(b.A*(N+1))};
    nb.role.set(b.role);nb.bias.set(b.bias);nb.gain.set(b.gain);nb.fb.set(b.fb);nb.w.set(b.w);
    if(isStrictKind(b.kind))nb.gain.fill(1);
    if(b.eta){nb.eta=new Int8Array(N+1);nb.eta.set(b.eta);nb.fade=new Int8Array(N+1);nb.fade.set(b.fade);nb.fade[N]=1}   // plastic: the new cell does not learn
    for(let x=0;x<3*N;x++){const s=b.src[x];nb.src[x]=s}                       // cell indices are unchanged: the new cell is last
    for(let a=0;a<b.A;a++)for(let i=0;i<N;i++)nb.dec[a*(N+1)+i]=b.dec[a*N+i];
    nb.role[N]=role;if(b.kind===KIND.PULSE){nb.bias[N]=2+Math.floor(rng.next()*3);nb.gain[N]=rng.next()}   // pulse: a new oscillator, 1-2 Hz (a paced brain's new tonic cell is steady, so growth stays neutral)
    for(let k=0;k<3;k++){const x=3*N+k;
      if(role===ROLE.TONIC){nb.src[x]=b.S+N;nb.w[x]=0}
      else{nb.src[x]=role===ROLE.INTERNAL||rng.next()>=sensorBias?b.S+Math.floor(rng.next()*N):pick(rng,LIVE_SENSORS);nb.w[x]=rng.next()<.5?-1:1}}
    b=nb;
  }
  return packRig(b);
}
/* shrink: remove one cell that no motor counts (never a tonic cell, never
 * below the internal share). Exactly neutral when no cell reads it; otherwise
 * its readers' slots are rewired. */
export function shrinkRig(g,rng,{internalShare=.5,sensorBias=.5}={}){
  const b=view(g),N=b.N;if(N<=MIN_N)return null;
  const votes=new Int32Array(N),reads=new Int32Array(N);
  for(let a=0;a<b.A;a++)for(let i=0;i<N;i++)if(b.dec[a*N+i])votes[i]++;
  for(let x=0;x<3*N;x++)if(b.src[x]>=b.S&&b.w[x])reads[b.src[x]-b.S]++;
  const nI=b.role.filter(r=>r===ROLE.INTERNAL).length,keepI=Math.ceil(internalShare*(N-1));
  const cand=[...Array(N).keys()].filter(i=>!votes[i]&&b.role[i]!==ROLE.TONIC&&!(b.role[i]===ROLE.INTERNAL&&nI-1<keepI));
  if(!cand.length)return null;
  const unread=cand.filter(i=>!reads[i]),j=pick(rng,unread.length?unread:cand),S=b.S;
  const nb={...b,N:N-1,role:new Int8Array(N-1),src:new Int32Array(3*(N-1)),w:new Int8Array(3*(N-1)),bias:new Float64Array(N-1),gain:new Float64Array(N-1),fb:new Float64Array(3*(N-1)),dec:new Int8Array(b.A*(N-1))};
  if(b.eta){nb.eta=new Int8Array(N-1);nb.fade=new Int8Array(N-1)}
  let r=0;
  for(let i=0;i<N;i++){if(i===j)continue;nb.role[r]=b.role[i];nb.bias[r]=b.bias[i];nb.gain[r]=b.gain[i];if(b.eta){nb.eta[r]=b.eta[i];nb.fade[r]=b.fade[i]}
    for(let k=0;k<3;k++){let s=b.src[3*i+k];nb.w[3*r+k]=b.w[3*i+k];nb.fb[3*r+k]=b.fb[3*i+k];
      if(s===S+j)s=nb.role[r]===ROLE.INTERNAL||rng.next()>=sensorBias?S+Math.floor(rng.next()*(N-1)):pick(rng,LIVE_SENSORS);else if(s>S+j)s--;
      if(nb.role[r]===ROLE.TONIC)s=S+r;nb.src[3*r+k]=s}
    for(let a=0;a<b.A;a++)nb.dec[a*(N-1)+r]=b.dec[a*N+i];r++}
  for(let x=0;x<3*(N-1);x++)if(nb.src[x]>=S+N-1)nb.src[x]=S+Math.floor(rng.next()*(N-1));
  return packRig(nb);
}
/* crossover: a block of whole cells from a second brain, any size; a cell is
 * taken only where both brains have the same role at that index, and any
 * source past the receiving brain's size is rewired. Votes stay the base's. */
export function crossRig(a,b2,rng){
  if((view(a).kind|0)!==(view(b2).kind|0))return null;   // brains of different kinds never cross
  const A=view(a),B=view(b2),c=cloneB(A),N=A.N,cut=Math.floor(rng.next()*N),len=Math.max(1,Math.floor(N*(.2+rng.next()*.4)));let took=0;
  for(let x=0;x<len;x++){const i=(cut+x)%N;if(i>=B.N||B.role[i]!==A.role[i]||A.role[i]===ROLE.TONIC)continue;took++;
    c.bias[i]=B.bias[i];c.gain[i]=B.gain[i];if(c.eta&&B.eta){c.eta[i]=B.eta[i];c.fade[i]=B.fade[i]}
    for(let k=0;k<3;k++){let s=B.src[3*i+k];if(s>=A.S+N||!allowedSource(A.role[i],s,A.S))s=A.S+Math.floor(rng.next()*N);c.src[3*i+k]=s;c.w[3*i+k]=B.w[3*i+k];c.fb[3*i+k]=B.fb[3*i+k]}}
  return took?packRig(c):null;
}
export function rigDistance(a,b){
  const A=view(a),B=view(b);if(A.N!==B.N||A.V!==B.V||(A.kind|0)!==(B.kind|0))return Infinity;let d=0;
  if(A.kind===KIND.PULSE)for(let i=0;i<A.N;i++)if(A.bias[i]!==B.bias[i])d++;   // pulse: a different base rate counts as a difference
  if(A.kind===KIND.PACED)for(let i=0;i<A.N;i++)if(A.role[i]===ROLE.TONIC&&A.bias[i]!==B.bias[i])d++;   // paced: so does a pacemaker's rate
  if(isPlasticKind(A.kind))for(let i=0;i<A.N;i++)if(A.eta[i]!==B.eta[i]||A.fade[i]!==B.fade[i])d++;   // plastic: so does a learning rate
  if(A.A!==B.A)return Infinity;
  for(let x=0;x<3*A.N;x++){if(A.src[x]!==B.src[x])d++;if(A.w[x]!==B.w[x])d++}
  for(let x=0;x<A.dec.length;x++)if(A.dec[x]!==B.dec[x])d++;
  for(let i=0;i<A.N;i++)if(A.role[i]!==B.role[i])d++;
  return d;
}

// ── the controller ──────────────────────────────────────────────────────────
export function makeRigController(g){
  if((g[6]|0)===KIND.PULSE)return makePulseController(unpackRig(g));
  const b=unpackRig(g),{N,S,A,V,K}=b,src=b.src,w=b.w,bias=b.bias,gain=b.gain,fb=b.fb,role=b.role,zc=T_LIMITS.zClamp;
  const voters=[];for(let a=0;a<A;a++){const u=[],sg=[];for(let i=0;i<N;i++){const v=b.dec[a*N+i];if(v){u.push(i);sg.push(v)}}voters.push({u:Int32Array.from(u),s:Int8Array.from(sg)})}
  const norm=Math.max(3,V*.55),s=new Int8Array(S),input=new Int8Array(S+N),h=new Int8Array(N),out=new Float64Array(A),acc=new Float64Array(A);let t=0;
  /* paced brain: a pacemaker's rate (Hz) and phase; 0 Hz = a steady tonic cell. A ternary brain has none. */
  const paced=b.kind===KIND.PACED,paceHz=Float64Array.from(role,(r,i)=>paced&&r===ROLE.TONIC&&bias[i]>0?PULSE_HZ[clamp(Math.round(bias[i])-1,0,PULSE_HZ.length-1)]:0),pacePh=Float64Array.from(gain,x=>((x%1)+1)%1);
  /* plastic brain: per-cell learning rate and trace fade, a fading activity trace per cell, a hidden counter per wire */
  const strict=isStrictKind(b.kind),plastic=isPlasticKind(b.kind),w0=plastic?w.slice():null;
  const lr=plastic?Float64Array.from(b.eta,(e,i)=>role[i]===ROLE.TONIC?0:Math.sign(e)*LEARN_RATES[Math.min(LEARN_RATES.length-1,Math.abs(e))]):null;
  const fd=plastic?Float64Array.from(b.fade,f=>LEARN_FADES[clamp(f,0,LEARN_FADES.length-1)]):null;
  const learns=plastic&&lr.some(x=>x!==0),tr=plastic?new Float64Array(N):null,hs=plastic?new Float64Array(N):null,cnt=plastic?new Float64Array(3*N):null;let flips=0;
  const control=obs=>{
    encodeTernary(obs,t,s,0);input.set(s,0);acc.fill(0);
    for(let tick=0;tick<K;tick++){
      const sec=(t*K+tick)*.02/K;
      for(let i=0;i<N;i++){
        if(role[i]===ROLE.TONIC){if(paceHz[i]){const v=Math.sin(2*Math.PI*(paceHz[i]*sec+pacePh[i]));h[i]=v>.5?1:v<-.5?-1:0}else h[i]=1;continue}
        let z=strict?0:bias[i];const k0=3*i;
        for(let k=0;k<3;k++){const wk=w[k0+k];if(wk)z+=wk*input[src[k0+k]]}
        if(strict){h[i]=z>0?1:z<0?-1:0}  // NO evolved bias, gain, thresholds or preferences
        else {const zz=z>zc?zc:z<-zc?-zc:z,d=gain[i]*zz/DECT,r0=fb[k0]-d,r1=fb[k0+1],r2=fb[k0+2]+d;
          h[i]=(r0>r1&&r0>=r2)?-1:(r2>r1&&r2>r0)?1:0;}
      }
      input.set(h,S);
      for(let a=0;a<A;a++){const Vv=voters[a];let sum=0;for(let j=0;j<Vv.u.length;j++)sum+=Vv.s[j]*h[Vv.u[j]];acc[a]+=sum}
      if(learns)for(let i=0;i<N;i++)hs[i]+=h[i];
    }
    for(let a=0;a<A;a++)out[a]=Math.tanh(acc[a]/K/norm);t++;
    /* learning, once per 20 ms step: fade each cell's trace toward its mean output this step;
     * then, while the forward-speed sense says the body is moving, grow each learning cell's
     * wire counters by rate x modulator x source activity x cell trace; a counter reaching
     * +1 or -1 steps that weight one notch (staying in -1, 0, +1) and starts again */
    if(learns){
      const m=FWD_SENSOR>=0?s[FWD_SENSOR]:1;
      for(let i=0;i<N;i++){tr[i]=fd[i]*tr[i]+(1-fd[i])*hs[i]/K;hs[i]=0}
      if(m!==0)for(let i=0;i<N;i++){const r=lr[i];if(!r)continue;const post=tr[i];if(post===0)continue;const k0=3*i;
        for(let k=0;k<3;k++){const x=k0+k,sr=src[x],pre=sr<S?s[sr]:tr[sr-S];if(!pre)continue;const c=cnt[x]+r*m*pre*post;
          if(c>=1){if(w[x]<1){w[x]++;flips++}cnt[x]=0}else if(c<=-1){if(w[x]>-1){w[x]--;flips++}cnt[x]=0}else cnt[x]=c}}
    }
    return out;
  };
  const hidden=()=>{const z=new Float64Array(N+S+A);for(let i=0;i<N;i++)z[i]=h[i];for(let i=0;i<S;i++)z[N+i]=s[i];for(let a=0;a<A;a++)z[N+S+a]=out[a];return z};
  return {control,hidden,N,S,A,V,K,stats:plastic?()=>({flips,learning:learns}):undefined,weights:plastic?()=>w.slice():undefined,
    reset(){t=0;input.fill(0);h.fill(0);out.fill(0);s.fill(0);if(plastic){w.set(w0);tr.fill(0);hs.fill(0);cnt.fill(0);flips=0}}};
}

// ── the pulse controller (v10) ──────────────────────────────────────────────
function makePulseController(b){
  const {N,S,A,V,K}=b,src=b.src,w=b.w,role=b.role,dt=.02/K,adv=new Int32Array(7*N);
  for(let i=0;i<N;i++){const hz=PULSE_HZ[clamp(b.bias[i]|0,0,PULSE_HZ.length-1)];for(let d=-3;d<=3;d++)adv[7*i+d+3]=Math.max(1,Math.round(65536*hz*Math.pow(2,d/3)*dt))}
  const voters=[];for(let a=0;a<A;a++){const u=[],sg=[];for(let i=0;i<N;i++){const v=b.dec[a*N+i];if(v){u.push(i);sg.push(v)}}voters.push({u:Int32Array.from(u),s:Int8Array.from(sg)})}
  const norm=Math.max(3,V*.55),s=new Int8Array(S),ph=new Int32Array(N),nx=new Int32Array(N),fired=new Uint8Array(N),fn=new Uint8Array(N),h=new Int8Array(N),out=new Float64Array(A),acc=new Float64Array(A);let t=0;
  const init=()=>{for(let i=0;i<N;i++)ph[i]=Math.floor(((b.gain[i]%1)+1)%1*65536)&0xFFFF;fired.fill(0)};init();
  const control=obs=>{
    encodeTernary(obs,t,s,0);acc.fill(0);
    for(let tick=0;tick<K;tick++){
      for(let i=0;i<N;i++){
        let drive=0,kick=0;
        if(role[i]!==ROLE.TONIC){const k0=3*i;for(let k=0;k<3;k++){const wk=w[k0+k];if(!wk)continue;const sr=src[k0+k];if(sr<S)drive+=wk*s[sr];else if(fired[sr-S])kick+=wk}}
        const raw=ph[i]+adv[7*i+(drive>3?3:drive<-3?-3:drive)+3]+kick*NUDGE[ph[i]>>8];
        fn[i]=raw>=65536?1:0;nx[i]=raw<0?0:raw&0xFFFF;                 // a wrap is one pulse; a nudge never runs the phase backwards past 0
      }
      ph.set(nx);fired.set(fn);
      for(let a=0;a<A;a++){const Vv=voters[a];let sum=0;for(let j=0;j<Vv.u.length;j++)sum+=Vv.s[j]*WAVE[ph[Vv.u[j]]>>8];acc[a]+=sum}
    }
    for(let i=0;i<N;i++){const v=WAVE[ph[i]>>8];h[i]=v>.33?1:v<-.33?-1:0}   // shown on the connectome: the wave's sign
    for(let a=0;a<A;a++)out[a]=Math.tanh(acc[a]/K/norm);t++;
    return out;
  };
  const hidden=()=>{const z=new Float64Array(N+S+A);for(let i=0;i<N;i++)z[i]=h[i];for(let i=0;i<S;i++)z[N+i]=s[i];for(let a=0;a<A;a++)z[N+S+a]=out[a];return z};
  return {control,hidden,N,S,A,V,K,kind:KIND.PULSE,phases:()=>Array.from(ph,x=>x/65536),reset(){t=0;init();h.fill(0);out.fill(0);s.fill(0)}};
}

// ── audit and view ──────────────────────────────────────────────────────────
export function rigAudit(g){
  const b=view(g),N=b.N,S=b.S,errs=[];let live=0,rec=0;const n=[0,0,0];
  for(let i=0;i<N;i++){n[b.role[i]]++;for(let k=0;k<3;k++){const x=3*i+k,s=b.src[x];if(![-1,0,1].includes(b.w[x]))errs.push(`C${i+1} weight`);if(s<0||s>=S+N)errs.push(`C${i+1} source`);
    if(b.role[i]===ROLE.INTERNAL&&s<S)errs.push(`internal C${i+1} reads a sensor`);if(b.w[x]&&b.role[i]!==ROLE.TONIC){live++;if(s>=S)rec++}}}
  for(let a=0;a<b.A;a++){let v=0;for(let i=0;i<N;i++){const d=b.dec[a*N+i];if(d){v++;if(b.role[i]===ROLE.INTERNAL)errs.push(`internal C${i+1} votes`)}}if(v!==b.V)errs.push(`motor ${a+1} has ${v} votes`)}
  if(b.kind===KIND.PULSE)for(let i=0;i<N;i++){if(!Number.isInteger(b.bias[i])||b.bias[i]<0||b.bias[i]>=PULSE_HZ.length)errs.push(`C${i+1} base rate`);if(!(b.gain[i]>=0&&b.gain[i]<=1))errs.push(`C${i+1} phase`)}
  let pace=0;if(b.kind===KIND.PACED)for(let i=0;i<N;i++)if(b.role[i]===ROLE.TONIC){if(!Number.isInteger(b.bias[i])||b.bias[i]<0||b.bias[i]>PULSE_HZ.length)errs.push(`C${i+1} pacemaker rate`);else if(b.bias[i]>0)pace++}
  if(isStrictKind(b.kind))for(let i=0;i<N;i++){
    if(b.bias[i]!==0||b.gain[i]!==1||b.fb[3*i]!==0||b.fb[3*i+1]!==0||b.fb[3*i+2]!==0)
      errs.push(`C${i+1} strict neuron has forbidden firing parameters`);
  }
  let learners=0;if(isPlasticKind(b.kind))for(let i=0;i<N;i++){const e=b.eta[i],f=b.fade[i];if(!Number.isInteger(e)||Math.abs(e)>=LEARN_RATES.length)errs.push(`C${i+1} learning rate`);if(!Number.isInteger(f)||f<0||f>=LEARN_FADES.length)errs.push(`C${i+1} fade`);if(e&&b.role[i]!==ROLE.TONIC)learners++}
  const muscles=b.A===2*T_ACT;
  return {ok:!errs.length,errors:errs,N,K:b.K,V:b.V,io:n[0],internal:n[1],tonic:n[2],live,recurrent:rec,learners,muscles,
    kind:b.kind|0,text:`${errs.length?'FAIL ('+errs.slice(0,3).join('; ')+')':'PASS'} — ${b.kind===KIND.PULSE?'PULSE brain, every cell an oscillator (0.5-4 Hz; sensors set its rate, pulses nudge its phase); ':b.kind===KIND.PACED?`PACED brain, ternary cells with ${pace} pacemaker${pace===1?'':'s'} among the tonic cells; `:isStrictKind(b.kind)?`STRICT ${isPlasticKind(b.kind)?'PLASTIC':'FIXED'}: sign(sum), zero bias/preference, gain 1, ${learners} learning cells; `:b.kind===KIND.PLASTIC?`PLASTIC brain, ternary cells, ${learners} of them learning during a trial; `:''}${N} cells: ${n[0]} sensor-motor, ${n[1]} internal (${Math.round(100*n[1]/N)} %), ${n[2]} tonic; ${b.K} brain ticks per 20 ms step (${(20/b.K).toFixed(1)} ms each); ${live} live slots, ${rec} recurrent; ${b.A} motors${muscles?' (8 muscle pairs)':''} x ${b.V} votes; ${b.kind===KIND.PULSE?'weights in {-1, 0, +1}; each motor the mean of its voters\' waves.':'weights and outputs in {-1, 0, +1}.'}`};
}
export function rigView(g){const b=view(g);return {kind:b.kind|0,learn:isPlasticKind(b.kind)?Array.from(b.eta):null,hz:b.kind===KIND.PULSE?Array.from(b.bias,x=>PULSE_HZ[x|0]):b.kind===KIND.PACED?Array.from(b.bias,(x,i)=>b.role[i]===ROLE.TONIC&&x>0?PULSE_HZ[(x|0)-1]:0):null,N:b.N,S:b.S,A:b.A,V:b.V,K:b.K,P:0,role:Array.from(b.role),src:Array.from(b.src),w:Array.from(b.w),dec:Array.from(b.dec)}}
export function rigConnectome(g){
  const b=view(g),L=[];for(let i=0;i<b.N;i++){L.push(`C${i+1} [${ROLE_NAMES[b.role[i]]}]`+(b.kind===KIND.PULSE?(b.role[i]===ROLE.TONIC?`  pacemaker ${PULSE_HZ[b.bias[i]|0]} Hz`:`  oscillator ${PULSE_HZ[b.bias[i]|0]} Hz`):(b.role[i]===ROLE.TONIC?(b.kind===KIND.PACED&&b.bias[i]>0?`  pacemaker ${PULSE_HZ[(b.bias[i]|0)-1]} Hz, phase ${(((b.gain[i]%1)+1)%1).toFixed(2)}`:'  always +1'):(isPlasticKind(b.kind)&&b.eta[i]?`  learns ${b.eta[i]>0?'+':'-'}${LEARN_RATES[Math.abs(b.eta[i])]} per step (${b.eta[i]>0?'Hebbian':'anti-Hebbian'}), trace fade ${LEARN_FADES[b.fade[i]]}`:''))));
    if(b.role[i]!==ROLE.TONIC)for(let k=0;k<3;k++){const x=3*i+k,s=b.src[x];L.push(`  <- ${s<b.S?'S'+(s+1):'C'+(s-b.S+1)}  ${b.w[x]}`)}}
  const JN=['FL hip','FL knee','FR hip','FR knee','RL hip','RL knee','RR hip','RR knee'],ml=a=>b.A===2*T_ACT?` (${JN[a%T_ACT]} ${a<T_ACT?'+':'-'} muscle)`:'';
  L.push('','MOTOR VOTES');for(let a=0;a<b.A;a++){const v=[];for(let i=0;i<b.N;i++)if(b.dec[a*b.N+i])v.push(`C${i+1}:${b.dec[a*b.N+i]}`);L.push(`M${a+1}${ml(a)}: ${v.join(' ')}`)}
  return L.join('\n');
}
