/* rig/core/safe_write.mjs — v12.2: atomic file writes that survive Windows.
 * On Windows a rename onto an existing file fails (EPERM / EBUSY / EACCES)
 * whenever another program holds it open for a moment: OneDrive syncing the
 * Desktop or Documents folder, Windows Defender scanning a fresh file, the
 * search indexer. The old code then stopped training with an error. Here the
 * rename is retried for up to ~2 s, then the file is copied over instead. */
import fs from 'node:fs';
import path from 'node:path';
const sleep=ms=>{try{Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0,ms)}catch{const t=Date.now();while(Date.now()-t<ms){}}};
const BUSY=new Set(['EPERM','EBUSY','EACCES','ENOTEMPTY','EEXIST']);
export function writeFileAtomic(file,data){
  fs.mkdirSync(path.dirname(file),{recursive:true});
  const tmp=`${file}.tmp-${process.pid}-${Math.random().toString(36).slice(2,8)}`;fs.writeFileSync(tmp,data);
  for(let i=0;i<12;i++){try{fs.renameSync(tmp,file);return file}catch(e){if(!BUSY.has(e.code))throw e;sleep(25*(i+1))}}
  try{fs.copyFileSync(tmp,file)}finally{try{fs.unlinkSync(tmp)}catch{}}
  return file;
}
