import * as THREE from 'three';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
const $=id=>document.getElementById(id),num=(v,d=0)=>Number.isFinite(Number(v))?Number(v):d;
const fx=(v,d)=>Number.isFinite(Number(v))&&v!==null?Number(v).toFixed(d):'—',pct=v=>Number.isFinite(Number(v))&&v!==null?(100*v).toFixed(0)+'%':'—';
let S=null,replay=null,lastReplayId=0,playing=false,frameIx=0,lastFrameT=0,knobsBuilt=false;

// ── settings (grouped like the pendulum lab) ────────────────────────────────
const GROUPS=[
 ['Brain and population',[['compare','Compare fixed vs plastic (based on selected brain family)',0,1,1],['brain','Brain model / comparison family',['ternary','plastic','strictFixed','strictPlastic','paced','pulse']],['joints','Joints',['muscles','servo','torque']],['friction','Friction',['firm','legacy']],['N','Cells',8,2500,8],['voters','Votes per motor',1,24,1],['ticks','Brain ticks / 20 ms step',1,40,1],['internalPct','Internal cells %',0,90,1],['tonicPct','Tonic cells %',0,30,1],['mixedSizes','Mixed sizes (½× to 4×)',0,1,1],['maxCells','Max cells',8,2500,8],['seed','Seed',0,4294967295,1],['founders','Founders',1,128,1],['lambda','Candidates/gen',1,64,1],['immigrants','Immigrants',0,16,1],['immigrantEvery','Immigrants every',1,500,1]]],
 ['Search and mutation strategy',[['basin','Basin search (off = champion climber)',0,1,1],['peaks','Peaks K',1,8,1],['separation','Peaks must differ in',['gait','wiring','both']],['escapePct','Escape probes %',0,50,1],['bandit','Bandit picks mutations, crossover, grow/shrink (and parent when climbing)',0,1,1],['mutations','Mutations/candidate',1,64,1],['strongEvery','Strong jump every',0,500,1],['focus','Mutate read cells %',0,100,1],['sensorBias','Rewire to sensors %',0,100,1],['silenceOdds','Silence odds %',0,100,1],['crossPct','Crossover %',0,100,1]]],
 ['Fitness and cycled curriculum',[['selection','Fitness',['curriculum','distance']],['distanceFloor','Cleanest-walker floor (cm/s)',0,20,0.5],['worstWeight','Worst-trial weight %',0,300,5],['passShare','Advance at % passing',10,100,5],['distanceGens','Gens on distance / cycle',10,5000,10],['earlyExit','Stop fallen trials (1 s)',0,1,1],['trainCases','Training trials',1,32,1],['trainSeconds','Trial seconds',2,20,0.5],['rotate','Rotate trials every',0,500,1],['valCases','Validation trials',4,128,1],['holdCases','Holdout trials',4,128,1],['valEvery','Validate every',1,50,1]]],
 ['Champion feeds and archive',[['poolSize','Champion pool',1,24,1],['threshold','Revisit threshold',5,1000,1],['revisitPct','Parent from champions %',0,100,1],['archivePct','…of those, archive %',0,100,1],['selExp','Selection exponent',.3,8,.1],['bins','Bins per axis',2,10,1],['archiveCap','Archive cap',8,400,1],['poolMinDiff','Min wiring differences',0,200,1],['governor','Plateau governor (KG)',0,1,1],['plateauGens','Plateau after gens',100,100000,100],['trialGens','Trial window gens',100,100000,100]]],
 ['Superneurons (view only — never changes training)',[['snMaxIn','Max inputs',0,12,1],['snMaxOut','Max outputs',1,12,1],['snMinSize','Min cells',2,16,1],['snMaxSize','Max cells',4,64,1],['snIsolation','Min isolation %',0,90,5]]],
 ['The KG and the view',[['tuner','KG tunes settings (switchback tests)',0,1,1],['tunerWindow','KG test window (gens)',100,5000,50],['liveView','Live walker view',0,1,1],['liveEvery','Live replay every (s)',10,600,5],['mapDims','Map dimensions',2,8,1]]],
];
function buildKnobs(){
  const box=$('knobs');box.innerHTML='';const reset=new Set(S.resetKeys||[]);
  for(const [title,items] of GROUPS){
    const h=document.createElement('div');h.className='head';h.textContent=title;box.appendChild(h);
    const row=document.createElement('div');row.className='controls';
    for(const [k,label,min,max,step] of items){
      const l=document.createElement('label');if(reset.has(k))l.className='reset';l.append(label+' ');
      let i;
      if(Array.isArray(min)){i=document.createElement('select');i.innerHTML=min.map(o=>`<option value="${o}">${o}</option>`).join('');i.value=S.cfg[k];i.onchange=()=>cmd('set',{cfg:{[k]:i.value}})}
      else{i=document.createElement('input');if(typeof S.defaults[k]==='boolean'){i.type='checkbox';i.checked=!!S.cfg[k]}else{i.type='number';i.min=min;i.max=max;i.step=step;i.value=S.cfg[k]}
        i.onchange=()=>cmd('set',{cfg:{[k]:i.type==='checkbox'?i.checked:Number(i.value)}})}
      i.id='k_'+k;l.appendChild(i);row.appendChild(l);
    }
    box.appendChild(row);
  }
  knobsBuilt=true;
}

// ── server calls ────────────────────────────────────────────────────────────
async function cmd(c,args={}){
  try{const r=await fetch('/api/cmd',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({cmd:c,args})});const j=await r.json();if(!r.ok)$('status').textContent=j.error||'error';}
  catch(e){$('status').textContent='The rig server is not answering: '+e.message}
  poll();
}
async function poll(){
  try{S=await (await fetch('/api/status',{cache:'no-store'})).json()}catch(e){$('status').textContent='Waiting for the rig server… ('+e.message+')';return}
  if(!knobsBuilt)buildKnobs();
  render();
  if(S.replayId&&S.replayId!==lastReplayId){lastReplayId=S.replayId;loadReplay(await (await fetch('/api/replay',{cache:'no-store'})).json())}
}
setInterval(poll,1000);

function render(){
  $('mode').textContent=S.mode;$('gen').textContent=S.generation;$('nCount').textContent=S.N;$('speed').textContent=fx(S.stepsPerSec/1000,0);
  $('rung').textContent=S.rung?`${S.rung} · ${S.cycle}`:'—';for(const r of ['posture','footfalls','distance'])$('r_'+r).className='rung'+(S.rung===r?' on':'');
  const c=S.champion;$('best').textContent=fx(c?.quality,3);$('bestQ').textContent=fx(c?.meanQ,4);$('slide').textContent=fx(c?.slipCm,1);
  $('cells').textContent=S.archive?.cells.length??0;$('coverage').textContent=S.archive?pct(S.archive.coverage):'0%';
  $('modeBadge').textContent=`${S.mode.toUpperCase()}${S.rung?' • '+S.rung:''}`;$('status').textContent=S.note||'';$('log').textContent=S.log||'';
  if(S.audit)$('auditOut').textContent=S.audit;
  $('championStatus').textContent=c?`Champions: ${S.archive.pool.length} in the pool • top #${c.id} from generation ${c.generation} • ladder ${fx(c.quality,3)} • reward of record ${fx(c.meanQ,5)} m/s • walking trials ${pct(c.walk)} • passes posture ${pct(c.pass?.posture)} footfalls ${pct(c.pass?.footfalls)} distance ${pct(c.pass?.distance)} • pool wiring spread min ${S.archive.spread.min} / mean ${fx(S.archive.spread.mean,0)}`:'Champions: 0';
  if(c&&c.learnFlips>0)$('championStatus').textContent+=` • learning changes ${fx(c.learnFlips,1)} of its wires per trial`;
  if(S.selection==='distance'&&c)$('championStatus').textContent+=` • distance mode: cleanest walker, injury ${fx(c.injury,2)} at ${fx(c.distRate,4)} m/s • farthest brain ${fx(S.farthest?.distRate,4)} m/s, injury ${fx(S.farthest?.injury,2)}`;
  const tr=S.mode==='train';$('pause').disabled=!tr;$('resume').disabled=S.mode!=='paused';$('test').disabled=!S.generation;$('testTop').disabled=!c;$('continue').disabled=!c;$('loadTop').disabled=!c;
  drawHistory();drawArchive();drawSelfTuning();drawCompare();
}
// ── v10.1.0: regular vs plastic ─────────────────────────────────────────────
const ARM_COL=['#53d9ff','#ffd166'];
function drawCompare(){
  const C=S.compare,card=$('compareCard');if(!C?.on){card.style.display='none';return}card.style.display='block';
  const A=C.arms,best=a=>a.champion?.quality??-Infinity;
  A.forEach((a,i)=>{const b=$('show'+i);if(!b)return;b.textContent=`Show ${a.name}`;b.className=i===C.shown?'primary':'';b.onclick=()=>cmd('show',{arm:i})});
  const rows=[['Generation',a=>a.generation,null],['Rung · cycle',a=>`${a.rung} · ${a.cycle}`,null],['Champion',a=>a.champion?`#${a.champion.id} · gen ${a.champion.generation}`:'—',null],
    ['Champion ladder',a=>fx(a.champion?.quality,3),a=>a.champion?.quality],['Walking trials',a=>pct(a.champion?.walk),a=>a.champion?.walk],['Distance passes',a=>pct(a.champion?.pass?.distance),a=>a.champion?.pass?.distance],
    ['Forward cm/s',a=>fx(a.champion?.distRate==null?null:100*a.champion.distRate,1),a=>a.champion?.distRate],['Slide cm (lower is better)',a=>fx(a.champion?.slipCm,1),a=>a.champion?.slipCm==null?null:-a.champion.slipCm],
    ['Cells that learn',a=>a.kind===0||a.kind===4?'— (cannot)':String(a.learners),null],['Wires changed per trial by learning',a=>a.kind===0||a.kind===4?'—':fx(a.champion?.learnFlips,1),null],['Archive cells',a=>a.cells,null],['Physics steps',a=>(a.spent/1e6).toFixed(1)+' M',null]];
  $('compareTable').innerHTML=`<tr><th></th>${A.map((a,i)=>`<th style="color:${ARM_COL[i]}">${a.label}${i===C.shown?' · shown':''}</th>`).join('')}</tr>`+rows.map(([k,f,v])=>{
    const vals=v?A.map(a=>{const x=v(a);return Number.isFinite(x)?x:null}):null,top=vals&&vals.every(x=>x!==null)&&new Set(vals).size>1?Math.max(...vals):null;
    return `<tr><td>${k}</td>${A.map((a,i)=>`<td class="${top!==null&&vals[i]===top?'lead':''}">${f(a)}</td>`).join('')}</tr>`}).join('');
  const [r,p]=A,lr=best(r),lp=best(p);let v='';
  if(!r.champion||!p.champion)v='Waiting for both arms to have a champion.';
  else{const d=lp-lr;v=Math.abs(d)<.005?`Level so far: both champions at ladder ${fx(lr,3)}.`:`${d>0?'Plastic':'Fixed'} leads by ${fx(Math.abs(d),3)} ladder (${fx(Math.max(lr,lp),3)} vs ${fx(Math.min(lr,lp),3)}).`;
    const one=p.learners===1;v+=!p.learners?' The plastic champion does not learn yet (no cell has a learning rate).':(p.champion.learnFlips||0)<.05?` The plastic champion has ${p.learners} ${one?'cell':'cells'} with a learning rate, but ${one?'it changes':'they change'} no wires in its trials.`:` The plastic champion has ${p.learners} learning ${one?'cell':'cells'}; ${one?'it changes':'they change'} ${fx(p.champion.learnFlips,1)} wires per trial.`}
  $('compareVerdict').textContent=v;
  const svg=$('compareChart'),W=640,H=240,pd=30,ns='http://www.w3.org/2000/svg';while(svg.firstChild)svg.removeChild(svg.firstChild);
  const add=(t,a,txt)=>{const e=document.createElementNS(ns,t);for(const [k,x] of Object.entries(a))e.setAttribute(k,x);if(txt!==undefined)e.textContent=txt;svg.appendChild(e);return e};
  add('rect',{x:0,y:0,width:W,height:H,fill:'#081321'});const gmax=Math.max(1,...A.flatMap(a=>a.history.map(h=>h.g))),xg=g=>pd+(W-pd-10)*(g/gmax),yv=v=>H-pd-(Math.max(0,Math.min(3,v))/3)*(H-pd*1.6);
  for(let i=0;i<=3;i++){add('line',{x1:pd,y1:yv(i),x2:W-10,y2:yv(i),stroke:'#1b3048','stroke-dasharray':'4 6'});add('text',{x:8,y:yv(i)+4,fill:'#8fa4bd','font-size':11},String(i))}
  add('text',{x:W-10,y:H-8,fill:'#8fa4bd','font-size':11,'text-anchor':'end'},`generation ${gmax}`);
  A.forEach((a,i)=>{let d='';for(const h of a.history)if(Number.isFinite(h.best))d+=(d?' L ':'M ')+xg(h.g).toFixed(1)+' '+yv(h.best).toFixed(1);if(d)add('path',{d,fill:'none',stroke:ARM_COL[i],'stroke-width':2.4})});
  if(!A.some(a=>a.history.length))add('text',{x:W/2,y:H/2,fill:'#9fb1c8','font-size':13,'text-anchor':'middle'},'No validation samples yet.');
}
function drawSelfTuning(){
  const b=S.bandit,g=S.governor,br=S.brain;
  $('bandit').innerHTML=b?Object.entries(b.dims).map(([d,a])=>`<div class="small" style="margin:4px 0"><b>${d}</b> ${a.map(x=>`<span class="pill">${x.arm}: <b>${(100*x.share).toFixed(0)}%</b> · ${x.wins}/${x.tried} won</span>`).join('')}</div>`).join(''):'<span class="small">Bandit off: the manual settings apply.</span>';
  $('governor').textContent=g?`${g.on?'ON':'OFF'} · a plateau is ${g.plateauGens} generations without a better champion · each trial runs ${g.trialGens}\n${g.trial?`now trying: ${g.trial.label} (since generation ${g.trial.start})`:`watching: champion ${fx(g.bestQ,4)}, last better at generation ${g.since}`}\nledger, wins of tries, kept across runs: ${Object.entries(g.ledger).map(([k,v])=>`${k} ${v.wins}/${v.tries}`).join(' · ')}\n\n${(g.log||[]).slice().reverse().map(x=>`g${x.generation}  ${x.text}`).join('\n')||'No plateau yet.'}`:'Start a run.';
  $('brainRoles').textContent=br?`Current brain: ${S.N} cells — ${br.io} sensor-motor, ${br.internal} internal, ${br.tonic} tonic · ${br.K} brain ticks per 20 ms step (${(20/br.K).toFixed(1)} ms each)${[3,5].includes(br.kind)?` · plastic: ${br.learners} learning cells`:''}${br.muscles?' · 16 motors (8 muscle pairs)':''}${S.frontier?` · basin search: frontier of ${S.frontier.size} brains, peaks of ${S.frontier.peaks.map(p=>p.n).join(' / ')} cells`:S.search==='champions'?' · champion climber':''}`:'';
  const T=S.tuner;$('tunerLog').textContent=T?`${T.pausedForCompare?'PAUSED while comparing (both arms keep identical settings)':T.on?'ON':'OFF'} · one setting at a time, its value against a neighbour, in 4 windows of ${T.windowGens} generations (old, new, new, old), scored per billion physics steps; adopted only if it wins by 10 %
adopted by the KG so far: ${Object.entries(T.adopted||{}).map(([k,v])=>`${k} ${v}`).join(' · ')||'nothing yet'}
now: ${T.current?Object.entries(T.current).map(([k,v])=>`${k} ${v}`).join(' · '):'—'}
${T.experiment?`testing ${T.experiment.setting}: ${T.experiment.old} against ${T.experiment.new} — window ${T.experiment.window} of ${T.experiment.of} (${T.experiment.arm} value) since generation ${T.experiment.since}`:'no test running'}
ledger, wins of tries: ${Object.entries(T.ledger||{}).map(([k,v])=>`${k} ${v.wins}/${v.tries}`).join(' · ')||'empty'}

${(T.log||[]).slice().reverse().map(x=>`g${x.generation}  ${x.text}`).join('\n')}`:'Start a run.';
  $('sizes').textContent=S.sizes?'Archive by size: '+Object.entries(S.sizes).map(([k,v])=>`${k} cells: ${v}`).join(' · '):'';
}

// ── validation history ─────────────────────────────────────────────────────
function drawHistory(){
  const svg=$('history'),W=860,H=260,p=34,ns='http://www.w3.org/2000/svg',h=S.history||[];while(svg.firstChild)svg.removeChild(svg.firstChild);
  const add=(t,a,txt)=>{const e=document.createElementNS(ns,t);for(const [k,v] of Object.entries(a))e.setAttribute(k,v);if(txt!==undefined)e.textContent=txt;svg.appendChild(e);return e};
  add('rect',{x:0,y:0,width:W,height:H,fill:'#081321'});
  const vk=S.selection==='distance'?'far':'curQ',ymax=3,qmax=Math.max(.01,...h.map(x=>num(x[vk],0)))*1.1;
  for(let i=0;i<=3;i++){const y=H-p-(i/3)*(H-p*1.45);add('line',{x1:p,y1:y,x2:W-40,y2:y,stroke:'#1b3048','stroke-dasharray':'4 6'});add('text',{x:6,y:y+4,fill:'#8fa4bd','font-size':11},String(i))}
  add('text',{x:W-38,y:p-6,fill:'#b9a0ff','font-size':10},qmax.toFixed(3));
  if(!h.length){add('text',{x:W/2-95,y:H/2,fill:'#9fb1c8','font-size':14},'No validation samples yet.');$('historyReadout').textContent='No samples yet.';return}
  const xa=i=>p+(W-p-44)*(i/Math.max(1,h.length-1)),ya=v=>H-p-(Math.max(0,Math.min(ymax,v))/ymax)*(H-p*1.45),yq=v=>H-p-(Math.max(0,v)/qmax)*(H-p*1.45);
  const band={posture:'#2b6cb0',footfalls:'#2f9e6b',distance:'#d4a72c'};
  h.forEach((x,i)=>add('rect',{x:xa(i)-1,y:H-p+4,width:Math.max(2,(W-p-44)/h.length),height:6,fill:band[x.rung]||'#334'}));
  for(const [key,col,f] of [['best','#ffd166',ya],['cur','#53d9ff',ya],[vk,'#b9a0ff',yq]]){let d='';h.forEach((x,i)=>{if(x[key]===null||x[key]===undefined)return;d+=(d?' L ':'M ')+xa(i)+' '+f(x[key])});add('path',{d,fill:'none',stroke:col,'stroke-width':2.2})}
  const last=h[h.length-1];$('historyReadout').textContent=`${h.length} samples • generation ${last.g} • best ladder ${fx(last.best,3)} • current ${fx(last.cur,3)} • current reward ${fx(last.curQ,5)} m/s • rung ${last.rung}`;
}

// ── behaviour archive (duty x coordination; number = cadence cells) ────────
function drawArchive(){
  const svg=$('archiveGrid'),W=430,H=330,ns='http://www.w3.org/2000/svg',A=S.archive,b=A?.bins||5;while(svg.firstChild)svg.removeChild(svg.firstChild);
  const add=(t,a,txt)=>{const e=document.createElementNS(ns,t);for(const [k,v] of Object.entries(a))e.setAttribute(k,v);if(txt!==undefined)e.textContent=txt;svg.appendChild(e);return e};
  add('rect',{x:0,y:0,width:W,height:H,fill:'#081321'});const px=56,py=18,pb=52,cw=(W-px-16)/b,ch=(H-py-pb)/b,cells=new Map();let mn=Infinity,mx=-Infinity;
  for(const e of A?.cells||[]){const k=e.cell[0]+'|'+e.cell[1];let c=cells.get(k);if(!c){c={count:0,best:-Infinity,top:null};cells.set(k,c)}c.count++;if(e.q>c.best){c.best=e.q;c.top=e}mn=Math.min(mn,e.q);mx=Math.max(mx,e.q)}
  for(let i=0;i<b;i++)for(let j=0;j<b;j++){const c=cells.get(i+'|'+j),x=px+i*cw,y=py+(b-1-j)*ch,t=c&&mx>mn?(c.best-mn)/(mx-mn):c?1:0;
    const r=add('rect',{x:x+1,y:y+1,width:cw-2,height:ch-2,rx:4,fill:c?`hsl(${(196-150*t).toFixed(0)},82%,${(26+26*t).toFixed(0)}%)`:'#0c1826',stroke:c?'#7fb6dd':'#1b3048'});
    if(c){r.style.cursor='pointer';r.onclick=()=>cmd('test',{which:'champion',id:c.top.id});const tt=document.createElementNS(ns,'title');tt.textContent=`#${c.top.id} ladder ${fx(c.best,3)} — click to replay`;r.appendChild(tt);
      add('text',{x:x+cw/2,y:y+ch/2+4,fill:'#06121d','font-size':Math.min(13,cw*.36),'text-anchor':'middle','font-weight':'700','pointer-events':'none'},String(c.count))}}
  const fr=k=>A?`${(100*A.ranges[k][0]).toFixed(0)} → ${(100*A.ranges[k][1]).toFixed(0)}%`:'';
  add('text',{x:px+b*cw/2,y:H-30,fill:'#9fb1c8','font-size':12,'text-anchor':'middle'},`duty factor  ${fr('duty')}`);
  const yl=add('text',{x:14,y:py+b*ch/2,fill:'#9fb1c8','font-size':12,'text-anchor':'middle'},`coordination (pace → trot)  ${fr('coordination')}`);yl.setAttribute('transform',`rotate(-90 14 ${py+b*ch/2})`);
  add('text',{x:px,y:H-10,fill:'#eaf3ff','font-size':12},`${A?.cells.length??0} cells • ${A?pct(A.coverage):'0%'} coverage • ladder ${mn===Infinity?'—':mn.toFixed(2)} → ${mx===-Infinity?'—':mx.toFixed(2)} • cadence ${fr('cadence')}`);
  const list=$('archiveList'),pool=new Set(A?.pool||[]),top=[...(A?.cells||[])].sort((a,b)=>b.q-a.q).slice(0,14);
  list.innerHTML=top.length?top.map(e=>`<span class="pill" data-id="${e.id}">${pool.has(e.id)?'pool':'cell'} #${e.id} • <b>${fx(e.q,3)}</b> • ${fx(e.meanQ,4)} m/s • duty ${pct(e.desc?.duty)} • coord ${fx(e.desc?.coordination,2)} • cadence ${fx(e.desc?.cadence,2)}</span>`).join(''):'<span class="small">No champions yet.</span>';
  for(const el of list.querySelectorAll('[data-id]'))el.onclick=()=>cmd('test',{which:'champion',id:Number(el.dataset.id)});
}

// ── 3D walker (the lab dashboard's way: capsules from frame body poses) ────
const arena=$('arena');let renderer,scene,camera,orbit,robot=null,bodyMeshes=[],robotSig='';
function makeMat(c){return new THREE.MeshStandardMaterial({color:c,roughness:.38,metalness:.18,emissive:new THREE.Color(c).multiplyScalar(.035)})}
function limb(L,r,c){const g=new THREE.CapsuleGeometry(r,L,7,14);g.rotateX(Math.PI/2);g.translate(0,0,-L/2);const m=new THREE.Mesh(g,makeMat(c));m.castShadow=true;return m}
function initScene(){
  scene=new THREE.Scene();scene.background=new THREE.Color(0x050b10);scene.fog=new THREE.Fog(0x050b10,5,18);
  camera=new THREE.PerspectiveCamera(44,1,.02,80);camera.up.set(0,0,1);camera.position.set(2.4,-3.5,1.55);
  renderer=new THREE.WebGLRenderer({antialias:true});renderer.setPixelRatio(Math.min(2,window.devicePixelRatio||1));renderer.shadowMap.enabled=true;arena.appendChild(renderer.domElement);
  orbit=new OrbitControls(camera,renderer.domElement);orbit.enableDamping=true;orbit.target.set(0,0,.3);
  scene.add(new THREE.HemisphereLight(0x9edbff,0x0b1218,1.4));const dl=new THREE.DirectionalLight(0xffffff,2);dl.position.set(-2,-3,6);dl.castShadow=true;scene.add(dl);
  const floor=new THREE.Mesh(new THREE.PlaneGeometry(60,60),new THREE.MeshStandardMaterial({color:0x0d1b26,roughness:.95}));floor.receiveShadow=true;scene.add(floor);
  const grid=new THREE.GridHelper(60,120,0x29415f,0x15283a);grid.rotation.x=Math.PI/2;grid.position.z=.001;scene.add(grid);
  new ResizeObserver(resize).observe(arena);resize();requestAnimationFrame(tick);
}
function resize(){if(!renderer)return;const w=arena.clientWidth,h=arena.clientHeight;if(!w||!h)return;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix()}
function buildRobot(g){
  const sig=[g.torsoLength,g.torsoWidth,g.torsoHeight,g.thighLength,g.thighRadius,g.shinLength,g.shinRadius,g.footRadius].join(',');if(robot&&sig===robotSig)return;robotSig=sig;
  if(robot)scene.remove(robot);robot=new THREE.Group();bodyMeshes=[];
  const torso=new THREE.Mesh(new THREE.BoxGeometry(g.torsoLength,g.torsoWidth,g.torsoHeight),makeMat(0x83c7ff));torso.castShadow=true;robot.add(torso);bodyMeshes.push(torso);
  const head=new THREE.Mesh(new THREE.SphereGeometry(.025,12,8),makeMat(0xffd166));head.position.set(g.torsoLength/2,0,0);torso.add(head);
  for(let i=0;i<4;i++){const t=limb(g.thighLength,g.thighRadius,0x72edc7);robot.add(t);bodyMeshes.push(t);
    const sh=limb(g.shinLength,g.shinRadius,0x5fc9e8),f=new THREE.Mesh(new THREE.SphereGeometry(g.footRadius,14,10),makeMat(0x8194a0));f.position.set(0,0,-g.shinLength);f.userData.isFoot=true;sh.add(f);robot.add(sh);bodyMeshes.push(sh)}
  scene.add(robot);
}
function applyFrame(fr){
  if(!fr||!bodyMeshes.length)return;
  fr.bodies.forEach((b,i)=>{const m=bodyMeshes[i];if(!m)return;m.position.set(b[0],b[1],b[2]);m.quaternion.set(b[4],b[5],b[6],b[3]);
    const foot=m.children.find(c=>c.userData?.isFoot);if(foot){const k=(i-1)>>1,on=num(fr.contacts?.[k])>.5;foot.material.color.setHex(on?0xffdf55:0x8194a0)}});
  const x=num(fr.x),y=num(fr.bodies?.[0]?.[1]);orbit.target.lerp(new THREE.Vector3(x+.4,y,.25),.08);
  if(playing){camera.position.x+=(x-camera.position.x+2.4)*.035;camera.position.y+=(y-camera.position.y-3.5)*.035}
}
function loadReplay(r){
  if(!r||!r.frames?.length)return;replay=r;frameIx=0;playing=true;buildRobot(r.geometry);$('networkCard').style.display='block';
  $('vizInfo').textContent=`${r.label} · validation case ${r.caseIndex+1}/${r.cases}\nladder ${fx(r.trial.ladder,3)} (${r.trial.rung}) · reward ${fx(r.trial.rewardOfRecord,5)} m/s\nforward ${fx(r.trial.forward==null?null:100*r.trial.forward,1)} cm/s · slide ${fx(r.trial.slipCm,1)} cm · floor contact ${pct(r.trial.floorContact)}${r.trial.learn?`\nlearning changed ${r.trial.learn} wires in this trial`:''}`;
  layout=null;snSel=0;renderSN();
}
function tick(t){
  if(replay&&playing&&t-lastFrameT>40){lastFrameT=t;frameIx=(frameIx+1)%replay.frames.length}
  if(replay){applyFrame(replay.frames[frameIx]);drawBrain()}
  orbit.update();renderer.render(scene,camera);requestAnimationFrame(tick);
}

// ── live connectome (v12.2: scales to 2,500 cells; superneurons on their own islands) ──
const net=$('netview'),nctx=net.getContext('2d');let layout=null,snSel=0;
const GOLD=2.399963229728653,snCol=(id,a=1)=>`hsla(${(id*137.508+20)%360},88%,64%,${a})`,clampN=(x,a,b)=>Math.max(a,Math.min(b,x));
function buildLayout(B){
  const N=B.N,W=net.width,H=net.height,R=Math.min(W,H),cx=W*.5,cy=H*.53,role=B.role||new Array(N).fill(0),SN=B.supers?.groups||[];
  const shown=[...SN].sort((x,y)=>y.size-x.size).slice(0,48),snOf=new Int32Array(N).fill(0),island=new Int32Array(N).fill(0);
  for(const g of SN)for(const i of g.cells)snOf[i]=g.id;for(const g of shown)for(const i of g.cells)island[i]=g.id;
  const pos=new Array(N),dr=shown.length?R*.27:R*.39,ir=R*.355;
  /* islands around a ring between the disc and the motors */
  const isl=[];if(shown.length){let rad=shown.map(g=>9+4.4*Math.sqrt(g.size));const need=rad.reduce((a,r)=>a+2*r+6,0),have=2*Math.PI*ir,k=Math.min(1,have/need);rad=rad.map(r=>r*k);
    let ang=-Math.PI/2;const tot=rad.reduce((a,r)=>a+2*r+6,0),gap=(have-tot)/shown.length;
    shown.forEach((g,n)=>{const r=rad[n],da=(2*r+6+gap)/ir;const a0=ang+da/2;ang+=da;const x=cx+Math.cos(a0)*ir,y=cy+Math.sin(a0)*ir;isl.push({id:g.id,x,y,r,g});
      g.cells.forEach((c,k)=>{const rr=g.size===1?0:(r-5)*Math.sqrt((k+.5)/g.size),t=k*GOLD+a0;pos[c]={x:x+Math.cos(t)*rr,y:y+Math.sin(t)*rr}})})}
  /* the rest: a sunflower disc, tonic core, internal middle, sensor-motor rim */
  const groups=[0,1,2].map(r=>{const ids=[];for(let i=0;i<N;i++)if(!island[i]&&(role[i]||0)===r)ids.push(i);return ids}),tot=Math.max(1,groups[0].length+groups[1].length+groups[2].length),gap=.035;
  let acc=0;const band=[];for(const r of [2,1,0]){const f=groups[r].length/tot,a0=acc;acc+=f;band[r]=[Math.sqrt(a0)*(1-2*gap)+(r===2?0:gap*(r===1?1:2)),Math.sqrt(acc)*(1-2*gap)+gap*(r===2?0:r===1?1:2)]}
  for(const r of [0,1,2]){const ids=groups[r],[f0,f1]=band[r],r0=f0*dr,r1=f1*dr;
    ids.forEach((i,k)=>{const rr=Math.sqrt(r0*r0+(k+.5)/ids.length*(r1*r1-r0*r0)),t=k*GOLD+r*.7;pos[i]={x:cx+Math.cos(t)*rr,y:cy+Math.sin(t)*rr}})}
  /* edges, sorted into ordinary / superneuron-internal / superneuron-boundary */
  const E=[];for(let i=0;i<N;i++)for(let k=0;k<3;k++){const x=3*i+k,s=B.src[x];if(s<B.S)continue;const j=s-B.S,a=snOf[j],c=snOf[i];E.push({x,j,i,cat:a&&a===c?1:a||c?2:0,sn:a&&a===c?a:(c||a)})}
  const nodeR=clampN(dr*1.05/Math.sqrt(Math.max(1,N-shown.reduce((a,g)=>a+g.size,0))),1.4,6);
  layout={N,pos,isl,snOf,island,E,cx,cy,mr:R*.45,nodeR,dr,count:SN.length,shownCount:shown.length};
}
function drawBrain(){
  const B=replay?.brain;if(!B)return;const N=B.N,W=net.width,H=net.height,h=replay.trace?.[Math.min(frameIx,(replay.trace.length||1)-1)]||'';
  const wt=replay.wtrace?.[Math.min(frameIx,(replay.wtrace.length||1)-1)]||null,wOf=x=>wt?(wt[x]==='+'?1:wt[x]==='-'?-1:0):B.w[x];   // a learning brain's wires at this frame
  if(!layout||layout.N!==N)buildLayout(B);const L=layout,P=L.pos,mode=$('edgeMode')?.value||'auto',big=N>400;
  const val=i=>h[i]==='+'?1:h[i]==='-'?-1:0;nctx.clearRect(0,0,W,H);
  let learned=0,learnedSensor=0;if(wt)for(let x=0;x<3*N;x++)if(wOf(x)!==B.w[x]){learned++;if(B.src[x]<B.S)learnedSensor++}
  const dim=snSel?.25:1;
  /* island halos, brighter the more of the superneuron is active */
  for(const I of L.isl){let act=0;for(const c of I.g.cells)if(val(c))act++;const f=act/I.g.size,sel=snSel===I.id;
    nctx.globalAlpha=(snSel&&!sel?.35:1);nctx.fillStyle=snCol(I.id,.07+.22*f);nctx.beginPath();nctx.arc(I.x,I.y,I.r+3,0,7);nctx.fill();
    nctx.lineWidth=sel?3:1.4;nctx.strokeStyle=snCol(I.id,.85);nctx.stroke();nctx.globalAlpha=1}
  /* ordinary wires, batched by sign and activity */
  const showAll=mode==='all'||(mode==='auto'&&N<=600),showSN=mode!=='none';
  if(showAll){const paths={};const key=(w,on)=>(w>0?'p':w<0?'n':'z')+(on?1:0);
    for(const e of L.E){if(e.cat===1)continue;const w=wOf(e.x);if(wt&&w!==B.w[e.x])continue;const k=key(w,val(e.j)!==0);(paths[k]||=new Path2D());const a=P[e.j],b=P[e.i];paths[k].moveTo(a.x,a.y);paths[k].lineTo(b.x,b.y)}
    for(const [k,pth] of Object.entries(paths)){const on=k[1]==='1';nctx.strokeStyle=k[0]==='p'?'#55e58b':k[0]==='n'?'#ff6f7d':'#42546c';nctx.globalAlpha=dim*(k[0]==='z'?.06:big?(on?.16:.035):(on?.7:.2));nctx.lineWidth=on&&!big?1.6:1;nctx.stroke(pth)}}
  /* superneuron wiring: internal in the superneuron's colour, boundary dashed */
  if(showSN)for(const e of L.E){if(e.cat===0)continue;const sel=!snSel||snSel===e.sn,w=wOf(e.x);if(w===0||(wt&&w!==B.w[e.x]))continue;const a=P[e.j],b=P[e.i],on=val(e.j)!==0;
    nctx.strokeStyle=e.cat===1?snCol(e.sn):(w>0?'#55e58b':'#ff6f7d');nctx.globalAlpha=(sel?1:.15)*(e.cat===1?(on?.95:.5):(on?.55:.18));nctx.lineWidth=e.cat===1?(on?2.2:1.3):1;
    if(e.cat===2)nctx.setLineDash([4,4]);nctx.beginPath();nctx.moveTo(a.x,a.y);nctx.lineTo(b.x,b.y);nctx.stroke();nctx.setLineDash([]);
    if(e.cat===1&&on&&sel){const f=(performance.now()/420+e.i*.071)%1;nctx.globalAlpha=.95;nctx.fillStyle=snCol(e.sn);nctx.beginPath();nctx.arc(a.x+(b.x-a.x)*f,a.y+(b.y-a.y)*f,2.2,0,7);nctx.fill()}}
  /* wires changed by learning this trial */
  if(wt){nctx.strokeStyle='#ffd166';nctx.lineWidth=2.4;nctx.globalAlpha=.9;const pth=new Path2D();for(const e of L.E)if(wOf(e.x)!==B.w[e.x]){const a=P[e.j],b=P[e.i];pth.moveTo(a.x,a.y);pth.lineTo(b.x,b.y)}nctx.stroke(pth)}
  /* small-brain pulses on ordinary active wires */
  if(showAll&&N<=200){nctx.globalAlpha=.95*dim;for(const e of L.E){if(e.cat)continue;const w=wOf(e.x);if(!w||!val(e.j))continue;const a=P[e.j],b=P[e.i],f=(performance.now()/420+e.i*.071)%1;nctx.fillStyle=w>0?'#55e58b':'#ff6f7d';nctx.beginPath();nctx.arc(a.x+(b.x-a.x)*f,a.y+(b.y-a.y)*f,2.4,0,7);nctx.fill()}}
  /* motors and their votes */
  nctx.globalAlpha=1;const mr=L.mr,cx=L.cx,cy=L.cy;
  for(let a=0;a<B.A;a++){const ang=-Math.PI/2+(a+.5)*(Math.PI*2/B.A),mx=cx+Math.cos(ang)*mr,my=cy+Math.sin(ang)*mr;let sum=0;
    for(let i=0;i<N;i++){const v=B.dec[a*N+i];if(!v)continue;sum+=v*val(i);const sn=L.snOf[i];nctx.strokeStyle=sn?snCol(sn):v>0?'#55e58b':'#ff6f7d';nctx.globalAlpha=sn?(snSel&&snSel!==sn?.12:.85):.16*dim;nctx.lineWidth=sn?1.6:1;if(sn)nctx.setLineDash([4,4]);nctx.beginPath();nctx.moveTo(P[i].x,P[i].y);nctx.lineTo(mx,my);nctx.stroke();nctx.setLineDash([])}
    nctx.globalAlpha=1;nctx.fillStyle=sum>0?'#55e58b':sum<0?'#ff6f7d':'#52647c';nctx.fillRect(mx-7,my-7,14,14);nctx.fillStyle='#d9e7f7';nctx.font='10px Segoe UI';nctx.fillText('M'+(a+1),mx+9,my+4)}
  /* cells: batched fills by state, rings by role (superneuron members ringed in their colour) */
  const fills=[new Path2D(),new Path2D(),new Path2D()],rings=[new Path2D(),new Path2D(),new Path2D()],r0=L.nodeR;
  for(let i=0;i<N;i++){if(L.island[i])continue;const p=P[i],v=val(i);fills[v+1].moveTo(p.x+r0,p.y);fills[v+1].arc(p.x,p.y,r0,0,7);if(!big){const rr=B.role?.[i]||0;rings[rr].moveTo(p.x+r0,p.y);rings[rr].arc(p.x,p.y,r0,0,7)}}
  nctx.globalAlpha=dim;['#ff6f7d','#52647c','#55e58b'].forEach((c,k)=>{nctx.fillStyle=c;nctx.fill(fills[k])});
  if(!big){nctx.lineWidth=1.6;['#53d9ff','#b9a0ff','#ffd166'].forEach((c,k)=>{nctx.strokeStyle=c;nctx.stroke(rings[k])})}
  nctx.globalAlpha=1;
  for(let i=0;i<N;i++){const sn=L.snOf[i];if(!sn)continue;const p=P[i],v=val(i),inIsl=!!L.island[i],rad=inIsl?4.2:r0+1.5,sel=!snSel||snSel===sn;nctx.globalAlpha=sel?1:.3;
    nctx.fillStyle=v>0?'#55e58b':v<0?'#ff6f7d':'#52647c';nctx.beginPath();nctx.arc(p.x,p.y,rad,0,7);nctx.fill();nctx.lineWidth=1.8;nctx.strokeStyle=snCol(sn);nctx.stroke()}
  nctx.globalAlpha=1;
  for(let i=0;i<N;i++)if(B.learn?.[i]&&!big){const p=P[i];nctx.lineWidth=1;nctx.strokeStyle='#ffffff';nctx.setLineDash([2,2]);nctx.beginPath();nctx.arc(p.x,p.y,r0+3.5,0,7);nctx.stroke();nctx.setLineDash([])}
  if(N<=96){nctx.fillStyle='#d9e7f7';nctx.font='9px Segoe UI';for(let i=0;i<N;i++)nctx.fillText(String(i+1),P[i].x+6,P[i].y+3)}
  for(const I of L.isl){nctx.globalAlpha=snSel&&snSel!==I.id?.4:1;nctx.fillStyle=snCol(I.id);nctx.font='bold 11px Segoe UI';const lx=I.x+(I.x-cx)/ (Math.hypot(I.x-cx,I.y-cy)||1)*(I.r+12)-12,ly=I.y+(I.y-cy)/(Math.hypot(I.x-cx,I.y-cy)||1)*(I.r+12)+4;nctx.fillText('SN'+I.id,lx,ly)}
  nctx.globalAlpha=1;nctx.fillStyle='#eaf3ff';nctx.font='13px Segoe UI';
  const rc=[0,0,0];(B.role||[]).forEach(r=>rc[r]++);
  nctx.fillText(`${N} cells • ${3*N} incoming slots • ${B.src.filter((s,x)=>s>=B.S&&B.w[x]!==0).length} live recurrent • ${B.S} ternary sensors • ${B.A} motors × ${B.V} votes • frame ${frameIx+1}/${replay.frames.length}`,18,24);
  nctx.fillText(`${rc[0]} sensor-motor (rim${big?'':', cyan ring'}) • ${rc[1]} internal (middle${big?'':', violet'}) • ${rc[2]} tonic (centre) • ${B.K||1} ticks per 20 ms step`,18,44);
  const S2=B.supers;nctx.fillStyle='#ffd166';
  nctx.fillText(S2?.groups?`${S2.groups.length} superneuron${S2.groups.length===1?'':'s'} (${S2.summary.cells} cells, ${(100*S2.summary.share).toFixed(1)} %)${L.count>L.shownCount?` • ${L.shownCount} largest on islands, the rest ringed in the disc`:''}${S2.groups.length?' • click an island to isolate it':''}`:'superneurons: not analysed',18,64);
  const nl=(B.learn||[]).filter(x=>x).length;if(nl||wt){nctx.fillStyle='#ffd166';nctx.fillText(`${nl} learning cells${big?'':' (dashed white ring)'} • ${learned} wires changed by learning so far this trial (gold)${learnedSensor?`, ${learnedSensor} of them from sensors (not drawn)`:''}`,18,84)}
  if(B.A===16){nctx.fillStyle='#9fb1c8';nctx.fillText('16 motors = 8 muscle pairs: M1-M8 pull each joint one way, M9-M16 the other way; both on = stiff',18,H-12)}
}
net.onclick=e=>{if(!layout)return;const r=net.getBoundingClientRect(),k=net.width/r.width,x=(e.clientX-r.left)*k,y=(e.clientY-r.top)*k;
  const hit=layout.isl.find(I=>Math.hypot(I.x-x,I.y-y)<=I.r+6);snSel=hit&&snSel!==hit.id?hit.id:0;renderSN()};
/* the superneuron panel: one card per superneuron with its modulation ranges */
const esc=t=>String(t).replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
function renderSN(){
  const box=$('snPanel');if(!box)return;const A=replay?.brain?.supers;
  if(!A){box.innerHTML='<span class="small">No analysis for this brain.</span>';return}
  if(A.error){box.innerHTML=`<span class="small">Analysis failed: ${esc(A.error)}</span>`;return}
  const lim=A.limits,head=`<div class="small" style="margin-bottom:8px">${A.groups.length} superneuron${A.groups.length===1?'':'s'} in this ${A.N}-cell brain (${A.summary.cells} cells, ${(100*A.summary.share).toFixed(1)} %), analysed in ${A.summary.ms} ms. Limits: ≤ ${lim.maxIn} inputs, ≤ ${lim.maxOut} outputs, ${lim.minSize}–${lim.maxSize} cells, isolation ≥ ${lim.minIsolation} (change them under <b>Superneurons</b> in the settings). One tick = ${(20/A.K).toFixed(1)} ms; a motor sees the mean of ${A.K} ticks.${snSel?` <b style="color:${snCol(snSel)}">SN${snSel} isolated — click it again to show all.</b>`:''}</div>`;
  if(!A.groups.length){box.innerHTML=head+'<span class="small">None yet. Newborn wiring is spread evenly, so sealed-off modules have to evolve; check the champion after a long run, or loosen the limits.</span>';return}
  box.innerHTML=head+'<div class="snGrid">'+A.groups.map(g=>{const t=g.transfer||{},per=(t.periods||[]).map(p=>`${p.ticks} ticks (${p.ms} ms ≈ ${p.hz} Hz) ×${p.patterns}`).join(', ');
    const lv=Object.entries(t.levels||{}).map(([k,v])=>`<div>${esc(k)}: <b>${v[0]} … ${v[v.length-1]}</b> <span class="tiny">(${v.length} level${v.length===1?'':'s'})</span></div>`).join('');
    const mt=Object.entries(t.motors||{}).map(([k,v])=>`<div>${esc(k)} push: <b>${v.min} … ${v.max}</b> votes <span class="tiny">(${v.levels} levels, ${v.votes} vote${v.votes===1?'':'s'})</span></div>`).join('');
    return `<div class="snCard${snSel===g.id?' sel':''}" data-sn="${g.id}" style="border-color:${snCol(g.id,.8)}"><div><b style="color:${snCol(g.id)}">SN${g.id}</b> · ${g.size} cells (${g.hidden} hidden) · <b>${g.inputs}</b> in / <b>${g.outputs}</b> out · ${g.wires} internal wires${g.recurrent?' · loop':''} · isolation ${g.isolation}</div>
      <div class="tiny" style="margin:3px 0">${(t.tags||[]).map(x=>`<span class="pill">${esc(x)}</span>`).join('')||''}</div>
      ${t.error?`<div class="tiny">${esc(t.error)}</div>`:t.inputs?`<div class="tiny">in: ${esc(t.inputs.join(', ')||'none')}${t.usedInputs!=null?` · ${t.usedInputs} matter`:''}<br>out: ${esc(t.outputs.join(', '))}</div>
      <div class="tiny">${t.patterns}${t.patterns<t.patternSpace?' sampled':''} input patterns → <b>${t.distinct}</b> responses · ${t.oscillating} oscillate${per?`: ${per}`:''} · ${t.memory} depend on history</div><div class="small" style="margin-top:4px">${lv}${mt}</div>`:'<div class="tiny">structure only (pulse brain)</div>'}</div>`}).join('')+'</div>';
  for(const el of box.querySelectorAll('[data-sn]'))el.onclick=()=>{const id=Number(el.dataset.sn);snSel=snSel===id?0:id;renderSN()};
}

// ── buttons ─────────────────────────────────────────────────────────────────
const on=(id,f)=>{$(id).onclick=f};
on('start',()=>cmd('start',{keep:false}));on('startSave',()=>cmd('startFromSave'));on('continue',()=>cmd('start',{keep:true}));on('pause',()=>cmd('pause'));on('resume',()=>cmd('resume'));on('reset',()=>cmd('reset'));
on('test',()=>cmd('test',{which:'current'}));on('testTop',()=>cmd('test',{which:'champion'}));on('testFar',()=>cmd('test',{which:'farthest'}));on('eval',()=>cmd('eval'));on('play',()=>{playing=!playing});
on('crossval',()=>cmd('crossval'));on('snReport',()=>cmd('superneurons'));on('audit',()=>cmd('audit'));on('rescore',()=>cmd('rescore'));on('revisit',()=>cmd('revisit'));on('loadTop',()=>cmd('loadTop'));on('clearArchive',()=>{if(confirm('Clear the champion pool and the archive?'))cmd('clearArchive')});
on('save',async()=>{await cmd('save');$('ioStatus').textContent=S?.note||'Saved.'});on('load',async()=>{await cmd('load');$('ioStatus').textContent=S?.note||''});
on('biopsy',async()=>{$('status').textContent='Building the biopsy…';const t=await (await fetch('/api/biopsy')).text();try{await navigator.clipboard.writeText(t);$('status').textContent='Biopsy copied.'}catch{$('ioBox').value=t;$('status').textContent='Clipboard unavailable — the biopsy is in the box below.'}});
on('toBox',async()=>{const t=await (await fetch('/api/export')).text();$('ioBox').value=t;$('ioStatus').textContent=`Wrote ${(t.length/1024).toFixed(0)} KB to the box.`});
async function importText(t){const r=await fetch('/api/import',{method:'POST',body:t});const j=await r.json();$('ioStatus').textContent=r.ok?`Loaded ${j.cells} archive cells.`:(j.error||'could not load');poll()}
on('fromBox',()=>importText($('ioBox').value.trim()));
$('file').onchange=async e=>{const f=e.target.files?.[0];if(f)importText(await f.text())};
// ── the fitness landscape (basin search's map) ─────────────────────────────
let LS=null,lsDrawn=[];
async function pollLandscape(){if(!$('lsLive').checked||!S||!S.generation)return;try{LS=await (await fetch('/api/landscape',{cache:'no-store'})).json();drawLandscape()}catch{}}
setInterval(pollLandscape,3000);$('lsMap').onchange=$('lsColor').onchange=$('lsAx').onchange=$('lsAy').onchange=drawLandscape;
function drawLandscape(){
  const c=$('landscape'),g=c.getContext('2d'),W=c.width,H=c.height,pad=44;g.clearRect(0,0,W,H);g.fillStyle='#081321';g.fillRect(0,0,W,H);lsDrawn=[];
  const pts=LS?.points||[];if(!pts.length){g.fillStyle='#9fb1c8';g.font='14px Segoe UI';g.fillText('No map yet — start a run.',W/2-80,H/2);return}
  const geno=$('lsMap').value==='genotype',by=$('lsColor').value,val=p=>by==='sel'?p.sel:p.ladder;
  const nd=LS.dims||2,ax=$('lsAx'),ay=$('lsAy');if(ax.options.length!==nd){const o=[...Array(nd).keys()].map(d=>`<option value="${d}">D${d+1} (${(100*(LS.share?.[d]||0)).toFixed(0)}%)</option>`).join('');ax.innerHTML=o;ay.innerHTML=o;ax.value='0';ay.value='1'}
  else for(const sel of [ax,ay])[...sel.options].forEach((op,d)=>op.textContent=`D${d+1} (${(100*(LS.share?.[d]||0)).toFixed(0)}%)`);
  const dx=Number(ax.value)||0,dy=Number(ay.value)||(nd>1?1:0);
  const X=p=>geno?(p.c?.[dx]??p.x):(p.desc?.duty??NaN),Y=p=>geno?(p.c?.[dy]??p.y):(p.desc?.coordination??NaN),shown=pts.filter(p=>Number.isFinite(X(p))&&Number.isFinite(Y(p)));
  const xs=shown.map(X),ys=shown.map(Y),x0=Math.min(...xs),x1=Math.max(...xs),y0=Math.min(...ys),y1=Math.max(...ys),sx=Math.max(1e-9,x1-x0),sy=Math.max(1e-9,y1-y0);
  const px=v=>pad+(v-x0)/sx*(W-2*pad),py=v=>H-pad-(v-y0)/sy*(H-2*pad);
  const known=shown.filter(p=>Number.isFinite(val(p))),vs=known.map(val),lo=Math.min(...vs),hi=Math.max(...vs),span=Math.max(1e-9,hi-lo);
  const col=(t,a=1)=>`hsla(${(225-180*t).toFixed(0)},78%,${(16+42*t).toFixed(0)}%,${a})`;
  if(known.length){const G=10,P=known.map(p=>[px(X(p)),py(Y(p)),(val(p)-lo)/span]);
    for(let gx=0;gx<W;gx+=G)for(let gy=0;gy<H;gy+=G){let ws=0,v=0;for(const [qx,qy,t] of P){const d2=(qx-gx)**2+(qy-gy)**2+600,w=1/(d2*d2);ws+=w;v+=w*t}g.fillStyle=col(v/ws,.55);g.fillRect(gx,gy,G,G)}}
  const order={elite:0,frontier:1,candidate:2,escape:3,peak:4},kindOf=p=>p.kinds.reduce((a,k)=>order[k]>order[a]?k:a,p.kinds[0]);
  for(const p of [...shown].sort((a,b)=>order[kindOf(a)]-order[kindOf(b)])){const x=px(X(p)),y=py(Y(p)),k=kindOf(p),t=Number.isFinite(val(p))?(val(p)-lo)/span:0;lsDrawn.push({x,y,p});
    g.lineWidth=2;
    if(k==='elite'){g.fillStyle='#8fa4bd';g.fillRect(x-5,y-5,10,10);g.strokeStyle='#06121d';g.strokeRect(x-5,y-5,10,10)}
    else if(k==='candidate'){g.fillStyle='#eaf3ff';g.beginPath();g.arc(x,y,3,0,7);g.fill()}
    else if(k==='escape'){g.fillStyle='#b9a0ff';g.beginPath();g.arc(x,y,5,0,7);g.fill()}
    else if(k==='frontier'){g.fillStyle=col(t);g.beginPath();g.arc(x,y,7,0,7);g.fill();g.strokeStyle='#53d9ff';g.stroke()}
    else{g.fillStyle=col(t);g.beginPath();g.arc(x,y,9,0,7);g.fill();g.strokeStyle='#ffd166';g.lineWidth=3;g.beginPath();g.arc(x,y,13,0,7);g.stroke();g.fillStyle='#ffd166';g.font='bold 13px Segoe UI';g.fillText('#'+(p.peak+1),x+15,y-10)}}
  g.fillStyle='#9fb1c8';g.font='11px Segoe UI';g.fillText(geno?`wiring map, dimension ${dx+1}`:'duty factor',W/2-50,H-12);g.save();g.translate(14,H/2+40);g.rotate(-Math.PI/2);g.fillText(geno?`wiring map, dimension ${dy+1}`:'coordination (pace → trot)',0,0);g.restore();
  const n=k=>pts.filter(p=>p.kinds.includes(k)).length,sizes=[...new Set(pts.filter(p=>p.kinds.includes('peak')).map(p=>p.n))];
  $('lsStatus').textContent=`generation ${LS.generation} · rung ${LS.rung} · ${n('peak')} peaks (${sizes.join(' / ')} cells) · ${n('frontier')} other frontier brains · ${n('candidate')} local candidates · ${n('escape')} escape probes · ${n('elite')} elites · colour ${by==='sel'?`training fitness ${lo.toFixed(3)} → ${hi.toFixed(3)}`:`ladder ${lo.toFixed(3)} → ${hi.toFixed(3)}`}${LS.search!=='basin'?' · champion climber: no frontier':''}`;
}
$('landscape').onclick=e=>{const r=$('landscape').getBoundingClientRect(),sx=$('landscape').width/r.width,x=(e.clientX-r.left)*sx,y=(e.clientY-r.top)*sx;let best=null,bd=18*18;
  for(const q of lsDrawn){const d=(q.x-x)**2+(q.y-y)**2;if(d<bd){bd=d;best=q}}if(best)cmd('test',{which:'landscape',id:best.p.i})};
initScene();poll();
