const $=id=>document.getElementById(id),fmt=(n,d=2)=>Number.isFinite(n)?Number(n).toFixed(d):'—',qty=n=>n>=1e6?(n/1e6).toFixed(2)+'M':n>=1000?(n/1000).toFixed(1)+'k':String(n??0);
let latest=null,working=false,playData=null;
const get=async url=>{const r=await fetch(url,{cache:'no-store'});if(!r.ok)throw Error(await r.text());return r.json()},post=async(cmd,args)=>{const r=await fetch('/api/proto/cmd',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({cmd,args})});const d=await r.json();if(!r.ok)throw Error(d.error||'Command failed');return d.result};
const cfg=()=>{const n=id=>Number($(id).value),b=id=>$(id).checked;return{seed:n('seed'),rounds:n('rounds'),refill:n('refill'),dirs:n('dirs'),starts:n('starts'),seconds:n('seconds'),pool:n('pool'),gate:n('gate'),plastic:b('plastic'),shortcuts:b('shortcuts'),rewiring:b('rewiring'),diversity:b('diversity'),autoFuel:b('autoFuel')}};
const toast=message=>$('status').textContent=message;
const task=async fn=>{if(working)return;working=true;try{const result=await fn();if(result?.events)render(result);else if(result)toast(JSON.stringify(result,null,2));await refresh()}catch(e){toast('ERROR: '+e.message)}finally{working=false}};
const drawChart=d=>{const cv=$('chart'),ctx=cv.getContext('2d'),w=cv.width,h=cv.height;ctx.fillStyle='#071c29';ctx.fillRect(0,0,w,h);let a=d.curve||[];
  if(!a.length){ctx.fillStyle='#9fbbc7';ctx.font='14px sans-serif';ctx.fillText('Validation chart appears after 20 learning rounds.',20,50);return}
  const lo=Math.min(0,...a.map(x=>x.ladder)),hi=Math.max(3,...a.map(x=>x.ladder)),minx=a[0].round,maxx=Math.max(minx+1,a.at(-1).round);ctx.strokeStyle='#314d5c';ctx.lineWidth=1;
  for(let i=0;i<4;i++){const y=20+(h-45)*i/3;ctx.beginPath();ctx.moveTo(38,y);ctx.lineTo(w-10,y);ctx.stroke();ctx.fillStyle='#91b1c0';ctx.font='11px sans-serif';ctx.fillText(fmt(hi-(hi-lo)*i/3,1),3,y+3)}
  ctx.beginPath();for(let i=0;i<a.length;i++){const x=38+(w-50)*(a[i].round-minx)/(maxx-minx),y=h-25-(h-45)*(a[i].ladder-lo)/(hi-lo||1);if(i===0)ctx.moveTo(x,y);else ctx.lineTo(x,y)}ctx.strokeStyle='#66dcb6';ctx.lineWidth=2.5;ctx.stroke();ctx.fillStyle='#a7c2c9';ctx.fillText('validation ladder (0–3) vs learning rounds',40,15)
};
const drawReplay=(data)=>{const canvas=$('replay'),ctx=canvas.getContext('2d');ctx.fillStyle='#071c29';ctx.fillRect(0,0,canvas.width,canvas.height);const frames=data?.frames||[];if(!frames.length){ctx.fillStyle='#bad4d8';ctx.fillText('No replay yet',20,30);return}
  // Recorded root displacement over time, from MuJoCo frames. Not synthetic walking.
  const xs=frames.map(f=>Number(f.x)||0),mn=Math.min(...xs),mx=Math.max(...xs),range=Math.max(.01,mx-mn);ctx.beginPath();xs.forEach((x,i)=>{let px=30+(canvas.width-55)*i/Math.max(1,xs.length-1),py=canvas.height-30-(canvas.height-55)*(x-mn)/range;i?ctx.lineTo(px,py):ctx.moveTo(px,py)});ctx.strokeStyle='#70e0c6';ctx.lineWidth=2;ctx.stroke();ctx.fillStyle='#a7c2c9';ctx.font='12px sans-serif';ctx.fillText('Real MuJoCo replay: recorded forward displacement (m) vs time',18,18);ctx.fillText('Δx = '+fmt(xs.at(-1)-xs[0],3)+' m · '+frames.length+' recorded frames',18,canvas.height-8)
};
function render(d){if(!d)return;latest=d;$('mode').textContent=d.exists?String(d.mode||'ready').toUpperCase():'READY';$('round').textContent=d.round||0;$('steps').textContent=qty(d.spent||0);$('archive').textContent=d.archive?.length||0;$('rewires').textContent=d.rewires||0;$('wins').textContent=d.rewireWins||0;$('rollouts').textContent=qty(d.rollouts||0);$('delta').textContent=fmt(d.lastDelta,3);$('top').textContent=fmt(d.archive?.[0]?.ladder,3);
  const st=d.stage||0;[...$('levels').children].forEach((e,i)=>e.className='level '+(i===st?'on':i<st?'done':''));const total=d.cfg?.rounds||1,pct=100*Math.min(1,(d.round||0)/total);$('bar').style.width=pct+'%';$('percent').textContent=fmt(pct,1)+'%';$('progress').textContent=(d.round||0)+' / '+total+' learning rounds · '+(d.rung||'posture')+' · '+(d.cfg?.autoFuel?'AUTO-REFUEL ON':'manual fuel');
  $('status').textContent=d.error?'Stopped: '+d.error.split('\n')[0]:d.busy?'Learning with real MuJoCo physics; you can pause after the current batch.':d.exists?'Paused / ready. Your champions and continuous weights are preserved.':'Press Start to begin.';
  $('events').textContent=(d.events||[]).slice().reverse().join('\n')||'No training events yet.';
  $('gate').textContent=d.gate?`Gate: round ${d.gate.round}; ${fmt(d.gate.passes?.posture*100,0)}% posture · ${fmt(d.gate.passes?.footfalls*100,0)}% footfalls · ${fmt(d.gate.passes?.distance*100,0)}% distance · held unless threshold passed`:'Gate evaluations begin after the first 20 learning rounds.';
  $('champions').replaceChildren(...(d.archive||[]).map(c=>{const tr=document.createElement('tr');for(const val of [`CH-${c.id}`,['Stand','Footfalls','Distance','Tone'][c.stage]||'—',fmt(c.reward,3),fmt(100*c.passes?.posture,0)+'%',fmt(100*c.passes?.footfalls,0)+'%',fmt(100*c.passes?.distance,0)+'%',c.origin]){const td=document.createElement('td');td.textContent=val;tr.appendChild(td)}return tr}));
  if(!(d.archive||[]).length){$('champions').innerHTML='<tr><td colspan="7">No champions yet. The first validation happens at round 20.</td></tr>'}
  $('benchmark').textContent=d.independent?JSON.stringify(d.independent,null,2):'No independent benchmark yet.';drawChart(d);
  for(const id of ['go','fresh','resume','bench','replayBtn','import','save'])$(id).disabled=!!d.busy;
  $('pause').disabled=!d.busy;
}
async function refresh(){try{render(await get('/api/proto/status'))}catch(e){toast('Cannot reach local server: '+e.message)}}
$('go').onclick=()=>task(()=>post('start'));
$('fresh').onclick=()=>task(()=>post('fresh',cfg()));
$('resume').onclick=()=>task(()=>post('start'));
$('fuel').onclick=()=>task(async()=>{await post('fuel',{amount:Number($('refill').value)});return latest?.busy?await get('/api/proto/status'):post('start')});
$('pause').onclick=()=>task(()=>post('pause'));
$('save').onclick=()=>task(()=>post('save'));
$('autoFuel').onchange=()=>{if(latest?.exists)task(()=>post('autoFuel',{yes:$('autoFuel').checked}))};
$('bench').onclick=()=>task(()=>post('benchmark'));
$('replayBtn').onclick=()=>task(async()=>{const d=await post('replay');playData=d;drawReplay(d);$('replayInfo').textContent='Recorded MuJoCo gait: '+fmt(d.trial?.rate,4)+' m/s · ladder '+fmt(d.trial?.L,3)+' · genuine steps '+(d.row?.gait?.genuineSteps??'—');return null});
$('bx').onclick=async()=>{try{await navigator.clipboard.writeText(await(await fetch('/api/proto/biopsy')).text());toast('Copied continuous connectome and weights to clipboard.')}catch(e){toast('BX copy failed: '+e.message)}};
$('import').onchange=()=>task(async()=>{const f=$('import').files?.[0];if(!f)return null;const r=await fetch('/api/proto/import',{method:'POST',headers:{'Content-Type':'application/json'},body:await f.text()});const d=await r.json();if(!r.ok)throw Error(d.error);return d});
// Initial Start takes currently chosen experimental settings; Resume never resets.
$('go').onclick=()=>task(()=>post(latest?.exists?'start':'fresh',latest?.exists?undefined:cfg()));
drawReplay(null);refresh();setInterval(refresh,1500);
