/* rig/lab.mjs — the Walker Ternary Rig: the pendulum lab v12, on the MuJoCo walker.
 *
 * One method only, as in the pendulum lab: evolution with champions and a
 * MAP-Elites diversity archive. A ternary protoneuron brain (3 incoming slots
 * per cell, weights and outputs in {-1, 0, +1}) drives the quadruped; the
 * training fitness is the lab's cycled rung curriculum scored pendulum-style
 * (rig/plants/walker.mjs). One run at a time; every knob is in the GUI.
 *
 * v10.1.0 COMPARE: with the Compare setting on, one Start runs two arms side by
 * side -- "regular" (ternary brains) and "plastic" (the same brains, able to
 * evolve learning within a trial) -- on the same seed and the same settings,
 * one generation each in turn, each with its own archive, curriculum, bandit and
 * plateau governor. The page shows one arm at a time (Show regular / Show
 * plastic) and a comparison panel; the biopsy reports both. The KG's settings
 * tests pause while comparing, so the two arms keep identical settings.
 */
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import {ChampionRun} from './core/evolve.mjs';
import {Archive} from './core/archive.mjs';
import {mean} from './core/stats.mjs';
import {unpackTernary,ternaryHeader,isTernaryGenome} from '../engine/ternary.mjs';
import {isRigGenome,rigAudit,rigView,rigConnectome,adaptRig,KIND} from './brain.mjs';
import {Bandit} from './core/bandit.mjs';
import {Governor,INTERVENTIONS} from './core/governor.mjs';
import {Tuner,TUNABLE,TUNABLE_LABEL} from './core/tuner.mjs';
import {analyzeSuperneurons,superneuronReport} from './superneuron.mjs';
import {writeFileAtomic} from './core/safe_write.mjs';

export const BUILD='v12.2-strict-ternary-superneurons-20261019';
/* GUI values (percentages as the GUI shows them). Which take effect when:
 * RESET = on the next Start fresh run; the rest apply from the next generation. */
export const DEFAULTS=Object.freeze({
  brain:'ternary',joints:'muscles',friction:'firm',compare:true,N:48,seed:47017,voters:6,ticks:10,internalPct:50,tonicPct:8,mixedSizes:true,founders:24, // RESET: the brain and its first population
  maxCells:192,bandit:true,governor:true,plateauGens:3000,trialGens:1500,               // self-tuning: size cap, bandit, plateau governor
  basin:true,peaks:4,escapePct:30,separation:'both',                                     // basin search (off = the champion climber); what peaks must differ in
  tuner:true,tunerWindow:500,liveView:true,liveEvery:60,mapDims:8,                     // v9.3: the KG tunes settings; live walker view; map dimensions
  snMaxIn:6,snMaxOut:6,snMinSize:3,snMaxSize:32,snIsolation:30,                       // v12.2: what counts as a superneuron (view only; never changes training)
  trainCases:6,trainSeconds:6,valCases:24,holdCases:32,bins:5,                        // RESET: suites and archive geometry
  lambda:20,mutations:2,strongEvery:20,focus:85,sensorBias:50,silenceOdds:10,crossPct:20, // search and mutation strategy
  immigrants:2,immigrantEvery:40,earlyExit:true,
  selection:'curriculum',distanceFloor:1,worstWeight:50,passShare:75,distanceGens:400,rotate:20,valEvery:4,                  // fitness and cycled curriculum
  poolSize:8,threshold:60,revisitPct:35,archivePct:45,selExp:1.8,archiveCap:300,poolMinDiff:8, // champion feeds and archive
});
const RESET_KEYS=new Set(['brain','joints','friction','compare','selection','basin','N','seed','voters','ticks','internalPct','tonicPct','mixedSizes','founders','trainCases','trainSeconds','valCases','holdCases','bins']);
const num=(v,d=0)=>Number.isFinite(Number(v))?Number(v):d;
/* v12.2: superneuron limits from the settings */
export const snOpts=c=>({maxIn:Math.max(0,Math.round(num(c?.snMaxIn,6))),maxOut:Math.max(1,Math.round(num(c?.snMaxOut,6))),minSize:Math.max(2,Math.round(num(c?.snMinSize,3))),maxSize:Math.max(3,Math.round(num(c?.snMaxSize,32))),minIsolation:Math.max(0,Math.min(1,num(c?.snIsolation,30)/100))});
/* v10.0.1: genomes in the biopsy, exact: Float64Array, little-endian, deflate-raw, base64 */
export const encodeGenomeB64=g=>{const f=g instanceof Float64Array?g:Float64Array.from(g);return zlib.deflateRawSync(Buffer.from(f.buffer,f.byteOffset,f.byteLength),{level:9}).toString('base64')};
export const decodeGenomeB64=s=>{const b=zlib.inflateRawSync(Buffer.from(s,'base64'));return new Float64Array(b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength))};
const jointsOfPayload=p=>p?.joints||p?.cfg?.joints||'torque',selectionOfPayload=p=>p?.selection||p?.cfg?.selection||'curriculum';
/* v10.0.2: saves made before firm friction were scored under the Foundry's soft (legacy) friction */
const frictionOfPayload=p=>p?.friction||p?.cfg?.friction||'legacy',frictionLabel=f=>f==='legacy'?'legacy (soft MuJoCo friction: planted feet creep)':'firm (elliptic friction cone, impratio 10: planted feet grip)';

/* v10.1.0: the two arms of a comparison: identical except for the brain's kind */
export const ARMS=Object.freeze([{name:'regular',kind:0,label:'regular (ternary)'},{name:'plastic',kind:3,label:'plastic (learns within a trial)'}]);
export const STRICT_ARMS=Object.freeze([{name:'strict-fixed',kind:KIND.STRICT_FIXED,label:'STRICT fixed · sign(sum)'},{name:'strict-plastic',kind:KIND.STRICT_PLASTIC,label:'STRICT Hebbian · sign(sum)'}]);
const armSpecs=(ui,rc)=>!ui.compare?[{name:'single',kind:rc.brainKind,label:null}]:ui.brain.startsWith('strict')?STRICT_ARMS:ARMS;
const jointsLabel=j=>j==='muscles'?'two muscles per joint (flexor and extensor: the brain sets angle AND stiffness), recomputed every 4 ms physics step':j==='servo'?'joint targets, PD servo every 4 ms physics step':'raw joint torques, held per 20 ms step';
function runCfg(g){
  const N=Math.round(num(g.N,24)),cap=Math.round(num(g.maxCells,192)),joints=g.joints==='torque'?'torque':g.joints==='servo'?'servo':'muscles';
  return {N,brain:'rig',joints,motors:joints==='muscles'?16:8,friction:g.friction==='legacy'?'legacy':'firm',voters:Math.round(num(g.voters,6)),ticks:Math.max(1,Math.round(num(g.ticks,10))),internalShare:num(g.internalPct,50)/100,tonicShare:num(g.tonicPct,8)/100,
    separation:['wiring','gait','both'].includes(g.separation)?g.separation:'gait',
    search:g.basin?'basin':'champions',peaks:Math.max(1,Math.round(num(g.peaks,4))),escapePct:Math.max(0,Math.min(50,num(g.escapePct,20))),
    maxCells:cap,founderSizes:g.mixedSizes?[...new Set([Math.max(8,Math.round(N/2)),N,2*N,4*N].map(x=>Math.min(x,cap)))]:null,bandit:!!g.bandit,
    founders:Math.max(1,Math.round(num(g.founders,1))),
    lambda:Math.max(1,Math.round(num(g.lambda,12))),mutations:Math.max(1,Math.round(num(g.mutations,2))),strongEvery:Math.max(0,Math.round(num(g.strongEvery,20))),
    focus:num(g.focus,85)/100,sensorBias:num(g.sensorBias,50)/100,silenceOdds:num(g.silenceOdds,10)/100,crossPct:num(g.crossPct,20),
    immigrants:Math.max(0,Math.round(num(g.immigrants,0))),immigrantEvery:Math.max(1,Math.round(num(g.immigrantEvery,40))),
    trainEarlyExit:g.earlyExit?{nonfootSeconds:1,mode:'cumulative'}:null,
    brainKind:g.brain==='pulse'?1:g.brain==='paced'?2:g.brain==='plastic'?3:g.brain==='strictFixed'?KIND.STRICT_FIXED:g.brain==='strictPlastic'?KIND.STRICT_PLASTIC:0,selection:g.selection==='distance'?'distance':'curriculum',distanceFloor:num(g.distanceFloor,1)/100,earlyExit:!!g.earlyExit,worstWeight:num(g.worstWeight,50)/100,passShare:num(g.passShare,75)/100,distanceGens:Math.round(num(g.distanceGens,400)),
    trainCases:Math.round(num(g.trainCases,6)),trainSeconds:num(g.trainSeconds,6),valCases:Math.round(num(g.valCases,24)),holdCases:Math.round(num(g.holdCases,32)),
    rotate:Math.round(num(g.rotate,20)),valEvery:Math.max(1,Math.round(num(g.valEvery,4))),
    poolSize:Math.round(num(g.poolSize,8)),threshold:Math.round(num(g.threshold,60)),revisitPct:num(g.revisitPct,35),archivePct:num(g.archivePct,45),selExp:num(g.selExp,1.8),
    bins:Math.round(num(g.bins,5)),archiveCap:Math.round(num(g.archiveCap,125)),poolMinDiff:Math.round(num(g.poolMinDiff,8)),stopWhenSolved:false};
}
const LIVE_RUN_KEYS=['separation','peaks','escapePct','maxCells','lambda','mutations','strongEvery','focus','sensorBias','silenceOdds','crossPct','immigrants','immigrantEvery','trainEarlyExit','worstWeight','passShare','distanceGens','rotate','valEvery','threshold','revisitPct','archivePct','selExp'];

export class Lab{
  constructor({makePlant,dataDir,quiet=false}){
    this.makePlant=makePlant;this.dataDir=dataDir;this.quiet=quiet;fs.mkdirSync(dataDir,{recursive:true});
    this.cfg={...DEFAULTS,...(process.env.RIG_START_STRICT==='1'?{brain:'strictPlastic',compare:true,N:192,maxCells:512,mixedSizes:false,tuner:false,founders:16,lambda:12}: {})};this.mode='idle';this.run=null;this.plant=null;this.looping=false;this.replayCase=0;
    this.lastReplay=null;this.replaySerial=0;this.logText='Ready. One method: evolution with champions, on the MuJoCo walker.';
    this.note='Press Start fresh run.';this.rate={t:Date.now(),spent:0,gens:0,stepsPerSec:0,gensPerMin:0};this.lastSave=Date.now();
  }
  say(s){this.note=s;if(!this.quiet)console.log(`[rig] ${s}`)}
  async ensurePlant(){if(!this.plant)this.plant=await this.makePlant();return this.plant}
  async close(){this.mode=this.mode==='train'?'paused':this.mode;await this.waitIdle();this.autosave(true);await this.plant?.close?.()}
  async waitIdle(){const t=Date.now();while(this.looping&&Date.now()-t<30000)await new Promise(r=>setTimeout(r,50))}

  // ── commands ──────────────────────────────────────────────────────────────
  async command(cmd,args={}){
    const c=this[`cmd_${cmd}`];if(!c)throw new Error(`unknown command ${cmd}`);
    return await c.call(this,args);
  }
  async cmd_set({cfg={}}){
    const changed=[];for(const [k,v] of Object.entries(cfg))if(k in DEFAULTS){this.cfg[k]=typeof DEFAULTS[k]==='boolean'?!!v:typeof DEFAULTS[k]==='string'?String(v):num(v,DEFAULTS[k]);changed.push(k)}
    if(this.tuner)this.tuner.windowGens=Math.round(this.cfg.tunerWindow);
    const rc=runCfg(this.cfg);
    for(const arm of this.allArms()){const run=arm.run;for(const k of LIVE_RUN_KEYS)run.cfg[k]=rc[k];
      run.archive.cap=rc.archiveCap;run.archive.poolMinDiff=rc.poolMinDiff;run.archive.poolSize=rc.poolSize;run.archive.prune();run.archive.derivePool();
      if(this.cfg.bandit&&!run.bandit)run.bandit=new Bandit();if(!this.cfg.bandit)run.bandit=null;
      if(arm.governor){arm.governor.plateauGens=Math.round(this.cfg.plateauGens);arm.governor.trialGens=Math.round(this.cfg.trialGens)}}
    if(changed.some(k=>k.startsWith('sn'))&&this.lastReplay?.genome){this.lastReplay={...this.lastReplay,id:++this.replaySerial,brain:brainView(this.lastReplay.genome,this.cfg)}}
    const later=changed.filter(k=>RESET_KEYS.has(k));
    this.say(later.length?`Applied. ${later.join(', ')} take effect on the next Start fresh run.`:'Search, curriculum and feed settings applied from the next generation.');
    return {ok:true};
  }
  async cmd_start({keep=false}={}){
    await this.pauseAndWait();const plant=await this.ensurePlant(),rc=runCfg(this.cfg);plant.setJoints?.(rc.joints);plant.setFriction?.(rc.friction);
    const old=this.allArms(),ledger=this.loadLedger(),specs=armSpecs(this.cfg,rc),arms=[];
    for(const sp of specs){
      const cfg={...rc,brainKind:sp.kind},src=keep?(old.find(a=>a.name===sp.name)||old[0])?.run:null;let run;
      if(src&&src.archive.cells.size){
        const top=src.archive.best(),g0=this.adaptFor(top.genome,cfg),N=plant.sizeOf(g0);
        run=await new ChampionRun({plant,cfg:{...cfg,N,founders:1},seed:this.cfg.seed>>>0,genome:plant.mutate(g0,src.rng,{strong:true,cfg:{...cfg,N}})}).init();
        const r=this.importPayload(this.exportPayload(src),run);run.foundersDone=true;run.curriculum={rung:'posture',cycle:0,since:0,transitions:[]};run.cfg.rung='posture';
        if((src.cfg.joints||'torque')!==rc.joints||(src.cfg.friction||'legacy')!==rc.friction||r.adapted){this.say(`Rescoring the ${sp.name==='single'?'':sp.name+' arm\'s '}archive for ${rc.joints} joints and ${rc.friction} friction...`);await this.rescoreRun(run)}
      }else run=await new ChampionRun({plant,cfg,seed:this.cfg.seed>>>0}).init();
      arms.push({name:sp.name,kind:sp.kind,label:sp.label,run,governor:new Governor({ledger,plateauGens:Math.round(this.cfg.plateauGens),trialGens:Math.round(this.cfg.trialGens)}),log:''});
    }
    this.setArms(arms);
    this.say(keep?`Continuing from the champions${arms.length>1?' in both arms':''}. Pool and archive stay as parent feeds; the generation counter and the curriculum restart.`
      :`Fresh run from seed ${this.cfg.seed}: ${rc.N} cells, ${rc.founders} founders, ${rc.lambda} candidates per generation, ${rc.joints} joints${arms.length>1?'; comparing '+(this.cfg.brain.startsWith('strict')?'strict fixed and strict plastic':'regular and plastic')+' brains, one generation each in turn':''}. The archive starts empty.`);
    this.tuner=new Tuner({ledger:this.loadJSON('tuner_ledger.json'),windowGens:Math.round(this.cfg.tunerWindow)});if(this.cfg.tuner)for(const a of arms)this.tuner.applyAdopted(a.run);
    this.rate={t:Date.now(),spent:0,gens:0,stepsPerSec:0,gensPerMin:0};
    this.mode='train';this.loop();return {ok:true};
  }
  /* v10.1.0 arms: one entry for a single run, two when comparing. this.run and
   * this.governor always point at the arm the page shows. */
  allArms(){return this.arms||(this.run?[{name:'single',kind:this.run.cfg.brainKind|0,run:this.run,governor:this.governor,log:''}]:[])}
  setArms(arms){if(arms.length>1){this.arms=arms;this.shown=Math.min(this.shown||0,arms.length-1)}else{this.arms=null;this.shown=0}const a=arms[this.shown||0];this.run=a.run;this.governor=a.governor}
  async cmd_show({arm=0}={}){if(!this.arms)throw new Error('Not comparing: there is only one run.');const i=typeof arm==='string'?this.arms.findIndex(a=>a.name===arm):arm|0;
    if(!(i>=0&&i<this.arms.length))throw new Error('no such arm');this.shown=i;this.run=this.arms[i].run;this.governor=this.arms[i].governor;if(this.arms[i].log)this.logText=this.arms[i].log;this.lsCache=null;
    if(this.mode!=='train'&&this.run.archive.best())await this.cmd_test({which:'champion'});   // paused: replay this arm's champion now (training: the live view does it)
    this.say(`Showing the ${this.arms[i].label} arm.${this.mode==='train'?' Training carries on in both.':''}`);return {ok:true}}
  /* convert a genome for a run's joints (8 or 16 motors) and, between ternary and plastic, its brain kind */
  adaptFor(g,cfg){if(!isRigGenome(g))return g;const k=g[6]|0,want=cfg.brainKind|0;
    const oldPair=(k===KIND.TERNARY||k===KIND.PLASTIC)&&(want===KIND.TERNARY||want===KIND.PLASTIC);
    const strictPair=(k===KIND.STRICT_FIXED||k===KIND.STRICT_PLASTIC)&&(want===KIND.STRICT_FIXED||want===KIND.STRICT_PLASTIC);
    return adaptRig(g,{motors:cfg.motors||8,kind:oldPair||strictPair?want:null})}
  async cmd_pause(){if(this.mode==='train'){await this.pauseAndWait();this.say(`Paused at generation ${this.run.generation}. Test the frozen current brain or press Resume.`)}return {ok:true}}
  async cmd_resume(){if(this.run&&this.mode==='paused'){this.mode='train';this.loop();this.say('Resuming. Current brain, champions and generation are preserved.')}return {ok:true}}
  async cmd_reset(){await this.pauseAndWait();this.run=null;this.arms=null;this.shown=0;this.governor=null;this.mode='idle';this.lastReplay=null;this.logText='Reset. Ready for a fresh run.';this.say('Reset complete.');return {ok:true}}
  async pauseAndWait(){if(this.mode==='train')this.mode='paused';await this.waitIdle()}
  needRun(){if(!this.run)throw new Error('Start a run first.')}
  async cmd_test({which='current',id=null,caseIndex=null}={}){
    this.needRun();if(which==='current'&&this.mode==='train')await this.cmd_pause();     // only the frozen current brain needs training paused
    const suite=this.run.suites.val,ix=caseIndex!==null?Math.max(0,Math.min(suite.length-1,caseIndex|0)):(this.replayCase++%suite.length);
    let genome=this.run.current,label='frozen current brain';
    if(which==='landscape'){const g=this.landscapeGenomes?.[id|0];if(!g)throw new Error('that point is no longer on the map');genome=g;label=`map point ${(id|0)+1}`}
    if(which==='farthest'){const f=this.run.farthest;if(!f)throw new Error('No farthest brain yet: it is tracked in distance mode, from the first validation.');genome=f.genome;label=`farthest brain (generation ${f.generation})`}
    if(which==='champion'){const e=id!==null?[...this.run.archive.cells.values()].find(x=>x.id===id):this.run.archive.best();if(!e)throw new Error('no such champion');genome=e.genome;label=`champion #${e.id}`}
    if(this.arms)label=`${this.arms[this.shown].name} arm ${label}`;   // v10.1.0: which arm, when comparing
    this.say(`Recording the ${label} on validation case ${ix+1}/${suite.length}…`);
    const r=await this.plant.replay(genome,suite[ix]);
    this.lastReplay={id:++this.replaySerial,genome,label,caseIndex:ix,cases:suite.length,frames:r.frames,trace:r.trace,wtrace:r.wtrace||null,geometry:r.geometry,
      trial:{ladder:r.trial.L,rung:['posture','footfalls','walking'][r.trial.tier],rewardOfRecord:r.trial.q,speed:r.trial.speed,forward:r.trial.rate,slipCm:100*r.trial.slipM,floorContact:r.trial.contact,pass:r.trial.pass,learn:num(r.learn)},brain:brainView(genome,this.cfg)};
    this.say(`Replay ready: ${label}, validation case ${ix+1}. Ladder ${r.trial.L.toFixed(3)} (${this.lastReplay.trial.rung}), reward of record ${r.trial.q.toFixed(5)} m/s, slide ${(100*r.trial.slipM).toFixed(1)} cm.`);
    return {ok:true,id:this.lastReplay.id};
  }
  async cmd_eval(){
    this.needRun();if(this.mode==='train')await this.cmd_pause();
    const [v,h]=await this.run.score([this.run.current,this.run.current].slice(0,1),this.run.suites.val).then(async a=>[a[0],(await this.run.score([this.run.current],this.run.suites.hold))[0]]);
    this.logText=`ROBUST EVALUATION OF THE CURRENT BRAIN
                         validation (${this.run.suites.val.length})   holdout (${this.run.suites.hold.length})
ladder (mean per trial)  ${v.quality.toFixed(4).padStart(14)}   ${h.quality.toFixed(4).padStart(12)}
reward of record (m/s)   ${v.meanQ.toFixed(5).padStart(14)}   ${h.meanQ.toFixed(5).padStart(12)}
walking / stepping / fallen trials   ${pct(v.tierWalk)}/${pct(v.tierStand)}/${pct(v.tierFall)}   ${pct(h.tierWalk)}/${pct(h.tierStand)}/${pct(h.tierFall)}
passes posture/footfalls/distance    ${pct(v.pass.posture)}/${pct(v.pass.footfalls)}/${pct(v.pass.distance)}   ${pct(h.pass.posture)}/${pct(h.pass.footfalls)}/${pct(h.pass.distance)}
median worst slide (cm)  ${v.slipMedianCm.toFixed(1).padStart(14)}   ${h.slipMedianCm.toFixed(1).padStart(12)}
behaviour: duty ${pct(v.desc.duty)} · coordination ${v.desc.coordination.toFixed(2)} (1 = trot, 0 = pace) · cadence ${v.desc.cadence.toFixed(2)}
Nothing about the brain, the champions or the generation counter was changed.`;
    this.say(`Robust evaluation: ladder ${v.quality.toFixed(3)} on validation, ${h.quality.toFixed(3)} on holdout.`);return {ok:true};
  }
  async cmd_crossval(){
    this.needRun();if(this.mode==='train')await this.cmd_pause();const A=this.run.archive;
    const list=[...new Set([...A.pool,...A.ranked().slice(0,10)])];if(!list.length)throw new Error('No champions yet.');
    const hs=await this.run.score(list.map(e=>e.genome),this.run.suites.hold),top=A.pool[0]||A.best();
    const rows=list.map((e,i)=>({e,h:hs[i],dist:top?A.distance(e.genome,top.genome):0})).sort((a,b)=>b.h.quality-a.h.quality);
    this.logText=`CHAMPION CROSS-VALIDATION — holdout suite, ${this.run.suites.hold.length} unseen scenarios
src   id     val.ladder  hold.ladder  hold.reward  walk%  duty  coord  cadence  dist
${rows.map(r=>`${A.pool.includes(r.e)?'pool':'cell'}  #${String(r.e.id).padEnd(5)} ${r.e.quality.toFixed(3).padStart(10)} ${r.h.quality.toFixed(3).padStart(12)} ${r.h.meanQ.toFixed(5).padStart(12)} ${pct(r.h.tierWalk).padStart(6)} ${pct(r.e.desc.duty).padStart(5)} ${r.e.desc.coordination.toFixed(2).padStart(6)} ${r.e.desc.cadence.toFixed(2).padStart(8)} ${String(Number.isFinite(r.dist)?r.dist:'size').padStart(5)}`).join('\n')}
val.ladder is the score the brain was archived with; hold.ladder is on scenarios it has never seen.
dist = wiring differences from the top pool champion, so a spread means the pool holds different brains.`;
    this.say(`Cross-validation finished on ${rows.length} champions.`);return {ok:true};
  }
  async cmd_audit(){this.needRun();if(isRigGenome(this.run.current)){this.auditText=rigAudit(this.run.current).text;this.say(this.auditText);return {ok:true}}const b=unpackTernary(this.run.current),N=b.N;let live=0,rec=0,ok=true;
    for(let x=0;x<3*N;x++){if(b.w[x]){live++;if(b.src[x]>=b.S)rec++}if(![-1,0,1].includes(b.w[x]))ok=false}
    const votes=[];for(let a=0;a<b.A;a++){let v=0;for(let i=0;i<N;i++)if(b.dec[a*N+i])v++;votes.push(v)}
    this.auditText=`${ok?'PASS':'FAIL'} — ${N} cells, ${3*N} incoming slots (3 each), ${live} live, ${rec} recurrent, ${b.S} ternary sensors, ${b.A} motors with ${votes.join('/')} votes, ${b.P>0?`a clock of period ${b.P} steps (${(b.P*.02).toFixed(2)} s)`:'no clock'}; weights and outputs in {-1, 0, +1}.`;
    this.say(this.auditText);return {ok:true}}
  /* v12.2: the superneuron report for the champion (or the current brain) */
  async cmd_superneurons({which='champion'}={}){this.needRun();const e=this.run.archive.best(),g=which==='current'||!e?this.run.current:e.genome;
    const an=analyzeSuperneurons(g,snOpts(this.cfg));this.logText=`${which==='current'||!e?'CURRENT BRAIN':'CHAMPION #'+e.id}  ${rigAudit(g).text}\n\n${superneuronReport(an)}`;
    this.say(`${an.groups.length} superneuron${an.groups.length===1?'':'s'} in the ${which==='current'||!e?'current brain':'champion'} (${an.summary.cells} of ${an.N} cells), analysed in ${an.summary.ms} ms. Report in the run log.`);return {ok:true}}
  async cmd_revisit(){this.needRun();const A=this.run.archive,e=(Math.random()*100<this.cfg.archivePct?A.pickAny(this.run.rng):null)||A.pickPool(this.run.rng,this.cfg.selExp);
    if(!e)throw new Error('No champion exists yet.');this.run.adopt(this.plant.mutate(e.genome,this.run.rng,{strong:true,cfg:this.run.cfg}));this.run.stagnation=0;
    this.say(`Revisited champion #${e.id}: the current brain is now a strong mutant of it.`);return {ok:true}}
  async cmd_loadTop(){this.needRun();if(this.mode==='train')await this.cmd_pause();const e=this.run.archive.best();if(!e)throw new Error('No champions yet.');
    this.run.adopt(e.genome);this.say(`Champion #${e.id} (generation ${e.generation}, ladder ${e.quality.toFixed(3)}) is now the current brain.`);return {ok:true}}
  async cmd_clearArchive(){this.needRun();const A=this.run.archive;this.run.archive=new Archive({axes:A.axes,ranges:A.initialRanges,bins:A.bins,cap:A.cap,poolSize:A.poolSize,poolMinDiff:A.poolMinDiff,distance:A.distance});
    this.say('Champion pool and behaviour archive cleared. The current brain is untouched.');return {ok:true}}
  async cmd_rescore(){this.needRun();if(this.mode==='train')await this.cmd_pause();const n=await this.rescoreRun(this.run);
    this.say(`Rescored ${n} archive entries under the current settings: ${this.run.archive.cells.size} cells.`);return {ok:true}}
  async rescoreRun(run){const A=run.archive,es=[...A.cells.values()];if(!es.length)return 0;
    const vs=await run.score(es.map(e=>e.genome),run.suites.val);run.archive=new Archive({axes:A.axes,ranges:A.initialRanges,bins:A.bins,cap:A.cap,poolSize:A.poolSize,poolMinDiff:A.poolMinDiff,distance:A.distance});
    const N=run.archive;es.forEach((e,i)=>{if(N.tryAdd({...e,quality:vs[i].quality,record:vs[i].record,guard:vs[i].guard,desc:vs[i].desc,stats:{...(e.stats||{}),...slimStats(vs[i])}})){const c=N.cells.get(N.key(N.binOf(vs[i].desc)));if(c)c.id=e.id}});   // v10.1.0: champions keep their numbers
    N.serial=Math.max(A.serial|0,N.serial,...es.map(e=>e.id|0));N.derivePool();return es.length}
  async cmd_save(){const f=this.autosave(true);this.say(`Saved champions to ${path.relative(process.cwd(),f)}.`);return {ok:true,file:f}}
  async cmd_load(){const f=(this.arms&&this.latestSave(`-${this.arms[this.shown].name}.json`))||this.latestSave();if(!f)throw new Error('No saved champions in the data folder yet.');const r=await this.importMatched(JSON.parse(fs.readFileSync(f,'utf8')));
    this.say(`Loaded champions from ${path.basename(f)}${r.rescored?', rescored for this run':''}.`);return {ok:true}}
  /* v10.0.1: archive scores must match the run's fitness AND joints, so a payload
   * scored under different ones is rescored after loading (training resumes after). */
  async importMatched(p){
    const r=this.importPayload(p),run=this.run,why=[];
    if(r.adapted)why.push(`${r.adapted} brains converted for ${run.cfg.joints} joints${this.arms?' and the '+this.arms[this.shown].name+' arm':''}`);
    if(jointsOfPayload(p)!==(run.cfg.joints||'torque'))why.push(`joints ${jointsOfPayload(p)} -> ${run.cfg.joints||'torque'}`);
    if(frictionOfPayload(p)!==(run.cfg.friction||'legacy'))why.push(`friction ${frictionOfPayload(p)} -> ${run.cfg.friction||'legacy'}`);
    if(selectionOfPayload(p)!==run.cfg.selection)why.push(`fitness ${selectionOfPayload(p)} -> ${run.cfg.selection}`);
    if(why.length){const was=this.mode==='train';this.say(`Rescoring the loaded champions (${why.join(', ')})...`);await this.cmd_rescore();if(was&&this.mode==='paused'){this.mode='train';this.loop()}}
    return {...r,rescored:why.length>0};
  }

  // ── the training loop ─────────────────────────────────────────────────────
  async loop(){
    if(this.looping)return;this.looping=true;let lastYield=Date.now();
    try{
      while(this.mode==='train'&&this.run){
        for(const arm of this.allArms()){if(this.mode!=='train')break;await this.stepArm(arm)}   // v10.1.0: comparing, one generation per arm in turn
        this.maybeLive();
        if(Date.now()-lastYield>100){await new Promise(r=>setImmediate(r));lastYield=Date.now()}
        if(Date.now()-this.lastSave>300000)this.autosave();
      }
    }catch(e){this.mode='paused';this.say(`Training stopped by an error: ${e.message}`);if(!this.quiet)console.error(e)}
    finally{this.looping=false}
  }
  async stepArm(arm){
    const run=arm.run,row=await run.step();if(!row)return;
    this.onRow(row,arm);const gov=arm.governor,comparing=!!this.arms,testing=!comparing&&!!(this.tuner&&this.cfg.tuner&&this.tuner.exp),govOn=!!(gov&&this.cfg.governor);
    if(govOn){const n=gov.log.length;await gov.onRow(run,this.plant,{defer:testing});if(gov.log.length!==n)this.saveLedger(gov)}
    /* v9.3.1: they no longer interrupt each other. A due plateau trial waits
     * for a running settings test; no new test starts during a plateau trial
     * or while one is due. v10.1.0: no settings tests while comparing. */
    if(!comparing&&this.tuner&&this.cfg.tuner&&(this.tuner.exp||!(govOn&&(gov.trial||gov.due(run.generation)))))
      if(this.tuner.onRow(run)!==undefined)this.saveJSON('tuner_ledger.json',{ledger:this.tuner.ledger,adopted:this.tuner.adopted});
  }
  onRow(row,arm=null){
    const now=Date.now(),dt=(now-this.rate.t)/1000,arms=this.allArms(),spent=arms.reduce((a,x)=>a+x.run.spent,0);
    if(dt>5&&(!arm||arm.run===this.run)){this.rate={t:now,spent,gens:this.run.generation,stepsPerSec:(spent-this.rate.spent)/dt,gensPerMin:60*(this.run.generation-this.rate.gens)/dt}}
    const r=arm?arm.run:this.run,gov=arm?arm.governor:this.governor,A=r.archive,cov=A.coverage(),sp=A.spread(),b=A.best(),cur=row.current,C=r.curriculum||{rung:r.cfg.rung,cycle:0};
    const text=`${this.arms&&arm?`${arm.label} arm (comparing; the other arm trains in turn)\n`:''}generation ${r.generation}   rung ${C.rung} (cycle ${C.cycle})   ${r.cfg.lambda} candidates x ${r.cfg.trainCases} trials, ${r.cfg.mutations} mutations each
current (validation): ladder ${fx(cur?.quality,3)} · reward of record ${fx(cur?.meanQ,5)} m/s · passes posture ${pct(cur?.pass?.posture)} footfalls ${pct(cur?.pass?.footfalls)} distance ${pct(cur?.pass?.distance)}
best champion #${b?.id??'—'}: ladder ${fx(b?.quality,3)} · reward ${fx(b?.stats?.meanQ,5)} m/s · slide ${fx(b?.stats?.slipMedianCm,1)} cm · from generation ${b?.generation??'—'}
${r.cfg.selection==='distance'?`distance mode: farthest brain ${fx(r.farthest?.val.distRate,4)} m/s (injury ${fx(r.farthest?.val.injury,2)}, from generation ${r.farthest?.generation??'—'}) · cleanest walker #${b?.id??'—'}: injury ${fx(b?.stats?.injury,2)} at ${fx(b?.stats?.distRate,4)} m/s\n`:''}archive: ${cov.cells} of ${cov.total} cells (${(100*cov.frac).toFixed(1)} %) · admissions new ${A.admissions.new} / improved ${A.admissions.improved} / rejected ${A.admissions.rejected}
pool: ${A.pool.length}/${A.poolSize} · wiring spread min ${sp.min} mean ${sp.mean.toFixed(0)} differences${sp.crossSize?` (${sp.crossSize} pairs differ in size)`:''}
improvements by source: ${Object.entries(r.parentWins).filter(([,v])=>v).map(([k,v])=>`${k} ${v}`).join(' · ')||'none yet'}
search: ${r.cfg.search==='basin'?`basin — frontier of ${r.frontier?.length??0} brains, ${r.cfg.peaks} peaks (${(r.lastPeaks||[]).map(x=>x.n+' cells').join(', ')||'—'}), ${r.cfg.escapePct}% escape probes`:'champion climber'}
stagnation ${r.stagnation}/${r.cfg.threshold} · immigrants tried ${r.immigrantsTried} · physics ${fx(this.rate.stepsPerSec/1000,0)}k steps/s · ${fx(this.rate.gensPerMin,0)} generations/min
fitness: rung score per trial, mean + ${fx(r.cfg.worstWeight,2)} x worst · advance at ${pct(r.cfg.passShare)} of validation trials passing · ${r.cfg.distanceGens} generations on distance per cycle
brain: ${isRigGenome(r.current)?rigAudit(r.current).text.replace(/^PASS — /,''):'the lab brain'} · joints ${r.cfg.joints||'torque'} · friction ${r.cfg.friction||'legacy'}${b?.stats&&Number.isFinite(b.stats.learnFlips)&&b.stats.learnFlips>0?` · the champion changes ${fx(b.stats.learnFlips,1)} wires per validation trial by learning`:''}
bandit: ${r.bandit?banditLine(r.bandit):'off (the settings above apply)'}
governor: ${gov&&this.cfg.governor?governorLine(gov,r.generation):'off'}`;
    if(arm)arm.log=text;if(!arm||arm.run===this.run)this.logText=text;
  }
  autosave(force=false){if(!this.run||(!force&&!this.run.archive.cells.size))return null;this.lastSave=Date.now();let shown=null;
    for(const arm of this.allArms()){   // v10.1.0: comparing, each arm saves to its own file
      const f=path.join(this.dataDir,`champions-${this.cfg.seed}-${arm.run.cfg.N}${this.arms?'-'+arm.name:''}.json`);
      writeFileAtomic(f,JSON.stringify(this.exportPayload(arm.run,arm.name)));if(arm.run===this.run)shown=f}
    return shown}
  /* the live walker view: the champion is replayed every liveEvery seconds and
   * whenever a new one appears, while training carries on (one rollout, queued
   * with the training work) */
  maybeLive(){
    if(!this.cfg.liveView||this.liveBusy||!this.run||this.mode!=='train')return;const b=this.run.archive.best();if(!b)return;
    if(!(Date.now()-(this.liveAt||0)>1000*this.cfg.liveEvery||b.id!==this.liveId||(this.shown|0)!==this.liveArm))return;
    this.liveBusy=true;this.liveAt=Date.now();this.liveId=b.id;this.liveArm=this.shown|0;const suite=this.run.suites.val,ix=this.replayCase++%suite.length;
    const armName=this.arms?this.arms[this.shown].name:null;
    this.plant.replay(b.genome,suite[ix]).then(r=>{this.lastReplay={id:++this.replaySerial,genome:b.genome,label:`live: ${armName?armName+' arm ':''}champion #${b.id}`,live:true,caseIndex:ix,cases:suite.length,frames:r.frames,trace:r.trace,wtrace:r.wtrace||null,geometry:r.geometry,
      trial:{ladder:r.trial.L,rung:['posture','footfalls','walking'][r.trial.tier],rewardOfRecord:r.trial.q,speed:r.trial.speed,forward:r.trial.rate,slipCm:100*r.trial.slipM,floorContact:r.trial.contact,pass:r.trial.pass,learn:num(r.learn)},brain:brainView(b.genome,this.cfg)}})
      .catch(()=>{}).finally(()=>{this.liveBusy=false});
  }
  /* start a new run straight from the latest save in the data folder: no
   * founders; the frontier is seeded from the loaded champions */
  async cmd_startFromSave(){
    await this.pauseAndWait();const latest=this.latestSave();if(!latest)throw new Error('No saved champions in the data folder yet. Copy an earlier data folder here first.');
    const plant=await this.ensurePlant(),rc=runCfg(this.cfg);plant.setJoints?.(rc.joints);plant.setFriction?.(rc.friction);
    const ledger=this.loadLedger(),specs=armSpecs(this.cfg,rc),arms=[],used=[];
    for(const sp of specs){
      /* comparing: each arm starts from its own save when there is one, otherwise both from the latest save */
      const f=sp.name!=='single'?(this.latestSave(`-${sp.name}.json`)||latest):latest,p=JSON.parse(fs.readFileSync(f,'utf8')),cfg={...rc,brainKind:sp.kind};used.push(path.basename(f));
      const run=await new ChampionRun({plant,cfg:{...cfg,founders:1},seed:this.cfg.seed>>>0}).init();run.foundersDone=true;
      const r=this.importPayload(p,run);
      if(selectionOfPayload(p)!==rc.selection||jointsOfPayload(p)!==rc.joints||frictionOfPayload(p)!==rc.friction||r.adapted){this.say(`Rescoring the loaded champions${sp.name!=='single'?' for the '+sp.name+' arm':''} under the current fitness, ${rc.joints} joints and ${rc.friction} friction...`);await this.rescoreRun(run)}   // archive scores must match the fitness, the joints and the friction
      const b=run.archive.best();if(b){run.current=b.genome;run.currentTrain=null}
      arms.push({name:sp.name,kind:sp.kind,label:sp.label,run,governor:new Governor({ledger,plateauGens:Math.round(this.cfg.plateauGens),trialGens:Math.round(this.cfg.trialGens)}),log:''});
    }
    this.setArms(arms);
    this.tuner=new Tuner({ledger:this.loadJSON('tuner_ledger.json'),windowGens:Math.round(this.cfg.tunerWindow)});if(this.cfg.tuner)for(const a of arms)this.tuner.applyAdopted(a.run);
    this.rate={t:Date.now(),spent:0,gens:0,stepsPerSec:0,gensPerMin:0};this.mode='train';this.loop();
    const b=this.run.archive.best();
    this.say(`Started from ${[...new Set(used)].join(' and ')}: ${this.run.archive.cells.size} archive cells, champion #${b?.id??'—'} (ladder ${fx(b?.quality,3)})${arms.length>1?'; both arms start from these champions':''}. The search continues from them with the current settings.`);return {ok:true};
  }
  loadJSON(name){try{return JSON.parse(fs.readFileSync(path.join(this.dataDir,name),'utf8'))}catch{return null}}
  saveJSON(name,obj){writeFileAtomic(path.join(this.dataDir,name),JSON.stringify(obj,null,1))}
  loadLedger(){try{return JSON.parse(fs.readFileSync(path.join(this.dataDir,'governor_ledger.json'),'utf8'))}catch{return null}}
  saveLedger(gov=this.governor){if(!gov)return;writeFileAtomic(path.join(this.dataDir,'governor_ledger.json'),JSON.stringify(gov.ledger,null,1))}
  latestSave(suffix=''){try{return fs.readdirSync(this.dataDir).filter(f=>/^champions-.*\.json$/.test(f)&&(!suffix||f.endsWith(suffix))).map(f=>path.join(this.dataDir,f)).sort((a,b)=>fs.statSync(b).mtimeMs-fs.statSync(a).mtimeMs)[0]||null}catch{return null}}

  // ── save / load: the archive with packed genomes ────────────────────────
  exportPayload(r=this.run,arm=null){
    if(!r)return {v:9,kind:'walker-ternary-rig',cells:[]};const A=r.archive;
    return {v:9,kind:'walker-ternary-rig',build:BUILD,saved:new Date().toISOString(),cfg:this.cfg,arm:arm||(this.arms?this.arms[this.shown].name:null),brainKind:r.cfg.brainKind|0,joints:r.cfg.joints||'torque',friction:r.cfg.friction||'legacy',selection:r.cfg.selection,generation:r.generation,curriculum:r.curriculum||null,
      axes:A.axes,ranges:A.ranges,initialRanges:A.initialRanges,bins:A.bins,serial:A.serial,poolIds:A.pool.map(e=>e.id),genomeCoding:'f64le-deflate-base64',current64:encodeGenomeB64(r.current),
      cells:[...A.cells.values()].map(e=>({id:e.id,generation:e.generation,quality:e.quality,record:e.record,guard:e.guard,desc:e.desc,stats:e.stats,cell:e.cell,g64:encodeGenomeB64(e.genome)}))};   // v12.2: packed genomes (a 2,500-cell archive as arrays was ~100 MB)
  }
  importPayload(p,r=this.run){
    if(!p||(p.v!==8&&p.v!==9)||!Array.isArray(p.cells))throw new Error('not a Walker Ternary Rig champion payload');
    if(!r)throw new Error('Press Start fresh run (or Reset and Start) before loading, so there is a run to load into.');let adapted=0;
    const A=new Archive({axes:p.axes||r.archive.axes,ranges:p.initialRanges||r.archive.initialRanges,bins:p.bins||r.archive.bins,cap:r.archive.cap,poolSize:r.archive.poolSize,poolMinDiff:r.archive.poolMinDiff,distance:r.archive.distance});
    if(p.ranges)A.ranges=JSON.parse(JSON.stringify(p.ranges));
    for(const e0 of p.cells){const {g64,...e}=e0;let g0;try{g0=g64?decodeGenomeB64(g64):Float64Array.from(e.genome||[])}catch{continue}if(!isTernaryGenome(g0)&&!isRigGenome(g0))continue;const g=this.adaptFor(g0,r.cfg);if(g!==g0)adapted++;   // v10.1.0: converted for the run's joints and arm
      A.cells.set(A.key(e.cell||A.binOf(e.desc)),{...e,genome:g,cell:e.cell||A.binOf(e.desc)})}
    A.serial=Math.max(p.serial|0,...[...A.cells.values()].map(e=>e.id),0);A.prune();
    const byId=new Map([...A.cells.values()].map(e=>[e.id,e]));A.pool=(p.poolIds||[]).map(id=>byId.get(id)).filter(Boolean);if(!A.pool.length)A.derivePool();
    r.archive=A;return {cells:A.cells.size,adapted};
  }

  // ── what the GUI reads ────────────────────────────────────────────────────
  status(){
    const r=this.run,A=r?.archive,cov=A?.coverage(),b=A?.best(),h=r?.history||[],C=r?.curriculum||null;
    return {build:BUILD,mode:this.mode,note:this.note,log:this.logText,audit:this.auditText||null,cfg:this.cfg,defaults:DEFAULTS,resetKeys:[...RESET_KEYS],
      generation:r?.generation??0,joints:r?.cfg.joints??this.cfg.joints,friction:r?.cfg.friction??this.cfg.friction,N:r?this.plant.sizeOf(r.current):this.cfg.N,rung:C?.rung??r?.cfg.rung??null,cycle:C?.cycle??0,transitions:(C?.transitions||[]).slice(-12),
      stagnation:r?.stagnation??0,spent:r?.spent??0,stepsPerSec:this.rate.stepsPerSec,gensPerMin:this.rate.gensPerMin,
      champion:b?{id:b.id,generation:b.generation,quality:b.quality,meanQ:b.stats?.meanQ??null,slipCm:b.stats?.slipMedianCm??null,walk:b.stats?.tierWalk??null,distRate:b.stats?.distRate??null,injury:b.stats?.injury??null,learnFlips:b.stats?.learnFlips??null,pass:b.stats?.pass??null,desc:b.desc}:null,
      compare:this.arms?{on:true,shown:this.shown,arms:this.arms.map(armSummary)}:{on:false},
      current:h.length?h[h.length-1].current:null,
      archive:A?{cells:[...A.cells.values()].map(e=>({id:e.id,n:this.plant.sizeOf(e.genome),cell:e.cell,q:e.quality,meanQ:e.stats?.meanQ??null,desc:e.desc,gen:e.generation})),total:cov.total,coverage:cov.frac,ranges:A.ranges,axes:A.axes,bins:A.bins,admissions:A.admissions,
        pool:A.pool.map(e=>e.id),spread:A.spread()}:null,
      parentWins:r?.parentWins??null,improvements:r?.improvements??0,
      history:h.slice(-240).map(x=>({g:x.generation,best:x.best,bestQ:x.bestMeanQ,cur:x.current?.quality??null,curQ:x.current?.meanQ??null,rung:x.rung,cycle:x.cycle,far:x.far??null})),
      replayId:this.lastReplay?.id??0,
      selection:r?.cfg.selection??this.cfg.selection,farthest:r?.farthest?{generation:r.farthest.generation,...r.farthest.val}:null,
      frontier:r?.frontier?{size:r.frontier.length,peaks:r.lastPeaks||[],rescored:r.rescored||0}:null,tuner:this.tuner?{...this.tuner.snapshot(),on:!!this.cfg.tuner&&!this.arms,pausedForCompare:!!this.arms,current:r?Object.fromEntries(Object.keys(TUNABLE).map(k=>[k,r.cfg[k]])):null}:null,search:r?.cfg.search??(this.cfg.basin?'basin':'champions'),
      bandit:r?.bandit?r.bandit.snapshot():null,governor:this.governor?{...this.governor.snapshot(),on:!!this.cfg.governor,interventions:INTERVENTIONS}:null,
      sizes:A?sizeHistogram(A,this.plant):null,brain:r&&isRigGenome(r.current)?(({io,internal,tonic,K,learners,muscles,kind})=>({io,internal,tonic,K,learners,muscles,kind}))(rigAudit(r.current)):null};
  }
  /* the basin search's map: every brain it holds or just tried, plus the top
   * archive elites, placed by classical multidimensional scaling of their wiring
   * differences (normalised by size; different sizes are kept apart in
   * proportion to how different they are) */
  landscape(){
    const r=this.run;if(!r)return {points:[]};
    if(this.lsCache&&this.lsCache.generation===r.generation&&this.lsCache.dims===this.cfg.mapDims)return this.lsCache.out;   // at most once per generation
    const P=this.plant,pts=[],seen=new Map(),M=r.lastMap;
    const add=(g,o)=>{let p=seen.get(g);if(!p){p={g,n:P.sizeOf(g),kinds:[],sel:null,ladder:null,desc:null,id:null,peak:null};seen.set(g,p);pts.push(p)}
      p.kinds.push(o.kind);if(Number.isFinite(o.sel))p.sel=o.sel;if(Number.isFinite(o.ladder))p.ladder=o.ladder;if(o.desc&&!p.desc)p.desc=o.desc;if(o.id!=null)p.id=o.id;if(o.peak!=null&&o.peak>=0)p.peak=o.peak};
    (r.frontier||[{genome:r.current,train:r.currentTrain}]).forEach(f=>{const k=M?M.peaks.indexOf(f.genome):-1;add(f.genome,{kind:k>=0?'peak':'frontier',sel:f.train?.selection,desc:f.train?.desc,peak:k})});
    if(M){M.peaks.forEach((g,k)=>add(g,{kind:'peak',sel:M.peakInfo[k].sel,desc:M.peakInfo[k].desc,peak:k}));M.cands.forEach(c=>add(c.genome,{kind:c.kind==='escape'?'escape':'candidate',sel:c.sel,desc:c.desc}))}
    r.archive.ranked().slice(0,24).forEach(e=>add(e.genome,{kind:'elite',ladder:e.quality,desc:e.desc,id:e.id}));
    const n=pts.length,D=Array.from({length:n},()=>new Float64Array(n));
    for(let i=0;i<n;i++)for(let j=i+1;j<n;j++){const a=pts[i],b=pts[j];let d=P.distance(a.g,b.g);d=Number.isFinite(d)?d/(15*Math.max(a.n,b.n)):1+.5*Math.abs(Math.log2(a.n/b.n));D[i][j]=D[j][i]=d}
    const k=Math.max(2,Math.min(8,Math.round(this.cfg.mapDims||8))),M2=mdsK(D,k);this.landscapeGenomes=pts.map(p=>p.g);
    const out={generation:r.generation,rung:r.cfg.rung,search:r.cfg.search,dims:k,share:M2.share,points:pts.map((p,i)=>({i,c:M2.coords[i],x:M2.coords[i][0],y:M2.coords[i][1],kinds:p.kinds,n:p.n,sel:p.sel,ladder:p.ladder,desc:p.desc,id:p.id,peak:p.peak}))};
    this.lsCache={generation:r.generation,dims:this.cfg.mapDims,out};return out;
  }
  /* v10.1.0: the comparison, for the biopsy: both arms side by side, their champions' genomes, and the history */
  comparisonLines(){
    if(!this.arms)return [];const S=this.arms.map(armSummary),L=['',`COMPARISON  ${this.arms.map(a=>a.label).join(' vs ')} · same seed (${this.cfg.seed}) and settings, one generation each in turn · showing ${this.arms[this.shown].name} below`,
      'arm, generation, physics steps, rung/cycle, champion, ladder, reward m/s, walking trials, distance passes, forward cm/s, slide cm, learning cells, wire changes per trial by learning'];
    for(const a of S)L.push(`${a.name} g${a.generation} ${a.spent} ${a.rung}/${a.cycle} #${a.champion?.id??'—'} ${fx(a.champion?.quality,4)} ${fx(a.champion?.meanQ,5)} ${pct(a.champion?.walk)} ${pct(a.champion?.pass?.distance)} ${fx(100*(a.champion?.distRate??NaN),1)} ${fx(a.champion?.slipCm,1)} ${a.learners??0} ${fx(a.champion?.learnFlips??0,1)}`);
    L.push('','COMPARISON HISTORY  generation, '+S.map(a=>`${a.name} best ladder`).join(', '));
    const by=new Map();S.forEach((a,k)=>a.history.forEach(h=>{const row=by.get(h.g)||Array(S.length).fill(null);row[k]=h.best;by.set(h.g,row)}));
    const gens=[...by.keys()].sort((x,y)=>x-y),step=Math.max(1,Math.ceil(gens.length/80));gens.filter((g,i)=>i%step===0||i===gens.length-1).forEach(g=>L.push(`${g} ${by.get(g).map(v=>fx(v,4)).join(' ')}`));
    for(const a of this.arms){const b=a.run.archive.best();if(b)L.push('',`${a.name.toUpperCase()} ARM CHAMPION GENOME  #${b.id} (generation ${b.generation}, ladder ${fx(b.quality,4)}, ${b.genome.length} values, same encoding)`,encodeGenomeB64(b.genome))}
    return L;
  }
  biopsy(){
    const s=this.status(),r=this.run;const L=[`WALKER TERNARY RIG BIOPSY ${BUILD}`,`timestamp=${new Date().toISOString()}`,`mode=${s.mode}`,`generation=${s.generation}`,`rung=${s.rung} cycle=${s.cycle}`,
      `cells=${s.N}`,`physicsSteps=${s.spent}`,`joints=${r?.cfg.joints||'torque'} (${jointsLabel(r?.cfg.joints||'torque')})`,`friction=${frictionLabel(r?.cfg.friction||'legacy')}`,
      `rngState=${r?r.rng.rngState>>>0:'—'} seed=${r?.seed??'—'} suiteSeed=${r?.cfg.suiteSeed??'—'} trainEpoch=${r?.epoch??'—'}`,`settings=${JSON.stringify(s.cfg)}`,`champion=${JSON.stringify(s.champion)}`,`selection=${s.selection}`,`farthest=${JSON.stringify(s.farthest)}`,`parentWins=${JSON.stringify(s.parentWins)}`,
      `archiveCells=${s.archive?.cells.length??0}/${s.archive?.total??0}`,`ranges=${JSON.stringify(s.archive?.ranges??null)}`,...this.comparisonLines(),'','CURRICULUM TRANSITIONS',...s.transitions.map(t=>`g${t.generation} ${t.from} -> ${t.to}: ${t.why}`),'','ARCHIVE  cell -> id, ladder, reward, duty, coordination, cadence',
      ...(s.archive?.cells||[]).sort((a,b)=>b.q-a.q).map(e=>`${e.cell.join('/')} -> #${e.id} ${fx(e.q,4)} ${fx(e.meanQ,5)} ${fx(e.desc?.duty,3)} ${fx(e.desc?.coordination,3)} ${fx(e.desc?.cadence,3)}`),
      '','VALIDATION HISTORY  generation, best ladder, best reward, current ladder, current reward, rung',...s.history.map(x=>`${x.g} ${fx(x.best,4)} ${fx(x.bestQ,5)} ${fx(x.cur,4)} ${fx(x.curQ,5)} ${x.rung}`)];
    if(r&&this.governor)L.push('','PLATEAU GOVERNOR (the KG)  ledger '+JSON.stringify(this.governor.ledger),...this.governor.log.slice(-30).map(x=>`g${x.generation} ${x.text}`));
    if(r&&this.tuner){const t=this.tuner.snapshot();L.push('','KG SETTINGS TESTS  live settings: '+Object.keys(TUNABLE).map(k=>`${k} ${r.cfg[k]}`).join(' · '),`ledger ${JSON.stringify(t.ledger)} · adopted ${JSON.stringify(t.adopted)}`,
      ...(t.experiment?[`testing ${t.experiment.setting}: ${t.experiment.old} against ${t.experiment.new}, window ${t.experiment.window} of ${t.experiment.of} (${t.experiment.arm} value) since generation ${t.experiment.since}`]:['no test running']),...t.log.slice(-30).map(x=>`g${x.generation} ${x.text}`))}
    if(r&&r.bandit){const s=r.bandit.snapshot();L.push('','BANDIT  option share, wins/tried',...Object.entries(s.dims).map(([d,a])=>`${d}: ${a.map(x=>`${x.arm} ${(100*x.share).toFixed(0)}% ${x.wins}/${x.tried}`).join('  ')}`))}
    if(r){const b=r.archive.best();
      if(b)L.push('',`CHAMPION GENOME  #${b.id} (generation ${b.generation}, ladder ${fx(b.quality,4)}, ${b.genome.length} values: Float64Array, little-endian, deflate-raw, base64)`,encodeGenomeB64(b.genome));
      L.push('',`CURRENT GENOME  (${r.current.length} values, same encoding)`,encodeGenomeB64(r.current))}
    if(r){const b=r.archive.best();if(b&&isRigGenome(b.genome))L.push('',`CHAMPION #${b.id} `+superneuronReport(analyzeSuperneurons(b.genome,snOpts(this.cfg))))}
    if(r&&isRigGenome(r.current))L.push('','CURRENT BRAIN '+superneuronReport(analyzeSuperneurons(r.current,snOpts(this.cfg))),'','CURRENT BRAIN  '+rigAudit(r.current).text,'',rigConnectome(r.current));
    else if(r){const b=unpackTernary(r.current);L.push('','CURRENT BRAIN CONNECTOME  cell <- source, weight (S = sensor, C = cell)');for(let i=0;i<b.N;i++)for(let k=0;k<3;k++){const x=3*i+k,sc=b.src[x];L.push(`C${i+1} <- ${sc<b.S?'S'+(sc+1):'C'+(sc-b.S+1)}  ${b.w[x]}`)}
      L.push('','MOTOR VOTES');for(let a=0;a<b.A;a++){const v=[];for(let i=0;i<b.N;i++)if(b.dec[a*b.N+i])v.push(`C${i+1}:${b.dec[a*b.N+i]}`);L.push(`M${a+1}: ${v.join(' ')}`)}}
    return L.join('\n');
  }
}
export function brainView(genome,cfg=null){if(isRigGenome(genome)){const v=rigView(genome);try{v.supers=analyzeSuperneurons(genome,snOpts(cfg))}catch(e){v.supers={groups:[],error:String(e.message||e)}}return v}const b=unpackTernary(genome);return {N:b.N,S:b.S,A:b.A,V:b.V,K:1,P:b.P,role:new Array(b.N).fill(0),src:Array.from(b.src),w:Array.from(b.w),dec:Array.from(b.dec)}}
/* classical MDS to 2-D: double-centre the squared distances, take the top two
 * eigenvectors by power iteration with deflation */
/* classical MDS to k dimensions, with each dimension's share of the total spread */
export function mdsK(D,k){
  const n=D.length;if(!n)return {coords:[],share:[]};if(n===1)return {coords:[Array(k).fill(0)],share:Array(k).fill(0)};
  const D2=D.map(r=>Array.from(r,v=>v*v)),rm=D2.map(r=>r.reduce((a,b)=>a+b,0)/n),gm=rm.reduce((a,b)=>a+b,0)/n;
  const B=D2.map((r,i)=>r.map((v,j)=>-.5*(v-rm[i]-rm[j]+gm))),mul=v=>B.map(r=>r.reduce((a,b,j)=>a+b*v[j],0)),vecs=[],vals=[];
  const trace=B.reduce((a,r,i)=>a+Math.max(0,r[i]),0)||1;
  for(let d=0;d<Math.min(k,n);d++){let v=Array.from({length:n},(_,i)=>Math.sin(1.7*i+d+.3));
    for(let it=0;it<150;it++){const w=mul(v);for(const u of vecs){const s=w.reduce((a,b,j)=>a+b*u[j],0);for(let j=0;j<n;j++)w[j]-=s*u[j]}const z=Math.hypot(...w)||1;v=w.map(x=>x/z)}
    vecs.push(v);vals.push(Math.max(0,mul(v).reduce((a,b,j)=>a+b*v[j],0)))}
  while(vecs.length<k){vecs.push(Array(n).fill(0));vals.push(0)}
  return {coords:Array.from({length:n},(_,i)=>vecs.map((v,d)=>v[i]*Math.sqrt(vals[d]))),share:vals.map(l=>l/trace)};
}
export function mds2(D){
  const n=D.length;if(!n)return [];if(n===1)return [[0,0]];
  const D2=D.map(r=>Array.from(r,v=>v*v)),rm=D2.map(r=>r.reduce((a,b)=>a+b,0)/n),gm=rm.reduce((a,b)=>a+b,0)/n;
  const B=D2.map((r,i)=>r.map((v,j)=>-.5*(v-rm[i]-rm[j]+gm))),vecs=[],vals=[],mul=v=>B.map(r=>r.reduce((a,b,j)=>a+b*v[j],0));
  for(let k=0;k<2;k++){let v=Array.from({length:n},(_,i)=>Math.sin(1.7*i+k+.3));
    for(let it=0;it<300;it++){const w=mul(v);for(const u of vecs){const d=w.reduce((a,b,j)=>a+b*u[j],0);for(let j=0;j<n;j++)w[j]-=d*u[j]}const z=Math.hypot(...w)||1;v=w.map(x=>x/z)}
    vecs.push(v);vals.push(Math.max(0,mul(v).reduce((a,b,j)=>a+b*v[j],0)))}
  return Array.from({length:n},(_,i)=>[vecs[0][i]*Math.sqrt(vals[0]),vecs[1][i]*Math.sqrt(vals[1])]);
}
function slimStats(s){const o={};for(const [k,v] of Object.entries(s||{}))if(typeof v==='number'||(v&&typeof v==='object'&&!Array.isArray(v)&&Object.values(v).every(x=>typeof x==='number')))o[k]=v;return o}
/* one arm of a comparison, as the page and the biopsy show it */
function armSummary(a){const r=a.run,b=r.archive.best(),C=r.curriculum||{rung:r.cfg.rung,cycle:0},au=b&&isRigGenome(b.genome)?rigAudit(b.genome):null;
  return {name:a.name,kind:a.kind,label:a.label,generation:r.generation,spent:r.spent,rung:C.rung,cycle:C.cycle,cells:r.archive.cells.size,learners:au?.learners??0,
    champion:b?{id:b.id,generation:b.generation,quality:b.quality,meanQ:b.stats?.meanQ??null,walk:b.stats?.tierWalk??null,distRate:b.stats?.distRate??null,slipCm:b.stats?.slipMedianCm??null,learnFlips:b.stats?.learnFlips??null,pass:b.stats?.pass??null,N:au?.N??null}:null,
    history:(r.history||[]).slice(-400).map(x=>({g:x.generation,best:x.best,cur:x.current?.quality??null}))}}
function sizeHistogram(A,plant){const h={};for(const e of A.cells.values()){const n=plant.sizeOf(e.genome),k=n<16?'8-15':n<32?'16-31':n<64?'32-63':n<128?'64-127':n<256?'128-255':n<512?'256-511':n<1024?'512-1023':'1024+';h[k]=(h[k]||0)+1}return h}
function banditLine(b){const s=b.snapshot().dims;return Object.entries(s).map(([d,a])=>`${d} ${a.map(x=>`${x.arm}:${(100*x.share).toFixed(0)}%`).join(' ')}`).join(' · ')}
function governorLine(g,gen){const s=g.snapshot();return s.trial?`trial "${s.trial.label}" since generation ${s.trial.start}`:`watching: champion ${fx(s.bestQ,4)} last improved at generation ${s.since} (plateau after ${s.plateauGens})`}
const pct=x=>Number.isFinite(x)?`${(100*x).toFixed(0)}%`:'—';
const fx=(x,d)=>Number.isFinite(x)?Number(x).toFixed(d):'—';
