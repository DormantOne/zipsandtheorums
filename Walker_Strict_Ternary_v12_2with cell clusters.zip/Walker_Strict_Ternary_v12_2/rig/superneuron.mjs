/* rig/superneuron.mjs — v12.2: find and characterise SUPERNEURONS in a rig brain.
 *
 * A superneuron is a group of cells that behaves like one bigger neuron:
 *   limited inputs   few distinct sources outside the group feed it
 *                    (sensors or outside cells; tonic cells and the constant
 *                    sensor are constants, not inputs)
 *   limited outputs  few distinct targets outside the group read it
 *                    (outside cells, plus each motor it votes on)
 *   internal work    more wires inside the group than members, and either a
 *                    recurrent loop inside it or at least one hidden member
 *                    (a member that neither hears nor talks to the outside)
 *
 * Detection is purely structural (live wires of the genome, w != 0). From every
 * cell the group is grown greedily, each time adding the neighbour that grows
 * the boundary least, and the best qualifying group along the way is kept; the
 * best non-overlapping groups win.
 *
 * Each superneuron is then run in isolation, exactly as the controller runs it
 * (synchronous ticks, the same firing rule, tonic = +1, inputs held constant
 * through a 20 ms step as the controller holds sensors), for every ternary
 * input pattern (3^inputs, at most 729). Per pattern the group settles into a
 * fixed point or a cycle. From those attractors come its MODULATION RANGES:
 *   levels   the values each output takes, averaged over one control step of
 *            K ticks (what a motor actually sees): a cycle inside the step turns
 *            ternary spikes into graded levels in steps of 1/K
 *   motors   per motor it votes on, the range of its push in vote units
 *   periods  cycle lengths in ticks (and Hz), how many patterns oscillate
 *   memory   patterns whose response depends on the previous input (hysteresis)
 *   used     inputs that change the response at least once
 * Plastic brains are analysed with their genome wiring (learning can change it
 * within a trial); pulse brains get the structure only.
 */
import {ROLE,KIND,unpackRig,isStrictKind,isRigGenome} from './brain.mjs';
import {DECT,T_LIMITS,TERNARY_SENSORS} from '../engine/ternary.mjs';

export const SN_DEFAULTS=Object.freeze({maxIn:6,maxOut:6,minSize:3,maxSize:32,minIsolation:.3});
const CONST_SENSORS=new Set(TERNARY_SENSORS.map((s,i)=>s.kind==='constant'?i:-1).filter(i=>i>=0));
const cache=new WeakMap();
const sensorLabel=s=>`S${s+1} ${TERNARY_SENSORS[s]?.label??''}`.trim();

function graph(b){
  const {N,S,A}=b,ins=Array.from({length:N},()=>[]),outs=Array.from({length:N},()=>[]),sens=Array.from({length:N},()=>[]),votes=Array.from({length:N},()=>[]),self=new Uint8Array(N);
  for(let i=0;i<N;i++){if(b.role[i]===ROLE.TONIC)continue;
    for(let k=0;k<3;k++){const x=3*i+k;if(!b.w[x])continue;const s=b.src[x];
      if(s<S){if(!CONST_SENSORS.has(s))sens[i].push(s);continue}
      const j=s-S;if(b.role[j]===ROLE.TONIC)continue;
      if(j===i){self[i]=1;continue}
      ins[i].push(j);outs[j].push(i)}}
  for(let a=0;a<A;a++)for(let i=0;i<N;i++)if(b.dec[a*N+i])votes[i].push(a);
  return {ins,outs,sens,votes,self};
}
/* boundary of a group (distinct sources and targets) and its internal wiring */
function measure(G,mem,list){
  const inSrc=new Set(),outTgt=new Set();let inLines=0,outLines=0,internal=0,hidden=0;
  for(const i of list){let ext=false;
    for(const s of G.sens[i]){inSrc.add('S'+s);inLines++;ext=true}
    for(const j of G.ins[i]){if(mem[j])internal++;else{inSrc.add('C'+j);inLines++;ext=true}}
    if(G.self[i])internal++;
    for(const j of G.outs[i])if(!mem[j]){outTgt.add('C'+j);outLines++;ext=true}
    for(const a of G.votes[i]){outTgt.add('M'+a);outLines++;ext=true}
    if(!ext)hidden++}
  return {inD:inSrc.size,outD:outTgt.size,inLines,outLines,internal,hidden,inSrc,outTgt};
}
function hasCycle(G,mem,list){
  for(const i of list)if(G.self[i])return true;
  const st=new Map();   // 1 = on stack, 2 = done
  const dfs=v=>{st.set(v,1);for(const j of G.outs[v]){if(!mem[j])continue;const q=st.get(j);if(q===1)return true;if(!q&&dfs(j))return true}st.set(v,2);return false};
  for(const v of list)if(!st.get(v)&&dfs(v))return true;return false;
}
function qualifies(m,size,o){return size>=o.minSize&&m.inD<=o.maxIn&&m.outD<=o.maxOut&&m.outD>=1&&m.internal>=size&&m.internal/(m.internal+m.inD+m.outD)>=o.minIsolation}

export function findSuperneurons(g,opt={}){
  const o={...SN_DEFAULTS,...opt};
  const b=g.N?g:unpackRig(g),N=b.N,G=graph(b),deg=i=>G.ins[i].length+G.outs[i].length,cands=[];
  const mem=new Uint8Array(N);
  for(let s=0;s<N;s++){
    if(b.role[s]===ROLE.TONIC||!deg(s))continue;
    const list=[s];mem[s]=1;let best=null;
    /* gain[v] = wires between v and the group (both directions): adding v turns them internal */
    const toC=new Map(),fromC=new Map(),front=new Set();
    const touch=v=>{for(const j of G.outs[v])if(!mem[j]){fromC.set(j,(fromC.get(j)||0)+1);front.add(j)}for(const j of G.ins[v])if(!mem[j]){toC.set(j,(toC.get(j)||0)+1);front.add(j)}};
    touch(s);
    while(list.length<o.maxSize&&front.size){
      let pick=-1,bd=Infinity,bi=-1;
      for(const v of front){const into=toC.get(v)||0,from=fromC.get(v)||0;   // v->group wires, group->v wires
        const ext=G.sens[v].length+G.ins[v].length-from+G.outs[v].length-into+G.votes[v].length;   // v's own new boundary lines
        const d=ext-into-from,inn=into+from;if(d<bd||(d===bd&&inn>bi)){bd=d;bi=inn;pick=v}}
      front.delete(pick);toC.delete(pick);fromC.delete(pick);mem[pick]=1;list.push(pick);touch(pick);
      if(list.length>=o.minSize){const m=measure(G,mem,list);
        if(qualifies(m,list.length,o)){const cyc=hasCycle(G,mem,list);
          if(cyc||m.hidden>0){const score=m.internal/(m.internal+m.inD+m.outD);
            if(!best||score>best.score+1e-9||(Math.abs(score-best.score)<1e-9&&list.length>best.cells.length))best={cells:list.slice(),score,m,cyc}}}}
    }
    for(const v of list)mem[v]=0;
    if(best)cands.push(best);
  }
  /* best non-overlapping groups */
  cands.sort((x,y)=>y.score-x.score||y.cells.length-x.cells.length);
  const taken=new Uint8Array(N),seen=new Set(),out=[];
  for(const c of cands){const key=c.cells.slice().sort((a,b)=>a-b).join(',');if(seen.has(key))continue;seen.add(key);
    if(c.cells.some(i=>taken[i]))continue;c.cells.forEach(i=>taken[i]=1);out.push(c)}
  return {b,G,groups:out};
}

/* run one superneuron in isolation for every input pattern */
function transfer(b,G,cells,m){
  const S=b.S,K=b.K,idx=new Map(cells.map((c,k)=>[c,k])),M=cells.length,strict=isStrictKind(b.kind);
  const inputs=[...m.inSrc],inIx=new Map(inputs.map((s,k)=>[s,k])),nIn=inputs.length;
  /* each member's three slots, resolved: member k, input u, or a constant */
  const slot=cells.map(i=>{const r=[];for(let q=0;q<3;q++){const x=3*i+q,w=b.w[x];if(!w)continue;const s=b.src[x];
    if(s<S){r.push(CONST_SENSORS.has(s)?{w,c:1}:{w,u:inIx.get('S'+s)});continue}
    const j=s-S;if(b.role[j]===ROLE.TONIC)r.push({w,c:1});else if(idx.has(j))r.push({w,m:idx.get(j)});else r.push({w,u:inIx.get('C'+j)})}return r});
  const bias=cells.map(i=>b.bias[i]),gain=cells.map(i=>b.gain[i]),fb=cells.map(i=>[b.fb[3*i],b.fb[3*i+1],b.fb[3*i+2]]),zc=T_LIMITS.zClamp;
  const fire=(k,z)=>{if(strict)return z>0?1:z<0?-1:0;z+=bias[k];const zz=z>zc?zc:z<-zc?-zc:z,d=gain[k]*zz/DECT,r0=fb[k][0]-d,r1=fb[k][1],r2=fb[k][2]+d;return (r0>r1&&r0>=r2)?-1:(r2>r1&&r2>r0)?1:0};
  /* outputs: each external target line, and per motor the summed vote of the members */
  const outCells=[],motorVotes=new Map();
  cells.forEach((i,k)=>{for(const j of G.outs[i])if(!idx.has(j))outCells.push({k,label:`C${j+1}`});for(const a of G.votes[i]){const v=b.dec[a*b.N+i];if(!motorVotes.has(a))motorVotes.set(a,[]);motorVotes.get(a).push({k,v})}});
  const outLabels=[...new Set(outCells.map(x=>x.label))];
  const run=(pat,start)=>{let h=Int8Array.from(start),nx=new Int8Array(M);const seen=new Map(),hist=[];
    for(let t=0;t<200;t++){const key=h.join('');if(seen.has(key)){const t0=seen.get(key);return {period:t-t0,cycle:hist.slice(t0),end:h}}seen.set(key,t);hist.push(h.slice());
      for(let k=0;k<M;k++){let z=0;for(const s of slot[k])z+=s.w*(s.m!==undefined?h[s.m]:s.u!==undefined?pat[s.u]:s.c);nx[k]=fire(k,z)}const tmp=h;h=nx;nx=tmp}
    return {period:0,cycle:hist.slice(-K),end:h}};   // no repeat within 200 ticks: treat the last K as the response
  /* K-tick window averages over the cycle, every phase */
  const windows=(cyc,f)=>{const P=cyc.length,vals=[];for(let ph=0;ph<P;ph++){let s=0;for(let t=0;t<K;t++)s+=f(cyc[(ph+t)%P]);vals.push(s/K)}return vals};
  const total=Math.pow(3,nIn),step=total>729?Math.ceil(total/729):1,pats=[];
  for(let n=0;n<total;n+=step){const p=new Int8Array(nIn);let r=n;for(let u=0;u<nIn;u++){p[u]=(r%3)-1;r=Math.floor(r/3)}pats.push(p)}
  const zero=new Int8Array(M),resp=[],periods=new Map(),levels=new Map(outLabels.map(l=>[l,new Set()])),mot=new Map([...motorVotes.keys()].map(a=>[a,{min:Infinity,max:-Infinity,levels:new Set()}]));
  let osc=0,memory=0,prevEnd=zero;
  /* a response = the cycle of output tuples, rotated to a canonical phase (so the same cycle entered at another phase matches) */
  const sig=r=>{const tup=r.cycle.map(h=>outCells.map(oc=>h[oc.k]).join('')+'/'+[...motorVotes.values()].map(vs=>vs.reduce((a,x)=>a+x.v*h[x.k],0)).join(','));return canon(tup)};
  for(const p of pats){
    const r=run(p,zero),r2=run(p,prevEnd);prevEnd=r.end;
    const s1=sig(r);resp.push(s1);if(sig(r2)!==s1)memory++;
    if(r.period>1){osc++;periods.set(r.period,(periods.get(r.period)||0)+1)}
    for(const oc of outCells)for(const v of windows(r.cycle,h=>h[oc.k]))levels.get(oc.label).add(Math.round(v*100)/100);
    for(const [a,vs] of motorVotes){const M2=mot.get(a);for(const v of windows(r.cycle,h=>vs.reduce((s,x)=>s+x.v*h[x.k],0))){M2.min=Math.min(M2.min,v);M2.max=Math.max(M2.max,v);M2.levels.add(Math.round(v*100)/100)}}
  }
  /* which inputs matter: changing that one input changes the response for some pattern */
  const used=new Array(nIn).fill(false);
  if(step===1)for(let n=0;n<total;n++)for(let u=0;u<nIn;u++){if(used[u])continue;const d=Math.floor(n/Math.pow(3,u))%3;if(d===2)continue;if(resp[n]!==resp[n+Math.pow(3,u)])used[u]=true}
  const distinct=new Set(resp).size,tickMs=20/K;
  const graded=[...levels.values(),...[...mot.values()].map(x=>x.levels)].some(set=>[...set].some(v=>Math.abs(v-Math.round(v))>1e-9));
  const tags=[];
  if(distinct===1)tags.push(nIn?'constant (ignores its inputs)':'autonomous');
  if(osc===pats.length&&pats.length)tags.push(nIn?'oscillator':'pacemaker / CPG');else if(osc)tags.push('input-switched oscillator');
  if(memory)tags.push('memory / latch');
  if(graded)tags.push('graded output (pulse-density)');
  if(!osc&&distinct>1&&!memory)tags.push(distinct<=3?'gate / switch':'combinational logic');
  return {inputs:inputs.map(s=>s[0]==='S'?sensorLabel(+s.slice(1)):`C${+s.slice(1)+1}`),usedInputs:step===1?inputs.filter((_,u)=>used[u]).length:null,
    outputs:[...outLabels,...[...motorVotes.keys()].map(a=>`M${a+1}`)],patterns:pats.length,patternSpace:total,distinct,oscillating:osc,memory,
    periods:[...periods.entries()].sort((x,y)=>x[0]-y[0]).map(([P,n])=>({ticks:P,ms:+(P*tickMs).toFixed(1),hz:+(1000/(P*tickMs)).toFixed(1),patterns:n})),
    levels:Object.fromEntries([...levels].map(([l,s])=>[l,[...s].sort((x,y)=>x-y)])),
    motors:Object.fromEntries([...mot].map(([a,x])=>[`M${a+1}`,{min:+x.min.toFixed(2),max:+x.max.toFixed(2),levels:x.levels.size,votes:motorVotes.get(a).length}])),
    tags};
}
/* a cycle's signature, the same whatever phase it was entered at */
function canon(tup){
  /* collapse a cycle that repeats a shorter output cycle (outputs can cycle faster than the hidden state) */
  const P=tup.length;let p=P;for(let d=1;d<P;d++)if(P%d===0&&tup.every((x,i)=>x===tup[i%d])){p=d;break}
  const base=tup.slice(0,p);let best=null;for(let r=0;r<p;r++){const s=base.slice(r).concat(base.slice(0,r)).join(' ');if(best===null||s<best)best=s}
  return p+':'+best;
}

export function analyzeSuperneurons(g,opt={}){
  if(!isRigGenome(g))return {groups:[],note:'not a rig brain'};
  const key=JSON.stringify(opt);let c=cache.get(g);if(c&&c.key===key)return c.out;
  const t0=Date.now(),{b,G,groups}=findSuperneurons(g,opt),o={...SN_DEFAULTS,...opt},pulse=b.kind===KIND.PULSE;
  const out={N:b.N,K:b.K,kind:b.kind,limits:{maxIn:o.maxIn,maxOut:o.maxOut,minSize:o.minSize,maxSize:o.maxSize,minIsolation:o.minIsolation},groups:[]};
  groups.forEach((gr,n)=>{const m=gr.m,cells=gr.cells,roles=[0,0,0];cells.forEach(i=>roles[b.role[i]]++);
    const e={id:n+1,cells,size:cells.length,io:roles[0],internal:roles[1],inputs:m.inD,outputs:m.outD,inLines:m.inLines,outLines:m.outLines,wires:m.internal,hidden:m.hidden,recurrent:gr.cyc,isolation:+gr.score.toFixed(3),
      inSrc:[...m.inSrc].map(s=>s[0]==='S'?-1-(+s.slice(1)):+s.slice(1)),outCells:[...m.outTgt].filter(s=>s[0]==='C').map(s=>+s.slice(1)),motors:[...m.outTgt].filter(s=>s[0]==='M').map(s=>+s.slice(1))};
    if(!pulse)try{e.transfer=transfer(b,G,cells,m)}catch(err){e.transfer={error:String(err.message||err)}}
    out.groups.push(e)});
  const covered=out.groups.reduce((a,x)=>a+x.size,0);
  out.summary={count:out.groups.length,cells:covered,share:b.N?covered/b.N:0,ms:Date.now()-t0};
  cache.set(g,{key,out});return out;
}

/* plain-text report for the biopsy and the page */
export function superneuronReport(an){
  if(!an?.groups)return 'No superneuron analysis.';
  const L=[`SUPERNEURONS  ${an.groups.length} found, ${an.summary.cells} of ${an.N} cells (${(100*an.summary.share).toFixed(1)} %) · limits: <= ${an.limits.maxIn} inputs, <= ${an.limits.maxOut} outputs, ${an.limits.minSize}-${an.limits.maxSize} cells, more internal wires than members, isolation >= ${an.limits.minIsolation}, a loop or a hidden member · ${an.K} ticks per 20 ms step (${(20/an.K).toFixed(1)} ms per tick)`];
  if(!an.groups.length)L.push('  none: no group of cells is both this sealed off and this internally wired. Newborn wiring is spread evenly, so superneurons appear (if at all) through evolution.');
  for(const g of an.groups){const t=g.transfer;
    L.push(`SN${g.id}  ${g.size} cells (${g.io} sensor-motor, ${g.internal} internal, ${g.hidden} hidden) · ${g.inputs} in / ${g.outputs} out · ${g.wires} internal wires${g.recurrent?', recurrent':''} · isolation ${g.isolation}`);
    L.push(`  members ${g.cells.map(i=>'C'+(i+1)).join(' ')}`);
    if(!t){L.push('  (pulse brain: structure only)');continue}if(t.error){L.push('  transfer failed: '+t.error);continue}
    L.push(`  inputs ${t.inputs.join(', ')||'none (autonomous)'}${t.usedInputs!==null?` · ${t.usedInputs} of ${t.inputs.length} change the output`:''}`);
    L.push(`  outputs ${t.outputs.join(', ')}`);
    L.push(`  ${t.patterns} input patterns${t.patterns<t.patternSpace?` (sampled from ${t.patternSpace})`:''} -> ${t.distinct} distinct responses · ${t.oscillating} oscillate${t.periods.length?` (periods ${t.periods.map(p=>`${p.ticks} ticks = ${p.ms} ms ≈ ${p.hz} Hz ×${p.patterns}`).join('; ')})`:''} · ${t.memory} history-dependent`);
    for(const [k,v] of Object.entries(t.levels))L.push(`  ${k} per-step level range ${v[0]} .. ${v[v.length-1]} (${v.length} levels: ${v.join(' ')})`);
    for(const [k,v] of Object.entries(t.motors))L.push(`  ${k} push ${v.min} .. ${v.max} votes per tick (${v.levels} levels, ${v.votes} member votes)`);
    L.push(`  type: ${t.tags.join(' · ')||'—'}`)}
  return L.join('\n');
}
