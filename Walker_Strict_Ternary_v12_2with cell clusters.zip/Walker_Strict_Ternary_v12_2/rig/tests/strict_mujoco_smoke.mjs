/* v12.2 REAL MuJoCo smoke for the strict brain at full scale (not a training-success claim):
 * a 2,500-cell strict plastic brain drives the real walker for 2 s, is replayed, and its
 * superneurons are analysed. Run after npm install. */
import assert from 'node:assert/strict';
import {makeWalkerPlant} from '../plants/walker.mjs';
import {birthRig,KIND} from '../brain.mjs';
import {analyzeSuperneurons} from '../superneuron.mjs';
import {Rng} from '../core/rng.mjs';
const plant=await makeWalkerPlant({workers:1,backend:'inprocess'});
try{
  plant.setJoints('muscles');plant.setFriction('firm');const t0=Date.now();
  const g=birthRig(new Rng(2500),{N:2500,K:10,kind:KIND.STRICT_PLASTIC,A:16}),suite=plant.trainingSuite(47017,0,{trainCases:1,trainSeconds:2,difficulty:1});
  const r=(await plant.evaluate([g],suite,{cfg:{rung:'posture'},train:true}))[0][0];
  assert.ok(Number.isFinite(r.L)&&r.steps>0,'the real walker ran a scored trial');
  const rep=await plant.replay(g,suite[0],{stride:5});assert.ok(rep.frames?.length>0&&rep.trace?.[0]?.length===2500,'replay frames and all 2,500 cell states');
  const an=analyzeSuperneurons(g);assert.ok(Array.isArray(an.groups));
  console.log(`REAL MUJOCO strict 2,500-cell smoke PASS · ${r.steps} physics steps, ladder ${r.L.toFixed(3)}, ${rep.frames.length} frames, ${an.groups.length} superneurons, ${Date.now()-t0} ms`);
}finally{await plant.close()}
