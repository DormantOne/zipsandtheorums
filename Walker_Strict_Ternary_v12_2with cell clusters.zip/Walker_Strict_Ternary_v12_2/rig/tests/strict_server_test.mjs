/* End-to-end strict preset and a mock-physics comparison. */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url));
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'rig_strict_')),port=19150+Math.floor(Math.random()*300);
const srv=spawn(process.execPath,[path.join(here,'..','server.mjs'),'--port',String(port)],{env:{...process.env,RIG_START_STRICT:'1',RIG_WALKER_BACKEND:'mock',RIG_DATA_DIR:dir,RIG_WORKERS:'2'},stdio:['ignore','pipe','pipe']});
let ready='';srv.stdout.on('data',d=>ready+=d);srv.stderr.on('data',d=>ready+=d);
const wait=ms=>new Promise(r=>setTimeout(r,ms));const url=`http://127.0.0.1:${port}`;
const cmd=async(cmd,args={})=>{const r=await fetch(url+'/api/cmd',{method:'POST',body:JSON.stringify({cmd,args})});const b=await r.json();assert.ok(r.ok,`${cmd}: ${JSON.stringify(b)}`);return b};
try {
 for(let t=0;t<70&&!ready.includes('at http');t++)await wait(100);
 assert.match(ready,/at http/);
 const status=async()=>await (await fetch(url+'/api/status')).json();
 let s=await status();assert.equal(s.cfg.N,192);assert.equal(s.cfg.brain,'strictPlastic');assert.equal(s.cfg.maxCells,512);assert.equal(s.cfg.compare,true);assert.equal(s.cfg.mixedSizes,false);
 const page=await (await fetch(url)).text();assert.match(page,/192 neurons by default/);
 await cmd('set',{cfg:{N:24,maxCells:48,mixedSizes:false,founders:3,lambda:3,trainCases:1,trainSeconds:2,valCases:4,holdCases:4,valEvery:2}});
 await cmd('start');await wait(1400);await cmd('pause');s=await status();
 assert.ok(s.generation>=1,JSON.stringify(s));assert.equal(s.compare.arms.length,2);assert.deepEqual(s.compare.arms.map(a=>a.kind),[4,5]);
 await cmd('audit');const biopsy=await (await fetch(url+'/api/biopsy')).text();assert.match(biopsy,/strict/i);const x=await (await fetch(url+'/api/export')).json();assert.equal(x.cfg.brain,'strictPlastic');
 console.log('strict server: separate preset, 192 cells default, compare kinds [4,5], training, export and biopsy PASS');
} finally {srv.kill('SIGTERM');for(let t=0;t<40&&srv.exitCode===null;t++)await wait(100);fs.rmSync(dir,{recursive:true,force:true});}
