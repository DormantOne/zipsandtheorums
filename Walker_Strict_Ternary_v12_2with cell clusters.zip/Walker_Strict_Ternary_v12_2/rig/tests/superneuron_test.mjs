/* v12.2: superneuron detection and its modulation analysis, on a planted module,
 * checked against the real controller; and the 2,500-cell scale. */
import assert from 'node:assert/strict';
import {birthRig,unpackRig,packRig,makeRigController,mutateRig,rigAudit,ROLE,KIND,RIG_MAX_N} from '../brain.mjs';
import {analyzeSuperneurons,superneuronReport} from '../superneuron.mjs';
import {encodeTernary,TERNARY_SENSORS,T_SENS} from '../../engine/ternary.mjs';
import {Rng} from '../core/rng.mjs';

assert.ok(RIG_MAX_N>=2500,'brains may have 2,500 cells');
/* plant a 4-cell module: io0 <- tonic(+1), int3(-1), sensor(+1); int1 <- io0; int2 <- int1; int3 <- int2; io0 votes on motor 1 */
const b=unpackRig(birthRig(new Rng(7),{N:40,K:10,kind:KIND.STRICT_FIXED,A:16,internalShare:.5,tonicShare:.08})),N=b.N,S=b.S;
const io=[...Array(N).keys()].filter(i=>b.role[i]===ROLE.IO),inn=[...Array(N).keys()].filter(i=>b.role[i]===ROLE.INTERNAL),ton=[...Array(N).keys()].filter(i=>b.role[i]===ROLE.TONIC);
const [c0]=io,[c1,c2,c3]=inn,T=ton[0],mem=new Set([c0,c1,c2,c3]),sensor=TERNARY_SENSORS.findIndex(s=>s.label==='fwd vel');
const others=[...Array(N).keys()].filter(i=>!mem.has(i)&&b.role[i]!==ROLE.TONIC);
for(const i of others)for(let k=0;k<3;k++){const x=3*i+k;if(b.src[x]>=S&&mem.has(b.src[x]-S))b.src[x]=S+others[(i+k+1)%others.length]}
const wire=(i,slots)=>{for(let k=0;k<3;k++){const s=slots[k];b.src[3*i+k]=s?s[0]:S+i;b.w[3*i+k]=s?s[1]:0}};
wire(c0,[[S+T,1],[S+c3,-1],[sensor,1]]);wire(c1,[[S+c0,1]]);wire(c2,[[S+c1,1]]);wire(c3,[[S+c2,1]]);
for(let a=0;a<b.A;a++){if(a!==0&&b.dec[a*N+c0]){const f=others.find(i=>b.role[i]===ROLE.IO&&!b.dec[a*N+i]);b.dec[a*N+f]=b.dec[a*N+c0];b.dec[a*N+c0]=0}}
if(!b.dec[c0]){const u=others.find(i=>b.dec[i]);b.dec[c0]=1;b.dec[u]=0}else b.dec[c0]=1;
const g=packRig(b);assert.ok(rigAudit(g).ok,rigAudit(g).text);
const an=analyzeSuperneurons(g),sn=an.groups.find(x=>x.cells.includes(c0));
assert.ok(sn,'the planted module is found:\n'+superneuronReport(an));
assert.deepEqual([...sn.cells].sort((x,y)=>x-y),[...mem].sort((x,y)=>x-y),'exactly the planted cells');
assert.equal(sn.inputs,1);assert.equal(sn.outputs,1);assert.ok(sn.recurrent);assert.equal(sn.hidden,3);
const t=sn.transfer;assert.equal(t.patterns,3);assert.equal(t.usedInputs,1);assert.equal(t.oscillating,1,'oscillates only when the sensor is 0');
assert.ok(t.tags.includes('input-switched oscillator'),t.tags.join());
assert.deepEqual(t.periods.map(p=>p.ticks),[8]);   // 0000 1000 1100 1110 1111 0111 0011 0001: a period of 8 ticks (16 ms)
const m=t.motors.M1;assert.equal(m.min,0);assert.equal(m.max,1);   // a step averages 8 or 10 of 10 ticks on: graded levels
assert.ok(t.tags.includes('graded output (pulse-density)'));
/* the isolated simulation is what the real controller does (whose tonic cells are read one tick late at the very start of a trial) */
const c=makeRigController(g),obs=new Float64Array(64),sv=new Int8Array(T_SENS);encodeTernary(obs,0,sv,0);
let h=[0,0,0,0],first=true;const step=()=>{for(let k=0;k<10;k++){const ton=first?0:1;first=false;const n0=Math.sign(ton-h[3]+sv[sensor]),n1=h[0],n2=h[1],n3=h[2];h=[n0,n1,n2,n3]}return h.slice()};
for(let s=0;s<30;s++){c.control(obs);const z=c.hidden(),want=step();assert.deepEqual([c0,c1,c2,c3].map(i=>z[i]),want,`step ${s}`)}
/* scale: 2,500 cells birth, audit, mutate, analyse within a few seconds */
const t0=Date.now();let big=birthRig(new Rng(2500),{N:2500,K:10,kind:KIND.STRICT_PLASTIC,A:16});for(let k=0;k<50;k++)big=mutateRig(big,new Rng(k),{count:4});
assert.equal(unpackRig(big).N,2500);assert.ok(rigAudit(big).ok);const ab=analyzeSuperneurons(big);assert.ok(Array.isArray(ab.groups));
const bc=makeRigController(big);for(let s=0;s<20;s++)bc.control(obs);
console.log(`superneuron: planted 4-cell module found exactly (1 in, 1 out, 3 hidden, period ${t.periods[0].ticks} ticks, motor push ${m.min}..${m.max}); isolated simulation = controller for 30 steps`);
console.log(`2,500 cells: birth + 50 mutations + analysis + 20 controller steps in ${Date.now()-t0} ms, ${ab.groups.length} superneurons in a random brain`);
console.log('superneuron_test ok');
