# Mystery-Cage v16 — Flask / Python Distributed Learning Society

This is a **local, long-running experiment** based on the user's v15.1 Mystery-Cage system. It is not an LLM agent. It is an experimental network of **3 traveling packets** and **12 stateful cities**, each possessing private evidence, routing/message policies, and limited opportunities to exchange information.

## Start (one click)

- **Windows:** double-click `start_windows.bat` (Python 3.10 or newer required).
- **macOS:** right-click or double-click `start_mac.command` and allow it to run (Python 3.10 or newer required).
- **Linux:** run `bash start_linux.sh`.
- **Manual:** `python -m venv .venv`, activate it, `python -m pip install -r requirements.txt`, then `python app.py`.

The app binds to **127.0.0.1:8765** and opens at http://127.0.0.1:8765. All computation and data remain local. The first launch requires installing Flask from PyPI. The application does not use an AI API, cloud services, or an external database.

Click **Start / Resume** to train for up to 5,000 completed puzzles (adjustable). Closing the **browser** does not stop the Python worker. Closing the terminal/server **does** stop it; each completed episode is checkpointed atomically, so relaunching resumes at the next puzzle. Pausing completes the current finite episode, then saves. Do not run multiple server copies against the same data directory.

## Starting point / checkpoint import

The included `initial_checkpoint.json` was extracted from your **v15.1 day-29 biopsy**, containing **28 completed episodes**, learned city message/deduction weights, learned packet message weights, and learned arithmetic-example scores. The packet routing and deduction-choice weights were reset because the old route decision features were mistakenly recomputed *after* moving and the old choice coefficients saturated. The incomplete day-29 puzzle itself is not resumed. On first launch the initial model is copied to `data/checkpoint.json`; afterward the local checkpoint takes precedence. You can separately import v15/v15.1 biopsies or later v16 checkpoints from the GUI.

The original v15.1 history is retained as a *legacy reference*. It was produced by JavaScript with a different PRNG and old policy learning; **do not treat it as perfectly comparable** to new Python data. The dashboard will show the legacy days as part of cumulative history. For clean v16-only analysis, use post-import episodes (day 29 onward), and especially matched frozen benchmarks.

## The actual protocol

- Task: 6×6 Latin-square arithmetic cages with three hidden operation symbols (A/B/C). Allowed operations: `+`, `×`, absolute difference, `max`, `min`. A secret mapping persists until manually shifted.
- Each city has independently stored digits/examples and message-choice weights; packets carry independently stored digits/examples and have routing, message, and deduction-choice weights.
- Clues are initially dispersed to custodians. Each packet starts with **two clue digits**, and the solver has no shared board. Every city receives two local calibration examples.
- Per visit, at most `payload` facts flow in each direction. City logic and packet logic take at most two deductions each. City reasoning is restricted to a local structural scope.
- The candidate propagator uses Latin-square row/column constraints and two-cell cage arithmetic. **It is hard-coded.** A learned operator prediction is only a preference, never a reason to eliminate any still-consistent operation.
- The hidden key/solution is used to construct uniquely solvable puzzles and audit deductions. No actor reads the key/solution during reasoning or message selection.
- The packet keeps scorecards for cities; a received fact gets delayed usefulness credit when later *related* deductions appear. The signal is a **proxy**, not counterfactual causal attribution. It is delivered only on a subsequent visit to the city.

## What changed in v16

### Correct packet decision credit

At destination selection, the packet now saves:

1. The **pre-move** features and distance to every candidate city.
2. The chosen candidate, softmax probabilities and actual pre-move distance.
3. A pending visit return. On the packet's *next visit*, the stored decision receives a reward that includes newly received evidence, newly constructed deductions, later related deductions, returned feedback and travel cost. At the episode boundary the last pending choice is settled.

The router update uses the softmax score-function feature difference:

`weight_delta ≈ learning_rate × (reward - baseline) × (chosen_features - probability_weighted_mean_features)`

This corrects both the previous **post-move distance-zero bug** and the previous **unconditional positive weight update** that caused nuisance feature saturation. Weights are clipped; packet deduction-choice policy also uses centered comparative updates.

**Caveat:** This is still an engineered reward/proxy, not discovered causal credit. The model sees public beacons (energy, counts and scorecard), not a city's private digits. Its learned directionality comes from reinforcement-style updates and not a precomputed route from the answer key.

### City credit remains delayed

City messaging is reinforced only by the packet's subsequent report, and city message selection now uses a saved contextual-policy gradient rather than unconditionally adding chosen features. The existing learned city weights are preserved from v15.1.

## What to test

The most important comparison is **Both learned** vs **Learned cities + fixed routing** on held-out puzzles. At fixed energy/payload, observe solve rate, best-packet progress, travel and facts delivered. This must be replicated across multiple seeds and training windows. Other controls: city-only, fresh, fixed all and no-transfer.

The benchmark takes an immutable **copy** of the current policies and disables all weight updates for held-out puzzles. It does not overwrite the training model. Puzzle seeds, clue distribution and calibration examples are matched across arms; stochastic routing decisions can differ normally. A single-seed 50-puzzle win is **not** proof of general superiority.

Automatic frozen-policy testing can run every 50/100/250/500 episodes (100 by default). Each automatic check evaluates 30 held-out puzzles with training disabled and saves per-puzzle results in `data/benchmark_*.json` plus `data/benchmark_history.json`. These evaluations are independent from the learning updates.

Changing hidden laws retains old weights and starts a new fresh puzzle, so it can evaluate adaptation (though no matched fresh-model recovery test is yet implemented). Energy, payload and disabled-city settings apply to new episodes, not episodes already in progress.

## Logs and durable files

- `data/checkpoint.json`: complete model, historical outcomes and configuration, **atomically rewritten after each completed episode**.
- `data/benchmark_YYYYMMDD_HHMMSS.json`: independent matched benchmark, including per-puzzle arm outcomes.
- `Export history CSV`: an easily plotted log from the browser.
- `Download checkpoint`: share/import all learned parameters and episode history.

## What this does not establish

- Autonomous invention of deduction rules: the arithmetic and consistency engine is programmed.
- Scientifically demonstrated recovery after structural damage. Disabling cities is possible, but matched lesion-versus-fresh recovery controls remain necessary.
- A proof that cities and packets have acquired complementary *causal* specializations.
- Identical random sequence to v15.1: Python's PRNG is deliberately independent from the JavaScript implementation, though experimental rules are carried over.

The correct success criterion is not total compute or an aesthetically pleasing learning curve: **learned city and packet policies must beat a strong fixed/ablated matched baseline on novel puzzles at the same budget, without validity violations.**

## Preliminary three-seed v16 validation

From the v15.1 day-29 city weights, resetting packet routing, train for 60 additional Python episodes with each of three independent seeds. Then test 30 held-out puzzles/seed on frozen weights with energy 3 and two facts/direction. Combined 90 held-out episodes:

| Frozen policy | Solved /90 | Mean travel |
|---|---:|---:|
| Corrected dual learner | **79** | **8.94** |
| Learned cities; fresh packet policies | 80 | 17.93 |
| Learned cities; fixed packet routing | 63 | 6.56 |
| Fresh both | 47 | 19.17 |
| Fixed both | 50 | 6.90 |
| No transfer | 0 | 19.80 |

Dual minus city+fixed: 20 paired wins, 4 losses, 66 ties (exploratory bootstrap 95% interval for the difference in solve rate: +7.8 to +27.8 percentage points). **This is not yet a demonstrated general advantage** over all alternatives: cities with random packet routing solved 80/90, essentially tying dual, but traveling about twice as far. Validation seeds, paired results and code are supplied in `v16_validation_3seed.json`. Repeat at larger sample sizes and with other keys, lesion patterns, and resource budgets.
