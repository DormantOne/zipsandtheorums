"""Flask front end + durable local experiment runner for Mystery-Cage v16."""
from __future__ import annotations
import csv, io, json, os, secrets, threading, time, traceback, copy, tempfile
from pathlib import Path
from datetime import datetime, timezone
from flask import Flask, request, jsonify, send_file, render_template, abort
from engine import World, new_model, load_model, reset_packet_policies, frozen_comparison, OPS, mean

ROOT=Path(__file__).resolve().parent
DATA=Path(os.environ.get('MYSTERY_DATA_DIR',ROOT/'data'));DATA.mkdir(parents=True,exist_ok=True)
CHECKPOINT=DATA/'checkpoint.json';INITIAL=ROOT/'initial_checkpoint.json'
app=Flask(__name__)
app.config['MAX_CONTENT_LENGTH']=8*1024*1024
TOKEN=secrets.token_urlsafe(28)
lock=threading.RLock()

class Runner:
    def __init__(self):
        self.model=new_model();self.history=[];self.key=[2,0,4];self.day=1
        self.config={'energy':3,'payload':2,'arm':'both','max_days':5000,'disabled':[],'benchmark_every':100}
        self.next_seed=192000;self.world=None;self.status='Paused';self.running=False;self.pausing=False
        self.worker=None;self.benchmark=None;self.benchmark_status='Not started';self.benchmark_result=None
        self.latest_error=None;self.events=[];self.last_saved=None;self.legacy=None;self.benchmark_history=[]
        self.load_initial()
    def note(self,s):
        self.events.insert(0,f'{datetime.now().strftime("%H:%M:%S")}  {s}');self.events=self.events[:50]
    def load_initial(self):
        try:
            f=CHECKPOINT if CHECKPOINT.is_file() else INITIAL
            if f.is_file():
                d=json.loads(f.read_text())
                if d.get('version')=='16.0':
                    self.model=load_model(d['model']);self.history=d.get('history',[]);self.key=d.get('key',[2,0,4]);self.config.update(d.get('config',{}));self.next_seed=int(d.get('next_seed',192000));self.day=len(self.history)+1
                    self.note(f'Resumed saved v16 checkpoint ({len(self.history)} completed episodes).')
                elif d.get('version') in ('15.1','15.0') and 'live' in d:
                    live=d['live'];self.model=load_model(live.get('models',{}));reset_packet_policies(self.model)
                    self.history=list(live.get('history',[]));self.key=live.get('lawForAudit',[2,0,4]);self.day=len(self.history)+1
                    self.config.update(live.get('config',{}));self.config['arm']='both';self.next_seed=192000
                    self.legacy={'source_version':d['version'],'original_day':live.get('day'), 'packet_router_reset':True}
                    self.note(f'Imported v15.1 day-{live.get("day")} learner: city weights preserved, packet router reset.')
                else:self.note('Unrecognized checkpoint format; started fresh.')
            else:self.note('Started new model.')
        except Exception as exc:self.note(f'Checkpoint load error: {exc}');self.latest_error=str(exc)
        self.write_checkpoint()
        try:
            f=DATA/'benchmark_history.json'
            if f.is_file():self.benchmark_history=json.loads(f.read_text())
        except Exception:self.benchmark_history=[]
    def checkpoint_data(self):
        return {'version':'16.0','saved_at':datetime.now(timezone.utc).isoformat(),'model':copy.deepcopy(self.model),
            'history':copy.deepcopy(self.history),'key':list(self.key),'config':dict(self.config),'next_seed':self.next_seed,
            'last_completed_day':len(self.history),'resume_policy':'continue at episode boundary; unfinished world is not serialized',
            'legacy':self.legacy}
    def write_checkpoint(self):
        # Atomic replace prevents a power loss from corrupting the last checkpoint.
        d=self.checkpoint_data();fd,name=tempfile.mkstemp(prefix='checkpoint_',suffix='.tmp',dir=DATA)
        try:
            with os.fdopen(fd,'w') as f:
                json.dump(d,f,separators=(',',':'));f.flush();os.fsync(f.fileno())
            os.replace(name,CHECKPOINT);self.last_saved=d['saved_at']
        finally:
            if os.path.exists(name):os.remove(name)
    def run_worker(self):
        while True:
            with lock:
                if not self.running or len(self.history)>=self.config['max_days']:
                    self.running=False;self.status='Campaign limit reached' if len(self.history)>=self.config['max_days'] else 'Paused';self.worker=None
                    self.write_checkpoint();return
                if self.pausing:
                    self.pausing=False;self.running=False;self.status='Paused';self.worker=None;self.write_checkpoint();return
                seed=self.next_seed;self.next_seed+=1009
                try:
                    self.world=World(seed,tuple(self.key),self.model,arm=self.config['arm'],energy=self.config['energy'],payload=self.config['payload'],train=True,disabled=self.config['disabled'])
                except Exception as exc:
                    self.latest_error=str(exc);self.running=False;self.status='Error';self.worker=None;return
                self.status='Training'
            try:
                while True:
                    with lock:
                        if self.world.done:break
                        self.world.step()
                    # Small yield interval permits the GUI to inspect updates during training.
                    if self.world.visits%6==0:time.sleep(.001)
                with lock:
                    result=self.world.outcome();self.history.append(result);self.day=len(self.history)+1
                    self.note(f'Day {len(self.history)}: {result["best"]}/36 · {"SOLVED" if result["anySolved"] else "partial"} · {result["travel"]:.1f} travel')
                    self.write_checkpoint()
                    milestone=(len(self.history)%max(1,int(self.config.get('benchmark_every',100)))==0) if int(self.config.get('benchmark_every',100))>0 else False
                    if milestone and not self.benchmark_status.startswith('Running'):
                        self.launch_benchmark(copy.deepcopy(self.model),list(self.key),self.config['energy'],self.config['payload'],30,570001,periodic=True)
            except Exception as exc:
                with lock:
                    self.latest_error=str(exc);self.note('Audit/worker error: '+str(exc));self.running=False;self.status='Stopped on error';self.worker=None;self.write_checkpoint()
                return
    def launch_benchmark(self,model,key,energy,payload,n,seed,periodic=False):
        self.benchmark_status=f'Running {n} matched new puzzles · frozen weights'
        self.benchmark_result=None
        episode_count=len(self.history)
        def job():
            try:
                result=frozen_comparison(model,key,seed,n,energy,payload)
                fname=DATA/f'benchmark_{episode_count:06d}_{datetime.now().strftime("%Y%m%d_%H%M%S")}.json'
                fname.write_text(json.dumps(result,indent=2))
                with lock:
                    self.benchmark_result=result;self.benchmark_status=f'Completed {n} matched puzzles'
                    if periodic:
                        entry={'day':episode_count,'tests':n,'rows':result['table'],'time':datetime.now(timezone.utc).isoformat()}
                        self.benchmark_history.append(entry)
                        (DATA/'benchmark_history.json').write_text(json.dumps(self.benchmark_history,indent=2))
                        self.note(f'Automatic frozen comparison completed at day {episode_count}')
                    else:self.note(f'Frozen benchmark finished: {n} puzzles')
            except Exception as exc:
                with lock:self.benchmark_status=f'Benchmark error: {exc}';self.note(self.benchmark_status)
        threading.Thread(target=job,name='MysteryCageBenchmark',daemon=True).start()
    def start(self):
        if self.running:return
        self.running=True;self.pausing=False;self.status='Starting';self.worker=threading.Thread(target=self.run_worker,name='MysteryCageTrain',daemon=True);self.worker.start()
    def pause(self):
        if self.running:self.pausing=True;self.status='Finishing episode before pause'
    def state(self):
        hist=self.history;last=hist[-100:];solved=sum(h['anySolved'] for h in hist);total=len(hist)
        tail=hist[-100:] if len(hist)>100 else hist
        prior=hist[-200:-100]
        route=self.model['route']
        return {'version':'16.0','status':self.status,'running':self.running,'pausing':self.pausing,
           'day':len(hist)+1,'total':total,'max_days':self.config['max_days'],'solved':solved,
           'solved_pct':100*solved/max(1,total),'mean_best':mean([h['best'] for h in hist]),
           'recent_solved_pct':100*mean([x['anySolved'] for x in tail]),
           'previous_solved_pct':100*mean([x['anySolved'] for x in prior]) if prior else None,
           'recent_best':mean([x['best'] for x in tail]),'recent_travel':mean([x['travel'] for x in tail]),
           'config':self.config,'rule_family':['ABC'[i]+'='+OPS[k] for i,k in enumerate(self.key)],
           'world':self.world.snapshot() if self.world else None,'history':last,'events':self.events[:8],
           'update':dict(self.model['update']), 'route_weights':route,'benchmark_status':self.benchmark_status,
           'benchmark_result':{'testN':self.benchmark_result['testN'],'table':self.benchmark_result['table']} if self.benchmark_result else None,
           'benchmark_milestones':self.benchmark_history[-8:],
           'error':self.latest_error,'last_saved':self.last_saved,'legacy':self.legacy}

r=Runner()

def protected():
    if request.headers.get('X-Mystery-Token')!=TOKEN:abort(403)
    if request.content_length and request.content_length>8*1024*1024:abort(413)

@app.get('/')
def index():return render_template('index.html',token=TOKEN)
@app.get('/api/state')
def api_state():
    with lock:return jsonify(r.state())
@app.post('/api/control')
def api_control():
    protected();v=request.get_json(silent=True) or {};action=v.get('action')
    with lock:
        if action=='start':
            for name,lo,hi in [('max_days',1,200000),('energy',1,30),('payload',1,5),('benchmark_every',0,5000)]:
                if name in v:
                    x=int(v[name]);r.config[name]=max(lo,min(hi,x))
            if 'arm' in v and v['arm'] in ('both','cities','packets','city_fixed','none','fixed','silent'):r.config['arm']=v['arm']
            if 'disabled' in v:
                ids=[int(x) for x in v['disabled'] if str(x).isdigit()];r.config['disabled']=sorted(set(x for x in ids if 0<=x<12))
            if r.config['max_days']<=len(r.history):r.config['max_days']=len(r.history)+max(1,int(v.get('additional',100)))
            r.start()
        elif action=='pause':r.pause()
        elif action=='save':r.write_checkpoint();r.note('Checkpoint saved')
        elif action=='reset_packets':
            if r.running:return jsonify({'error':'Pause before resetting policies'}),409
            reset_packet_policies(r.model);r.note('Packet routing/choice reset; learned city policies preserved.');r.write_checkpoint()
        elif action=='next_one':
            if r.running:return jsonify({'error':'Pause before stepping an episode'}),409
            r.config['max_days']=max(r.config['max_days'],len(r.history)+1)
            r.running=True;r.pausing=True;r.status='Training one episode';r.pausing=False
            # run_worker needs a finite limit; temporarily cap and restore after completion
            cap=r.config['max_days'];r.config['max_days']=len(r.history)+1
            r.start() if False else None
            r.worker=threading.Thread(target=lambda:(r.run_worker(),restore_max(cap)),daemon=True);r.worker.start()
        elif action=='new_law':
            if r.running:return jsonify({'error':'Pause first'}),409
            import random
            R=random.Random(r.next_seed);old=list(r.key);candidates=list(range(5));R.shuffle(candidates)
            new=candidates[:3]
            if new==old:new=new[1:]+new[:1]
            r.key=new;r.note('Changed secret operator language; retained learned weights, cleared puzzle evidence.');r.write_checkpoint()
        else:return jsonify({'error':'Unknown action'}),400
        return jsonify({'ok':True,'state':r.state()})

def restore_max(cap):
    with lock:r.config['max_days']=cap;r.write_checkpoint()

@app.post('/api/benchmark')
def api_benchmark():
    protected();v=request.get_json(silent=True) or {}
    with lock:
        if r.benchmark_status.startswith('Running'):return jsonify({'error':'Benchmark already running'}),409
        model=copy.deepcopy(r.model);key=list(r.key);energy=int(v.get('energy',r.config['energy']));payload=int(v.get('payload',r.config['payload']))
        n=max(10,min(600,int(v.get('tests',100))));seed=int(v.get('seed',570001))
        r.launch_benchmark(model,key,energy,payload,n,seed,periodic=False)
        return jsonify({'ok':True,'status':r.benchmark_status})

@app.get('/api/export/checkpoint')
def export_checkpoint():
    with lock:r.write_checkpoint()
    return send_file(CHECKPOINT,as_attachment=True,download_name='mystery_cage_v16_checkpoint.json')
@app.get('/api/export/history')
def export_history():
    with lock:hist=copy.deepcopy(r.history)
    output=io.StringIO();fields=['day','seed','best','mean','anySolved','nSolved','visits','travel','delivered','examples','feedbacks','reason','invalid','clues','routeReward','routeSettles']
    writer=csv.DictWriter(output,fieldnames=fields,extrasaction='ignore');writer.writeheader()
    for i,row in enumerate(hist):writer.writerow({'day':i+1,**row})
    b=io.BytesIO(output.getvalue().encode('utf-8'));return send_file(b,mimetype='text/csv',as_attachment=True,download_name='mystery_cage_v16_history.csv')
@app.get('/api/export/benchmark')
def export_benchmark():
    with lock:
        if r.benchmark_result is None:abort(404)
        data=json.dumps(r.benchmark_result,indent=2).encode()
    return send_file(io.BytesIO(data),mimetype='application/json',as_attachment=True,download_name='mystery_cage_v16_matched_benchmark.json')
@app.post('/api/import')
def api_import():
    protected()
    with lock:
        if r.running:return jsonify({'error':'Pause training first'}),409
    body=request.get_json(silent=True)
    if not isinstance(body,dict):return jsonify({'error':'Expected JSON checkpoint or v15 biopsy'}),400
    try:
        if body.get('version') in ('15.0','15.1'):
            live=body['live'];model=load_model(live['models']);reset_packet_policies(model)
            hist=live.get('history',[]);key=live['lawForAudit'];legacy={'source_version':body['version'],'original_day':live.get('day'),'packet_router_reset':True}
        elif body.get('version')=='16.0':
            model=load_model(body['model']);hist=body.get('history',[]);key=body['key'];legacy=body.get('legacy')
        else:raise ValueError('Not a v15/15.1 biopsy or a v16 checkpoint')
        if len(key)!=3 or any(type(x)!=int or x not in range(5) for x in key):raise ValueError('Invalid hidden rule key')
        if len(hist)>200000:raise ValueError('Excessive history length')
        with lock:
            r.model=model;r.history=hist;r.key=key;r.legacy=legacy;r.world=None;r.day=len(hist)+1
            r.next_seed=int(body.get('next_seed',192000));r.note(f'Imported {len(hist)} completed episodes; retained city policies.');r.write_checkpoint()
        return jsonify({'ok':True})
    except Exception as exc:return jsonify({'error':str(exc)}),400

if __name__=='__main__':
    print('Mystery-Cage v16 · local server at http://127.0.0.1:8765',flush=True)
    app.run(host='127.0.0.1',port=int(os.environ.get('PORT',8765)),threaded=True,debug=False,use_reloader=False)
