"""Mystery-Cage v16: independent local knowledge, transported evidence, delayed credit.
Faithful to v15.1 puzzle structure, deliberately NEW packet policy learner.
The audit key is ONLY used for puzzle generation, validation and reporting.
"""
from __future__ import annotations
import copy, math, random, statistics
from dataclasses import dataclass, field

N=6; S=36; CITIES=12; PACKETS=3; OPS=['+','×','Δ','max','min']
CAGE_OF=[(i//6)*3+(i%6)//2 for i in range(S)]
CAGE_CELLS=[(k//3*6+(k%3)*2,k//3*6+(k%3)*2+1) for k in range(18)]
PEERS=[tuple(sorted(set([i//6*6+x for x in range(6)]+[x*6+i%6 for x in range(6)]))) for i in range(S)]
ALL=(1<<6)-1

def clamp(x,a,b): return max(a,min(b,x))
def calc(op,a,b): return (a+b,a*b,abs(a-b),max(a,b),min(a,b))[op]
def bit(v): return 1<<(v-1)
def count(g): return sum(bool(v) for v in g)
def mean(x): return sum(x)/len(x) if x else 0

def latin(R):
    rr=list(range(6));cc=list(range(6));dd=list(range(1,7));R.shuffle(rr);R.shuffle(cc);R.shuffle(dd)
    return [dd[(rr[i//6]+cc[i%6])%6] for i in range(S)]

def solution_count(givens,cages,key,cap=2,max_nodes=2400):
    # Fail closed on pathological enumeration. An exhausted search is NOT a proof
    # of uniqueness; the generator will add more given digits and retry.
    g=list(givens);found=0;nodes=0;exhausted=False
    def dfs():
        nonlocal found,nodes,exhausted
        if found>=cap or exhausted:return
        nodes+=1
        if nodes>max_nodes:
            exhausted=True;return
        who=-1;opts=None
        for i,v in enumerate(g):
            if v:continue
            candidate=[];k=CAGE_OF[i];other=CAGE_CELLS[k][0] if CAGE_CELLS[k][1]==i else CAGE_CELLS[k][1]
            used={g[z] for z in PEERS[i] if g[z]}
            for x in range(1,7):
                if x in used:continue
                if g[other] and calc(key[cages[k]['t']],x,g[other])!=cages[k]['target']:continue
                candidate.append(x)
            if not candidate:return
            if opts is None or len(candidate)<len(opts):who,opts=i,candidate
            if len(candidate)==1:break
        if who<0:found+=1;return
        for v in opts:
            g[who]=v;dfs();g[who]=0
            if found>=cap or exhausted:break
    dfs();return cap if exhausted else found

def make_puzzle(seed,key):
    R=random.Random(seed); sol=latin(R)
    cages=[]
    for k,(i,j) in enumerate(CAGE_CELLS):
        t=(k+R.randrange(3))%3;cages.append({'t':t,'target':calc(key[t],sol[i],sol[j])})
    order=list(range(S));R.shuffle(order);givens=[0]*S;n=0;valid=False
    for i in order:
        givens[i]=sol[i];n+=1
        if n<8:continue
        if n%2==0 or n>=24:
            if solution_count(givens,cages,key)==1:valid=True;break
    return {'seed':seed,'sol':sol,'cages':cages,'givens':givens,'clues':n,'unique':valid}

def data_key(f):return ('d',f['i'],f['v']) if f['k']=='d' else ('ex',f['id'])
@dataclass
class Memory:
    g:list=field(default_factory=lambda:[0]*S)
    facts:dict=field(default_factory=dict)
    examples:dict=field(default_factory=dict)
    inferences:int=0
    def put(self,f):
        key=data_key(f)
        if key in self.facts:return False
        if f['k']=='d':
            i=f['i'];v=f['v']
            if self.g[i] and self.g[i]!=v:raise ValueError('Contradictory transported digit')
            if self.g[i]==v:return False
            self.g[i]=v
        else:
            if f['id'] in self.examples:return False
            self.examples[f['id']]=dict(f)
        self.facts[key]=dict(f);return True
    def operator_mask(self,t):
        mask=31
        for e in self.examples.values():
            if e['t']==t:
                for op in range(5):
                    if calc(op,e['a'],e['b'])!=e['target']:mask&=~(1<<op)
        return mask

def candidates(mem,p):
    m=[bit(v) if v else ALL for v in mem.g]
    for _ in range(12):
        changed=False
        for i in range(S):
            if mem.g[i]:continue
            mask=m[i]
            for j in PEERS[i]:
                if mem.g[j]:mask&=~bit(mem.g[j])
            if mask!=m[i]:m[i]=mask;changed=True
        for k,(i,j) in enumerate(CAGE_CELLS):
            cage=p['cages'][k];allowed=mem.operator_mask(cage['t']);a=b=0
            for x in range(1,7):
                if not (m[i]&bit(x)):continue
                for y in range(1,7):
                    if x==y or not(m[j]&bit(y)):continue
                    if any(allowed&(1<<o) and calc(o,x,y)==cage['target'] for o in range(5)):
                        a|=bit(x);b|=bit(y)
            if a!=m[i] or b!=m[j]:m[i]=a;m[j]=b;changed=True
        if not changed:break
    return m

def proposals(mem,p):
    m=candidates(mem,p);out=[];seen=set()
    for i in range(S):
        if not mem.g[i] and m[i].bit_count()==1:
            out.append({'k':'d','i':i,'v':m[i].bit_length(),'rule':'naked'});seen.add(i)
    for a in range(12):
        cells=[a*6+q if a<6 else q*6+a-6 for q in range(6)]
        for v in range(1,7):
            if any(mem.g[i]==v for i in cells):continue
            hits=[i for i in cells if not mem.g[i] and (m[i]&bit(v))]
            if len(hits)==1 and hits[0] not in seen:
                out.append({'k':'d','i':hits[0],'v':v,'rule':'hidden'});seen.add(hits[0])
    return out

def new_model():
    return {'route':[[0.0]*7 for _ in range(3)],'sendP':[[0.0]*5 for _ in range(3)],
      'sendC':[[0.0]*5 for _ in range(12)],'chooseP':[[0.0]*4 for _ in range(3)],
      'chooseC':[[0.0]*4 for _ in range(12)],
      'ruleP':[[[0.0]*5 for _ in range(3)] for _ in range(3)],
      'ruleC':[[[0.0]*5 for _ in range(3)] for _ in range(12)],
      'baselineP':[0.0]*3,'baselineC':[0.0]*12,
      'update':{'packet':0,'city':0,'examples':0,'feedback':0,'route':0}}

def load_model(old):
    m=new_model()
    for k in m:
        if k in old and isinstance(old[k],type(m[k])):m[k]=copy.deepcopy(old[k])
    m['update'].setdefault('route',0)
    return m

def reset_packet_policies(m,keep_semantics=True):
    m['route']=[[0.0]*7 for _ in range(3)]
    m['chooseP']=[[0.0]*4 for _ in range(3)]
    # Existing score-weighted message preferences are preserved; rule P is evidence ranks only.
    if not keep_semantics:m['sendP']=[[0.0]*5 for _ in range(3)]
    m['baselineP']=[0.0]*3

def dot(w,f):return sum(a*b for a,b in zip(w,f))
def policy_pick(items,feat,weights,R,kind='random',temp=.45):
    if not items:return None
    fs=[feat(item) for item in items]
    if kind=='random':idx=R.randrange(len(items));probs=[1/len(items)]*len(items)
    else:
        scores=[dot(weights,f) for f in fs]
        if kind=='fixed':idx=max(range(len(items)),key=scores.__getitem__);probs=[1.0 if i==idx else 0.0 for i in range(len(items))]
        else:
            highest=max(scores);ex=[math.exp(clamp((s-highest)/temp,-40,0)) for s in scores];total=sum(ex);probs=[v/total for v in ex]
            pick=R.random();acc=0;idx=len(items)-1
            for i,q in enumerate(probs):
                acc+=q
                if pick<=acc:idx=i;break
    return {'item':items[idx],'features':fs[idx],'allFeatures':fs,'probabilities':probs,'idx':idx}

def policy_gradient(w,chosen,all_f,probs,reward,lr=.04,baseline=0,maxweight=3.0):
    if not all_f or len(all_f)<2:return
    # True score-function gradient: chosen context minus choice-probability weighted context.
    adv=clamp(reward-baseline,-3,3)
    for j in range(len(w)):
        average=sum(q*f[j] for f,q in zip(all_f,probs));grad=chosen[j]-average
        w[j]=clamp(w[j]+lr*adv*grad,-maxweight,maxweight)
    # Center nuisance bias terms; constant coordinates automatically have zero gradient.

def old_update(w,f,adv,lr=.02):
    for j in range(len(w)):w[j]=clamp(w[j]+lr*clamp(adv,-2,2)*f[j],-2.8,2.8)

def update_from_example(model,e):
    t=e['t']
    for op in range(5):model[t][op]=clamp(model[t][op]+(.4 if calc(op,e['a'],e['b'])==e['target'] else -.5),-30,30)

def accuracy(model,key):return sum(model[t].index(max(model[t]))==key[t] for t in range(3))
def related(f,d,p):
    if f['k']=='ex':return p['cages'][CAGE_OF[d['i']]]['t']==f['t']
    return f['i']//6==d['i']//6 or f['i']%6==d['i']%6 or CAGE_OF[f['i']]==CAGE_OF[d['i']]

def fact_features(f,src,dst):
    if f['k']=='d':
        i=f['i'];region=set(PEERS[i]);region.update(CAGE_CELLS[CAGE_OF[i]])
        return [1,1,sum(dst.g[j]==0 for j in region)/15,0,1/(1+len(src.facts))]
    allowed=dst.operator_mask(f['t']);other=sum(1<<o for o in range(5) if calc(o,f['a'],f['b'])==f['target'])
    return [1,0,0,clamp(allowed.bit_count()-(allowed&other).bit_count(),0,3),1/(1+len(dst.examples))]

@dataclass
class City:
    id:int;energy:int;mem:Memory=field(default_factory=Memory)
    served:int=0;score:float=0;feedback:float=0;disabled:bool=False;last:str=''
@dataclass
class Packet:
    id:int;city:int;mem:Memory=field(default_factory=Memory)
    visits:int=0;travel:float=0;board:list=field(default_factory=list)
    pending_route:dict|None=None;solved:bool=False

def new_card():return {'visits':0,'received':0,'sent':0,'credit':0.,'debt':0.,'positive':0,'negative':0,'pending':[]}

class World:
    def __init__(self,seed,key,model,arm='both',energy=3,payload=2,train=True,disabled=()):
        self.seed=seed;self.key=key;self.model=model;self.arm=arm;self.energy=energy;self.payload=payload;self.limit=energy*CITIES
        self.p=make_puzzle(seed,key);self.R=random.Random(seed+17);self.train=train
        self.cities=[City(i,energy,disabled=i in disabled) for i in range(CITIES)]
        self.packets=[Packet(i,(i*4)%12,board=[new_card() for _ in range(CITIES)]) for i in range(PACKETS)]
        self.visits=0;self.turn=0;self.delivered=0;self.examples=0;self.feedbacks=0;self.city_reason=0;self.packet_reason=0;self.invalid=0;self.done=False;self.solved=False;self.log=[];self.route_rewards=0.;self.route_settles=0
        ids=[i for i,v in enumerate(self.p['givens']) if v];self.R.shuffle(ids)
        for k,i in enumerate(ids):
            for j in (k%12,(k+5)%12):self.cities[j].mem.put({'k':'d','i':i,'v':self.p['givens'][i]})
        for j in range(3):
            for i in ids[j*2:j*2+2]:self.packets[j].mem.put({'k':'d','i':i,'v':self.p['givens'][i]})
        for c in self.cities:
            t=c.id%3
            for q in range(2):
                a=self.R.randint(1,6);b=self.R.randint(1,6);e={'k':'ex','t':t,'a':a,'b':b,'target':calc(key[t],a,b),'id':c.id*2+q};c.mem.put(e)
                if train and self.city_training: update_from_example(model['ruleC'][c.id],e);model['update']['examples']+=1
    @property
    def packet_training(self):return self.arm in ('both','packets','city_fixed','packet_fixed','packet_only')
    @property
    def city_training(self):return self.arm in ('both','cities','city_fixed','packet_fixed','city_only')
    @property
    def route_fixed(self):return self.arm in ('city_fixed','packet_fixed','fixed')
    def route_features(self,p,c):
        card=p.board[c.id];dist=min(abs(p.city-c.id),12-abs(p.city-c.id))/6
        rw=self.model['ruleP'][p.id][c.id%3];sorted_rw=sorted(rw,reverse=True)
        uncert=clamp(1-(sorted_rw[0]-sorted_rw[1])/4,0,1)
        # Public beacon only; no private facts or solutions are exposed.
        return [1,c.energy/max(1,self.energy),clamp(len(c.mem.facts)/20,0,1.5),clamp(len(c.mem.examples)/5,0,1.5)*uncert,
            -dist,clamp(card['credit']/(1+card['visits']),-2,2),-min(1,card['visits']/12)]
    def choose_city(self,p):
        choices=[c for c in self.cities if not c.disabled and c.energy>0]
        if len(choices)>1:choices=[c for c in choices if c.id!=p.city]
        if not choices:return None
        kind=('fixed' if self.route_fixed or self.arm=='fixed' else 'soft' if self.packet_training else 'random')
        weights=[0,.4,.5,.55,1.7,.1,-.3] if kind=='fixed' else self.model['route'][p.id]
        select=policy_pick(choices,lambda c:self.route_features(p,c),weights,self.R,kind,.55 if self.train else .25)
        return select
    def pick_message(self,src,dst,who,idx):
        arr=[f for f in src.facts.values() if data_key(f) not in dst.facts and (dst.g[f['i']]==0 if f['k']=='d' else f['id'] not in dst.examples)]
        if not arr:return None
        kind='fixed' if self.arm=='fixed' else 'soft' if ((who=='city' and self.city_training) or (who=='packet' and self.packet_training)) else 'random'
        weights=[0,1,1.4,1.8,.2] if kind=='fixed' else self.model['sendC' if who=='city' else 'sendP'][idx]
        return policy_pick(arr,lambda f:fact_features(f,src,dst),weights,self.R,kind,.38 if self.train else .22)
    def exchange(self,src,dst,who,sender,receiver):
        changed=0;examples=0;out=[]
        for _ in range(self.payload):
            s=self.pick_message(src,dst,who,sender)
            if not s:break
            f=s['item'];accepted=dst.put(f)
            if not accepted:continue
            changed+=1;self.delivered+=1
            if f['k']=='ex':
                examples+=1;self.examples+=1
                if self.train and ((who=='city' and self.packet_training) or (who=='packet' and self.city_training)):
                    rm=self.model['ruleP'][receiver] if who=='city' else self.model['ruleC'][receiver]
                    update_from_example(rm,f);self.model['update']['examples']+=1
            if who=='city':
                card=self.packets[receiver].board[sender];card['received']+=1
                card['pending'].append({'f':dict(f),'age':0,'credited':False,'settled':False,'updated':False,
                  'select':{'features':s['features'],'allFeatures':s['allFeatures'],'probabilities':s['probabilities']}})
            elif self.train and self.packet_training:
                # Evidence novelty is a bounded, directly observed learning signal.
                policy_gradient(self.model['sendP'][sender],s['features'],s['allFeatures'],s['probabilities'],.7 if f['k']=='d' else .6,lr=.028,baseline=.35)
                self.model['update']['packet']+=1
            out.append(f)
        return changed,examples,out
    def reason(self,mem,who,id):
        derived=[]
        for _ in range(2):
            ps=proposals(mem,self.p)
            if who=='city':
                ps=[f for f in ps if CAGE_OF[f['i']]%12==id%12 or f['i']%6==id%6 or f['i']//6==id%6]
            if not ps:break
            trained=self.city_training if who=='city' else self.packet_training
            rule_model=self.model['ruleC' if who=='city' else 'ruleP'][id];weights=self.model['chooseC' if who=='city' else 'chooseP'][id]
            def features(f):
                r=rule_model[self.p['cages'][CAGE_OF[f['i']]]['t']];sort=sorted(r,reverse=True)
                return [1,int(f.get('rule')=='naked'),1-len(mem.facts)/60,clamp((sort[0]-sort[1])/4,0,1)]
            choice=policy_pick(ps,features,weights,self.R,'fixed' if self.arm=='fixed' else 'soft' if trained else 'random',.32)
            if not choice or not mem.put(choice['item']):break
            derived.append(choice['item']);mem.inferences+=1
            if self.train and trained:
                # Centered comparative update, unlike v15.1's unconditional +1 (saturated at +4).
                policy_gradient(weights,choice['features'],choice['allFeatures'],choice['probabilities'],.6,lr=.025,baseline=.15,maxweight=2.8)
                self.model['update']['city' if who=='city' else 'packet']+=1
        return derived
    def advance_ledger(self,p,derived):
        for card in p.board:
            for item in card['pending']:
                if item['settled']:continue
                item['age']+=1
                if item['age']>=2 and any(related(item['f'],d,self.p) for d in derived):
                    item['credited']=True;item['settled']=True;card['debt']+=1;card['positive']+=1;card['credit']+=1
                elif item['age']>7:
                    item['settled']=True;card['debt']-=.18;card['negative']+=1;card['credit']-=.18
    def feedback(self,p,c):
        card=p.board[c.id];delta=card['debt']
        if abs(delta)<1e-10:return 0.
        card['debt']=0;card['positive']=0;card['negative']=0;c.feedback+=delta;self.feedbacks+=1;self.model['update']['feedback']+=1
        if self.train and self.city_training:
            for item in card['pending']:
                if item['settled'] and not item['updated']:
                    s=item['select'];policy_gradient(self.model['sendC'][c.id],s['features'],s['allFeatures'],s['probabilities'],1 if item['credited'] else -.3,lr=.09,baseline=.2)
                    item['updated']=True;self.model['update']['city']+=1
        # Routing policy updates happen from SAVED pre-move decisions, NOT from here.
        return delta
    def settle_previous_route(self,p):
        old=p.pending_route
        if not old:return
        # Only credit evidence from the original destination. Later deductions
        # that actually relate to facts received there increment that city's
        # packet-local scorecard; an unrelated city's feedback earns nothing.
        destination_card=p.board[old['destination']]
        downstream=destination_card['credit']-old['credit_at']
        reward=old['reward']+.45*clamp(downstream,-1,3)
        if self.train and self.packet_training and not self.route_fixed:
            baseline=self.model['baselineP'][p.id]
            policy_gradient(self.model['route'][p.id],old['features'],old['allFeatures'],old['probabilities'],reward,lr=.085,baseline=baseline)
            self.model['baselineP'][p.id]=.93*baseline+.07*reward
            self.model['update']['packet']+=1;self.model['update']['route']+=1
        self.route_rewards+=reward;self.route_settles+=1;p.pending_route=None
    def flush_routes(self):
        for p in self.packets:
            if p.pending_route:self.settle_previous_route(p)
    def step(self):
        if self.done:return False
        p=self.packets[self.turn%3];pick=self.choose_city(p)
        if not pick:self.done=True;self.flush_routes();return False
        c=pick['item'];dist=min(abs(p.city-c.id),12-abs(p.city-c.id))/6
        before=count(p.mem.g);origin=p.city;p.city=c.id;p.travel+=dist;p.visits+=1;c.energy-=1;c.served+=1;self.visits+=1
        feedback=self.feedback(p,c)
        up=down=0;cr=pr=[]
        if self.arm!='silent':
            up,_,_=self.exchange(p.mem,c.mem,'packet',p.id,c.id)
            cr=self.reason(c.mem,'city',c.id)
            down,ex,_=self.exchange(c.mem,p.mem,'city',c.id,p.id)
        pr=self.reason(p.mem,'packet',p.id)
        self.advance_ledger(p,pr)
        self.settle_previous_route(p)
        new=max(0,count(p.mem.g)-before)
        # Marginal novelty plus future related work. Zero distance is not a free feature.
        reward=clamp(.18*down+.52*new+.35*len(pr)-.65*dist-.12,-1.5,3.5)
        p.pending_route={'features':pick['features'],'allFeatures':pick['allFeatures'],'probabilities':pick['probabilities'],
            'distance':dist,'destination':c.id,'origin':origin,'credit_at':p.board[c.id]['credit'],'reward':reward}
        p.board[c.id]['visits']+=1;p.board[c.id]['sent']+=up
        self.city_reason+=len(cr);self.packet_reason+=len(pr);c.score+=down
        self.log.append({'visit':self.visits,'packet':p.id,'city':c.id,'sent':up,'received':down,'inferences':len(cr)+len(pr), 'new':new, 'distance':round(dist,3),'returnCredit':round(feedback,2),'routeReward':round(reward,3)})
        if len(self.log)>100:self.log.pop(0)
        self.turn+=1
        # Audit is outside actor decision-making. Any invalid inference stops the episode.
        sol=self.p['sol']
        for agent in (*self.cities,*self.packets):
            for i,v in enumerate(agent.mem.g):
                if v and v!=sol[i]:
                    self.invalid+=1;self.done=True;raise AssertionError(f'Invalid local deduction r{i//6+1}c{i%6+1}, {v} != {sol[i]}')
        for pk in self.packets:pk.solved=count(pk.mem.g)==36
        self.solved=any(pk.solved for pk in self.packets)
        if self.visits>=self.limit or self.solved:
            self.done=True;self.flush_routes()
        return True
    def run(self):
        while not self.done:self.step()
        return self.outcome()
    def outcome(self):
        nk=[count(p.mem.g) for p in self.packets]
        return {'best':max(nk),'mean':mean(nk),'anySolved':int(self.solved),'nSolved':sum(p.solved for p in self.packets),
          'visits':self.visits,'travel':sum(p.travel for p in self.packets),'delivered':self.delivered,'examples':self.examples,
          'feedbacks':self.feedbacks,'reason':self.city_reason+self.packet_reason,'invalid':self.invalid,
          'knownRules':[accuracy(self.model['ruleP'][j],self.key) for j in range(3)],'clues':self.p['clues'],
          'routeReward':self.route_rewards,'routeSettles':self.route_settles,'seed':self.seed}
    def snapshot(self):
        return {'seed':self.seed,'visits':self.visits,'limit':self.limit,'solved':self.solved,'done':self.done,'outcome':self.outcome(),
          'cages':self.p['cages'],'packetGrids':[p.mem.g for p in self.packets],
          'packetSites':[p.city for p in self.packets],
          'packets':[{'id':p.id,'cells':count(p.mem.g),'visits':p.visits,'travel':round(p.travel,2),'rulePredictions':[r.index(max(r)) for r in self.model['ruleP'][p.id]]} for p in self.packets],
          'cities':[{'id':c.id,'cells':count(c.mem.g),'energy':c.energy,'served':c.served,'feedback':round(c.feedback,2),
                     'rulePredictions':[r.index(max(r)) for r in self.model['ruleC'][c.id]]} for c in self.cities],
          'events':self.log[-15:]}

def frozen_comparison(model,key,start_seed=570001,tests=40,energy=3,payload=2):
    """Same puzzles, frozen weights. Learn vs fixed routing with identical cities."""
    arms=['both','cities','city_fixed','none','fixed','silent']
    results={a:[] for a in arms};mods={}
    for a in arms:
        mm=copy.deepcopy(model)
        if a=='cities':reset_packet_policies(mm)
        if a=='none':mm=new_model()
        if a=='fixed':mm=new_model()
        if a=='silent':mm=new_model()
        mods[a]=mm
    for i in range(tests):
        sd=start_seed+7919*i
        for a in arms:
            w=World(sd,key,mods[a],arm=a,energy=energy,payload=payload,train=False)
            results[a].append(w.run())
    output=[]
    for a in arms:
        rr=results[a];output.append({'arm':a,'solved':sum(x['anySolved'] for x in rr),'rate':mean([x['anySolved'] for x in rr]),
          'best':mean([x['best'] for x in rr]),'travel':mean([x['travel'] for x in rr]),'visits':mean([x['visits'] for x in rr]),
          'delivered':mean([x['delivered'] for x in rr]),'invalid':sum(x['invalid'] for x in rr)})
    return {'testN':tests,'seed':start_seed,'energy':energy,'payload':payload,'table':output,
      'rows':[{a:results[a][i] for a in arms} for i in range(tests)]}
