#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)' || { echo "Python 3.10+ required"; exit 1; }
if [ ! -d .venv ]; then python3 -m venv .venv; fi
.venv/bin/python -m pip install -q -r requirements.txt
(sleep 3; xdg-open 'http://127.0.0.1:8765' >/dev/null 2>&1 || true) &
exec .venv/bin/python app.py
