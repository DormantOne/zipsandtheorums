@echo off
cd /d "%~dp0"
py -3 -c "import sys; assert sys.version_info >= (3,10)"
if errorlevel 1 goto :error
if not exist ".venv\Scripts\python.exe" (
    py -3 -m venv .venv
    if errorlevel 1 goto :error
)
.venv\Scripts\python.exe -m pip install -q -r requirements.txt
if errorlevel 1 goto :error
start "" "http://127.0.0.1:8765"
.venv\Scripts\python.exe app.py
pause
exit /b
:error
echo Python 3.10+ and an internet connection are needed for the first Flask install.
pause
