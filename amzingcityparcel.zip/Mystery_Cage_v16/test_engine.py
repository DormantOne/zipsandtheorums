"""Run with: python -m unittest -v test_engine (requires no web server)."""
import copy, json, math, unittest
from pathlib import Path
from engine import World, load_model, new_model, reset_packet_policies, frozen_comparison, make_puzzle, solution_count

HERE=Path(__file__).parent
class TestEngine(unittest.TestCase):
    def setUp(self):
        self.biopsy=json.loads((HERE/'initial_checkpoint.json').read_text())['live'];self.key=self.biopsy['lawForAudit']
        self.m=load_model(self.biopsy['models']);reset_packet_policies(self.m)
    def test_original_city_weights_preserved(self):
        old=self.biopsy['models'];self.assertEqual(self.m['sendC'],old['sendC'])
        self.assertEqual(self.m['chooseC'],old['chooseC'])
        self.assertTrue(all(sum(abs(x) for x in r)==0 for r in self.m['route']))
    def test_original_decision_coordinates_preserved(self):
        w=World(304123,self.key,self.m,arm='both',energy=3,payload=2,train=True)
        original=w.packets[0].city;w.step();p=w.packets[0];record=p.pending_route
        self.assertEqual(record['origin'],original)
        self.assertEqual(record['destination'],p.city)
        dist=min(abs(original-p.city),12-abs(original-p.city))/6
        self.assertAlmostEqual(record['distance'],dist)
        self.assertAlmostEqual(record['features'][4],-dist)
        self.assertGreater(dist,0)
    def test_independent_deductions_accurate_after_law_shift(self):
        for key in [self.key,[3,0,4],[0,1,2]]:
            for i in range(9):
                w=World(200100+2347*i,key,self.m,'both',3,2,True)
                result=w.run()
                self.assertEqual(result['invalid'],0)
                self.assertLessEqual(result['visits'],36)
                self.assertGreaterEqual(result['best'],0)
    def test_no_transfer_blocks_reconstruction(self):
        for j in range(3):
            w=World(800300+413*j,self.key,new_model(),'silent',energy=3,payload=2,train=False)
            result=w.run();self.assertEqual(result['delivered'],0)
            self.assertEqual(result['anySolved'],0)
    def test_held_out_no_weight_updates(self):
        before=copy.deepcopy(self.m)
        r=frozen_comparison(self.m,self.key,310001,tests=10,energy=3,payload=2)
        self.assertEqual(before,self.m)
        self.assertEqual(len(r['rows']),10)
        self.assertEqual(set(r['rows'][0]),{'both','cities','city_fixed','none','fixed','silent'})
        self.assertTrue(all(x['invalid']==0 for x in r['table']))
    def test_packet_reward_learns_travel_sensitivity(self):
        for i in range(25):World(630001+i*1009,self.key,self.m,'both',3,2,True).run()
        self.assertGreater(self.m['update']['route'],100)
        weights=self.m['route']
        self.assertGreater(sum(abs(x[4]) for x in weights),.001)
        self.assertTrue(all(all(math.isfinite(v) and abs(v)<=3 for v in row) for row in weights))
    def test_puzzle_generation_audited_unique(self):
        for i in range(6):
            p=make_puzzle(234123+i*1200,self.key)
            self.assertTrue(p['unique']);self.assertEqual(solution_count(p['givens'],p['cages'],self.key),1)

if __name__=='__main__':unittest.main()
