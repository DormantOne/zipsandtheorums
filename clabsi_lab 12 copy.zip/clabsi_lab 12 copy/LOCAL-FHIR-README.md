# Local FHIR host — Docker-free, synthetic-only (v0.7.3)

The **default** CLABSI Lab host is a built-in Python HTTP server with SQLite persistence. It exposes a deliberately limited **FHIR R4 REST subset**, not the full HAPI/HL7 FHIR protocol. It uses the *same FHIR JSON resource content and REST retrieval calls* our CLABSI investigator uses against Epic, allowing repeatable fictional-case tests.

## Start

1. Double-click `START-CLABSI.command` on macOS. Python 3 is required; Docker is **not** required.
2. Open the app at `http://127.0.0.1:8858`; select **Local FHIR patients**. It starts/loads automatically without manually refreshing the page.
3. The seven patient IDs are `lab-p001` through `lab-p007`. Select `lab-p007` for the 27-note/31-chunk long chart, and click **Query local FHIR**.
4. Use **Guide me through Local FHIR** if you'd like the interactive spoken tutorial.

## Endpoints (default port 8890)

- `http://127.0.0.1:8890/fhir/metadata` — FHIR R4 CapabilityStatement with explicit subset identification.
- `http://127.0.0.1:8890/fhir/Patient/lab-p007` — resource read.
- `http://127.0.0.1:8890/fhir/DocumentReference?patient=lab-p007&_count=50` — searchset Bundle for notes.
- `http://127.0.0.1:8890/fhir/Binary/<ID>` — Base64-encoded clinical text as a Binary FHIR resource.
- `http://127.0.0.1:8890/fhir/Observation?patient=lab-p007&category=laboratory` — laboratory observations.
- `POST http://127.0.0.1:8890/fhir` with `Bundle.type=transaction` containing `PUT` requests — atomic upserts.

If port 8890 is occupied, the app uses 8891 or 8892; the actual address is shown in the UI. The SQLite store is `local_host/synthetic_fhir.sqlite3` inside the application folder.

## What is implemented and not implemented

Implements: FHIR R4-style resource JSON, `Patient`, `Encounter`, `Observation`, `DiagnosticReport`, `DocumentReference`, `Binary`, `Device`, `DeviceUseStatement`, `Procedure`, `Specimen`, `Condition`, `MedicationRequest`, `MedicationAdministration`; direct read, patient/category search, paging, atomic transaction Bundle import.

Does **not** implement: full FHIR conformance validation, profiling, terminology, standard OAuth/SMART authorization, history/versioning, all search parameters, subscriptions, transactions with arbitrary references, bulk export, ETag updates, or institutional access controls. Its CapabilityStatement explicitly labels the implementation as a limited test subset. No claims of HAPI-equivalent interoperability.

The optional `local_host/compose.yaml` shows a separate HAPI/PostgreSQL configuration for future full-server testing. It is not launched by default and has not been verified on your Mac. Never mix synthetic data with clinical PHI; this host is unauthenticated and bound to loopback only.
