# CLABSI FHIR Lab v0.7.3 — One-click local FHIR without Docker

**Research prototype for fictional patients only. Not validated for real patient care, NHSN surveillance determinations, diagnosis or clinical reporting. Never load production PHI.**

## The one button

On a Mac with Python 3 installed, unzip this package and double-click **`START-CLABSI.command`**. Both `start.command` and `start-local.command` are identical aliases.

The launcher opens Ollama if available, starts the Python application on `127.0.0.1:8858`, and the application starts an independent synthetic-only FHIR R4 REST **subset server** automatically. It needs **no Docker Desktop or HAPI containers**. The local server listens at `127.0.0.1:8890` (fallback `8891` or `8892` if occupied) and stores FHIR JSON in `local_host/synthetic_fhir.sqlite3` using SQLite. It imports seven fictional patients by FHIR transaction POST, retrieves each Patient and searches notes to verify the writes, then populates the patient selector. For `lab-p007`, it returns 27 notes / 31 overlapping chunks.

Click **Local FHIR patients → Query local FHIR**. Or click **Guide me through Local FHIR** for a narrated interactive walkthrough with a draggable instruction panel, current and next controls illuminated, and user-confirmed actions. There is also a Full tour of the less-used features.

For AI investigation, the separate optional Ollama server must have `gpt-oss:120b` installed. Its maximum advertised thinking level is requested (normally `high`), with up to 131072 context tokens and a 32768 output-token budget. No silent model fallback. The app records chunk-level operations, progress, verification and a rubric-based report.

## Important distinction

The built-in host implements a small but genuine JSON-over-HTTP FHIR R4 **subset**: `/fhir/metadata`, REST `GET` resource reads, search sets with pagination, `DocumentReference` and `Binary` records, and atomic transaction Bundles with idempotent PUT entries. It is **not HAPI FHIR and not a fully conformant FHIR R4 server**. It is ideal for controlled retrieval and CLABSI reasoning tests, not for certifying broad interoperability. For a full implementation, `local_host/compose.yaml` is still included as an **optional** Docker/HAPI experiment but is no longer part of normal startup and may require separate configuration/debugging.

The Epic developer-sandbox SMART flow remains separate. It is not affected by the built-in host. Local records are fictional and require no Epic credentials.

## Inspection

- Local FHIR base address shown in the user interface. Usually `http://127.0.0.1:8890/fhir`.
- `GET /fhir/metadata`, `GET /fhir/Patient/lab-p007`, `GET /fhir/DocumentReference?patient=lab-p007` are working JSON endpoints.
- `stop-local.command` stops the application and built-in listener. SQLite persists the fictional records across restarts.
- To reset fictional patients, stop the application, then delete `local_host/synthetic_fhir.sqlite3` and its `-wal`/`-shm` files. The next start recreates everything.
- Local HTTP is loopback-only and unauthenticated. Do not expose it on a network or use real PHI.

## Validation

The package includes unit and real-loopback HTTP tests (`python3 -m unittest discover -p 'test_*.py' -q`). Tests include seven actual FHIR transaction imports, patient searches, note-body reads, 27-note retrieval, 31-chunk processing, pagination, and rejection/rollback of invalid transactions. Actual Ollama 120b inference and macOS Chrome startup remain to be tested on your Mac.

See `TUTORIAL.md` for the step-by-step work-through and `LOCAL-FHIR-README.md` for the exact interface limits.
