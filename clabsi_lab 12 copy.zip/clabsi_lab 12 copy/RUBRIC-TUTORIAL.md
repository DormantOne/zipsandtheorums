# CLABSI Lab v0.6 — Experimental Rubric Reference

For the complete operating guide, including the spoken 42-step Full tour, use **`TUTORIAL.md`**.

## What the rubric does

The rubric is an experimental research checklist that guides all three model passes:

- **Pass 1:** uses each domain's question, look-for list and pitfall as a retrieval/search map.
- **Pass 2:** uses the same domains as an evidence-extraction checklist and asks the model to preserve positive, negative, negated, uncertain and contradictory evidence.
- **Pass 3:** receives the complete rubric and must address every domain, cite verified evidence IDs, and explain missing or contrary evidence.

The model's domain-by-domain reasoning is retained as an advisory. It does not award points. The deterministic evaluator calculates coverage status and points from the canonical evidence ledger.

## Domains and weights

| Domain | Weight | Core question |
|---|---:|---|
| Bloodstream laboratory evidence | 15% | Which cultures, organisms, specimen sources and collection times are documented? |
| Central-line chronology | 15% | Was an eligible line present at the relevant time, and what continuity evidence exists? |
| Encounter and event timing | 15% | Can admission, infection-window and event timing be reconstructed? |
| Secondary bloodstream infection | 15% | What competing sites are documented, and is attribution assessable? |
| Repeat-event and special-case review | 10% | Are prior infections, location history or special criteria relevant? |
| Clinical context and interventions | 10% | What symptoms, treatments and device actions were documented or performed? |
| Evidence provenance and certainty | 10% | Can each assertion be traced to an exact quote/resource and faithful timestamp? |
| Completeness and contradiction audit | 10% | Have evidence, unknowns, endpoint gaps and contradictions been reconciled? |

## Evidence states

- **Supported:** sufficient cited chart evidence addresses the question; does not mean CLABSI-positive.
- **Negative:** explicit evidence establishes absence for the relevant scope/time.
- **Partial:** some evidence exists, but an essential detail remains unverified.
- **Unknown:** not established in the retrieved material; not equivalent to negative.
- **Conflicting:** sources materially disagree; preserve both for adjudication.
- **Not applicable:** the criterion is demonstrably irrelevant to this case.

## Interpretation cautions

- The score measures evidence completeness, not CLABSI probability, clinical certainty or NHSN reportability.
- A positive blood culture is not automatically a complete LCBI definition.
- Insertion before and removal after a culture do not prove uninterrupted presence of the same eligible line.
- Encounter-relative calendar-day arithmetic is not an inpatient day unless inpatient class/status is established, and it is not the NHSN date of event.
- A note saying no definite alternate source was identified is not a complete secondary-source exclusion.
- A medication order is not proof of administration.
- A missing or inaccessible FHIR endpoint is not a clinical negative.

The rubric is editable in `rubric.json` and can be downloaded from the application. It is not a transcription of, nor a substitute for, the current NHSN protocol.
