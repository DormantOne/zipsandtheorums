#!/bin/bash
# CLABSI Lab 0.7.3 — one-click, Docker-free synthetic FHIR + investigator.
set -u
cd "$(dirname "$0")" || exit 1
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
export PORT=8858
export FHIR_BASE_URL='https://fhir.epic.com/interconnect-fhir-oauth/api/FHIR/R4'
export FHIR_CLIENT_ID='5b6f6c37-34ed-467a-80f7-d94fe91e57d0'
export FHIR_REDIRECT_URI='http://127.0.0.1:8858/oauth/callback'
export FHIR_SCOPES='openid fhirUser user/Patient.read user/DocumentReference.read user/Binary.read user/Observation.read user/DiagnosticReport.read user/Encounter.read user/Condition.read'

if command -v python3 >/dev/null 2>&1; then PYTHON="$(command -v python3)"
elif [ -x /opt/homebrew/bin/python3 ]; then PYTHON=/opt/homebrew/bin/python3
elif [ -x /usr/local/bin/python3 ]; then PYTHON=/usr/local/bin/python3
else printf '\nPython 3 is required. Please install Python 3 and try again.\n'; read -r _; exit 1; fi

printf '\n============================================================\n'
printf ' CLABSI FHIR LAB v0.7.3 — ONE CLICK, NO DOCKER\n'
printf ' Built-in synthetic FHIR R4 REST subset + persistent SQLite\n'
printf '============================================================\n'

# Ollama is optional for chart retrieval. Preserve its existing model install.
if ! "$PYTHON" -c 'import urllib.request;urllib.request.urlopen("http://127.0.0.1:11434/api/tags",timeout=1).read()' >/dev/null 2>&1; then
  if [ -d '/Applications/Ollama.app' ] || [ -d "$HOME/Applications/Ollama.app" ]; then
    printf '[Ollama] Opening the local Ollama application…\n'
    open -a Ollama >/dev/null 2>&1 || true
  elif command -v ollama >/dev/null 2>&1; then
    printf '[Ollama] Starting local service…\n'
    (nohup ollama serve >/tmp/clabsi-ollama.log 2>&1 </dev/null &)
  else
    printf '[Ollama] Not installed; FHIR retrieval still works. AI investigation requires gpt-oss:120b.\n'
  fi
else printf '[Ollama] Local service detected.\n'; fi

# Restart only a positively identified old CLABSI Lab listener, not unrelated services.
if command -v lsof >/dev/null 2>&1; then
  pids="$(lsof -nP -tiTCP:${PORT} -sTCP:LISTEN 2>/dev/null | sort -u || true)"
  for pid in $pids; do
    cmd="$(ps -p "$pid" -o command= 2>/dev/null || true)"
    cwd="$(lsof -nP -a -p "$pid" -d cwd -Fn 2>/dev/null | sed -n 's/^n//p' | head -n 1)"
    if [[ "$cmd" == *server.py* && "$(basename "$cwd" 2>/dev/null || true)" == 'clabsi_lab' ]]; then
      printf '[App] Replacing previous CLABSI Lab process %s…\n' "$pid"
      kill -TERM "$pid" 2>/dev/null || true
    else
      printf '\nPort %s belongs to another service (%s). Nothing was stopped.\n' "$PORT" "$pid"
      read -r _; exit 1
    fi
  done
  for _ in $(seq 1 40); do
    if ! lsof -nP -tiTCP:${PORT} -sTCP:LISTEN >/dev/null 2>&1; then break; fi
    sleep 0.2
  done
fi

printf '[FHIR] Starting built-in loopback synthetic server and loading seven patients.\n'
printf '[App] Launching at http://127.0.0.1:%s\n' "$PORT"
printf 'No Docker, no manual patient refresh, no Epic login for fictional local data.\n'
printf 'Keep this Terminal window open; stop-local.command ends the session.\n\n'
(sleep 1.4; open -a 'Google Chrome' "http://127.0.0.1:${PORT}" >/dev/null 2>&1 || open "http://127.0.0.1:${PORT}" >/dev/null 2>&1 || true) &
exec "$PYTHON" -u server.py
