# CLABSI FHIR Lab v0.7.3 — complete operating tutorial

**Research prototype only; synthetic patients and Epic public developer sandbox only.** Not a validated clinical or NHSN adjudication system. No real PHI.

## 1. One-click startup — no Docker or HAPI required

1. Unzip the ZIP and open its `clabsi_lab` folder.
2. Double-click **`START-CLABSI.command`** (or the equivalent `start.command` / `start-local.command`).
3. The Python app opens at `http://127.0.0.1:8858`; a lightweight, SQLite-backed FHIR R4 REST **subset** automatically starts on local port 8890 (or 8891/8892 if already occupied).
4. Seven fictional patient Bundles are stored through actual FHIR POST transactions and verified through FHIR Patient reads and note searches. No Docker, no Epic login and no manual refresh are required.
5. Choose **Local FHIR patients** and select `lab-p007` (27 notes, 31 overlapping text chunks); click **Query local FHIR**. The local FHIR tour explains each button and lets you press it.
6. Click **Check Ollama** to verify your separately installed `gpt-oss:120b`, then **Investigate loaded case**. The multi-pass engine uses its highest supported thinking level, normally HIGH.
7. Review the progress bar, live process log, exact quote verification, evidence states, inspectable rubric, contradictions and downloadable analysis.

**No automatic model downloads or AI inference.** `gpt-oss:120b` is used only when you click Investigate. Local retrieval works with just Python 3; the optional Ollama installation is required for AI analysis.

`stop-local.command` stops the app and its built-in FHIR listener. Fictional patient data persist in `local_host/synthetic_fhir.sqlite3`; the host is unauthenticated and loopback-only and must never contain real patient data.

The built-in host is a limited FHIR R4 REST subset, not a fully compliant FHIR server and not HAPI. It is appropriate for test retrieval through authentic FHIR JSON and REST patterns. For full HAPI interoperability testing, the separate optional Docker configuration is still in `local_host/compose.yaml` but is not part of this default workflow.

## 2. The interactive tutorial

There are three tutorial routes:

- **Start guided walkthrough:** a thorough first run using the built-in synthetic chart. It takes you through source selection, retrieval, all evidence tabs, model readiness, investigation, progress, logs, chunk biopsy, quotes, evidence states, rubric, audit, benchmark, history and downloads.
- **Guide me through Local FHIR:** demonstrates patient discovery and chart retrieval through the built-in host's actual FHIR R4 REST subset endpoints.
- **Full tour — all features:** includes the core walkthrough plus optional Local FHIR and Epic sandbox/SMART OAuth features, including the patient atlas, login helper and cancellation control.

### How the guide works

- The guide highlights the actual control you should use and scrolls it into view.
- You click the highlighted button, tab, dropdown or control yourself. The tutorial does not click expensive actions on your behalf.
- **Next** checks that required actions have happened. If not, it explains what is missing.
- **Back** returns to the prior step.
- **Skip this step** moves past one optional or unavailable feature. **Skip tour** closes the entire guide.
- The tutorial is a detachable floating panel. Drag its header to move it anywhere on screen; **Auto place** returns it to the best position opposite the active control.
- The active control is illuminated in bright cyan (**NOW**); the next control/panel is previewed in the guide and illuminated in amber (**NEXT**) when present on the current page. The rest of the interface remains clickable.
- The first walkthrough defaults to the 27-note long chart, which generates exactly 31 overlapping chunks. It pauses at a checkpoint if fewer than 25 note bodies or fewer than 20 chunks are found, so the walkthrough cannot quietly fall back to the old three-note demo.
- **Speak instructions** is on by default. It uses the browser's speech-synthesis voice to read each step. Uncheck it at any time to stop narration; **Speak this step** repeats the current instruction; **Stop voice** immediately cancels speech. If Chrome has no available speech voice, the text tutorial still works normally.

The Full tour is deliberately longer. It explains less-used controls instead of stopping after the first successful analysis.

## 3. Retrieval views — before the AI runs

Choose a data source in the **Choose evidence** panel.

### Synthetic cases

Choose one of the built-in scenarios. The guided walkthrough defaults to **Long chart — 31-chunk guided stress test** (27 note bodies, exactly 31 chunks). The scenarios are fictional research cases, not independently NHSN-adjudicated gold standards. The intended target is hidden from the investigator and can be inspected later in **Synthetic benchmark**.

### Local FHIR patients

This is the preferred controlled test environment. The persistent SQLite-backed test host stores fictional FHIR R4 resources. CLABSI Lab searches and reads them over FHIR R4 HTTP endpoints. The investigator receives the chart retrieved over HTTP from the local host, not a direct fixture or answer key.

### Authorized Epic

This uses the configured non-production Epic SMART registration and Epic's public developer sandbox. Use only Epic's fictional sandbox users and patient records. The atlas is a small documented sample, not a complete patient census. API/resource availability differs by patient and app registration.

The password helper copies the public test password and opens the Epic OAuth flow. You still enter credentials on Epic's own page. The app does not autofill the external login form or store the password.

### Evidence review tabs

- **Assessment:** initial structured screening. Candidate flags are leads, not a final classification.
- **Timeline:** dated events assembled from FHIR resources and note timestamps. Note time and event time are not necessarily identical.
- **Clinical notes:** decoded note bodies. This is the source text that will be split into chunks.
- **Coverage biopsy:** endpoint/resource counts, pages, empty/error/incomplete states and retrieval limitations. An empty or unavailable endpoint is not a negative clinical finding.
- **Raw FHIR:** original resources. Select a resource in the left pane to inspect its JSON.

FHIR retrieval safety limits are 250 note bodies, 2,000 resources and 40 pages (50 records requested per page). The investigator then allows up to 1,000 text chunks and 500 expanded windows. Any omitted work is recorded and marks the analysis incomplete.

## 4. Ollama 120b — maximum supported reasoning profile

The investigator is deliberately fixed to **`gpt-oss:120b`**. It never silently falls back to a smaller model.

The preflight checks the local Ollama server and `/api/show` metadata. It selects the highest thinking level advertised by that exact installed model. For GPT-OSS the documented levels are **low, medium and high**, so **high is the top supported level**; `max` is not a GPT-OSS level unless the installed model explicitly advertises it. Each model response must include a thinking field or the call is rejected as unverified.

The current profile requests:

- Model: `gpt-oss:120b`
- Thinking: highest level advertised (normally `high` for GPT-OSS)
- Context: up to 131,072 tokens, reduced only if `/api/show` reports a lower model maximum
- Output budget: 32,768 tokens
- Temperature: 1.0, matching the installed model's reported default
- Keep-alive: 30 minutes
- Serial model calls: one at a time; the supplied Mac diagnostic showed no throughput benefit from concurrent requests
- No model fallback and no silent reduction in thinking level

The profile is shown under the Ollama status badge after **Check Ollama**. Your supplied diagnostic reported `gpt-oss:120b` with a 131,072-token context and full GPU offload on the M4 Max. The app rechecks the installed model rather than assuming those settings have not changed.

A high reasoning setting does not guarantee a correct answer. The app records whether thinking was requested and returned, plus token counts and timing metadata. It does **not** display or store the model's private thinking text; the visible log records operations, concise selection rationales, evidence IDs and verification results.

## 5. Multi-pass investigation — what happens in detail

Click **Investigate loaded case**. This is the expensive step. The engine runs serially through the following stages:

### Preflight and rubric loading

1. Verify Ollama is reachable.
2. Verify the exact `gpt-oss:120b` model is installed.
3. Inspect its advertised thinking levels and context length.
4. Require a returned thinking field on each inference call.
5. Load the experimental rubric. The rubric guides Pass 1 search, Pass 2 extraction and Pass 3 synthesis.

### Chunking

- Each readable note body is split into overlapping chunks.
- Current chunk size: 1,900 characters.
- Current overlap: 300 characters.
- Each chunk has a source note ID, note timestamp, chunk ID, and character start/end offsets.
- The process log records each note's length and number of chunks, then each chunk ID and its source offsets. The built-in long chart has 27 notes and exactly 31 chunks. The investigator can screen up to 1,000 chunks; it is not limited to three.

### Pass 1 — chunk screening

- The model reads every chunk in small batches of four.
- It uses the rubric domains as a search map: microbiology, line chronology, timing, secondary source, special cases, clinical context, provenance and consistency.
- For every chunk, the log records the model flag, lexical safety-net flag, selected/not-selected state, reason and flags.
- A lexical safety net can retain an obvious clinical clue even if the model does not select the chunk.

### Flanking-context expansion

- Every selected chunk brings in its immediately preceding and following chunk from the same note, where available.
- Overlapping ranges are merged into context windows.
- The log records every added neighbor and every context window, including note ID, source offsets, character count and source chunk IDs.

### Pass 2 — evidence extraction

- The model reads each expanded context window using the rubric as an extraction checklist.
- It extracts positive, negative, negated, uncertain and contradictory evidence.
- A quotation is accepted only if it is found verbatim inside the cited original note window and has a minimum length.
- Accepted quotes receive stable evidence IDs and source offsets.
- Non-verbatim or unsupported quotes are rejected and logged.
- Missing-data suggestions are proposals, not facts; they are later reconciled against the evidence ledger.

### Pass 3 — rubric-guided synthesis

- The model receives only verified quotations plus structured FHIR sources, including Encounter, culture, line/device, specimen, medication and endpoint-coverage context where available.
- The full rubric, questions, look-for items and pitfalls are included in the synthesis prompt.
- The model returns a research-only summary, findings, unresolved items, follow-up queries and a domain-by-domain advisory.
- A deterministic evaluator—not the model—assigns rubric coverage status and points from the canonical evidence ledger.

### Evidence integrity and report assembly

- The consistency audit checks unsupported line-continuity and inpatient-day claims, stale absence statements and missing-data suggestions that duplicate already retrieved evidence.
- The final report is assembled from the reconciled evidence ledger, rubric, verified quotations and audit.

## 6. Progress bar and live process log

The progress panel is immediately below the investigation controls and above the error log.

The bar tracks the full workflow, not merely the number of Pass 1 chunks:

- Preflight and inventory
- Chunking
- Pass 1 screening
- Flanking-context expansion
- Pass 2 verified extraction
- Pass 3 rubric-guided synthesis
- Deterministic audit and final report assembly

The live counters show:

- Chunks screened / total chunks
- Selected chunks
- Expanded chunks
- Context windows processed / total windows
- Verified and rejected quotations
- Chunks and windows skipped by safety caps

The operational log records note inventory, each chunk and offset, every model batch, every model call's timing/token metadata, every selection decision, each flanking chunk, every context window, accepted/rejected quotations, each rubric domain score, audit outcomes and final report assembly.

Use the filter to isolate Pass 1, flanking, Pass 2, Pass 3, rubric or errors. **Show all** expands the visible log beyond the latest 180 entries. **Download log** exports the entire available operational trace.

The separate **Error log** is directly below the process log. It shows actual errors and explicit coverage-cap warnings. A clean error log does not prove complete retrieval; inspect skipped-work counters and the `analysis_incomplete` flag.

Safety caps are explicit: up to 1,000 chunks and 500 expanded context windows in this build. If a case exceeds a cap, the application records the number and IDs/ranges not processed, marks the analysis incomplete, and includes the warning in the final report. Do not treat a capped analysis as a complete chart review.

## 7. Inspecting the investigator output

The investigator tabs are:

- **Investigator summary:** synthesis, suspicion label, key findings, unresolved questions, follow-up queries and run counts.
- **Evidence states:** one canonical ledger. Each question is supported, negative, unknown, conflicting or not applicable. Unknown is not the same as negative.
- **Chunk biopsy:** every screened chunk, model decision, lexical safety-net result, reason, flags and expanded windows.
- **Verified quotations:** exact quote, claim, evidence ID, source note, date basis, certainty and source offsets. Rejected quotes appear separately.
- **Training rubric:** the complete inspectable rubric and its domain questions/look-for/pitfalls, deterministic coverage status, evidence IDs and points. Expand each model rubric advisory to inspect its reasoning; the model advisory does not determine the score. Expand the raw JSON to inspect the exact rubric object.
- **Consistency audit:** removed contradictions, rewritten absence claims, unsupported inferences and Pass-2 missing-data proposals reconciled against the ledger.
- **Synthetic benchmark:** reveals the scenario's hidden research target. It is not formal NHSN ground truth.
- **Previous synthetic runs:** loads prior synthetic/local synthetic runs from SQLite for reproducibility.

## 8. Final downloadable analysis

When an investigation completes, use:

1. **Download final analysis (.md):** a readable report named with patient name, case number, case ID and run ID. It includes patient/FHIR identity, source, model profile, retrieval counts, chunk/window counts, verified quotations, chronology, synthesis, findings, unresolved questions, rubric table, canonical evidence states and consistency audit.
2. **Download complete trace (.json):** report metadata plus the full investigator object, including per-chunk screening, expansions, context windows, model metrics, process log, quotations, rubric results, evidence ledger and audit.
3. **Download log:** separate JSON operational trace.
4. **Download rubric:** the complete editable rubric JSON.

The case number is generated as `CLABSI-YYYYMMDD-CASEID-RUNID`. Patient name and FHIR Patient.id are taken from the retrieved Patient resource where available; if the server does not expose a name, the report labels it as unknown or uses the scenario name rather than inventing a patient identity.

## 9. Experimental rubric — how to interpret it

The rubric has eight weighted domains:

1. Bloodstream laboratory evidence — 15%
2. Central-line chronology — 15%
3. Encounter and event timing — 15%
4. Secondary bloodstream infection — 15%
5. Repeat-event and special-case review — 10%
6. Clinical context and interventions — 10%
7. Evidence provenance and certainty — 10%
8. Completeness and contradiction audit — 10%

The deterministic score is **evidence completeness only**. It is not probability of CLABSI, clinical certainty, or NHSN reportability. A high score can occur in a case that is not CLABSI-positive; a low score may simply reflect missing documentation or inaccessible endpoints.

## 10. Troubleshooting

### Ollama is not running

Start Ollama from Applications or the menu bar, then click **Check Ollama**. The expected local API is `http://127.0.0.1:11434`.

### `gpt-oss:120b` is missing

Run `ollama list` in Terminal. If it is not installed, install/pull the exact model `gpt-oss:120b`. The investigator will not substitute a smaller model.

### Thinking could not be verified

The app requires the exact installed model to advertise a thinking capability and every inference response to return a thinking field. Check the Ollama version and `/api/show` for `gpt-oss:120b`. The app will fail closed rather than claiming a high-thinking run when it cannot verify it.

### Local FHIR patient list is empty

Click **Start Local FHIR automatically** inside the app. It starts the lightweight loopback-only FHIR R4 test host and seeds seven synthetic charts. Docker is not required.

### Epic login succeeds but a FHIR query fails

Check that OAuth returned to CLABSI Lab and the token is present. The selected resource scopes and Epic's sandbox test data determine which resources can be read. A missing or forbidden resource is recorded as an endpoint limitation, not as a clinical negative.

### Investigation takes a long time

This is expected for `gpt-oss:120b` with high thinking, especially when a chart contains many chunks and expanded context windows. Follow the progress bar and live process log. **Stop after current Ollama request** asks the worker not to start another model call after the active request returns; it cannot interrupt an in-flight Ollama call.

## 11. Safety and limitations

- Use fictional data only in this experimental build. Do not use production PHI.
- No automated NHSN reportable-CLABSI determination is made.
- The synthetic structured line codes are demonstration conventions, not universal Epic mappings.
- The project does not implement every NHSN LCBI definition, infection-window rule, secondary-BSI attribution rule, repeat-infection timeframe, MBI-LCBI criterion, location exclusion or special-case rule.
- A positive blood culture is not automatically an LCBI or CLABSI.
- Line insertion before and removal after a culture does not prove uninterrupted presence of the same eligible line.
- A note stating that no alternate source was identified is not a complete secondary-source exclusion.
- This application is not production-hardened and has no user authentication for its local loopback interface.

## References

- FHIR R4: https://hl7.org/fhir/R4/
- FHIR R4 subset host: https://hapifhir.io/hapi-fhir/docs/server_jpa/get_started.html
- Epic on FHIR: https://fhir.epic.com/
- CDC NHSN BSI protocol: https://www.cdc.gov/nhsn/psc/bsi/index.html
- Ollama thinking controls: https://docs.ollama.com/capabilities/thinking
- Ollama API: https://docs.ollama.com/api
