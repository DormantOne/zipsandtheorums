'use strict';
let DATA=null,MODE='demo',TAB='assessment',INFO=null;
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
function el(tag,cls,txt){const e=document.createElement(tag);if(cls)e.className=cls;if(txt!==undefined)e.textContent=txt;return e;}
function node(parent,tag,cls,txt){const e=el(tag,cls,txt);parent.appendChild(e);return e;}
function clear(e){e.replaceChildren();}
function chip(status){return el('span','status '+(status||'unknown'),status||'unknown');}
function source(parent,src){if(!src)return;const b=node(parent,'button','linklike',src);b.type='button';b.addEventListener('click',()=>{TAB='raw';renderTabs();selectRaw(src)});}
function renderTabs(){$$('[data-tab]').forEach(b=>b.classList.toggle('active',b.dataset.tab===TAB));render()}
function render(){let v=$('#view');clear(v);if(!DATA){node(v,'p','hint','No case loaded.');return}
 if(TAB==='assessment')renderAssessment(v);
 if(TAB==='timeline')renderTimeline(v);
 if(TAB==='notes')renderNotes(v);
 if(TAB==='coverage')renderCoverage(v);
 if(TAB==='raw')renderRaw(v);
}
function renderAssessment(v){let hero=node(v,'div','hero '+DATA.tone);node(hero,'h2','',DATA.title);node(hero,'p','',DATA.summary);node(hero,'p','mini',DATA.method);
 let cards=node(v,'div','cards');[['FHIR resources',DATA.count],['Clinical notes',Object.keys(DATA.notes||{}).length],['Blood culture records',(DATA.cultures||[]).length]].forEach(p=>{let k=node(cards,'div','stat');node(k,'strong','',String(p[1]));node(k,'span','',p[0])});
 let layout=node(v,'div','grid2');let left=node(layout,'section','');node(left,'h2','','Screening checks');DATA.checks.forEach(c=>{let x=node(left,'div','check');x.append(chip(c.status));node(x,'span','label',c.name);node(x,'div','hint',c.text)});let right=node(layout,'section','');node(right,'h2','','Evidence supporting review');if(!DATA.evidence.length)node(right,'p','hint','No qualifying evidence extracted.');DATA.evidence.forEach(e=>{let x=node(right,'div','evidence');node(x,'div','',e.text);source(x,e.source)});node(right,'h2','','Missing or unresolved');(DATA.missing||[]).forEach(m=>node(right,'p','hint','• '+m));}
function renderTimeline(v){node(v,'h2','','Clinical chronology');node(v,'p','hint','Dates are taken from FHIR timestamps; report time and specimen time are not necessarily identical. Click a source to inspect its FHIR record.');const list=node(v,'div','timeline');if(!DATA.events.length)node(list,'p','hint','No dated events returned');DATA.events.forEach(ev=>{let e=node(list,'div','event '+ev.kind);node(e,'time','',ev.when);node(e,'div','label',ev.label);node(e,'div','hint',ev.detail);source(e,ev.source)})}
function renderNotes(v){node(v,'h2','','Retrieved note contents');node(v,'p','hint','These are the actual decoded note bodies in the synthetic FHIR fixture. In live mode, the program retrieves attachments referenced by DocumentReference, including Binary.');let nn=Object.entries(DATA.notes||{});if(!nn.length)node(v,'p','hint','No note bodies retrieved. Check the Coverage biopsy.');nn.forEach(([rid,n])=>{let e=node(v,'article','note');node(e,'h3','',n.title||rid);node(e,'div','mini',n.date||'No date');if(n.error)node(e,'p','error',n.error);else node(e,'pre','',n.text||'[Empty note]');source(e,rid);if(n.binary)node(e,'div','mini','Attachment: '+n.binary)})}
function renderCoverage(v){node(v,'h2','','Data completeness and endpoint biopsy');node(v,'p','hint','Empty is not a negative clinical finding. Error means the result could not be evaluated. Incomplete indicates retrieval limits.');DATA.coverage.forEach(c=>{let x=node(v,'div','coverage');x.append(chip(c.status));node(x,'strong','',c.label);node(x,'p','mini',`${c.resource} · ${c.count} records · ${c.pages} pages`);if(c.query)node(x,'p','mini','GET '+c.query);if(c.note)node(x,'p','hint',c.note)});node(v,'h3','','Safety boundaries');node(v,'p','hint','The pilot never treats a missing or unauthorized endpoint as a negative result. It does not assert formal CLABSI status. Only the local process communicates with a configured FHIR server; no remote language-model service is used.')}
function renderRaw(v,selected){node(v,'h2','','Original FHIR resource explorer');let spl=node(v,'div','split');let left=node(spl,'div','selectbox');let right=node(spl,'pre','raw');node(right,'span','', 'Choose a source resource to inspect.');let list=(DATA.resources||[]);list.forEach(r=>{let rid=r.resourceType+'/'+r.id;let b=node(left,'button','',rid);b.type='button';b.addEventListener('click',()=>{right.textContent=JSON.stringify(r,null,2);left.querySelectorAll('button').forEach(x=>x.style.color='');b.style.color='#79d2de'})});if(selected)selectRaw(selected);}
function selectRaw(id){RAW_SELECTED=id;if(TAB!=='raw'){TAB='raw';renderTabs()}const r=(DATA.resources||[]).find(x=>x.resourceType+'/'+x.id===id);const p=$('#view pre.raw');if(p)p.textContent=r?JSON.stringify(r,null,2):('Source '+id+' is an attachment or derived value. Original contained document is listed in note pane.')}
function mode(m){MODE=m;$('#demoFields').classList.toggle('hide',m!=='demo');$('#liveFields').classList.toggle('hide',m!=='live');$('#localFields').classList.toggle('hide',m!=='local');$('#demoMode').classList.toggle('on',m==='demo');$('#liveMode').classList.toggle('on',m==='live');$('#localMode').classList.toggle('on',m==='local');$('#runBtn').textContent=m==='demo'?'▶ Run evidence search':m==='local'?'▶ Query local FHIR':'▶ Query Epic FHIR endpoint';$('#runMessage').textContent=m==='demo'?'In-memory synthetic scenario.':m==='local'?'Local FHIR will start automatically if needed.': 'Requires authorization and Epic sandbox.';if(m==='local'&&!LOCAL_PATIENTS_LOADED)ensureLocalFHIR();}

async function setup(){try{INFO=await (await fetch('/api/info',{cache:'no-store'})).json();const cases=$('#caseSelect');INFO.sample_cases.forEach(c=>{let o=el('option','','');o.value=c.id;o.textContent=c.name;cases.appendChild(o)});cases.addEventListener('change',()=>{const c=INFO.sample_cases.find(x=>x.id===cases.value);$('#caseDescription').textContent=c?.summary||''});if([...cases.options].some(o=>o.value==='synth:long_chart'))cases.value='synth:long_chart';cases.dispatchEvent(new Event('change'));$('#connectionStatus').textContent=INFO.connected?'FHIR TOKEN PRESENT · LOCAL PILOT':'DEMO · SYNTHETIC DATA';$('#connectionStatus').className='pill '+(INFO.connected?'ok':'warn');$('#liveHelp').textContent=INFO.base?('Endpoint: '+INFO.base+' · '+(INFO.connected?'token available':'not authenticated')):'Set FHIR_BASE_URL in the startup shell; no live endpoint configured.';$('#patientId').value=INFO.smart_patient_id||'';$('#connectBtn').classList.toggle('hide',!(INFO.client_configured&&INFO.base));}catch(e){$('#runMessage').textContent='Server startup error: '+e.message}}
async function run(){let btn=$('#runBtn');btn.disabled=true;$('#runMessage').textContent='Retrieving and evaluating…';try{let request={mode:MODE,case:$('#caseSelect').value,patient_id:(MODE==='local'?$('#localPatientId').value.trim():$('#patientId').value.trim())};let r=await fetch('/api/analyze',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(request),cache:'no-store'});let data=await r.json();if(!r.ok)throw Error(data.error||'FHIR request failed');DATA=data;TAB='assessment';renderTabs();$('#caseSummary').textContent=data.case_name||'FHIR case screening · clinical evidence retrieval';$('#runMessage').textContent='Completed: '+data.count+' resources. Inspect results below.';$('#saveBtn').disabled=false;}catch(e){$('#runMessage').textContent='Could not complete: '+e.message;DATA=null;$('#saveBtn').disabled=true;render();}finally{btn.disabled=false}}
function exportData(){if(!DATA)return;let blob=new Blob([JSON.stringify(DATA,null,2)],{type:'application/json'});let a=document.createElement('a');let url=URL.createObjectURL(blob);a.href=url;a.download='clabsi_biopsy.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),500)}
$('#demoMode').addEventListener('click',()=>mode('demo'));$('#localMode').addEventListener('click',()=>mode('local'));$('#startLocal').addEventListener('click',()=>ensureLocalFHIR(true));$('#refreshLocal').addEventListener('click',async()=>{const ok=await loadLocalPatients();if(!ok)await ensureLocalFHIR(true)});$('#liveMode').addEventListener('click',()=>mode('live'));$('#runBtn').addEventListener('click',run);$('#saveBtn').addEventListener('click',exportData);$$('[data-tab]').forEach(b=>b.addEventListener('click',()=>{TAB=b.dataset.tab;renderTabs()}));setup();

// CLABSI v0.5 — evidence-integrity investigator, canonical ledger and guided tutorial.
let LABTAB='summary', CURRENT_JOB=null, JOB_TIMER=null, JOB_OUTPUT=null, TRAINING_RUBRIC=null, OLLAMA_STATUS=null, RAW_SELECTED=null, SHOW_ALL_LOG=false, LAST_DOWNLOADS={};
async function getJSON(path){let r=await fetch(path,{cache:'no-store'});let j=await r.json();if(!r.ok)throw Error(j.error||('HTTP '+r.status));return j}
async function postJSON(path,body){let r=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body),cache:'no-store'});let j=await r.json();if(!r.ok)throw Error(j.error||('HTTP '+r.status));return j}
async function atlasInit(){try{let data=await getJSON('/api/atlas');let picker=$('#atlasSelect');data.patients.forEach(p=>{let o=el('option','',p.name+' — '+p.resources);o.value=p.id;picker.appendChild(o)});picker.addEventListener('change',()=>{if(picker.value)$('#patientId').value=picker.value});}catch(e){$('#clipMsg').textContent='Could not load Epic patient atlas: '+e.message}}
async function testClipboard(value){try{await navigator.clipboard.writeText(value);return true}catch(e){return false}}
$('#copyUser').addEventListener('click',async()=>{$('#clipMsg').textContent=(await testClipboard('FHIR'))?'FHIR test username copied.':'Clipboard blocked: type FHIR on the Epic login screen.'});
$('#copyAndConnect').addEventListener('click',async()=>{let success=await testClipboard('EpicFhir11!');if(!success){$('#clipMsg').textContent='Clipboard access denied. Manually copy EpicFhir11! from above before continuing.';return}$('#clipMsg').textContent='Public sandbox password copied. Redirecting to Epic login.';window.location.assign('/oauth/start')});
async function ollamaCheck(){
 let b=$('#ollamaState');
 try{
  const s=await getJSON('/api/ollama');OLLAMA_STATUS=s;
  if(s.reachable&&s.installed&&s.profile){
   const p=s.profile;
   b.textContent=`120b ready · ${String(p.thinking_level).toUpperCase()} · ${Math.round(p.context_tokens/1024)}K context`;
   b.className='pill ok';
   $('#modelProfileText').textContent=`Verified local profile: ${p.model} · thinking ${p.thinking_level} (highest level advertised by this installed model) · ${p.context_tokens.toLocaleString()} context tokens · ${p.num_predict.toLocaleString()} output-token budget · temperature ${p.temperature} · keep-alive ${p.keep_alive} · serial requests · no fallback.`;
  }else{
   b.textContent=s.reachable?(s.installed?'Model profile could not be verified':'Missing model: '+s.model):'Ollama not running';
   b.className='pill warn';$('#modelProfileText').textContent=s.profile_error||s.error||'Start Ollama and ensure gpt-oss:120b is installed.';
  }
 }catch(e){OLLAMA_STATUS={error:e.message};b.textContent='Ollama check failed';b.className='pill warn';$('#modelProfileText').textContent=e.message;}
}
$('#refreshModel').addEventListener('click',ollamaCheck);
// Hook into existing evidence run without replacing the stable working Epic FHIR logic.
const oldRun=run;
$('#runBtn').removeEventListener('click',run);
$('#runBtn').addEventListener('click',async()=>{await oldRun();$('#investigateBtn').disabled=!DATA;JOB_OUTPUT=null;CURRENT_JOB=null;RAW_SELECTED=null;renderLab();renderProcessPanel();});
async function startInvestigation(){
 let button=$('#investigateBtn');button.disabled=true;$('#jobStatus').textContent='Starting investigator…';
 JOB_OUTPUT=null;renderProcessPanel();
 try{let result=await postJSON('/api/investigate',{});CURRENT_JOB=result.job_id;$('#cancelJob').disabled=false;$('#exportInvestigator').disabled=true;$('#downloadReport').disabled=true;await pollJob();if(JOB_OUTPUT&&!['complete','cancelled','error'].includes(JOB_OUTPUT.status))JOB_TIMER=setInterval(pollJob,1100)}
 catch(e){$('#jobStatus').textContent='Could not start: '+e.message;button.disabled=!DATA;showError(e.message)}
}
$('#investigateBtn').addEventListener('click',startInvestigation);
$('#cancelJob').addEventListener('click',async()=>{if(CURRENT_JOB){await postJSON('/api/cancel',{id:CURRENT_JOB});$('#jobStatus').textContent='Stop requested; current Ollama request may need to finish before cancellation.'}});
async function pollJob(){
 if(!CURRENT_JOB)return;
 try{
  JOB_OUTPUT=await getJSON('/api/job?id='+encodeURIComponent(CURRENT_JOB));
  const done=['complete','cancelled','error'].includes(JOB_OUTPUT.status);
  $('#exportInvestigator').disabled=!done;$('#downloadReport').disabled=!(JOB_OUTPUT.status==='complete'&&JOB_OUTPUT.result);
  $('#jobStatus').textContent=JOB_OUTPUT.stage+' · '+JOB_OUTPUT.status;
  renderProcessPanel();renderLab();
  if(done){clearInterval(JOB_TIMER);JOB_TIMER=null;$('#cancelJob').disabled=true;$('#investigateBtn').disabled=!DATA;$('#jobStatus').textContent=JOB_OUTPUT.status.toUpperCase()+' · '+JOB_OUTPUT.stage;}
 }catch(e){clearInterval(JOB_TIMER);JOB_TIMER=null;$('#jobStatus').textContent='Could not check investigation: '+e.message;showError(e.message)}
}
function showError(message){const box=$('#errorLog');box.replaceChildren();node(box,'strong','','Error log');paragraph(box,String(message),'error');}
function renderProcessPanel(){
 const j=JOB_OUTPUT;const bar=$('#jobProgress');if(!j){bar.style.width='0%';$('#progressLabel').textContent='Waiting for investigation';$('#progressDetail').textContent='The progress bar tracks chunk screening, expanded-context extraction, rubric synthesis and final audit.';$('#progressPercent').textContent='0%';$('#progressTrack').setAttribute('aria-valuenow','0');$('#progressCounts').textContent='No chunks processed yet.';$('#processLog').replaceChildren(el('p','mini','No process events yet. Start an investigation to see each operation appear here.'));$('#errorLog').replaceChildren(el('strong','','Error log'),el('p','mini','No errors reported.'));return;}
 const pct=Number(j.progress_percent||0);bar.style.width=pct+'%';$('#progressLabel').textContent=j.progress_label||j.stage||'Working';$('#progressDetail').textContent=j.progress_detail||j.stage||'';$('#progressPercent').textContent=pct.toFixed(0)+'%';$('#progressTrack').setAttribute('aria-valuenow',String(pct));
 const counts=`Chunks screened ${j.screening?.length||0}/${j.chunk_count||j.total||0} · selected ${j.selection_count??(j.screening||[]).filter(x=>x.selected).length} · expanded chunks ${j.expanded_count||0} · context windows ${j.processed_windows||0}/${j.window_count||0} · verified quotes ${j.events?.length||0} · rejected quotes ${j.rejected_quotes?.length||0} · skipped chunks ${j.overflow||0} · skipped windows ${j.pass2_windows_skipped||0} · FHIR coverage gaps ${j.coverage_warnings?.length||0}`;
 $('#progressCounts').textContent=counts+(j.logs_truncated?' · OPERATIONAL LOG TRUNCATED':'');$('#downloadProcessLog').disabled=!j.logs?.length;
 const all=j.logs||[];const filter=$('#logFilter').value;const filtered=filter==='all'?all:all.filter(x=>x.phase===filter|| (filter==='error'&&['error','warning'].includes(x.level)));
 const shown=SHOW_ALL_LOG?filtered:filtered.slice(-180);const pane=$('#processLog');const follow=pane.scrollHeight-pane.scrollTop-pane.clientHeight<45;pane.replaceChildren();
 if(!shown.length)node(pane,'p','mini','No entries for this filter yet.');
 for(const entry of shown){const row=node(pane,'div','logEntry '+(entry.level||'info'));node(row,'span','logTime',`${entry.seq||''} · ${entry.time||''}`);node(row,'span','logPhase',(entry.phase||'').toUpperCase());node(row,'span','logDetail',entry.detail||entry.event||'');}
 if(follow)pane.scrollTop=pane.scrollHeight;
 $('#showAllLog').textContent=SHOW_ALL_LOG?'Show latest 180':'Show all '+filtered.length;
 const err=$('#errorLog');err.replaceChildren();node(err,'strong','','Error log');
 const errors=j.errors||[];if(!errors.length)paragraph(err,j.status==='error'?'No detailed error message was returned.':'No errors reported.','mini');else errors.forEach(x=>paragraph(err,String(x),'error'));
 if(j.analysis_warnings?.length){const w=node(err,'div','');paragraph(w,'Analysis coverage warnings:','mini');j.analysis_warnings.forEach(x=>paragraph(w,'• '+x,'error'));}
}
$('#logFilter').addEventListener('change',()=>renderProcessPanel());
$('#showAllLog').addEventListener('click',()=>{SHOW_ALL_LOG=!SHOW_ALL_LOG;renderProcessPanel()});
function downloadBlob(filename,content,mime){const url=URL.createObjectURL(new Blob([content],{type:mime}));const a=document.createElement('a');a.href=url;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);LAST_DOWNLOADS[filename]=true;}
function slug(s){return String(s||'unknown').normalize('NFKD').replace(/[^a-zA-Z0-9]+/g,'-').replace(/^-|-$/g,'').toLowerCase().slice(0,70)||'unknown';}
function patientMeta(){
 const p=(DATA?.resources||[]).find(x=>x.resourceType==='Patient');let patientName='';
 if(p){const names=p.name||[];const n=names.find(x=>x.text)||names[0];patientName=n?.text||[...(n?.given||[]),n?.family].filter(Boolean).join(' ')||'';}
 return {patient_name:patientName||DATA?.patient_name||DATA?.case_name||'Synthetic patient',patient_id:DATA?.patient_id||p?.id||$('#patientId').value||$('#localPatientId').value||'unknown',case_name:DATA?.case_name||DATA?.case_summary||'CLABSI research case',source:JOB_OUTPUT?.source||MODE,case_id:JOB_OUTPUT?.case_id||DATA?.synthetic_id||$('#caseSelect').value||'unknown'};
}
function buildReportMeta(){const p=patientMeta();const d=new Date();const date=d.toISOString();const caseNumber=`CLABSI-${date.slice(0,10).replaceAll('-','')}-${slug(p.case_id).toUpperCase()}-${(JOB_OUTPUT?.id||'NORUN').toUpperCase()}`;return {...p,case_number:caseNumber,run_id:JOB_OUTPUT?.id||'',generated_at:date};}
function buildMarkdownReport(){
 const m=buildReportMeta(),j=JOB_OUTPUT||{},r=j.result||{},rub=r.rubric||{},ledger=r.evidence_ledger||{},audit=r.consistency_audit||{};
 const lines=[`# CLABSI Research Investigator Report`,``,`**Case number:** ${m.case_number}  `,`**Patient:** ${m.patient_name}  `,`**FHIR Patient ID:** ${m.patient_id}  `,`**Case:** ${m.case_name}  `,`**Source:** ${m.source}  `,`**Run ID:** ${m.run_id}  `,`**Generated:** ${m.generated_at}  `,``,`> Research prototype only. Not an NHSN adjudication, clinical diagnosis, or validated surveillance determination.`,``,`## Model configuration`,``,`- Model: ${j.model||'gpt-oss:120b'}`,`- Thinking requested: ${j.thinking_requested||'not recorded'}`,`- Thinking verified: ${j.thinking_verified?'yes':'no'}`,`- Context tokens: ${j.model_profile?.context_tokens||'not verified'}`,`- Output budget: ${j.model_profile?.num_predict||'not recorded'}`,`- Temperature: ${j.model_profile?.temperature??'not recorded'}`,`- No model fallback: ${j.model_profile?.no_model_fallback?'yes':'not verified'}`,``,`## Retrieval and processing metrics`,``,`- FHIR resources: ${DATA?.count??'unknown'}`,`- Clinical notes: ${Object.keys(DATA?.notes||{}).length}`,`- Chunks screened: ${(j.screening||[]).length} / ${j.chunk_count||j.total||0}`,`- Chunks selected: ${j.selection_count||0}`,`- Expanded chunks: ${j.expanded_count||0}`,`- Context windows processed: ${j.processed_windows||0} / ${j.window_count||0}`,`- Exact quotations accepted: ${(j.events||[]).length}`,`- Quotations rejected: ${(j.rejected_quotes||[]).length}`,`- Analysis incomplete: ${j.analysis_incomplete?'YES':'no'}`,...(j.analysis_warnings||[]).map(x=>`- Coverage warning: ${x}`),``,`## Investigator assessment`,``,`${r.summary||'No synthesis available.'}`,``,`**Clinical suspicion (model-generated research label):** ${r.suspicion||'uncertain'}`,``,`## Retrieved chronology`,``,...(DATA?.events||[]).map(x=>`- ${x.when||'Date unknown'} · ${x.label||'Event'} · ${x.detail||''} [${x.source||'no source'}]`),``,`## Key findings`,...(r.key_findings||[]).map(x=>`- ${x}`),``,`## Unresolved questions`,...(r.unresolved||[]).map(x=>`- ${x}`),``,`## Additional chart queries`,...(r.followup_queries||[]).map(x=>`- ${x}`),``,`## Rubric — evidence completeness`,``,`**Score:** ${rub.evidence_completeness_score??'not calculated'}/100. This is evidence coverage, not CLABSI probability.`,``,`| Domain | Status | Points | Evidence IDs | Rationale |`,`|---|---|---:|---|---|`,...(rub.domains||[]).map(x=>`| ${x.name} | ${x.status} | ${x.earned??'N/A'}/${x.weight} | ${(x.evidence_ids||[]).join(', ')} | ${String(x.rationale||'').replaceAll('|','\\|')} |`),``,`## Canonical evidence states`,``,`| Question | State | Basis | Evidence IDs |`,`|---|---|---|---|`,...(ledger.states||[]).map(x=>`| ${x.label} | ${x.state} | ${String(x.basis||'').replaceAll('|','\\|')} | ${(x.evidence_ids||[]).join(', ')} |`),``,`## Verified source quotations`,``,...(j.events||[]).map(x=>`### ${x.evidence_id} · ${x.type} · ${x.date}\n\n> ${String(x.quote||'').replaceAll('\n','\n> ')}\n\nSource: ${x.source}; offsets ${(x.offsets||[]).join('–')}; certainty ${x.certainty}; date basis: ${x.date_basis}`),``,`## Consistency audit`,``,`- Contradictions removed: ${(audit.removed_contradictions||[]).length}`,`- Unsupported inferences flagged: ${(audit.unsupported_inferences||[]).length}`,`- Missing-data proposals reconciled: ${(audit.reconciled_missing_proposals||[]).length}`,...(audit.unsupported_inferences||[]).map(x=>`- ${x.original} → ${x.replacement}`),``,`## Operational log`,``,`Full detailed trace is available in the companion JSON export. This report does not include private model thinking text.`];
 return {meta:m,markdown:lines.join('\n')};
}
$('#downloadReport').addEventListener('click',()=>{if(!JOB_OUTPUT?.result)return;const {meta,markdown}=buildMarkdownReport();downloadBlob(`${slug(meta.patient_name)}_${meta.case_number.toLowerCase()}_analysis.md`,markdown,'text/markdown;charset=utf-8')});
$('#exportInvestigator').addEventListener('click',()=>{if(!JOB_OUTPUT)return;const meta=buildReportMeta();const pack={report_metadata:meta,retrieval_summary:{resource_count:DATA?.count,note_count:Object.keys(DATA?.notes||{}).length,source:meta.source,patient_id:meta.patient_id},investigation:JOB_OUTPUT};downloadBlob(`${slug(meta.patient_name)}_${meta.case_number.toLowerCase()}_complete_trace.json`,JSON.stringify(pack,null,2),'application/json')});
$('#downloadProcessLog').addEventListener('click',()=>{if(!JOB_OUTPUT)return;const m=buildReportMeta();downloadBlob(`${slug(m.patient_name)}_${m.case_number.toLowerCase()}_process_log.json`,JSON.stringify(JOB_OUTPUT.logs||[],null,2),'application/json')});
$('#downloadRubric').addEventListener('click',()=>{if(!TRAINING_RUBRIC)return;downloadBlob('clabsi_experimental_training_rubric.json',JSON.stringify(TRAINING_RUBRIC,null,2),'application/json')});
function paragraph(parent,text,cls=''){node(parent,'p',cls,text)}
function bullets(parent,items){(items||[]).forEach(t=>paragraph(parent,'• '+String(t),'hint'))}
function renderLab(){let v=$('#jobView');if(!v)return;clear(v);
 if(LABTAB==='synthetic'){node(v,'h3','','Benchmarks');paragraph(v,'Seven reproducible synthetic FHIR R4 cases are available under Synthetic cases above. The gold categories are investigative targets, not independently validated NHSN surveillance determinations.');if(DATA&&DATA.gold_standard){let c=node(v,'div','gold');node(c,'strong','','Known synthetic category: '+DATA.gold_standard.category);paragraph(c,DATA.gold_standard.explanation)}else paragraph(v,'Choose a synthetic case to display its target.');return}
 if(LABTAB==='history'){node(v,'h3','','Stored synthetic investigations');paragraph(v,'Only synthetic-run ledgers are written to SQLite. Epics sandbox note data remain memory-only.');getJSON('/api/runs').then(d=>{let p=$('#jobView');if(LABTAB!=='history')return;for(let x of d.runs){let b=node(p,'button','secondary',x.created.slice(0,19)+' · '+x.case_id+' · '+x.status);b.style.display='block';b.style.margin='8px 0';b.addEventListener('click',async()=>{JOB_OUTPUT=await getJSON('/api/run?id='+encodeURIComponent(x.id));LABTAB='summary';paintLabTabs();})}if(!d.runs.length)paragraph(p,'No stored synthetic runs yet.');}).catch(e=>paragraph(v,e.message));return}
 if(LABTAB==='states'){
  node(v,'h3','','Canonical evidence-state ledger');
  paragraph(v,'Every final section is reconciled against this one ledger. A missing resource is not a negative clinical finding. Line placement before and removal after a culture do not, by themselves, prove uninterrupted presence.');
  const ledger=JOB_OUTPUT&&JOB_OUTPUT.result&&JOB_OUTPUT.result.evidence_ledger;
  if(!ledger){paragraph(v,'Run an investigation to build the canonical ledger.');return}
  const states=node(v,'div','');
  for(const row of ledger.states||[]){
    const a=node(states,'div','stateRow');node(a,'div','stateLabel',row.label);node(a,'div','',chip(row.state));
    const right=node(a,'div','stateBasis');paragraph(right,row.basis,'');
    if(row.evidence_ids&&row.evidence_ids.length)paragraph(right,'Evidence: '+row.evidence_ids.join(', '),'mini');
  }
  const ctx=ledger.structured_context||{};
  if(ctx.calendar_day_context&&ctx.calendar_day_context.length){
    node(v,'h4','','Encounter / specimen date arithmetic');
    for(const x of ctx.calendar_day_context){let a=node(v,'div','subtleBox');paragraph(a,`${x.encounter} began ${x.encounter_start}`,'mini');paragraph(a,`${x.culture_source} collected ${x.culture_collection_time}`);paragraph(a,`Inclusive calendar day ${x.inclusive_calendar_day_from_encounter_start}`,'smallStrong');paragraph(a,x.caveat,'mini')}
  }
  if(ctx.line_events&&ctx.line_events.length){node(v,'h4','','Structured line events');for(const x of ctx.line_events){let a=node(v,'div','audit');paragraph(a,x.date+' · '+x.source,'mini');paragraph(a,x.claim)}}
  return;
 }
 if(LABTAB==='rubric'){
  node(v,'h3','','Experimental evidence rubric');
  if(!TRAINING_RUBRIC){paragraph(v,'Loading rubric…');return}
  paragraph(v,TRAINING_RUBRIC.warning,'hint');
  const evaluation=JOB_OUTPUT&&JOB_OUTPUT.result&&JOB_OUTPUT.result.rubric;
  if(evaluation&&evaluation.evidence_completeness_score!==null){
    let top=node(v,'div','gold');node(top,'strong','',`Evidence completeness: ${evaluation.evidence_completeness_score}/100`);
    paragraph(top,'Measures documented answers and provenance; NOT a risk score, CLABSI probability or NHSN classification.');paragraph(top,evaluation.scoring_method||'Deterministic evidence-state scoring.','mini');
    (evaluation.downgrades||[]).forEach(t=>paragraph(top,t,'error'));
  }else paragraph(v,'Run an investigation to populate evidence coverage; the rubric itself is visible below.');
  TRAINING_RUBRIC.domains.forEach(d=>{
    let a=node(v,'div','audit');node(a,'h3','',d.name+' · '+d.weight+'%');
    let r=evaluation&&(evaluation.domains||[]).find(q=>q.domain_id===d.id);
    if(r){node(a,'span','tag','Deterministic coverage: '+r.status);node(a,'span','tag','Points: '+(r.earned===null?'N/A':r.earned)+' / '+d.weight);paragraph(a,r.rationale);if(r.evidence_ids.length)paragraph(a,'Evidence anchors: '+r.evidence_ids.join(', '),'mini');}
    paragraph(a,d.question,'hint');paragraph(a,'Look for: '+d.look_for.join(' • '),'mini');paragraph(a,'Pitfall: '+d.pitfall,'mini');
    const advisory=(JOB_OUTPUT?.result?.model_rubric_advisory||[]).find(q=>q.domain_id===d.id);
    if(advisory){let det=node(a,'details','subtleBox');node(det,'summary','',"Model's rubric reasoning (advisory; not used for scoring)");paragraph(det,advisory.status||'No model status');paragraph(det,advisory.rationale||'No rationale returned.');if(advisory.evidence_ids?.length)paragraph(det,'Model-cited evidence: '+advisory.evidence_ids.join(', '),'mini');}
  });
  const raw=node(v,'details','audit');node(raw,'summary','','Inspect complete rubric JSON');node(raw,'pre','raw',JSON.stringify(TRAINING_RUBRIC,null,2));
  return;
 }
 if(LABTAB==='audit'){
  node(v,'h3','','Consistency audit');
  paragraph(v,'The integrity layer reconciles all sections against one evidence ledger, removes stale absence claims, flags unsupported date/line-continuity inferences, and reconciles Pass-2 missing-data proposals. It is a targeted audit, not proof of full logical consistency or NHSN classification.');
  if(!JOB_OUTPUT||!JOB_OUTPUT.result||!JOB_OUTPUT.result.consistency_audit){paragraph(v,'Run the investigator to see its audit.');return}
  const a=JOB_OUTPUT.result.consistency_audit;
  let b=node(v,'div','audit');node(b,'h4','','Evidence already found');
  Object.entries(a.known_evidence_categories||{}).forEach(([k,val])=>{const state=typeof val==='boolean'?(val?'supported':'unknown'):String(val);let row=node(b,'div','row');node(row,'span','tag',k.replaceAll('_',' '));row.append(chip(state));});
  node(v,'h4','','Removed contradictions');
  if(!a.removed_contradictions.length)paragraph(v,'No matching contradiction was caught by the mechanical rules. This is not proof of absence of contradiction.');
  for(const f of a.removed_contradictions){let x=node(v,'div','audit');paragraph(x,'Removed: '+f.removed_statement,'error');paragraph(x,'Conflicts with established '+f.conflicts_with.replaceAll('_',' '),'mini')}
  node(v,'h4','','Ambiguous absence claims rewritten as uncertainty');
  for(const f of (a.rewritten_absences||[])){let x=node(v,'div','audit');paragraph(x,'Original: '+f.original,'mini');paragraph(x,'Clarified: '+f.replacement,'hint')}
  if(!(a.rewritten_absences||[]).length)paragraph(v,'No generic absence claims needed rewriting.');
  node(v,'h4','','Unsupported inferences caught');
  if(!(a.unsupported_inferences||[]).length)paragraph(v,'No targeted unsupported-inference rule fired.');
  for(const f of (a.unsupported_inferences||[])){let x=node(v,'div','audit');paragraph(x,'Original: '+f.original,'error');paragraph(x,'Correction: '+f.replacement,'hint');paragraph(x,f.reason,'mini')}
  node(v,'h4','','Pass-2 missing-data proposals reconciled against the ledger');
  paragraph(v,"The model's suggestions are not facts. Each is either removed as already documented, rewritten as partial, retained as unknown, or retained only as optional context.");
  for(const f of (a.reconciled_missing_proposals||[])){let x=node(v,'div','audit');node(x,'span','tag',f.disposition.replaceAll('_',' '));paragraph(x,f.original);paragraph(x,f.reason,'mini');if(f.replacement)paragraph(x,'Retained wording: '+f.replacement,'hint')}
  if(JOB_OUTPUT.result.model_rubric_advisory&&JOB_OUTPUT.result.model_rubric_advisory.length){let d=node(v,'details','audit');node(d,'summary','','Original model rubric advisory (not used for scoring)');for(const f of JOB_OUTPUT.result.model_rubric_advisory){let x=node(d,'div','audit');paragraph(x,(f.domain_id||'domain')+' · '+(f.status||'unrated'),'mini');paragraph(x,f.rationale||'');if(f.evidence_ids&&f.evidence_ids.length)paragraph(x,'Model cited: '+f.evidence_ids.join(', '),'mini')}}
  return;
 }
 if(!JOB_OUTPUT){paragraph(v,'Run local Ollama investigation to populate this section.');return}
 const j=JOB_OUTPUT;
 if(LABTAB==='summary'){let r=j.result||{};node(v,'h3','','Research-only investigator summary');if(r.summary)paragraph(v,r.summary);else paragraph(v,'Processing: '+j.stage);if(r.suspicion)paragraph(v,'Clinical suspicion: '+r.suspicion,'smallStrong');if(r.rubric&&r.rubric.evidence_completeness_score!==null)paragraph(v,'Experimental evidence-completeness score: '+r.rubric.evidence_completeness_score+'/100 (not CLABSI probability).','mini');if(r.consistency_audit&&((r.consistency_audit.removed_contradictions||[]).length||(r.consistency_audit.unsupported_inferences||[]).length))paragraph(v,'Integrity audit: '+(r.consistency_audit.removed_contradictions||[]).length+' stale/contradictory statements reconciled; '+(r.consistency_audit.unsupported_inferences||[]).length+' unsupported inference(s) flagged. Open Consistency audit.','error');if(r.key_findings){node(v,'h4','','Key findings');bullets(v,r.key_findings)}if(r.unresolved){node(v,'h4','','Unresolved');bullets(v,r.unresolved)}if(r.followup_queries){node(v,'h4','','Additional chart queries');bullets(v,r.followup_queries)}const dayCtx=r.evidence_ledger&&r.evidence_ledger.structured_context&&r.evidence_ledger.structured_context.calendar_day_context;if(dayCtx&&dayCtx.length)paragraph(v,'Structured encounter arithmetic: calendar day '+dayCtx[0].inclusive_calendar_day_from_encounter_start+' from Encounter.period.start; '+(dayCtx[0].inpatient_class_verified?'Encounter.class identifies inpatient care.':'Encounter.class does not establish inpatient status.')+' This is not an NHSN date of event.','mini');paragraph(v,'Quotes verified: '+j.events.length+' · Rejected hallucinated quotations: '+j.rejected_quotes.length+' · Selected chunks: '+(j.selection_count||0)+' · Unscreened due to cap: '+(j.overflow||0),'mini');if(j.errors.length)paragraph(v,j.errors.join('; '),'error')}
 if(LABTAB==='ledger'){node(v,'h3','','Pass 1: every chunk screened');paragraph(v,'Screening calls are made with high reasoning. Lexical safety net also selects relevant chunks the model may miss. Immediate flanking chunks are included in pass 2.');for(let e of (j.screening||[])){let a=node(v,'div','audit');node(a,'span','tag',e.id);node(a,'span','tag',e.selected?'FLAGGED':'not flagged');if(e.lexical_safety)node(a,'span','tag','lexical safety');paragraph(a,e.reason);if(e.flags.length)paragraph(a,e.flags.join(' · '),'hint')}node(v,'h4','','Expanded windows');for(let w of (j.expansions||[])){let a=node(v,'div','audit');paragraph(a,`${w.note_id} · ${w.start}–${w.end} · ${w.chunk_ids.length} flanking/selected chunks`,'mini')}}
 if(LABTAB==='quotes'){node(v,'h3','','Pass 2: exact verified source quotations');for(let e of j.events){let a=node(v,'div','audit');node(a,'span','tag',e.type+' · '+e.certainty);paragraph(a,e.claim);paragraph(a,'“'+e.quote+'”','quote');paragraph(a,(e.evidence_id||'')+' · '+e.source+' • '+e.date+' • offsets '+(e.offsets||[]).join('–'),'mini');if(e.date_basis)paragraph(a,'Date basis: '+e.date_basis,'mini')}if(!j.events.length)paragraph(v,'No source-verified events yet.');if(j.rejected_quotes.length){node(v,'h4','','Rejected model quotations');for(let e of j.rejected_quotes){let a=node(v,'div','audit');paragraph(a,e.reason+' — '+e.claim,'error');paragraph(a,e.source,'mini')}}}
}
function paintLabTabs(){document.querySelectorAll('[data-labtab]').forEach(b=>b.classList.toggle('active',b.dataset.labtab===LABTAB));renderLab()}
document.querySelectorAll('[data-labtab]').forEach(b=>b.addEventListener('click',()=>{LABTAB=b.dataset.labtab;paintLabTabs()}));
async function getRubric(){try{TRAINING_RUBRIC=await getJSON('/api/rubric');if(LABTAB==='rubric')renderLab()}catch(e){console.warn('Could not load training rubric:',e.message)}}
atlasInit();ollamaCheck();getRubric();renderLab();


let LOCAL_PATIENTS_LOADED=false, LOCAL_START_BUSY=false;
async function loadLocalPatients(quiet=false){
 const picker=$('#localSelect');const label=$('#localHelp');
 try{
  if(!quiet)label.textContent='Checking the local FHIR R4 server…';
  let result=await getJSON('/api/local_patients');
  picker.replaceChildren(el('option','','Choose a fictional patient…'));
  for(const p of result.patients){let o=el('option','',p.name+' — '+p.id);o.value=p.id;picker.appendChild(o)}
  if(result.patients.length){const preferred=result.patients.find(p=>p.id==='lab-p007')||result.patients[0];picker.value=preferred.id;$('#localPatientId').value=picker.value}
  label.textContent=result.patients.length+' fictional FHIR Patient resources verified at '+result.base+'. '+(picker.value==='lab-p007'?'The 27-note stress-test chart is selected.':'');
  $('#startLocal').textContent='Local FHIR ready ✓';LOCAL_PATIENTS_LOADED=result.patients.length>0;
  return LOCAL_PATIENTS_LOADED;
 }catch(e){
  LOCAL_PATIENTS_LOADED=false;$('#localPatientId').value='';
  picker.replaceChildren(el('option','','Local FHIR not started — start automatically'));
  label.textContent='Local FHIR is not running yet. Click Start Local FHIR automatically, or select Local FHIR patients to start it automatically. '+e.message;
  $('#startLocal').textContent='Start Local FHIR automatically';
  return false;
 }
}
async function ensureLocalFHIR(force=false){
 if(LOCAL_START_BUSY)return;
 if(LOCAL_PATIENTS_LOADED&&!force){return;}
 LOCAL_START_BUSY=true;
 const button=$('#startLocal'),label=$('#localHelp');
 button.disabled=true;button.textContent='Starting local FHIR…';
 try{
  const started=await postJSON('/api/local/start',{});
  let state=started;
  for(let i=0;i<930;i++){
   if(state.status==='ready'){
    const ok=await loadLocalPatients(true);
    if(!ok)throw new Error('Local FHIR reported ready, but the Patient search did not return the seeded records.');
    label.textContent='Ready. Seven fictional patients imported and read back through the local FHIR R4 REST interface. lab-p007 is selected automatically.';
    $('#runMessage').textContent='Local FHIR ready. Click Query local FHIR to retrieve the chart.';
    return;
   }
   if(state.status==='error')throw new Error(state.error||state.message||'Local FHIR startup failed.');
   label.textContent=(state.stage||'Starting local FHIR')+' · '+(state.progress||0)+'% — '+(state.message||'Please wait…');
   button.textContent=(state.stage||'Starting')+'…';
   await new Promise(resolve=>setTimeout(resolve,2000));
   state=await getJSON('/api/local/status');
  }
  throw new Error('Local FHIR startup exceeded 30 minutes. Please download the process log and report this error.');
 }catch(e){
  label.textContent='Automatic Local FHIR startup could not complete: '+e.message+' You can retry this button; no Docker is required.';
  button.textContent='Retry Local FHIR startup';
  $('#runMessage').textContent='Local FHIR is not ready yet.';
 }finally{LOCAL_START_BUSY=false;button.disabled=false;}
}
loadLocalPatients();

// Full, interactive tutorials. The user clicks the real highlighted controls;
// the guide checks that the requested action happened before allowing Next.
let GUIDE_STEPS=[], GUIDE_INDEX=0, GUIDE_TARGET=null, GUIDE_NEXT_TARGET=null, GUIDE_OPEN=false, GUIDE_KIND='core', GUIDE_USER_MOVED=false, GUIDE_DRAG=null;
function guideVoiceAvailable(){return 'speechSynthesis' in window && 'SpeechSynthesisUtterance' in window;}
function stopGuideVoice(){if(guideVoiceAvailable())window.speechSynthesis.cancel();$('#guideVoiceStatus').textContent='Voice stopped';}
function speakGuideStep(){
 if(!GUIDE_OPEN||!$('#guideVoice').checked)return;
 if(!guideVoiceAvailable()){$('#guideVoiceStatus').textContent='Speech is not available in this browser';return;}
 window.speechSynthesis.cancel();
 const step=GUIDE_STEPS[GUIDE_INDEX];const utterance=new SpeechSynthesisUtterance(`${step.title}. ${step.body}`);
 utterance.lang='en-US';utterance.rate=0.96;utterance.pitch=1;utterance.volume=1;
 const voices=window.speechSynthesis.getVoices();const preferred=voices.find(v=>/^en-US/i.test(v.lang))||voices.find(v=>/^en/i.test(v.lang));if(preferred)utterance.voice=preferred;
 utterance.onstart=()=>$('#guideVoiceStatus').textContent='Speaking';utterance.onend=()=>$('#guideVoiceStatus').textContent=$('#guideVoice').checked?'Voice ready':'Voice off';utterance.onerror=()=>$('#guideVoiceStatus').textContent='Voice unavailable';
 window.speechSynthesis.speak(utterance);
}
const CORE_GUIDE=[
 {title:'Welcome — what this lab does',body:'This is a research prototype. It retrieves FHIR resources, reads clinical notes, screens overlapping text chunks with local Ollama gpt-oss 120b, expands selected passages with neighboring context, verifies exact quotations, reasons against an inspectable rubric, reconciles evidence states, and creates a downloadable report. The tutorial will point to the real controls. You press the buttons; it will not launch expensive work without your click.'},
 {title:'Choose the synthetic case mode',body:'Click Synthetic cases. This is the quickest safe route: fictional data, no Docker, no Epic login and no real patient information. Local FHIR and Epic are separate data-source options.',target:'#demoMode',require:()=>MODE==='demo',requireMessage:'Click the highlighted Synthetic cases button.'},
 {title:'Choose a test scenario',body:'The selector defaults to Long chart — 31-chunk guided stress test. It contains 27 fictional notes, including two long documents, routine noise, a buried line-care event, a copied-forward error and a correction. This is deliberately much larger than the three-note demonstration. You can later select the smaller cases for controlled tests.',target:'#caseSelect',require:()=>$('#caseSelect').value==='synth:long_chart',requireMessage:'Select Long chart — 31-chunk guided stress test. The older three-note demo is not the intended walkthrough case.'},
 {title:'Retrieve the source chart',body:'Click Run evidence search. This loads the fictional FHIR records, decodes all 27 note bodies and prepares the evidence review. This is retrieval only; Ollama has not been called yet.',target:'#runBtn',require:()=>!!DATA,requireMessage:'Click Run evidence search and wait for the resource count.'},
 {title:'Confirm this is a multi-note chart',body:'Check that the chart contains at least 25 note bodies. The earlier three-chunk run came from the old three-note demo fixture. The investigator has a 1,000-chunk safety cap; there is no three-chunk limit. The long chart should create 31 overlapping chunks after the note text is chunked.',target:'#caseSummary',require:()=>!!DATA&&Object.keys(DATA.notes||{}).length>=25,requireMessage:'This is not the long chart. Re-select Long chart — 31-chunk guided stress test and retrieve it.'},
 {title:'Assessment — the first-pass screen',body:'Click Assessment. This is the initial structured screen from the FHIR retrieval layer. Treat candidate labels as leads, not final conclusions.',target:'[data-tab="assessment"]',require:()=>TAB==='assessment',requireMessage:'Click the Assessment tab.'},
 {title:'Timeline — event chronology',body:'Click Timeline. Compare specimen collection time, report time, note timestamps, line insertion/access/removal, symptoms and encounter start. A note timestamp is not necessarily the event time.',target:'[data-tab="timeline"]',require:()=>TAB==='timeline',requireMessage:'Click the Timeline tab.'},
 {title:'Clinical notes — original text',body:'Click Clinical notes. Read the original note bodies. The investigator receives these source texts, not just the titles. Long notes are split into overlapping chunks later.',target:'[data-tab="notes"]',require:()=>TAB==='notes',requireMessage:'Click Clinical notes.'},
 {title:'Coverage biopsy — what FHIR returned',body:'Click Coverage biopsy. Each resource type shows count, pages, endpoint status and retrieval limitations. Empty, inaccessible and error are not clinical negatives.',target:'[data-tab="coverage"]',require:()=>TAB==='coverage',requireMessage:'Click Coverage biopsy.'},
 {title:'Raw FHIR — inspect the source resources',body:'Click Raw FHIR. This is the underlying resource explorer. It lets you inspect the original Patient, Encounter, Observation, DocumentReference, Specimen, Device and other records.',target:'[data-tab="raw"]',require:()=>TAB==='raw',requireMessage:'Click Raw FHIR.'},
 {title:'Select a raw resource',body:'Click one resource in the left-hand list. The JSON on the right is the original FHIR resource. This is useful when a summary seems wrong or an event timestamp needs verification.',target:'.selectbox button',require:()=>TAB==='raw'&&!!RAW_SELECTED,requireMessage:'Choose a resource from the Raw FHIR list.'},
 {title:'Return to Assessment',body:'Return to Assessment. The source tabs are retrieval views; the investigator will now run its own multi-pass analysis against the loaded chart.',target:'[data-tab="assessment"]',require:()=>TAB==='assessment',requireMessage:'Click Assessment.'},
 {title:'Check the exact Ollama profile',body:'Click Check Ollama. The app is fixed to gpt-oss:120b and refuses silent fallback. It reads the installed model metadata and verifies the highest thinking level it advertises. For GPT-OSS this is normally high; max is used only if that exact installed model advertises it. The diagnostic you supplied showed 131072 context tokens on your M4 Max.',target:'#refreshModel',require:()=>!!OLLAMA_STATUS&&OLLAMA_STATUS.reachable&&OLLAMA_STATUS.installed&&!!OLLAMA_STATUS.profile,requireMessage:'Click Check Ollama. If unavailable, start Ollama and ensure gpt-oss:120b is installed.'},
 {title:'Read the model configuration',body:'Read the verified profile beneath the Ollama status. The current configuration requests the highest supported thinking level, up to 131072 context tokens, a 32768 output-token budget, temperature 1.0, and 30-minute keep-alive. Model requests are serialized because your diagnostic found no throughput benefit from concurrency. Each call must return a thinking field or the run fails.',target:'#modelProfileText'},
 {title:'Start the investigation',body:'Click Investigate loaded case. This is the expensive step. The engine will inspect every chunk within its explicit cap, select candidate chunks, add adjacent chunks from the same note, merge overlapping ranges, extract events, verify quotations and synthesize against all rubric domains.',target:'#investigateBtn',require:()=>!!JOB_OUTPUT&&['complete','error','cancelled'].includes(JOB_OUTPUT.status),requireMessage:'Click Investigate loaded case and wait until it completes or reports an error.'},
 {title:'Follow the progress bar',body:'The bar now reports stage-based progress rather than only counting Pass 1 chunks. The counters show chunks screened, selected, expanded, context windows processed, quotes accepted/rejected and any skipped work. A long run may take several minutes or longer with 120b.',target:'#progressTrack'},
 {title:'Verify the real chunk count',body:'The long chart should produce substantially more than three chunks. Confirm the actual count in the counters and chunk inventory. Every chunk is screened in batches of four; each batch is a separate serial 120b request. If the count is below 20, stop and inspect whether all note bodies were retrieved.',target:'#progressCounts',require:()=>!!JOB_OUTPUT&&Number(JOB_OUTPUT.chunk_count||0)>=20,requireMessage:'The run has fewer than 20 chunks. Check the selected patient and readable note count before continuing.'},
 {title:'Read the live process log',body:'The log records note inventory, each chunk ID and source offsets, each model batch, each selection reason, each flanking chunk, every Pass-2 context window, quote acceptance/rejection, model timing/token metadata, rubric scoring and final audit. It deliberately does not display private model thinking text; it displays the operational trace and evidence rationale.',target:'#processLog'},
 {title:'Filter the log to Pass 1',body:'Choose Pass 1 in the log filter. You should see the batch calls and individual chunk decisions, including model flag, lexical safety-net flag and selected/not-selected status.',target:'#logFilter',require:()=>$('#logFilter').value==='pass1',requireMessage:'Set the process-log filter to Pass 1.'},
 {title:'Show the full log',body:'Click Show all if the log is longer than the default latest 180 entries. This is useful for charts with hundreds of chunks. Download log saves the entire event list, not just the visible portion.',target:'#showAllLog',require:()=>SHOW_ALL_LOG,requireMessage:'Click Show all.'},
 {title:'Inspect the error log',body:'The error log sits immediately below the process log. It reports actual failures and coverage-cap warnings. A clean error log does not prove complete retrieval; inspect the skipped-chunk and skipped-window counters too.',target:'#errorLog'},
 {title:'Chunk biopsy — selection decisions',body:'Click Chunk biopsy. Each chunk shows its source note, offsets, model selection, lexical safety-net result, rationale and flags. The expanded-window list shows the neighboring context added before extraction.',target:'[data-labtab="ledger"]',require:()=>LABTAB==='ledger',requireMessage:'Click Chunk biopsy.'},
 {title:'Verified quotations — source fidelity',body:'Click Verified quotations. Every accepted quote must be an exact substring of its source note and has a note ID plus character offsets. Rejected quotations are listed separately. Verify that the quote actually supports the claim.',target:'[data-labtab="quotes"]',require:()=>LABTAB==='quotes',requireMessage:'Click Verified quotations.'},
 {title:'Evidence states — one source of truth',body:'Click Evidence states. Supported, negative, unknown, conflicting and not-applicable are distinct. The summary, unresolved list, rubric and audit are reconciled against this canonical ledger. Unknown does not mean absent.',target:'[data-labtab="states"]',require:()=>LABTAB==='states',requireMessage:'Click Evidence states.'},
 {title:'Training rubric — inspect the criteria',body:'Click Training rubric. Read each domain question, look-for list, pitfall, deterministic coverage status, points and evidence IDs. Expand the model rubric reasoning to inspect its rationale, but remember that the model advisory does not award points.',target:'[data-labtab="rubric"]',require:()=>LABTAB==='rubric',requireMessage:'Click Training rubric.'},
 {title:'Consistency audit — check the model',body:'Click Consistency audit. Look for stale absence claims, unsupported inpatient-day assumptions, unsupported line continuity, conflicting source statements and missing-data suggestions reconciled against the ledger.',target:'[data-labtab="audit"]',require:()=>LABTAB==='audit',requireMessage:'Click Consistency audit.'},
 {title:'Synthetic benchmark — hidden target',body:"Click Synthetic benchmark only after you have formed your own assessment. It exposes the case factory's intended research target. These labels are not independently adjudicated NHSN ground truth.",target:'[data-labtab="synthetic"]',require:()=>LABTAB==='synthetic',requireMessage:'Click Synthetic benchmark.'},
 {title:'Previous runs — reproducibility',body:'Click Previous synthetic runs. Synthetic and local synthetic investigations are stored in SQLite. Epic sandbox patient content is not persisted there. Select a prior run to inspect its original trace.',target:'[data-labtab="history"]',require:()=>LABTAB==='history',requireMessage:'Click Previous synthetic runs.'},
 {title:'Download the final patient-named analysis',body:'Return to the investigator summary if you wish, then click Download final analysis. The Markdown report is named using patient name, case number and run ID. It includes the model profile, retrieval counts, summary, findings, unresolved items, rubric, evidence states, verified quotations and audit.',target:'#downloadReport',require:()=>Object.keys(LAST_DOWNLOADS).some(x=>x.endsWith('_analysis.md')),requireMessage:'Click Download final analysis (.md).'},
 {title:'Download the complete trace',body:'Click Download complete trace. The JSON companion contains the complete job object including per-chunk logs, model call metrics, selected chunks, expansions, quotations, rubric results, evidence ledger and audit.',target:'#exportInvestigator',require:()=>Object.keys(LAST_DOWNLOADS).some(x=>x.endsWith('_complete_trace.json')),requireMessage:'Click Download complete trace (.json).'},
 {title:'Download the inspectable rubric',body:'Click Download rubric. This saves the editable rubric JSON so its domains, questions, weights, look-for items and pitfalls can be reviewed or versioned independently.',target:'#downloadRubric',require:()=>Object.keys(LAST_DOWNLOADS).some(x=>x.includes('training_rubric')),requireMessage:'Click Download rubric (.json).'},
 {title:'Download the full process log',body:'Click Download log. This is a separate machine-readable operational trace, useful for auditing how many chunks were screened and which windows or calls were skipped.',target:'#downloadProcessLog',require:()=>Object.keys(LAST_DOWNLOADS).some(x=>x.endsWith('_process_log.json')),requireMessage:'Click Download log.'},
 {title:'Core walkthrough complete',body:'You have completed the full synthetic investigation. The remaining optional sections cover Local FHIR and Epic sandbox connectivity. You can start the extended tour at any time; voice narration can be turned off with the checkbox.'}
];
const LOCAL_GUIDE=[
 {title:'Local FHIR — why this is different',body:'This path uses the built-in lightweight FHIR R4 REST subset with persistent SQLite. It stores the fictional chart and returns it via FHIR transaction, search, read and Binary endpoints. The investigator receives retrieved resources, not the hidden answer key. No Docker required.'},
 {title:'Switch to Local FHIR patients',body:'Click Local FHIR patients. This automatically starts the local FHIR R4 REST subset, imports seven fictional charts, verifies them, and fills the patient selector. No separate Terminal launcher or manual refresh is required.',target:'#localMode',require:()=>MODE==='local',requireMessage:'Click Local FHIR patients. Automatic startup begins immediately.'},
 {title:'Wait for automatic FHIR startup and patient discovery',body:'Watch this status line. The app reports server readiness, synthetic chart import and read-back verification. When ready, it automatically selects lab-p007. If startup fails, click Retry Local FHIR startup after checking the Local FHIR status.',target:'#localHelp',require:()=>LOCAL_PATIENTS_LOADED,requireMessage:'Wait for the automatic startup to finish. If it fails, use Start Local FHIR automatically to retry.'},
 {title:'Select the long-chart FHIR Patient',body:'The list should default to lab-p007, the seven-patient seed set’s long chart. It has 27 DocumentReference note bodies and produces 31 overlapping chunks. The Patient.id is a FHIR logical ID, not an MRN.',target:'#localSelect',require:()=>$('#localSelect').value==='lab-p007',requireMessage:'Select lab-p007 — the 27-note long chart. If it is absent, click Retry Local FHIR startup or skip this step.'},
 {title:'Query the real FHIR endpoint',body:'Click Query local FHIR. The app retrieves resources through the local FHIR REST endpoints, including Patient, Encounter, DocumentReference and related resources. Wait for retrieval to finish.',target:'#runBtn',require:()=>MODE==='local'&&!!DATA,requireMessage:'Click Query local FHIR and wait for the resource count.'},
 {title:'Verify the 27-note local chart',body:'Confirm that the local FHIR REST endpoint returned at least 25 note bodies. This is the same long-chart stress case as the built-in route, but every resource was retrieved through actual FHIR REST searches and Binary reads.',target:'#caseSummary',require:()=>!!DATA&&Object.keys(DATA.notes||{}).length>=25,requireMessage:'Fewer than 25 notes were retrieved. Check local FHIR seeding and Coverage biopsy; the local tour expects lab-p007.'},
 {title:'Inspect FHIR note content',body:'Open Clinical notes and confirm the DocumentReference attachments have been decoded into note text. This is what the investigator will split into chunks.',target:'[data-tab="notes"]',require:()=>TAB==='notes',requireMessage:'Click Clinical notes.'},
 {title:'Inspect coverage and raw resources',body:'Use Coverage biopsy to see the actual endpoint results, then Raw FHIR to inspect the Patient and Encounter resources. This is a real FHIR R4 REST retrieval, not a local fixture passed directly to the model.',target:'[data-tab="coverage"]',optional:true},
 {title:'Run the local 120b investigator',body:'Click Investigate loaded case. It is the same model and same multi-pass rubric-guided engine used for the synthetic and Epic sandbox sources.',target:'#investigateBtn',require:()=>!!JOB_OUTPUT&&['complete','error','cancelled'].includes(JOB_OUTPUT.status),requireMessage:'Click Investigate loaded case and wait for completion.'},
 {title:'Review the detailed log and download',body:'Inspect the chunk counts and process trace, then download the final report and full trace. The report includes the Patient name if the FHIR Patient resource exposes one.',target:'#processLog'},
 {title:'Local FHIR tour complete',body:'You have tested the same investigator through a real local FHIR R4 endpoint. You can now modify the synthetic patient factory without changing the investigator retrieval interface.'}
];
const FULL_GUIDE=[
 ...CORE_GUIDE.slice(0,-1),
 {title:'Optional advanced path — Local FHIR',body:'The next section covers the local FHIR R4 subset server. If you do not want to switch data sources now, use Skip this step to continue through the rest of the tour.',target:'#localMode',optional:true},
 {title:'Start or verify Local FHIR automatically',body:'Click Start Local FHIR automatically. The app starts the included synthetic-only FHIR R4 subset host, seeds seven fictional patient charts, verifies the read-back, and selects lab-p007. If already running, it simply verifies and refreshes the patient list.',target:'#startLocal',optional:true,require:()=>LOCAL_PATIENTS_LOADED,requireMessage:'Wait for automatic local FHIR startup, or skip this optional step.'},
 {title:'Select a local FHIR patient',body:'Choose a local patient and inspect the logical Patient.id. This path is optional when you prefer the built-in case view.',target:'#localSelect',optional:true,require:()=>!!$('#localSelect').value,requireMessage:'Select a local patient or skip this optional step.'},
 {title:'Query local HTTP FHIR endpoint',body:'Click Query local FHIR. This makes the application retrieve the chart over FHIR REST instead of using the built-in scenario fixture.',target:'#runBtn',optional:true,require:()=>MODE==='local'&&!!DATA,requireMessage:'Query a local FHIR patient or skip this optional step.'},
 {title:'Optional advanced path — Epic sandbox',body:'Epic sandbox mode uses the registered SMART application and public fictional test accounts. Do not use hospital production credentials or real patient data in this research prototype.',target:'#liveMode',optional:true},
 {title:'Choose Authorized Epic',body:'Click Authorized Epic. The sandbox patient atlas is a sample list, not a complete census. Choose a documented fictional patient ID only.',target:'#liveMode',optional:true,require:()=>MODE==='live',requireMessage:'Click Authorized Epic or skip this optional step.'},
 {title:'Inspect the Epic sandbox atlas',body:'Choose a patient from the atlas dropdown. The app copies the exact FHIR Patient.id into the query field. The atlas is only a convenience; API availability varies by patient and registration.',target:'#atlasSelect',optional:true},
 {title:'Sandbox login helper',body:"The public sandbox helper copies the documented test password and opens Epic OAuth. You still enter it on Epic's own login page. This app never autofills or stores a password. Skip if already authenticated.",target:'#copyAndConnect',optional:true},
 {title:'Connect with SMART OAuth',body:'Click Connect via SMART OAuth if the app is not connected. Epic will redirect to its sandbox login and then back to this local app. This step navigates away from the tutorial, so it is optional; return and restart the tour afterward if needed.',target:'#connectBtn',optional:true},
 {title:'Run the Epic FHIR query',body:'After sandbox OAuth is complete, select the patient and click Query Epic FHIR endpoint. This prototype is restricted to the Epic public developer sandbox; it is not enabled for hospital production endpoints.',target:'#runBtn',optional:true},
 {title:'Inspect the cancellation control',body:'Stop after current Ollama request asks the worker to stop after the active model call returns. It cannot interrupt a model call already running inside Ollama. Use it for long investigations only when you intend to stop.',target:'#cancelJob'},
 {title:'Full feature tour complete',body:'You have visited the primary and less-used features: retrieval tabs, raw FHIR, Local FHIR, Epic sandbox, patient atlas, OAuth helper, Ollama profile, chunk screening, logs, rubric, evidence states, audit, history and downloads. Voice narration can be disabled at any time.'}
];
function guideVisibleTarget(selector){if(!selector)return null;try{return [...document.querySelectorAll(selector)].find(e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);return s.display!=='none'&&s.visibility!=='hidden'&&r.width>0&&r.height>0;})||null;}catch(e){return null;}}
function placeGuideDock(){
 const dock=$('#guideDock');if(!GUIDE_OPEN||GUIDE_USER_MOVED)return;
 const r=GUIDE_TARGET?.getBoundingClientRect();const w=dock.offsetWidth||500,h=dock.offsetHeight||360,pad=14;
 let left=r?(r.left>window.innerWidth/2?pad:window.innerWidth-w-pad):window.innerWidth-w-pad;
 let top=r?(r.top>window.innerHeight/2?pad:window.innerHeight-h-pad):window.innerHeight-h-pad;
 left=Math.max(pad,Math.min(window.innerWidth-w-pad,left));top=Math.max(pad,Math.min(window.innerHeight-h-pad,top));
 dock.style.left=left+'px';dock.style.top=top+'px';dock.style.right='auto';dock.style.bottom='auto';
}
function clearGuideHighlights(){if(GUIDE_TARGET)GUIDE_TARGET.classList.remove('guideTarget');if(GUIDE_NEXT_TARGET)GUIDE_NEXT_TARGET.classList.remove('guideNextTarget');GUIDE_TARGET=null;GUIDE_NEXT_TARGET=null;}
function closeGuide(){clearGuideHighlights();GUIDE_OPEN=false;$('#guideDock').hidden=true;$('#guideDimmer').hidden=true;stopGuideVoice();}
function showGuideStep(){
 if(!GUIDE_OPEN)return;
 clearGuideHighlights();
 const step=GUIDE_STEPS[GUIDE_INDEX];if(!step){closeGuide();return;}
 if(step.prepare)step.prepare();
 $('#guideCounter').textContent=`${GUIDE_KIND==='full'?'Full tour':GUIDE_KIND==='local'?'Local FHIR tour':'Guided walkthrough'} · Step ${GUIDE_INDEX+1} of ${GUIDE_STEPS.length}`;
 $('#guideTitle').textContent=step.title;$('#guideBody').textContent=step.body;$('#guideHint').textContent='';
 $('#guideProgressBar').style.width=(100*(GUIDE_INDEX+1)/GUIDE_STEPS.length)+'%';
 $('#guideBack').disabled=GUIDE_INDEX===0;$('#guideNext').textContent=GUIDE_INDEX===GUIDE_STEPS.length-1?'Finish':'Next';
 if(step.optional)$('#guideHint').textContent='Optional feature — use Skip this step if it is not available now.';
 const next=GUIDE_STEPS[GUIDE_INDEX+1];$('#guideNextPreview').hidden=!next;$('#guideNextTitle').textContent=next?next.title:'Tour complete';
 if(step.target){GUIDE_TARGET=guideVisibleTarget(step.target);if(GUIDE_TARGET){GUIDE_TARGET.classList.add('guideTarget');GUIDE_TARGET.scrollIntoView({behavior:'smooth',block:'center',inline:'nearest'});}}
 if(next?.target){GUIDE_NEXT_TARGET=guideVisibleTarget(next.target);if(GUIDE_NEXT_TARGET&&GUIDE_NEXT_TARGET!==GUIDE_TARGET)GUIDE_NEXT_TARGET.classList.add('guideNextTarget');}
 requestAnimationFrame(placeGuideDock);
 speakGuideStep();
}
function startGuide(kind){
 GUIDE_KIND=kind;GUIDE_STEPS=kind==='local'?LOCAL_GUIDE:kind==='full'?FULL_GUIDE:CORE_GUIDE;GUIDE_INDEX=0;GUIDE_OPEN=true;GUIDE_USER_MOVED=false;$('#guideDock').hidden=false;$('#guideDimmer').hidden=false;showGuideStep();
}
function initGuideDrag(){
 const handle=$('#guideDragHandle'),dock=$('#guideDock');
 handle.addEventListener('pointerdown',e=>{if(e.target.closest('button'))return;const r=dock.getBoundingClientRect();GUIDE_USER_MOVED=true;GUIDE_DRAG={x:e.clientX,y:e.clientY,left:r.left,top:r.top,pointerId:e.pointerId};handle.setPointerCapture?.(e.pointerId);e.preventDefault();});
 handle.addEventListener('pointermove',e=>{if(!GUIDE_DRAG)return;const w=dock.offsetWidth,h=dock.offsetHeight;const left=Math.max(6,Math.min(window.innerWidth-w-6,GUIDE_DRAG.left+e.clientX-GUIDE_DRAG.x));const top=Math.max(6,Math.min(window.innerHeight-h-6,GUIDE_DRAG.top+e.clientY-GUIDE_DRAG.y));dock.style.left=left+'px';dock.style.top=top+'px';dock.style.right='auto';dock.style.bottom='auto';});
 const end=()=>{GUIDE_DRAG=null;};handle.addEventListener('pointerup',end);handle.addEventListener('pointercancel',end);
 $('#guideAutoPlace').addEventListener('click',()=>{GUIDE_USER_MOVED=false;placeGuideDock();});
 window.addEventListener('resize',()=>{if(GUIDE_OPEN&&!GUIDE_USER_MOVED)placeGuideDock();});
}
function nextGuide(){
 const step=GUIDE_STEPS[GUIDE_INDEX];
 if(step&&step.require&&!step.require()&&!step.optional){$('#guideHint').textContent=step.requireMessage||'Complete the highlighted action before continuing.';if($('#guideVoice').checked)speakGuideStep();return;}
 if(step&&step.require&&!step.require()&&step.optional){$('#guideHint').textContent='This optional step was not completed; continuing.';}
 if(GUIDE_INDEX>=GUIDE_STEPS.length-1){closeGuide();return;}GUIDE_INDEX++;showGuideStep();
}
function skipGuideStep(){if(GUIDE_INDEX>=GUIDE_STEPS.length-1){closeGuide();return;}GUIDE_INDEX++;showGuideStep();}
$('#startGuide').addEventListener('click',()=>startGuide('core'));
$('#startLocalGuide').addEventListener('click',()=>startGuide('local'));
$('#startFullGuide').addEventListener('click',()=>startGuide('full'));
$('#openWrittenGuide').addEventListener('click',()=>{$('#tutorial').open=true;$('#tutorial').scrollIntoView({behavior:'smooth',block:'start'})});
$('#guideNext').addEventListener('click',nextGuide);
$('#guideBack').addEventListener('click',()=>{if(GUIDE_INDEX>0){GUIDE_INDEX--;showGuideStep()}});
$('#guideSkipStep').addEventListener('click',skipGuideStep);
$('#guideSkip').addEventListener('click',closeGuide);
$('#guideClose').addEventListener('click',closeGuide);
$('#guideSpeak').addEventListener('click',speakGuideStep);
$('#guideStopVoice').addEventListener('click',stopGuideVoice);
initGuideDrag();
$('#guideVoice').addEventListener('change',()=>{if(!$('#guideVoice').checked){stopGuideVoice();$('#guideVoiceStatus').textContent='Voice off';}else{speakGuideStep();}});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&GUIDE_OPEN)closeGuide()});
