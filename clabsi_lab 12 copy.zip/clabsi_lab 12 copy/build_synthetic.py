"""Build exportable FHIR R4 bundles for fully fictional test patients, offline."""
import json
from pathlib import Path
from synthetic import SCENARIOS, fhir_bundle,make_scenario
OUT=Path(__file__).resolve().parent/'synthetic_patients'
OUT.mkdir(exist_ok=True)
index=[]
for sid in SCENARIOS:
    p=make_scenario(sid)
    (OUT/(sid+'.json')).write_text(json.dumps(fhir_bundle(sid),ensure_ascii=False,indent=2)+'\n')
    index.append({'scenario':sid,'name':p['name'],'gold':p['gold'],'notes':len(p['notes']),
                  'fhir_patient_id':p['patient_id'],'filename':sid+'.json'})
(OUT/'index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
print(f'Exported {len(index)} fictional FHIR R4 bundles to {OUT}')
