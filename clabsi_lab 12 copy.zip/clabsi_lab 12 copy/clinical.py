"""CLABSI FHIR Lab: intentionally conservative evidence extraction (not NHSN adjudication)."""
import base64
import html
import re
from datetime import datetime, date, timedelta
from html.parser import HTMLParser
from collections import Counter

class TextExtractor(HTMLParser):
    def __init__(self):
        super().__init__(); self.parts=[]; self.ignored=0
    def handle_starttag(self, tag, attrs):
        if tag in ('script','style'): self.ignored += 1
        elif not self.ignored and tag in ('br','p','div','li','tr','h1','h2','h3'): self.parts.append('\n')
    def handle_endtag(self, tag):
        if tag in ('script','style'): self.ignored=max(0,self.ignored-1)
        elif not self.ignored and tag in ('p','div','li','tr'): self.parts.append('\n')
    def handle_data(self, data):
        if not self.ignored: self.parts.append(data)

def readable_note(content, mime='text/plain'):
    content = content[:600000]
    if 'html' in mime.lower():
        parser=TextExtractor(); parser.feed(content); s=parser.get_data() if hasattr(parser,'get_data') else ''.join(parser.parts)
        return re.sub(r'\n{3,}', '\n\n', html.unescape(s)).strip()
    if 'rtf' in mime.lower(): return '[RTF note: original format requires an RTF reader; not interpreted]'
    return content.strip()

def display(concept):
    if not isinstance(concept,dict): return ''
    return concept.get('text') or next((c.get('display') or c.get('code') for c in concept.get('coding',[]) if c.get('display') or c.get('code')), '')

def ref_id(resource):
    return f"{resource.get('resourceType','Unknown')}/{resource.get('id','?')}"

def stamp(resource):
    if resource.get('resourceType')=='DocumentReference': return resource.get('date') or resource.get('content',[{}])[0].get('attachment',{}).get('creation')
    if resource.get('resourceType')=='Encounter': return resource.get('period',{}).get('start')
    if resource.get('resourceType')=='Specimen': return resource.get('collection',{}).get('collectedDateTime')
    return resource.get('effectiveDateTime') or resource.get('issued') or resource.get('occurrenceDateTime') or resource.get('authoredOn')

def iso_date(value):
    try: return date.fromisoformat(str(value)[:10])
    except (TypeError,ValueError): return None

def demo_note(note_id,when,title,text):
    binary={'resourceType':'Binary','id':note_id,'contentType':'text/html',
            'data':base64.b64encode(('<p>'+html.escape(text).replace('\n','</p><p>')+'</p>').encode()).decode()}
    doc={'resourceType':'DocumentReference','id':note_id,'status':'current','docStatus':'final',
         'subject':{'reference':'Patient/demo'},'date':when,'type':{'text':title},
         'content':[{'attachment':{'contentType':'text/html','url':'Binary/'+note_id}}]}
    return doc,binary

def obs(oid, when, label, value, kind, positive=None):
    out={'resourceType':'Observation','id':oid,'status':'final','subject':{'reference':'Patient/demo'},
         'effectiveDateTime':when,
         'code':{'coding':[{'system':'https://example.invalid/fhir/demo-codes','code':kind,'display':label}], 'text':label}}
    if kind=='blood-culture':
        out['code']={'coding':[{'system':'http://loinc.org','code':'600-7','display':'Bacteria identified in Blood by Culture'}], 'text':'Blood culture'}
        out['specimen']={'reference':'Specimen/blood-'+oid}
        out['valueCodeableConcept']={'text':value}
        out['interpretation']=[{'text':'Positive' if positive else 'No growth'}]
    elif kind=='temperature':
        out['code']={'coding':[{'system':'http://loinc.org','code':'8310-5','display':'Body temperature'}],'text':'Temperature'}
        out['valueQuantity']={'value':value,'unit':'Cel'}
    elif kind in ('line-insert','line-access','line-remove'):
        out['valueString']=value
    else: out['valueString']=str(value)
    return out

def fixture(case):
    """Every datum is made up. Custom line event codes are synthetic, not an Epic mapping."""
    cases={
      'possible': {'name':'Case A — possible CLABSI', 'summary':'Positive S. aureus blood culture after a central line has been in place.','culture':'Staphylococcus aureus',
         'blood_when':'2026-10-06T09:40:00-04:00','admit':'2026-10-01T13:00:00-04:00',
         'insert':'2026-10-02T12:00:00-04:00','access':'2026-10-02T13:00:00-04:00',
         'notes':[
           ('2026-10-02T12:45:00-04:00','Procedure note','Right internal jugular central venous catheter placed with sterile precautions. Tip confirmed. Line accessed for infusion.'),
           ('2026-10-06T15:30:00-04:00','Infectious Diseases consult','Fever to 39.1 C and S. aureus in blood cultures. Possible line-associated infection. No definite alternate source identified in initial assessment. Evaluate skin, urine, and other foci. Do not equate suspicion with NHSN classification.'),
           ('2026-10-07T07:00:00-04:00','Progress note','Central line removed for suspected source control. Surveillance criteria and possible secondary source still require formal evaluation.')],
         'extra':[]},
      'alternate': {'name':'Case B — competing source', 'summary':'A blood culture coincides with a documented urinary source.','culture':'Escherichia coli',
         'blood_when':'2026-10-06T10:10:00-04:00','admit':'2026-10-01T13:00:00-04:00',
         'insert':'2026-10-02T12:00:00-04:00','access':'2026-10-02T13:00:00-04:00',
         'notes':[
           ('2026-10-02T12:30:00-04:00','Procedure note','Right internal jugular CVC inserted and used for IV therapy.'),
           ('2026-10-06T16:00:00-04:00','Urology note','Febrile patient with obstructing ureteral stone and clinical pyelonephritis. E. coli identified in urine and blood. Verify whether the exact NHSN urinary tract infection criteria and secondary BSI attribution period are satisfied.'),
           ('2026-10-07T09:00:00-04:00','Infectious Diseases consult','Urinary source strongly favored clinically. The presence of a line alone does not establish CLABSI. Formal infection prevention attribution is pending.')],
         'extra':[obs('urine-1','2026-10-06T08:55:00-04:00','Urine culture','Escherichia coli','urine-culture')]},
      'commensal': {'name':'Case C — possible contaminant', 'summary':'A single common-commensal positive blood culture requires more evaluation.','culture':'Staphylococcus epidermidis',
         'blood_when':'2026-10-06T09:40:00-04:00','admit':'2026-10-01T13:00:00-04:00',
         'insert':'2026-10-02T12:00:00-04:00','access':'2026-10-02T13:00:00-04:00',
         'notes':[
           ('2026-10-02T12:00:00-04:00','Line placement note','Left IJ CVC placed and used.'),
           ('2026-10-06T18:00:00-04:00','Progress note','One blood culture with S. epidermidis. No matching second positive specimen documented in the available record; repeat cultures pending. Clinical significance unclear.')],
         'extra':[]},
      'missing': {'name':'Case D — missing line data', 'summary':'Positive culture, but line eligibility cannot be established from available material.','culture':'Staphylococcus aureus',
         'blood_when':'2026-10-06T09:40:00-04:00','admit':'2026-10-01T13:00:00-04:00',
         'insert':None,'access':None,
         'notes':[('2026-10-06T18:00:00-04:00','Progress note','S. aureus bacteremia. The note mentions a PICC but its insertion/access dates and removal status are not available here.')],
         'extra':[]}}
    if case not in cases: raise ValueError('Unknown demonstration case')
    cfg=cases[case]
    records=[{'resourceType':'Patient','id':'demo','name':[{'given':['Fictional'],'family':'Patient'}]},
             {'resourceType':'Encounter','id':'enc','status':'in-progress','subject':{'reference':'Patient/demo'},'period':{'start':cfg['admit']}}]
    if cfg['insert']: records.append(obs('line-placed',cfg['insert'],'Central venous line inserted','Internal jugular CVC','line-insert'))
    if cfg['access']: records.append(obs('line-access',cfg['access'],'Central venous line accessed','Infusion','line-access'))
    records.append(obs('fever','2026-10-06T07:50:00-04:00','Temperature',39.1,'temperature'))
    records.append(obs('blood-1',cfg['blood_when'],'Blood culture',cfg['culture'],'blood-culture',True))
    records+=cfg['extra']
    if case=='possible': records.append(obs('line-removal','2026-10-07T06:30:00-04:00','Central venous line removed','CVC removed','line-remove'))
    notes={}
    for i,(when,title,body) in enumerate(cfg['notes'],1):
        doc,binary=demo_note('note-'+str(i),when,title,body)
        records.append(doc); notes[ref_id(doc)]={'title':title,'text':readable_note(base64.b64decode(binary['data']).decode(),'text/html'),'date':when,'binary':ref_id(binary)}
        records.append(binary)
    return {'case':case,'name':cfg['name'],'summary':cfg['summary'],'records':records,'notes':notes}

def parse_culture(r):
    if r.get('resourceType')!='Observation': return None
    name=display(r.get('code',{})).lower()
    coding=[str(c.get('code','')) for c in r.get('code',{}).get('coding',[])]
    if not ('blood culture' in name or 'blood by culture' in name or '600-7' in coding): return None
    value=display(r.get('valueCodeableConcept',{})) or r.get('valueString','')
    interpret=' '.join(display(x) for x in r.get('interpretation',[])).lower()
    if any(x in str(value).lower() for x in ('no growth','negative','not detected')) or 'negative' in interpret:
        positive=False
    else:
        positive=bool(value and (('positive' in interpret) or any(s in str(value).lower() for s in ('staphylococcus','escherichia','klebsiella','enterococcus','pseudomonas','candida','streptococcus','bacteremia'))))
    return {'organism':str(value),'positive':positive,'date':stamp(r),'source':ref_id(r)}

def classify(records, notes, coverage, is_demo=False):
    culture=[c for r in records if (c:=parse_culture(r))]
    positive=[c for c in culture if c['positive']]
    events=[]
    line_insert=None; line_access=None; line_remove=None; admit=None
    for r in records:
        typ=r.get('resourceType'); rid=ref_id(r); ts=stamp(r)
        if typ=='Encounter': admit=iso_date(r.get('period',{}).get('start'))
        if typ=='Observation':
            code=next((x.get('code') for x in r.get('code',{}).get('coding',[]) if x.get('system')=='https://example.invalid/fhir/demo-codes'),None)
            if code=='line-insert': line_insert=iso_date(ts)
            if code=='line-access': line_access=iso_date(ts)
            if code=='line-remove': line_remove=iso_date(ts)
            cult=parse_culture(r)
            if cult: events.append({'when':ts,'label':'Blood culture: '+cult['organism'], 'kind':'culture' if cult['positive'] else 'other','source':rid,'detail':'Positive' if cult['positive'] else 'Not identified as positive'})
            elif code=='urine-culture': events.append({'when':ts,'label':'Urine culture: '+str(r.get('valueString','')),'kind':'alternate','source':rid,'detail':'Investigate alternate infection source'})
            elif code and code.startswith('line-'): events.append({'when':ts,'label':display(r.get('code',{})), 'kind':'line','source':rid,'detail':r.get('valueString','')})
            elif code=='temperature': events.append({'when':ts,'label':'Temperature '+str(r.get('valueQuantity',{}).get('value'))+' °C','kind':'vital','source':rid,'detail':'Fever is contextual; not sufficient for LCBI 1'})
        elif typ=='Encounter': events.append({'when':ts,'label':'Hospital encounter begins','kind':'encounter','source':rid,'detail':'Encounter data'})
        elif typ=='DiagnosticReport':
            results=', '.join(x.get('reference','') for x in r.get('result',[])[:8])
            events.append({'when':ts,'label':'Diagnostic report: '+display(r.get('code',{})),
                           'kind':'other','source':rid,'detail':(r.get('conclusion','')+' '+results).strip()[:320]})
        elif typ=='Procedure':
            events.append({'when':ts,'label':'Procedure: '+display(r.get('code',{})),
                           'kind':'line' if 'central' in display(r.get('code',{})).lower() else 'other',
                           'source':rid,'detail':'Procedure evidence; not independently verified as first line access'})
        elif typ=='MedicationRequest':
            med=display(r.get('medicationCodeableConcept',{})) or r.get('medicationReference',{}).get('display','')
            events.append({'when':ts,'label':'Medication ordered: '+med,
                           'kind':'other','source':rid,'detail':'An order does not prove administration'})
        elif typ=='Specimen':
            events.append({'when':ts,'label':'Specimen: '+display(r.get('type',{})),
                           'kind':'other','source':rid,'detail':'Specimen metadata, not a positive culture result'})
    for rid,n in notes.items():
        excerpt=n.get('text','')[:260]
        events.append({'when':n.get('date'),'label':n.get('title') or 'Clinical note','kind':'note','source':rid,'detail':excerpt})
    events=sorted([e for e in events if e['when']],key=lambda e:e['when'])
    evidence=[]; checks=[]
    if positive:
        first=min(positive,key=lambda p:p['date'] or '9999')
        evidence.append({'text':f"Positive blood culture candidate: {first['organism']} ({first['date'][:10] if first['date'] else 'date unknown'}).",'source':first['source']})
        known_common=any(x in first['organism'].lower() for x in ('epidermidis','coagulase-negative','micrococcus','corynebacterium','cutibacterium','bacillus sp'))
        if known_common:
            checks.append({'name':'LCBI laboratory criterion','status':'review','text':'Common commensal: matching specimens from separate occasions and qualifying symptoms must be assessed. One positive specimen alone is insufficient.'})
            title='Laboratory criterion not established'; tone='uncertain'
        else:
            checks.append({'name':'LCBI laboratory criterion','status':'candidate','text':'Recognized-pathogen candidate; confirm organism mapping, specimen, and relevant event definition.'})
            title='Possible CLABSI — requires review'; tone='possible'
    else:
        first=None; known_common=False; title='No positive blood culture identified'; tone='uncertain'
        checks.append({'name':'LCBI laboratory criterion','status':'unknown','text':'No qualifying culture detected in retrieved records; incomplete or differently coded results cannot be excluded.'})
    doe=iso_date(first['date']) if first else None
    if admit and doe:
        had=(doe-admit).days+1
        checks.append({'name':'Healthcare-associated timing','status':'candidate' if had>=3 else 'review','text':f'Candidate specimen collected on inpatient calendar day {had}; final date of event requires NHSN infection-window analysis.'})
    else: checks.append({'name':'Healthcare-associated timing','status':'unknown','text':'Admission date or candidate event date unavailable.'})
    if line_insert and line_access and doe:
        line_day=(doe-max(line_insert,line_access)).days+1
        eligible=line_day>=3 and (not line_remove or line_remove>=doe-timedelta(days=1))
        checks.append({'name':'Central-line eligibility','status':'candidate' if eligible else 'review','text':f'In synthetic structured data, first access and placement are documented; candidate event is central-line day {line_day}. Eligibility also depends on line continuity and actual NHSN date of event.'})
        evidence.append({'text':f'Central line placement {line_insert} and access {line_access} (synthetic structured events).','source':'Observation/line-placed'})
    else:
        checks.append({'name':'Central-line eligibility','status':'unknown','text':'Line placement, first access, continuity, and/or date of event are not reliably established.'})
        if positive and not known_common: title='Possible BSI; line eligibility unknown'; tone='uncertain'
    alt=[e for e in events if e['kind']=='alternate']
    alt_notes=[(rid,n) for rid,n in notes.items() if re.search(r'pyelonephritis|urinary source|obstructing ureteral',n.get('text',''),re.I)]
    if alt or alt_notes:
        checks.append({'name':'Secondary BSI exclusion','status':'review','text':'Potential urinary source is documented. Formal NHSN site-specific UTI criteria, organism matching, and attribution-period rules must be verified.'})
        title='Competing source — attribution unresolved'; tone='uncertain'
        if alt: evidence.append({'text':'Matching non-blood culture is available; this alone does not prove NHSN secondary attribution.','source':alt[0]['source']})
        else: evidence.append({'text':'Clinical note indicates a possible urinary source.','source':alt_notes[0][0]})
    else:
        checks.append({'name':'Secondary BSI exclusion','status':'unknown','text':'A second source has not been established by this limited retrieval; absence of evidence is not exclusion.'})
    checks.append({'name':'Additional NHSN exclusions','status':'unknown','text':'MBI-LCBI, special exclusions, infection-window, repeat infection timeframe and location attribution require review.'})
    if known_common: title='Single commensal: insufficient LCBI evidence'
    holes=[]
    for key,label in [('DocumentReference','Clinical notes'),('Observation','Observations / microbiology'),('Encounter','Hospital encounter'),('Device','Devices')]:
        hits=[c for c in coverage if c.get('resource')==key]
        if hits and all(c.get('status') in ('error','unsupported','incomplete') for c in hits): holes.append(label+' not reliably retrieved')
    if not line_insert: holes.append('Verified central-line insertion/first-access dates unavailable')
    if not is_demo: holes.append('FHIR alone does not establish complete NHSN surveillance eligibility')
    return {'title':title,'tone':tone,'summary':'Research screening only; no automated NHSN reportable-CLABSI determination.','events':events,
            'evidence':evidence,'checks':checks,'cultures':culture,'notes':notes,'coverage':coverage,
            'missing':holes,'count':len(records),'resources':records,
            'method':'Synthetic structured line codes are for demonstration only' if is_demo else 'Live FHIR screening: unstructured line and infection evidence requires validation'}
