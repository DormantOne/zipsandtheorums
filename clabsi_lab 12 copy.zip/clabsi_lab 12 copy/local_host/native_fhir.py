#!/usr/bin/env python3
"""Self-contained, loopback-only FHIR R4 REST *subset* for synthetic CLABSI charts.

Implements R4 JSON resource CRUD (read and idempotent PUT via transaction Bundle),
patient/category search and paging for the resource types exercised by CLABSI Lab.
This is NOT a complete FHIR server or interoperability conformance implementation.
It has no authentication and must NEVER be used with actual patient information.
"""
import json
from contextlib import closing
import os
import re
import sqlite3
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlencode, urlparse

DB_PATH = Path(__file__).parent / 'synthetic_fhir.sqlite3'
ALLOWED_TYPES = frozenset(('Patient','Encounter','DocumentReference','Binary','Observation',
    'DiagnosticReport','Condition','Device','DeviceUseStatement','Procedure','Specimen',
    'MedicationRequest','MedicationAdministration'))
FHIR_VERSION = '4.0.1'
ID_RE = re.compile(r'^[A-Za-z0-9.\-]{1,64}$')
MAX_BODY = 12_000_000
_ACTIVE = None
_ACTIVE_LOCK = threading.Lock()


def connect(db_path=None):
    p = str(db_path or DB_PATH)
    conn = sqlite3.connect(p, timeout=15)
    conn.execute('PRAGMA journal_mode=WAL')
    conn.execute('PRAGMA busy_timeout=15000')
    conn.execute('''CREATE TABLE IF NOT EXISTS resources (
      resource_type TEXT NOT NULL,
      id TEXT NOT NULL,
      patient_id TEXT,
      category TEXT,
      json TEXT NOT NULL,
      PRIMARY KEY (resource_type,id))''')
    conn.execute('CREATE INDEX IF NOT EXISTS idx_resource_patient ON resources(resource_type,patient_id)')
    conn.commit()
    return conn


def get_patient_id(res):
    if res['resourceType']=='Patient': return res['id']
    for key in ('subject','patient'):
        ref = (res.get(key) or {}).get('reference','')
        if ref.startswith('Patient/'): return ref.split('/')[-1]
    return None


def get_categories(res):
    result=[]
    for category in res.get('category',[]):
        result.extend(c.get('code','') for c in category.get('coding',[]))
    return ','.join(result)


def put_resource(conn, res, method='PUT', route=''):
    if not isinstance(res,dict): raise ValueError('FHIR entry resource must be an object')
    kind,id_=res.get('resourceType'),res.get('id')
    if kind not in ALLOWED_TYPES or not isinstance(id_,str) or not ID_RE.fullmatch(id_):
        raise ValueError('Unsupported or malformed FHIR resource type/id')
    if method!='PUT' or route!=f'{kind}/{id_}':
        raise ValueError('Only correctly addressed idempotent transaction PUT requests are allowed')
    old=conn.execute('SELECT 1 FROM resources WHERE resource_type=? AND id=?',(kind,id_)).fetchone()
    conn.execute('''INSERT INTO resources(resource_type,id,patient_id,category,json) VALUES (?,?,?,?,?)
      ON CONFLICT(resource_type,id) DO UPDATE SET patient_id=excluded.patient_id,
      category=excluded.category, json=excluded.json''',
      (kind,id_,get_patient_id(res),get_categories(res),json.dumps(res,separators=(',',':'),ensure_ascii=False)))
    return '200 OK' if old else '201 Created'


def capability(port):
    return {'resourceType':'CapabilityStatement','id':'clabsi-local-r4-subset',
            'status':'active','date':'2026-11-12','kind':'instance',
            'fhirVersion':FHIR_VERSION,'format':['json','application/fhir+json'],
            'software':{'name':'CLABSI Local FHIR R4 Subset','version':'0.7.3'},
            'implementation':{'description':'Synthetic-only limited FHIR R4 REST test interface, not full FHIR conformance',
                              'url':f'http://127.0.0.1:{port}/fhir'},
            'rest':[{'mode':'server','resource':[{'type':r,'interaction':[{'code':'read'},{'code':'search-type'}]} for r in sorted(ALLOWED_TYPES)]}]}


def resource_match(res, patient='', category=''):
    if patient and get_patient_id(res)!=patient: return False
    if category and category not in get_categories(res).split(','): return False
    return True


def create_handler(db_path=None):
    class FHIRHandler(BaseHTTPRequestHandler):
        server_version='CLABSI-FHIR-Subset/0.7.3'
        def log_message(self, fmt, *args):
            # No clinical content, query text or patient ids in server logs.
            return
        def respond(self, data, status=200):
            body=json.dumps(data,ensure_ascii=False,separators=(',',':')).encode('utf-8')
            self.send_response(status)
            self.send_header('Content-Type','application/fhir+json; charset=utf-8')
            self.send_header('Cache-Control','no-store')
            self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Content-Length',str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        def failure(self, status, msg):
            self.respond({'resourceType':'OperationOutcome','issue':[{'severity':'error',
                'code':'processing' if status!=404 else 'not-found','diagnostics':msg[:240]}]},status)
        def valid_host(self):
            return self.headers.get('Host','') in (f'127.0.0.1:{self.server.server_port}',f'localhost:{self.server.server_port}')
        def do_GET(self):
            if not self.valid_host(): return self.failure(403,'Request host is not local')
            parsed=urlparse(self.path)
            path=parsed.path.rstrip('/')
            if path=='/fhir/metadata': return self.respond(capability(self.server.server_port))
            parts=path.split('/')
            if len(parts) not in (3,4) or parts[:2]!=['','fhir'] or parts[2] not in ALLOWED_TYPES:
                return self.failure(404,'FHIR resource endpoint not found')
            kind=parts[2]
            with closing(connect(db_path)) as conn:
                if len(parts)==4:
                    if not ID_RE.fullmatch(parts[3]): return self.failure(400,'Invalid resource ID')
                    row=conn.execute('SELECT json FROM resources WHERE resource_type=? AND id=?',(kind,parts[3])).fetchone()
                    if not row: return self.failure(404,'FHIR resource not found')
                    return self.respond(json.loads(row[0]))
                query=parse_qs(parsed.query)
                p=(query.get('patient') or [''])[0]
                if p.startswith('Patient/'): p=p[8:]
                cat=(query.get('category') or [''])[0]
                if p and not ID_RE.fullmatch(p): return self.failure(400,'Malformed patient search parameter')
                if cat and not re.fullmatch(r'[A-Za-z0-9._-]{1,64}',cat):return self.failure(400,'Malformed category search parameter')
                try:
                    count=max(1,min(int((query.get('_count') or [50])[0]),100))
                    page=max(1,min(int((query.get('_page') or [1])[0]),10000))
                except ValueError: return self.failure(400,'Invalid FHIR search paging parameter')
                rows=conn.execute('SELECT json FROM resources WHERE resource_type=? ORDER BY id',(kind,)).fetchall()
                matches=[json.loads(row[0]) for row in rows]
                matches=[r for r in matches if resource_match(r,p,cat)]
                total=len(matches); first=(page-1)*count
                matches=matches[first:first+count]
                entries=[{'fullUrl':f'http://127.0.0.1:{self.server.server_port}/fhir/{kind}/{r["id"]}',
                          'resource':r,'search':{'mode':'match'}} for r in matches]
                def link(pg):
                    q={key:val[0] for key,val in query.items() if key!='_page'}
                    q['_count']=str(count);q['_page']=str(pg)
                    return f'http://127.0.0.1:{self.server.server_port}/fhir/{kind}?{urlencode(q)}'
                links=[{'relation':'self','url':link(page)}]
                if first+count<total:links.append({'relation':'next','url':link(page+1)})
                if page>1:links.append({'relation':'previous','url':link(page-1)})
                return self.respond({'resourceType':'Bundle','type':'searchset','total':total,'link':links,'entry':entries})
        def do_POST(self):
            if not self.valid_host(): return self.failure(403,'Request host is not local')
            if urlparse(self.path).path.rstrip('/')!='/fhir':return self.failure(404,'FHIR transaction endpoint not found')
            try:
                length=int(self.headers.get('Content-Length','0'))
                if length<1 or length>MAX_BODY:return self.failure(413,'FHIR transaction payload limit exceeded')
                body=json.loads(self.rfile.read(length))
                if body.get('resourceType')!='Bundle' or body.get('type')!='transaction':
                    return self.failure(400,'Only FHIR transaction Bundles supported')
                items=body.get('entry',[])
                if not isinstance(items,list) or len(items)>500:
                    return self.failure(400,'Invalid or oversized transaction entries')
                with closing(connect(db_path)) as conn, conn:
                    replies=[]
                    for entry in items:
                        if not isinstance(entry,dict):raise ValueError('Malformed Bundle entry')
                        request=entry.get('request',{})
                        status=put_resource(conn, entry.get('resource'),request.get('method'),request.get('url'))
                        replies.append({'response':{'status':status}})
                return self.respond({'resourceType':'Bundle','type':'transaction-response','entry':replies})
            except (ValueError,TypeError,json.JSONDecodeError) as exc:
                return self.failure(400,str(exc))
            except sqlite3.Error:
                return self.failure(500,'FHIR database error')
    return FHIRHandler


class LoopbackServer(ThreadingHTTPServer):
    daemon_threads=True
    allow_reuse_address=True


def ensure_started(preferred_ports=(8890,8891,8892),db_path=None):
    """Start a true localhost FHIR HTTP listener, or return the existing in-process one."""
    global _ACTIVE
    with _ACTIVE_LOCK:
        if _ACTIVE is not None: return _ACTIVE.server_port
        bind_error=None
        for port in preferred_ports:
            try:
                service=LoopbackServer(('127.0.0.1',port),create_handler(db_path))
                threading.Thread(target=service.serve_forever,daemon=True,name='clabsi-native-fhir').start()
                _ACTIVE=service
                return service.server_port
            except OSError as e: bind_error=e
        raise RuntimeError(f'No available loopback FHIR port among {preferred_ports}: {bind_error}')


def stop():
    global _ACTIVE
    with _ACTIVE_LOCK:
        service,_ACTIVE=_ACTIVE,None
    if service:
        service.shutdown();service.server_close()


if __name__=='__main__':
    import time
    port=ensure_started()
    print(f'CLABSI synthetic-only FHIR R4 subset: http://127.0.0.1:{port}/fhir',flush=True)
    try:
        while True:time.sleep(3)
    except KeyboardInterrupt:stop()
