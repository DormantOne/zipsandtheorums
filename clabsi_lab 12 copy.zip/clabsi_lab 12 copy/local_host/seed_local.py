#!/usr/bin/env python3
"""Load BLIND synthetic CLABSI chart cases into a real FHIR R4 server.

Only supports our own fixed loopback HAPI server. Never import a real patient.
"""
import copy
import os
import json
import re
import sys
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError

ROOT=Path(__file__).resolve().parent.parent
FHIR=os.environ.get('CLABSI_LOCAL_FHIR_BASE','http://127.0.0.1:8890/fhir').rstrip('/')
ORIGINS=['line_candidate','urinary_source','single_commensal','early_line','missing_dates','buried_negation','long_chart']
LAB_CATEGORY={'coding':[{'system':'http://terminology.hl7.org/CodeSystem/observation-category','code':'laboratory','display':'Laboratory'}]}
VITAL_CATEGORY={'coding':[{'system':'http://terminology.hl7.org/CodeSystem/observation-category','code':'vital-signs','display':'Vital Signs'}]}
PROCEDURE_CATEGORY={'coding':[{'system':'http://terminology.hl7.org/CodeSystem/observation-category','code':'procedure','display':'Procedure'}]}


def clean_id(v):
    return re.sub('[^A-Za-z0-9.\\-]','-',v)


def req(method,url,body=None):
    if not (url==FHIR or url.startswith(FHIR+'/')): raise ValueError('Unsafe destination')
    data=json.dumps(body).encode() if body is not None else None
    r=Request(url,data=data,method=method,headers={'Accept':'application/fhir+json','Content-Type':'application/fhir+json'})
    try:
        with urlopen(r,timeout=100) as response: return response.status,json.load(response)
    except HTTPError as e:
        message=e.read(4000).decode('utf-8','replace')
        raise RuntimeError(f'{method} failed HTTP {e.code}: {message[:900]}') from None


def convert_case(key,num):
    """Take original collection Bundle, remap every ID, rewrite refs, add missing FHIR resources."""
    source=json.loads((ROOT/'synthetic_patients'/f'{key}.json').read_text())
    patient=f'lab-p{num:03d}'
    items=[copy.deepcopy(e['resource']) for e in source.get('entry',[]) if e.get('resource')]
    mapping={}
    for r in items:
        kind=r['resourceType'];orig=r['id']
        new=patient if kind=='Patient' else f'p{num:03d}-{clean_id(orig)}'
        if len(new)>64: new=new[:64]
        mapping[f'{kind}/{orig}']=f'{kind}/{new}'
        r['id']=new
    # Remap all internal FHIR references and note URLs; don't rewrite explanatory text.
    def fix_ref(obj):
        if isinstance(obj,dict):
            for k,v in obj.items():
                if k in ('reference','url') and isinstance(v,str) and v in mapping:
                    obj[k]=mapping[v]
                else: fix_ref(v)
        elif isinstance(obj,list):
            for x in obj:fix_ref(x)
    for r in items:fix_ref(r)
    for r in items:
        kind=r['resourceType']
        if kind=='Patient':
            r['name']=[{'family':'Fictional','given':[f'Patient {num:03d}']}]
            r['identifier']=[{'system':'https://example.org/fhir/synthetic-study','value':f'P{num:03d}'}]
        if kind=='Observation':
            code=r.get('code',{}).get('coding',[{}])[0].get('code','')
            r['category']=[VITAL_CATEGORY if code=='8310-5' else LAB_CATEGORY if code=='600-7' else PROCEDURE_CATEGORY]
    # If the source references Specimen resources, create them with collection times.
    byid={f"{r['resourceType']}/{r['id']}":r for r in items}
    for r in list(items):
        if r['resourceType']!='Observation' or not r.get('specimen',{}).get('reference'):continue
        ref=r['specimen']['reference']
        if ref.startswith('Specimen/'):
            specid=f'p{num:03d}-spec-{clean_id(r["id"])}'[:64]
            r['specimen']['reference']='Specimen/'+specid
            if 'Specimen/'+specid not in byid:
                spec={'resourceType':'Specimen','id':specid,'status':'available',
                      'type':{'text':'Blood culture specimen'},'subject':{'reference':'Patient/'+patient},
                      'collection':{'collectedDateTime':r.get('effectiveDateTime','2026-10-01T00:00:00Z')}}
                items.append(spec);byid['Specimen/'+specid]=spec
    for r in list(items):
        if r['resourceType']=='Observation' and any(c.get('code')=='600-7' for c in r.get('code',{}).get('coding',[])):
            did=f'{patient}-report-{len([x for x in items if x["resourceType"]=="DiagnosticReport"])+1}'
            report={'resourceType':'DiagnosticReport','id':did,'status':'final',
                'category':[LAB_CATEGORY], 'code':{'text':'Blood culture diagnostic report'},
                'subject':{'reference':'Patient/'+patient},
                'effectiveDateTime':r.get('effectiveDateTime','2026-10-01T00:00:00Z'),
                'result':[{'reference':'Observation/'+r['id']}],
                'conclusion':r.get('valueCodeableConcept',{}).get('text','Blood culture result')}
            items.append(report)
    # Upgrade line evidence to native FHIR resource models; still synthetic only.
    insert=next((r for r in items if r['resourceType']=='Observation' and 'insert' in r.get('code',{}).get('text','').lower()),None)
    if insert:
        device={'resourceType':'Device','id':f'{patient}-cvc','status':'active',
                'type':{'text':'Central venous catheter'},'patient':{'reference':'Patient/'+patient}}
        procedure={'resourceType':'Procedure','id':f'{patient}-cvc-insertion',
                   'status':'completed','code':{'text':'Central venous catheter placement'},
                   'subject':{'reference':'Patient/'+patient},
                   'performedDateTime':insert['effectiveDateTime']}
        use={'resourceType':'DeviceUseStatement','id':f'{patient}-cvc-use','status':'active',
             'subject':{'reference':'Patient/'+patient},
             'device':{'reference':'Device/'+device['id']},
             'timingPeriod':{'start':insert['effectiveDateTime']},
             'recordedOn':insert['effectiveDateTime']}
        items.extend([device,procedure,use])
    # A self-contained transaction: server persists them in one atomic operation.
    response={'resourceType':'Bundle','type':'transaction',
      'entry':[{'fullUrl':f"{r['resourceType']}/{r['id']}",
                'resource':r,
                'request':{'method':'PUT','url':f"{r['resourceType']}/{r['id']}"}}
               for r in items]}
    return response,patient


def main():
    status,meta=req('GET',FHIR+'/metadata')
    version=meta.get('fhirVersion','')
    if not version.startswith('4.0'):
        raise RuntimeError('Expected FHIR R4 (4.0.x), got '+repr(version))
    print('Connected to a FHIR R4 endpoint (metadata verified). Version:',version, flush=True)
    for i,key in enumerate(ORIGINS,1):
        bundle,pid=convert_case(key,i)
        code,result=req('POST',FHIR,bundle)
        if result.get('resourceType')!='Bundle' or result.get('type')!='transaction-response':
            raise RuntimeError('Expected FHIR transaction-response for '+pid)
        outcomes=[e.get('response',{}).get('status','') for e in result.get('entry',[])]
        bad=[v for v in outcomes if not v.startswith(('200','201'))]
        if bad:raise RuntimeError(f'{pid}: unsuccessful resource writes: {bad}')
        _,person=req('GET',FHIR+'/Patient/'+pid)
        if person.get('resourceType')!='Patient' or person.get('id')!=pid: raise RuntimeError('Readback failed: '+pid)
        _,notes=req('GET',FHIR+'/DocumentReference?patient='+pid+'&_count=50')
        if notes.get('resourceType')!='Bundle' or not notes.get('entry'):
            raise RuntimeError('Missing indexed notes after write: '+pid)
        print(f'  {pid}: wrote {len(bundle["entry"])} resources; read back {len(notes.get("entry",[]))} notes',flush=True)
    print(f'All {len(ORIGINS)} synthetic patients have passed FHIR transaction and read-back checks.',flush=True)
    print('Visit http://127.0.0.1:8890/fhir/Patient/lab-p001',flush=True)

if __name__=='__main__':
    try:main()
    except Exception as e: print('LOCAL FHIR SEED ERROR:',e,file=sys.stderr);sys.exit(1)
