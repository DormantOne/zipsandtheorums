"""Smoke tests for loader and CLABSI query engine over real HTTP with mocked FHIR storage.

This is NOT a HAPI JPA integration test. It exercises the Python API contract.
"""
import json
import threading
import unittest
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.request import urlopen,Request
from urllib.parse import urlparse,parse_qs

sys.path.insert(0,str(Path(__file__).resolve().parent))
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from seed_local import main as seed_main
from server import Handler
DB={}

class FauxFhir(BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def send_json(self,obj,code=200):
        payload=json.dumps(obj).encode();self.send_response(code);self.send_header('Content-Type','application/fhir+json');self.send_header('Content-Length',str(len(payload)));self.end_headers();self.wfile.write(payload)
    def do_POST(self):
        if self.path!='/fhir':return self.send_json({'error':'unknown'},404)
        bundle=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        for e in bundle['entry']:
            r=e['resource'];DB[r['resourceType']+'/'+r['id']]=r
        self.send_json({'resourceType':'Bundle','type':'transaction-response',
            'entry':[{'response':{'status':'201 Created'}} for e in bundle['entry']]})
    def do_GET(self):
        p=urlparse(self.path);path=p.path
        if path=='/fhir/metadata':return self.send_json({'resourceType':'CapabilityStatement','fhirVersion':'4.0.1'})
        if not path.startswith('/fhir/'):return self.send_json({'error':'unknown'},404)
        target=path[len('/fhir/'):]
        if target in DB:return self.send_json(DB[target])
        parts=target.split('/')
        if len(parts)>1:return self.send_json({'resourceType':'OperationOutcome'},404)
        kind=parts[0];query=parse_qs(p.query)
        records=[r for r in DB.values() if r['resourceType']==kind]
        patient=query.get('patient',[None])[0]
        if patient:
            def matches(r):
                return r.get('subject',r.get('patient',{})).get('reference')=='Patient/'+patient
            records=[r for r in records if matches(r)]
        if query.get('category') and kind=='Observation':
            categories=query['category']; records=[r for r in records if any(c.get('code') in categories for cat in r.get('category',[]) for c in cat.get('coding',[]))]
        return self.send_json({'resourceType':'Bundle','type':'searchset',
                   'entry':[{'resource':r} for r in records], 'link':[]})

class E2E(unittest.TestCase):
    def test_loader_works_over_actual_http(self):
        DB.clear()
        host=ThreadingHTTPServer(('127.0.0.1',8890),FauxFhir)
        t=threading.Thread(target=host.serve_forever,daemon=True);t.start()
        try:
            seed_main()
            app=ThreadingHTTPServer(('127.0.0.1',8858),Handler)
            q=threading.Thread(target=app.serve_forever,daemon=True);q.start()
            try:
                with urlopen('http://127.0.0.1:8858/api/local_patients') as f: atlas=json.load(f)
                self.assertEqual(len(atlas['patients']),7)
                long_notes=DB.get('Patient/lab-p007')
                self.assertIsNotNone(long_notes)
                self.assertEqual(sum(1 for r in DB.values() if r['resourceType']=='DocumentReference' and r.get('subject',{}).get('reference')=='Patient/lab-p007'),27)
                request=Request('http://127.0.0.1:8858/api/analyze',method='POST',
                    data=json.dumps({'mode':'local','patient_id':'lab-p001'}).encode(),
                    headers={'Content-Type':'application/json','Origin':'http://127.0.0.1:8858'})
                with urlopen(request) as f: result=json.load(f)
                self.assertGreater(result['count'],15)
                self.assertGreater(len(result['notes']),5)
                self.assertTrue(any(n.get('text') for n in result['notes'].values()))
                self.assertTrue(any(c['label']=='Lab observations' and c['count']>0 for c in result['coverage']))
            finally:
                app.shutdown();app.server_close();q.join(timeout=2)
        finally:
            host.shutdown();host.server_close();t.join(timeout=2)
if __name__=='__main__':unittest.main()
