import sys
import re
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
sys.path.insert(0,str(Path(__file__).parent.parent))
from seed_local import convert_case,ORIGINS,clean_id
import server

class FhirHostTests(unittest.TestCase):
    def test_seven_are_fhir_transactions(self):
        for i,key in enumerate(ORIGINS,1):
            bundle,pid=convert_case(key,i)
            self.assertEqual(bundle['resourceType'],'Bundle')
            self.assertEqual(bundle['type'],'transaction')
            kinds={e['resource']['resourceType'] for e in bundle['entry']}
            self.assertTrue({'Patient','Encounter','DocumentReference','Binary','Observation'} <= kinds)
            self.assertIn('DiagnosticReport',kinds)
            self.assertIn('Specimen',kinds)
            self.assertEqual(pid,f'lab-p{i:03d}')
            ids={(e['resource']['resourceType'],e['resource']['id']) for e in bundle['entry']}
            self.assertEqual(len(ids),len(bundle['entry']))
            for e in bundle['entry']:
                r=e['resource']
                self.assertRegex(r['id'],r'^[A-Za-z0-9.\-]{1,64}$')
                self.assertEqual(e['request']['method'],'PUT')
                self.assertEqual(e['request']['url'],r['resourceType']+'/'+r['id'])
                self.assertEqual(e['fullUrl'],e['request']['url'])
                if r['resourceType']=='Patient':
                    self.assertNotIn(key,str(r))
                if r['resourceType']=='DocumentReference':
                    self.assertEqual(r['subject']['reference'],'Patient/'+pid)
                    for c in r['content']:
                        self.assertIn(('Binary',c['attachment']['url'].split('/')[1]),ids)
            labs=[e['resource'] for e in bundle['entry'] if e['resource']['resourceType']=='Observation']
            self.assertTrue(all('category' in r for r in labs))
    def test_trusted_url_keeps_localhost_local(self):
        self.assertEqual(server.trusted_url('Patient/lab-p001',server.LOCAL_BASE),server.LOCAL_BASE+'/Patient/lab-p001')
        self.assertEqual(server.trusted_url('http://localhost:8080/fhir/Patient/lab-p001',server.LOCAL_BASE),server.LOCAL_BASE+'/Patient/lab-p001')
        for url in ['http://evil.example/fhir/Patient/p','http://127.0.0.1:11434/api/generate','../../etc/passwd','https://127.0.0.1:8890/fhir']:
            with self.assertRaises(ValueError):server.trusted_url(url,server.LOCAL_BASE)
    def test_local_requests_do_not_need_epic_token(self):
        old=server.fetch_json
        try:
            def sample(url,token=None,form=None):
                self.assertTrue(url.startswith(server.LOCAL_BASE+'/'))
                self.assertIsNone(token)
                if '/Encounter?' in url or '/DocumentReference?' in url:
                    return {'resourceType':'Bundle','type':'searchset','entry':[]}
                return {'resourceType':'Bundle','type':'searchset','entry':[]}
            server.fetch_json=sample
            results,pages,incomplete=server.search('Encounter','lab-p001',base=server.LOCAL_BASE)
            self.assertEqual(results,[]);self.assertFalse(incomplete)
        finally:server.fetch_json=old

if __name__=='__main__':unittest.main()
