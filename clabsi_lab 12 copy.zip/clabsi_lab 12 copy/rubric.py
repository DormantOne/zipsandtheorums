"""Evidence-ledger and integrity evaluator for the CLABSI research prototype.

This module deliberately does NOT implement NHSN adjudication. It reconciles
model output against retrieved evidence and computes a heuristic evidence-
completeness rubric from deterministic facts rather than model self-grading.
"""
from __future__ import annotations
import json
import re
from datetime import datetime
from pathlib import Path

RUBRIC_PATH = Path(__file__).resolve().with_name('rubric.json')
VALID_DOMAIN_STATUSES = {'supported', 'partial', 'unknown', 'contradicted', 'not_applicable'}
SCORE = {'supported': 1.0, 'partial': 0.5, 'unknown': 0.0, 'contradicted': 0.0}
EVIDENCE_STATES = {'supported', 'negative', 'unknown', 'conflicting', 'not_applicable'}


def load_rubric():
    doc = json.loads(RUBRIC_PATH.read_text(encoding='utf-8'))
    assert sum(x['weight'] for x in doc['domains']) == 100
    return doc


def _s(value):
    return str(value or '').strip()


def _concept(resource):
    code = resource.get('code') or resource.get('type') or {}
    if isinstance(code, dict):
        bits = [code.get('text', '')]
        bits.extend(c.get('display', '') or c.get('code', '') for c in code.get('coding', []) if isinstance(c, dict))
        return ' '.join(x for x in bits if x).strip()
    return _s(code)


def _stamp(resource):
    for key in ('effectiveDateTime', 'issued', 'occurrenceDateTime', 'authoredOn', 'date'):
        if resource.get(key):
            return _s(resource[key])
    if resource.get('resourceType') == 'Encounter':
        return _s(resource.get('period', {}).get('start'))
    if resource.get('resourceType') == 'Specimen':
        return _s(resource.get('collection', {}).get('collectedDateTime'))
    return ''


def _parse_date(value):
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace('Z', '+00:00')).date()
    except Exception:
        try:
            return datetime.strptime(str(value)[:10], '%Y-%m-%d').date()
        except Exception:
            return None


def structured_resource_sources(data):
    """Summarize only relevant structured FHIR resources; never send whole chart JSON."""
    out = []
    resources = data.get('resources', []) or []
    for r in resources:
        if not isinstance(r, dict):
            continue
        typ = r.get('resourceType', '')
        if typ not in ('Encounter', 'Observation', 'DiagnosticReport', 'Specimen', 'Device',
                       'DeviceUseStatement', 'Procedure', 'MedicationRequest', 'MedicationAdministration',
                       'Condition', 'ServiceRequest'):
            continue
        rid = f"{typ}/{r.get('id', '?')}"
        label = _concept(r)
        when = _stamp(r)
        text = ''
        category = 'fhir_' + typ.lower()
        if typ == 'Encounter':
            start = _s(r.get('period', {}).get('start'))
            end = _s(r.get('period', {}).get('end'))
            locs = [x.get('location', {}).get('display', '') for x in r.get('location', []) if isinstance(x, dict)]
            enc_class = r.get('class', {}) if isinstance(r.get('class'), dict) else {}
            text = f"Encounter start={start or 'not recorded'}; end={end or 'not recorded'}; status={r.get('status', 'unknown')}; class={enc_class.get('code', '')} {enc_class.get('display', '')}; location={'; '.join(x for x in locs if x) or 'not recorded'}"
        elif typ == 'Observation':
            value = r.get('valueString', '')
            if not value and isinstance(r.get('valueCodeableConcept'), dict):
                value = r['valueCodeableConcept'].get('text', '') or ', '.join(x.get('display', '') or x.get('code', '') for x in r['valueCodeableConcept'].get('coding', []))
            if not value and isinstance(r.get('valueQuantity'), dict):
                q = r['valueQuantity']; value = f"{q.get('value', '')} {q.get('unit', '')}".strip()
            interpretation = ' '.join(x.get('text', '') for x in r.get('interpretation', []) if isinstance(x, dict))
            specimen = r.get('specimen', {}).get('reference', '')
            text = f"{label}; value={value or 'not recorded'}; interpretation={interpretation or 'not recorded'}; specimen={specimen or 'not recorded'}; effective={when or 'not recorded'}"
            low = (label + ' ' + ' '.join(str(c.get('code', '')) for c in r.get('code', {}).get('coding', []) if isinstance(c, dict))).lower()
            if 'blood culture' in low or 'blood by culture' in low or '600-7' in low:
                category = 'structured_blood_culture'
            elif any(x in low for x in ('line-insert', 'line-access', 'line-remove', 'central venous line', 'central venous catheter')):
                category = 'structured_line_event'
            elif 'temperature' in low or '8310-5' in low:
                category = 'structured_temperature'
            elif 'urine culture' in low or 'wound culture' in low or 'respiratory culture' in low:
                category = 'structured_alternate_culture'
        elif typ == 'DiagnosticReport':
            conclusion = _s(r.get('conclusion'))
            result_refs = ', '.join(x.get('reference', '') for x in r.get('result', []) if isinstance(x, dict))
            text = f"{label}; conclusion={conclusion or 'not recorded'}; results={result_refs or 'not recorded'}; issued={when or 'not recorded'}"
        elif typ == 'Specimen':
            collection = r.get('collection', {}).get('collectedDateTime', '')
            text = f"Specimen type={label or 'not recorded'}; collected={collection or 'not recorded'}"
        elif typ == 'Device':
            text = f"Device type={label or 'not recorded'}; status={r.get('status', 'unknown')}; distinct device resource"
        elif typ == 'DeviceUseStatement':
            period = r.get('timingPeriod', {})
            text = f"Device use timing={period.get('start', '') or 'not recorded'} to {period.get('end', '') or 'not recorded'}; status={r.get('status', 'unknown')}"
        elif typ == 'Procedure':
            text = f"Procedure={label or 'not recorded'}; occurrence={when or 'not recorded'}; status={r.get('status', 'unknown')}"
        elif typ in ('MedicationRequest', 'MedicationAdministration'):
            med = r.get('medicationCodeableConcept', {}).get('text', '') if isinstance(r.get('medicationCodeableConcept'), dict) else ''
            if not med:
                med = r.get('medicationReference', {}).get('display', '')
            category = 'medication_order' if typ == 'MedicationRequest' else 'medication_administration'
            text = f"Medication={med or 'not recorded'}; status={r.get('status', 'unknown')}; time={when or 'not recorded'}"
        elif typ == 'Condition':
            text = f"Condition={label or 'not recorded'}; clinical_status={r.get('clinicalStatus', {}).get('text', 'not recorded')}"
        elif typ == 'ServiceRequest':
            text = f"Service request={label or 'not recorded'}; status={r.get('status', 'unknown')}"
        if text:
            out.append({'evidence_id': f'F{len(out)+1}', 'type': category, 'source': rid,
                        'date': when, 'claim': text[:650]})
    return out


def build_structured_context(data, structured_sources=None):
    """Expose dates/resource facts the prior prompt omitted (especially Encounter.start)."""
    sources = structured_sources if structured_sources is not None else structured_resource_sources(data)
    by_type = {}
    for x in sources:
        by_type.setdefault(x.get('type', ''), []).append(x)
    encounters = []
    for r in data.get('resources', []) or []:
        if isinstance(r, dict) and r.get('resourceType') == 'Encounter':
            start = _s(r.get('period', {}).get('start'))
            if start:
                encounters.append({'source': f"Encounter/{r.get('id', '?')}", 'start': start,
                                   'status': r.get('status', 'unknown'),
                                   'class_code': r.get('class', {}).get('code', '') if isinstance(r.get('class'), dict) else '',
                                   'class_display': r.get('class', {}).get('display', '') if isinstance(r.get('class'), dict) else '',
                                   'locations': [x.get('location', {}).get('display', '') for x in r.get('location', []) if isinstance(x, dict)]})
    cultures = []
    for c in data.get('cultures', []) or []:
        if isinstance(c, dict):
            cultures.append({'source': c.get('source', ''), 'organism': c.get('organism', ''),
                             'positive': c.get('positive'), 'collection_time': c.get('date', '')})
    # Include structured FHIR blood cultures if the summary list was not populated.
    if not cultures:
        for x in by_type.get('structured_blood_culture', []):
            cultures.append({'source': x.get('source'), 'claim': x.get('claim'), 'collection_time': x.get('date')})
    day_context = []
    for culture in cultures:
        specimen_day = _parse_date(culture.get('collection_time'))
        for enc in encounters:
            admit_day = _parse_date(enc.get('start'))
            if admit_day and specimen_day and specimen_day >= admit_day:
                day_context.append({'encounter': enc['source'], 'encounter_start': enc['start'],
                    'culture_source': culture.get('source', ''), 'culture_collection_time': culture.get('collection_time', ''),
                    'encounter_class_code': enc.get('class_code', ''), 'encounter_class_display': enc.get('class_display', ''),
                    'inpatient_class_verified': (enc.get('class_code') == 'IMP' or 'inpatient' in _s(enc.get('class_display')).lower()),
                    'inclusive_calendar_day_from_encounter_start': (specimen_day - admit_day).days + 1,
                    'caveat': 'Calendar-day arithmetic only; not an NHSN date-of-event or reportability determination.'})
    line_events = [x for x in sources if x.get('type') == 'structured_line_event']
    return {
        'encounters': encounters,
        'blood_cultures': cultures,
        'calendar_day_context': day_context,
        'line_events': line_events,
        'alternate_culture_sources': by_type.get('structured_alternate_culture', []),
        'medication_orders': by_type.get('medication_order', []),
        'medication_administrations': by_type.get('medication_administration', []),
        'device_resources': by_type.get('fhir_device', []) + by_type.get('fhir_deviceusestatement', []),
        'location_context': [x for x in encounters if x.get('locations')]
    }


def _event_blob(events):
    return [(_s(e.get('quote')) + ' ' + _s(e.get('claim'))).strip() for e in events if isinstance(e, dict)]


def _all_text(data, events, sources):
    chunks = _event_blob(events)
    for note in (data.get('notes', {}) or {}).values():
        if isinstance(note, dict): chunks.append(_s(note.get('text')))
    chunks.extend(_s(x.get('claim')) for x in sources)
    chunks.extend(_s(e.get('detail')) + ' ' + _s(e.get('label')) for e in (data.get('events', []) or []) if isinstance(e, dict))
    return '\n'.join(x for x in chunks if x)


def _ids(events, sources, predicate):
    found = []
    for e in events:
        if predicate(_s(e.get('type')), _s(e.get('quote')) + ' ' + _s(e.get('claim'))):
            if e.get('evidence_id'): found.append(e['evidence_id'])
    for s in sources:
        if predicate(_s(s.get('type')), _s(s.get('claim'))):
            if s.get('evidence_id'): found.append(s['evidence_id'])
    return list(dict.fromkeys(found))


def _state(pos, neg):
    if pos and neg: return 'conflicting'
    if pos: return 'supported'
    if neg: return 'negative'
    return 'unknown'


def build_evidence_ledger(data, events, structured_sources):
    """Create one canonical state map. Inference is intentionally conservative."""
    texts = _all_text(data, events, structured_sources)
    low = texts.lower()
    sources_by_type = {x.get('type'): x for x in structured_sources}
    culture_rows = data.get('cultures', []) or []
    pos_cultures = [c for c in culture_rows if isinstance(c, dict) and c.get('positive') is True]
    neg_cultures = [c for c in culture_rows if isinstance(c, dict) and c.get('positive') is False]
    if not culture_rows:
        for s in structured_sources:
            if s.get('type') == 'structured_blood_culture':
                claim = _s(s.get('claim')).lower()
                if re.search(r'positive=true|positive|grew|isolated', claim): pos_cultures.append(s)
                elif re.search(r'negative|no growth|positive=false', claim): neg_cultures.append(s)
    culture_note = any(e.get('type') == 'culture' or re.search(r'blood.?cultur|bacteremi', _s(e.get('quote')) + ' ' + _s(e.get('claim')), re.I) for e in events)
    culture_any = bool(pos_cultures or neg_cultures or culture_note)
    culture_pos = bool(pos_cultures or any(e.get('type') == 'culture' and e.get('certainty') in ('confirmed', 'reported') and not re.search(r'no growth|negative|not detected', _s(e.get('quote')) + ' ' + _s(e.get('claim')), re.I) for e in events))
    culture_neg = bool(neg_cultures or any(e.get('certainty') == 'negated' and re.search(r'blood.?cultur|no growth|negative culture', _s(e.get('quote')) + ' ' + _s(e.get('claim')), re.I) for e in events))
    fever_pos = any((e.get('type') == 'symptom' and e.get('certainty') in ('confirmed', 'reported')) or re.search(r'\bfever\b|\bfebrile\b|temperature\s+(?:of|to)\s+3[89]', _s(e.get('quote')) + ' ' + _s(e.get('claim')), re.I) for e in events if e.get('certainty') != 'negated')
    # Structured temperature observations count as objective symptom context; this is not an NHSN criterion by itself.
    for r in data.get('resources', []) or []:
        if not isinstance(r, dict) or r.get('resourceType') != 'Observation': continue
        label = _concept(r).lower(); q = r.get('valueQuantity', {}) or {}
        if ('temperature' in label or any(c.get('code') == '8310-5' for c in r.get('code', {}).get('coding', []) if isinstance(c, dict))) and isinstance(q.get('value'), (int, float)) and q.get('value') >= 38.0:
            fever_pos = True
    fever_neg = any(e.get('certainty') == 'negated' and re.search(r'\bfever\b|\bfebrile\b|afebrile', _s(e.get('quote')) + ' ' + _s(e.get('claim')), re.I) for e in events)
    line_insert = any(re.search(r'insert|placed|placement', _s(e.get('quote')) + ' ' + _s(e.get('claim')), re.I) for e in events if e.get('type') == 'line') or any(re.search(r'line|catheter', _s(s.get('claim')), re.I) and re.search(r'insert|placed', _s(s.get('claim')), re.I) for s in structured_sources if s.get('type') == 'structured_line_event')
    line_access = any(re.search(r'access|used|infusion|manipulat', _s(e.get('quote')) + ' ' + _s(e.get('claim')), re.I) for e in events if e.get('type') == 'line') or any(re.search(r'access', _s(s.get('claim')), re.I) for s in structured_sources if s.get('type') == 'structured_line_event')
    line_remove = any(re.search(r'remov|pulled|discontinu', _s(e.get('quote')) + ' ' + _s(e.get('claim')), re.I) for e in events if e.get('type') == 'line') or any(re.search(r'remov|pulled|discontinu', _s(s.get('claim')), re.I) for s in structured_sources if s.get('type') == 'structured_line_event')
    structured_context_pre = build_structured_context(data, structured_sources)
    encounters = structured_context_pre.get('encounters', [])
    inpatient_class_verified = any(x.get('class_code') == 'IMP' or 'inpatient' in _s(x.get('class_display')).lower() for x in encounters)
    explicit_noninpatient_class = any((x.get('class_code') or x.get('class_display')) and not (x.get('class_code') == 'IMP' or 'inpatient' in _s(x.get('class_display')).lower()) for x in encounters)
    culture_times = [c.get('date', '') for c in culture_rows if isinstance(c, dict) and c.get('date')]
    if not culture_times:
        culture_times = [s.get('date', '') for s in structured_sources if s.get('type') in ('structured_blood_culture','structured_culture') and s.get('date')]
    source_texts = _event_blob(events) + [_s(n.get('text')) for n in (data.get('notes', {}) or {}).values() if isinstance(n, dict)] + [_s(x.get('claim')) for x in structured_sources]
    positive_presence_re = re.compile(r'(?:central\s+)?(?:line|catheter|cvc|picc).{0,70}(?:still\s+)?(?:in place|present at|remains? in place|in situ|intact at)', re.I | re.S)
    negative_presence_re = re.compile(r'\b(?:no|without)\s+(?:central\s+)?(?:line|catheter|cvc|picc)\b.{0,70}(?:in place|present|in situ|at|during|when|before).{0,40}(?:culture|collection)?|\b(?:line|catheter|cvc|picc)\b.{0,50}(?:removed|discontinued).{0,50}before.{0,40}(?:culture|collection)', re.I | re.S)
    line_presence_positive = any(positive_presence_re.search(t) and not negative_presence_re.search(t) for t in source_texts)
    line_presence_negative = any(negative_presence_re.search(t) or re.search(r'no\s+(?:central\s+)?(?:line|catheter|cvc|picc).{0,40}before.{0,30}(?:blood\s+)?cultures?',t,re.I|re.S) for t in source_texts)
    # A bounded DeviceUseStatement period that spans a culture collection is stronger structured continuity evidence.
    device_use_spans_culture = False
    for r in data.get('resources', []) or []:
        if not isinstance(r, dict) or r.get('resourceType') != 'DeviceUseStatement': continue
        period = r.get('timingPeriod', {}) or {}
        start_d = _parse_date(period.get('start')); end_d = _parse_date(period.get('end'))
        if start_d and end_d and any((cd := _parse_date(ct)) and start_d <= cd <= end_d for ct in culture_times):
            device_use_spans_culture = True
    line_presence_positive = line_presence_positive or device_use_spans_culture
    bracketed = False
    for s in structured_sources:
        if s.get('type') != 'structured_line_event': continue
        claim = _s(s.get('claim')).lower(); dt = _parse_date(s.get('date'))
        for ct in culture_times:
            cd = _parse_date(ct)
            if dt and cd and ('insert' in claim or 'placed' in claim) and dt < cd: inserted_before = True
            else: inserted_before = False
            if dt and cd and ('remov' in claim or 'discontinu' in claim) and dt > cd: removed_after = True
            else: removed_after = False
            if inserted_before or removed_after: bracketed = True
    line_continuity_state = _state(line_presence_positive, line_presence_negative)
    if line_continuity_state == 'unknown' and bracketed:
        line_continuity_basis = 'Placement precedes and removal follows a culture in the retrieved chronology, but uninterrupted presence of the same line at collection is not directly documented.'
    elif line_continuity_state == 'unknown':
        line_continuity_basis = 'No direct documentation of the same eligible line being present at culture collection was found.'
    else:
        line_continuity_basis = 'Direct line-presence or line-absence language was identified; inspect its source and context.'
    alt_positive = bool(any(s.get('type') == 'structured_alternate_culture' for s in structured_sources) or any(e.get('type') == 'secondary_source' and e.get('certainty') in ('confirmed', 'reported') for e in events))
    alt_note = bool(re.search(r'possible secondary source|alternate source|other focus|urinary source|pyelonephritis|wound source|pneumonia|skin source', low, re.I))
    alt_pending = bool(re.search(r'remain under review|pending|requires? formal evaluation|evaluate skin|evaluate urine|other foci', low, re.I))
    explicit_no_alt = bool(re.search(r'no definite alternate source|no other focus identified|no alternate source identified', low, re.I))
    alt_complete_negative = explicit_no_alt and not alt_pending and bool(re.search(r'workup complete|evaluation completed|all cultures negative|comprehensive evaluation negative', low, re.I))
    line_type = bool(re.search(r'right internal jugular|left internal jugular|\bpicc\b|\btunneled\b|\bsubclavian\b|\bfemoral\b|central venous catheter', low, re.I))
    meds_order = any(s.get('type') == 'medication_order' for s in structured_sources)
    meds_admin = any(s.get('type') == 'medication_administration' for s in structured_sources) or any(e.get('type') == 'antibiotic' and e.get('certainty') in ('confirmed', 'reported') for e in events)
    location_known = any(x.get('locations') for x in encounters) or bool(re.search(r'\b(?:icu|micu|sicu|ccu|step[- ]down|medical floor|surgical floor)\b', low, re.I))

    ledger = [
      {'id':'blood_culture','label':'Blood-culture evidence','state':'supported' if culture_any else 'unknown',
       'evidence_ids':_ids(events, structured_sources, lambda t,x: t in ('culture','structured_blood_culture','structured_culture') or bool(re.search(r'blood.?cultur|bacteremi',x,re.I))),
       'basis':('Positive blood-culture evidence was retrieved.' if culture_pos else 'Negative blood-culture evidence was retrieved.' if culture_neg else 'No blood-culture result was established in retrieved material.')},
      {'id':'fever','label':'Fever / infection symptoms','state':_state(fever_pos, fever_neg),
       'evidence_ids':_ids(events, structured_sources, lambda t,x: t in ('symptom','structured_temperature') or bool(re.search(r'fever|febrile|temperature',x,re.I))),
       'basis':'Fever evidence was found.' if fever_pos else 'Explicit negative fever evidence was found.' if fever_neg else 'No qualifying symptom evidence was established.'},
      {'id':'line_insertion','label':'Line insertion / placement','state':'supported' if line_insert else 'unknown',
       'evidence_ids':_ids(events, structured_sources, lambda t,x: t == 'line' and bool(re.search(r'insert|placed|placement',x,re.I)) or t == 'structured_line_event' and bool(re.search(r'insert|placed',x,re.I))),
       'basis':'A line insertion/placement event was documented.' if line_insert else 'No line insertion date was established.'},
      {'id':'line_access','label':'Line first access / use','state':'supported' if line_access else 'unknown',
       'evidence_ids':_ids(events, structured_sources, lambda t,x: t == 'line' and bool(re.search(r'access|used|infusion',x,re.I)) or t == 'structured_line_event' and bool(re.search(r'access',x,re.I))),
       'basis':'Line access/use was documented.' if line_access else 'No first-access/use evidence was established.'},
      {'id':'line_removal','label':'Line removal','state':'supported' if line_remove else 'unknown',
       'evidence_ids':_ids(events, structured_sources, lambda t,x: t == 'line' and bool(re.search(r'remov|pulled|discontinu',x,re.I)) or t == 'structured_line_event' and bool(re.search(r'remov|pulled|discontinu',x,re.I))),
       'basis':'Line removal was documented.' if line_remove else 'No line-removal evidence was established.'},
      {'id':'line_continuity_at_culture','label':'Same eligible line continuously present at culture collection','state':line_continuity_state,
       'evidence_ids':_ids(events, structured_sources, lambda t,x: t in ('line','structured_line_event','fhir_device','fhir_deviceusestatement') or bool(re.search(r'line|catheter|cvc|picc',x,re.I))),
       'basis':line_continuity_basis},
      {'id':'encounter_start','label':'Encounter.period.start timestamp','state':'supported' if encounters else 'unknown',
       'evidence_ids':[x.get('evidence_id') for x in structured_sources if x.get('type') == 'fhir_encounter'],
       'basis':('Encounter.period.start retrieved: '+', '.join(x['start'] for x in encounters)) if encounters else 'No Encounter.period.start was retrieved; encounter-relative calendar-day arithmetic cannot be calculated.'},
      {'id':'inpatient_class','label':'Encounter explicitly identified as inpatient','state':'supported' if inpatient_class_verified else ('negative' if explicit_noninpatient_class else 'unknown'),
       'evidence_ids':[x.get('evidence_id') for x in structured_sources if x.get('type') == 'fhir_encounter'],
       'basis':'FHIR Encounter.class explicitly identifies inpatient care.' if inpatient_class_verified else 'FHIR Encounter.class explicitly identifies a non-inpatient encounter.' if explicit_noninpatient_class else 'Encounter.class is absent; do not label encounter-relative arithmetic as an inpatient day.'},
      {'id':'secondary_source','label':'Potential secondary source / attribution evidence','state':'supported' if alt_positive else ('negative' if alt_complete_negative else 'unknown'),
       'evidence_ids':_ids(events, structured_sources, lambda t,x: t in ('secondary_source','structured_alternate_culture') or bool(re.search(r'alternate source|secondary source|urine|wound|respiratory|pyelonephritis|other focus',x,re.I))),
       'basis':('A potential alternate-site culture or source was retrieved; formal attribution still requires site-specific criteria.' if alt_positive else 'An initial note says no definite alternate source, but evaluation is pending; this does not exclude secondary BSI.' if explicit_no_alt or alt_pending or alt_note else 'No sufficiently specific secondary-source assessment was retrieved.')},
      {'id':'medication_order','label':'Antimicrobial order','state':'supported' if meds_order else 'unknown',
       'evidence_ids':[x.get('evidence_id') for x in structured_sources if x.get('type') == 'medication_order'],
       'basis':'MedicationRequest evidence was retrieved; an order is not administration.' if meds_order else 'No medication order was established in retrieved records.'},
      {'id':'medication_administration','label':'Antimicrobial administration','state':'supported' if meds_admin else 'unknown',
       'evidence_ids':[x.get('evidence_id') for x in structured_sources if x.get('type') == 'medication_administration'],
       'basis':'Medication administration evidence was retrieved.' if meds_admin else 'No medication administration was established; this is contextual, not a stand-alone surveillance requirement.'},
      {'id':'location','label':'Unit / location at candidate event','state':'supported' if location_known else 'unknown',
       'evidence_ids':[x.get('evidence_id') for x in structured_sources if x.get('type') == 'fhir_encounter'],
       'basis':'Encounter location or unit information was retrieved.' if location_known else 'Patient location/unit at the candidate event was not established.'},
      {'id':'prior_bsi','label':'Prior BSI / repeat-event history','state':'unknown', 'evidence_ids':[],
       'basis':'The retrieved chart slice does not establish a complete prior-event history.'},
      {'id':'mbi_special','label':'MBI-LCBI / special exclusions','state':'unknown', 'evidence_ids':[],
       'basis':'Special criteria require separate review if clinically applicable; absence from this slice is not exclusion.'}
    ]
    context = structured_context_pre
    return {'version':'1.2','states':ledger,'structured_context':context,
            'facts':{'blood_culture':culture_any,'positive_blood_culture':culture_pos,'line_insertion':line_insert,
                     'line_access':line_access,'line_removal':line_remove,'fever':fever_pos,
                     'line_continuity':line_continuity_state,'encounter_start':bool(encounters),'inpatient_class_verified':inpatient_class_verified,'explicit_noninpatient_class':explicit_noninpatient_class,
                     'secondary_source_evaluation_pending':alt_pending,'potential_secondary_source':alt_positive,
                     'antibiotic_order':meds_order,'antibiotic_administration':meds_admin,
                     'location_known':location_known,'bracketed_line_chronology':bracketed}}


ABSENCE_PATTERNS = [
    ('blood_culture', re.compile(r'^\s*(?:no|none|not any)\s+(?:(?:documented|available|positive)\s+){0,3}(?:blood\s+cultur\w*(?:\s+results?)?|culture\s+results?)(?:\s+(?:identified|found|provided|present|available))?\s*\.?$', re.I)),
    ('line_removal', re.compile(r'^\s*(?:no|none|not any)\s+(?:documented\s+)?(?:line|central line|catheter|picc|cvc)\s+remov\w*(?:\s+documented)?\s*\.?$', re.I)),
    ('fever', re.compile(r'^\s*(?:no|none|not any)\s+(?:documented\s+)?(?:fever|signs? or symptoms? of infection|signs? (?:and|or) symptoms? of infection)(?:\s+documented)?\s*\.?$', re.I)),
    ('line_insertion', re.compile(r'^\s*(?:no|none|not any)\s+(?:documented\s+)?(?:central\s+line|line\s+placement|central\s+venous\s+catheter)(?:\s+(?:documented|recorded))?\s*\.?$', re.I)),
]


def _find_state(ledger, key):
    return next((x for x in ledger.get('states', []) if x['id'] == key), {'state':'unknown','evidence_ids':[],'basis':'Not assessed.'})


def _proposal_category(text):
    s = _s(text).lower()
    if s == 'culture' or re.search(r'blood.?cultur|culture result|culture not', s): return 'blood_culture'
    if re.search(r'fever|symptom|signs? of infection', s): return 'fever'
    if re.search(r'line insertion|insertion date|line placement', s): return 'line_insertion'
    if re.search(r'line removal|removal date|catheter removal', s): return 'line_removal'
    if re.search(r'line type|catheter type|device type', s): return 'line_type'
    if re.search(r'secondary source|alternate source|other source', s): return 'secondary_source'
    if re.search(r'culture sites|urine|wound|respiratory culture|other sites', s): return 'alternate_cultures'
    if re.search(r'admission|inpatient day|hospital day', s): return 'encounter_start'
    if re.search(r'antibiotic|antimicrobial', s): return 'medication_administration'
    if re.search(r'line continuity|continuously|line still in place', s): return 'line_continuity_at_culture'
    if re.search(r'repeat|prior bsi|previous bloodstream', s): return 'prior_bsi'
    if re.search(r'mbi|special exclusion', s): return 'mbi_special'
    if re.search(r'unit|location|icu|ward', s): return 'location'
    return 'other'


def reconcile_missing_proposals(proposals, ledger):
    out=[]
    for original in list(dict.fromkeys(_s(x) for x in (proposals or []) if _s(x)))[:60]:
        category = _proposal_category(original)
        state = _find_state(ledger, category)['state']
        if category == 'blood_culture' and state in ('supported','negative','conflicting'):
            disposition='removed_as_already_documented'; reason='The canonical evidence ledger already contains blood-culture evidence.'; replacement=''
        elif category == 'fever' and state in ('supported','negative','conflicting'):
            disposition='removed_as_already_documented'; reason='The canonical evidence ledger already contains symptom/temperature evidence.'; replacement=''
        elif category == 'line_insertion' and state == 'supported':
            disposition='removed_as_already_documented'; reason='A line insertion/placement event and date are already documented.'; replacement=''
        elif category == 'line_removal' and state == 'supported':
            disposition='removed_as_already_documented'; reason='A line removal event is already documented.'; replacement=''
        elif category == 'encounter_start' and state == 'supported':
            disposition='removed_as_already_documented'; reason='Encounter.period.start is available; encounter-relative calendar-day arithmetic is supplied separately.'; replacement=''
        elif category == 'secondary_source' and ledger['facts'].get('secondary_source_evaluation_pending'):
            disposition='rewritten_as_partial'; reason='A possible source is mentioned, but the evaluation is not complete.'; replacement='Secondary-source evaluation is mentioned but remains incomplete; retrieve site-specific cultures and supporting criteria.'
        elif category == 'line_continuity_at_culture' and state == 'unknown':
            disposition='retained_as_unknown'; reason='Placement/removal chronology does not prove uninterrupted line presence.'; replacement='Continuous presence of the same eligible line at culture collection is not explicitly documented.'
        elif category == 'medication_administration':
            disposition='retained_as_context_only'; reason='Medication details may inform clinical context but are not a stand-alone CLABSI surveillance requirement.'; replacement='Medication administration was not established in retrieved records; this is contextual, not a stand-alone CLABSI criterion.'
        elif category == 'line_type' and ledger['facts'].get('line_insertion'):
            disposition='retained_as_detail_gap'; reason='A central line is documented, but a precise device subtype may remain unclear.'; replacement='Confirm the exact central-line device subtype and whether it meets the applicable surveillance definition.'
        elif category == 'alternate_cultures' and ledger['facts'].get('potential_secondary_source'):
            disposition='retained_for_attribution'; reason='An alternate-site culture/source is present; formal attribution still needs review.'; replacement='Review alternate-site culture results and site-specific attribution criteria.'
        else:
            disposition='retained_as_unresolved'; reason='No adequate evidence in the ledger resolves this proposal.'; replacement='Not established in the retrieved records: ' + original.rstrip('.') + '.'
        out.append({'original':original,'category':category,'disposition':disposition,'reason':reason,'replacement':replacement})
    return out


def _clean_model_items(items, ledger, audit, section):
    kept=[]
    for raw in items if isinstance(items, list) else []:
        text=_s(raw)
        if not text: continue
        absence_category=next((k for k,pat in ABSENCE_PATTERNS if pat.match(text)),None)
        category=absence_category or _proposal_category(text)
        if absence_category and _find_state(ledger, category)['state'] in ('supported','negative','conflicting'):
            audit['removed_contradictions'].append({'section':section,'removed_statement':text,'conflicts_with':category,
                'action':'Removed global absence statement because the evidence ledger already contains a finding.'})
            continue
        if category == 'encounter_start' and ledger['facts'].get('encounter_start') and re.search(r'(?:admission|inpatient day|hospital day).{0,80}(?:missing|unknown|not provided|not retrieved|what is|confirm)', text, re.I):
            audit['removed_contradictions'].append({'section':section,'removed_statement':text,'conflicts_with':'encounter_start',
                'action':'Removed stale admission-date query; Encounter.period.start is present in structured FHIR data.'})
            continue
        if category == 'line_insertion' and _find_state(ledger, 'line_insertion')['state'] == 'supported' and re.search(r'(?:missing|unknown|not provided|not retrieved)', text, re.I):
            audit['removed_contradictions'].append({'section':section,'removed_statement':text,'conflicts_with':'line_insertion',
                'action':'Removed stale line-insertion query; a dated insertion event is already present.'})
            continue
        if category == 'line_removal' and _find_state(ledger, 'line_removal')['state'] == 'supported' and re.search(r'(?:missing|unknown|not provided|not retrieved)', text, re.I):
            audit['removed_contradictions'].append({'section':section,'removed_statement':text,'conflicts_with':'line_removal',
                'action':'Removed stale line-removal query; a dated removal event is already present.'})
            continue
        if category == 'medication_administration' and section in ('unresolved','followup_queries') and re.search(r'\b(?:antibiotic|antimicrobial)\b', text, re.I):
            audit['rewritten_absences'].append({'section':section,'original':text,
                'replacement':'Medication administration is optional clinical context here, not a stand-alone CLABSI surveillance requirement.',
                'reason':'Do not elevate medication details into a required surveillance criterion.'})
            continue
        # A missing Encounter timestamp means no inpatient-day assertion can be made.
        if re.search(r'\b(?:inpatient|hospital)\s+(?:calendar\s+)?day\s+\d+\b', text, re.I) and not ledger['facts'].get('encounter_start'):
            replacement='Inpatient day cannot be calculated because Encounter.period.start was not retrieved.'
            audit['unsupported_inferences'].append({'section':section,'original':text,'replacement':replacement,'reason':'No encounter admission/start timestamp in structured FHIR data.'})
            kept.append(replacement); continue
        # If a day is stated, compare it to a reproducible encounter/culture date calculation.
        day_match=re.search(r'\b(?:inpatient|hospital)\s+(?:calendar\s+)?day\s+(\d+)\b', text, re.I)
        day_context=ledger['structured_context'].get('calendar_day_context', [])
        if day_match and day_context and not ledger['facts'].get('inpatient_class_verified'):
            actual=day_context[0]['inclusive_calendar_day_from_encounter_start']
            replacement=(f'The specimen falls on inclusive calendar day {actual} from Encounter.period.start; Encounter.class identifies a non-inpatient encounter. This is not an NHSN date-of-event determination.' if ledger['facts'].get('explicit_noninpatient_class') else f'The specimen falls on inclusive calendar day {actual} from Encounter.period.start; Encounter.class does not explicitly identify inpatient status. This is not an NHSN date-of-event determination.')
            audit['unsupported_inferences'].append({'section':section,'original':text,'replacement':replacement,'reason':'Encounter-relative day arithmetic is available, but the FHIR Encounter class does not establish inpatient status.'})
            kept.append(replacement); continue
        if day_match and day_context:
            stated=int(day_match.group(1)); actual=day_context[0]['inclusive_calendar_day_from_encounter_start']
            if stated != actual:
                replacement=f"The specimen falls on calendar day {actual} from the retrieved Encounter.period.start; this arithmetic is not an NHSN date-of-event determination."
                audit['unsupported_inferences'].append({'section':section,'original':text,'replacement':replacement,'reason':f'Stated day {stated} disagrees with structured calendar-day arithmetic ({actual}).'})
                kept.append(replacement); continue
        # Placement before + removal after does not establish uninterrupted presence.
        if not ledger['facts'].get('line_continuity') in ('supported','negative','conflicting') and re.search(r'(?:line|catheter|cvc|picc).{0,100}(?:present at|in place at|remained? in place|continuous(?:ly)? present|line presence on the culture|establish(?:es|ing)? line presence)', text, re.I):
            replacement='Line placement/removal dates bracket the culture, but continuous presence of the same eligible line at collection is not explicitly documented.'
            audit['unsupported_inferences'].append({'section':section,'original':text,'replacement':replacement,'reason':'No direct continuity evidence; chronology alone is insufficient.'})
            kept.append(replacement); continue
        kept.append(text)
    return list(dict.fromkeys(kept))


def build_unresolved(ledger):
    unresolved=[]; queries=[]
    state={x['id']:x for x in ledger['states']}
    if state['encounter_start']['state']=='unknown':
        unresolved.append('Encounter.period.start was not retrieved; encounter-relative calendar-day arithmetic cannot be calculated. Inpatient onset remains undetermined.')
        queries.append('What is the Encounter.period.start timestamp, and does this Encounter represent the inpatient admission?')
    elif state['inpatient_class']['state']=='unknown':
        unresolved.append('FHIR Encounter.class does not explicitly identify inpatient status; do not label the encounter-relative calendar day as an inpatient day.')
        queries.append('Does this FHIR Encounter represent the inpatient admission (for example, Encounter.class = IMP)?')
    elif state['inpatient_class']['state']=='negative':
        unresolved.append('FHIR Encounter.class identifies a non-inpatient encounter; confirm whether a separate inpatient admission encounter governs surveillance timing.')
        queries.append('Is there a separate inpatient Encounter for this patient and episode?')
    if state['line_continuity_at_culture']['state']=='unknown':
        unresolved.append('Continuous presence of the same eligible central line at the blood-culture collection time is not explicitly documented; insertion/removal dates alone do not establish continuity.')
        queries.append('Was the same eligible central line continuously present at the exact blood-culture collection time, with no removal or replacement in between?')
    if state['secondary_source']['state'] in ('unknown','conflicting'):
        unresolved.append('Secondary-source exclusion remains unresolved; an initial statement of no definite alternate source does not substitute for completed site-specific evaluation.')
        queries.append('Were urine, wound, respiratory, skin, or other source studies performed in the relevant window, and what were their results and attribution evidence?')
    if state['location']['state']=='unknown':
        unresolved.append('Patient location/unit at the candidate event was not established in the retrieved encounter data.')
        queries.append('Which unit/location was the patient assigned to at the candidate event time?')
    if state['prior_bsi']['state']=='unknown':
        unresolved.append('Prior bloodstream infection history and the applicable repeat-infection timeframe were not established by this chart slice.')
        queries.append('Were there prior bloodstream infection events or positive blood cultures in the relevant repeat-infection timeframe?')
    if state['mbi_special']['state']=='unknown':
        unresolved.append('MBI-LCBI and other special-case criteria have not been assessed; determine applicability from the full chart and current protocol.')
        queries.append('Is there a relevant MBI-LCBI risk/organism context or another special exclusion requiring review?')
    return unresolved, queries


def _domain_status(domain_id, ledger, audit):
    s={x['id']:x['state'] for x in ledger['states']}
    ids={x['id']:x['evidence_ids'] for x in ledger['states']}
    if domain_id=='microbiology':
        return ('supported' if s['blood_culture'] in ('supported','negative') and ids['blood_culture'] else 'unknown',
                'Blood-culture result(s) and specimen timing are present in the evidence ledger.' if s['blood_culture'] in ('supported','negative') else 'No blood-culture result was established.',
                ids['blood_culture'])
    if domain_id=='line':
        refs=list(dict.fromkeys(ids['line_insertion']+ids['line_access']+ids['line_removal']+ids['line_continuity_at_culture']))
        if s['line_continuity_at_culture']=='conflicting': status='contradicted'
        elif s['line_continuity_at_culture'] in ('supported','negative'): status='supported'
        elif s['line_insertion']=='supported' or s['line_removal']=='supported': status='partial'
        else: status='unknown'
        rationale='Line events are documented, but placement/removal bracketing does not prove continuous presence at collection.' if status=='partial' else 'Direct line-presence/absence evidence is available.' if status=='supported' else 'Conflicting continuity evidence requires review.' if status=='contradicted' else 'Line chronology is not established.'
        return status,rationale,refs
    if domain_id=='timing':
        refs=list(dict.fromkeys(ids['encounter_start']+ids['blood_culture']))
        if s['encounter_start']=='supported' and ledger['structured_context'].get('calendar_day_context'):
            day=ledger['structured_context']['calendar_day_context'][0]['inclusive_calendar_day_from_encounter_start']
            return 'partial',f'Encounter start and culture collection allow inclusive calendar-day arithmetic (day {day}); inpatient status is {'not established' if not ledger['facts'].get('explicit_noninpatient_class') else 'not supported by the retrieved Encounter.class'}, and this is not the NHSN date of event.',refs
        if s['blood_culture']!='unknown': return 'partial','Culture timing is known, but Encounter.period.start is missing; inpatient day cannot be calculated.',refs
        return 'unknown','Neither a reliable candidate culture timestamp nor encounter start is established.',refs
    if domain_id=='secondary':
        refs=ids['secondary_source']
        if s['secondary_source']=='conflicting': return 'contradicted','Alternate-source statements conflict and need adjudication.',refs
        if s['secondary_source']=='supported': return 'partial','A potential secondary source is documented; formal site-specific attribution still needs evaluation.',refs
        if refs: return 'partial','The chart mentions no definite source initially, but source evaluation is incomplete.',refs
        return 'unknown','No adequate alternate-source assessment was retrieved.',refs
    if domain_id=='special':
        refs=ids['prior_bsi']+ids['mbi_special']
        return 'unknown','Prior BSI, repeat timeframe, MBI-LCBI and special exclusions are not established by this chart slice.',refs
    if domain_id=='clinical_context':
        refs=list(dict.fromkeys(ids['fever']+ids['line_removal']+ids['medication_order']+ids['medication_administration']))
        if refs: return 'partial','Symptoms and/or interventions are documented, but orders and administrations are distinct and clinical context is not a surveillance criterion by itself.',refs
        return 'unknown','Limited clinical-context evidence was retrieved.',refs
    if domain_id=='provenance':
        verified=[e.get('evidence_id') for e in audit.get('verified_events', []) if e.get('evidence_id')]
        if verified: return 'supported','Material narrative events are anchored to exact, source-verified quotations or structured FHIR resource references.',verified
        return 'unknown','No verified source anchors were established.',[]
    if domain_id=='consistency':
        refs=list(dict.fromkeys(x for row in ledger['states'] for x in row.get('evidence_ids', [])))
        if audit.get('removed_contradictions') or audit.get('unsupported_inferences') or any(x.get('disposition') in ('removed_as_already_documented','rewritten_as_partial') for x in audit.get('reconciled_missing_proposals', [])):
            return 'partial','The integrity layer found or reconciled unsupported/duplicate model statements; inspect the audit trail.',refs
        return 'supported','No targeted contradiction or unsupported-inference rule fired; this limited audit is not proof of full logical consistency.',refs
    return 'unknown','No evaluator implemented for this domain.',[]


def score_rubric(model_assessment, events, ledger=None, audit=None):
    """Deterministic evidence coverage. Model's self-awarded statuses are ignored."""
    rubric=load_rubric(); audit=audit or {}
    if ledger is None:
        ledger={'states':[],'structured_context':{'calendar_day_context':[]},'facts':{}}
    audit={**audit,'verified_events':events}
    domain_results=[]; denom=0; numer=0
    for domain in rubric['domains']:
        status,rationale,refs=_domain_status(domain['id'],ledger,audit)
        weight=domain['weight']; earned=None
        if status!='not_applicable':
            denom+=weight; earned=round(weight*SCORE.get(status,0.0),1); numer+=earned
        domain_results.append({'domain_id':domain['id'],'name':domain['name'],'weight':weight,
            'status':status,'rationale':rationale,'evidence_ids':refs,'earned':earned})
    return {'rubric_id':rubric['id'],'domains':domain_results,
        'evidence_completeness_score':round(100*numer/denom,1) if denom else None,
        'score_possible':denom,'downgrades':[],
        'scoring_method':'Deterministic evidence-state rubric; the model does not grade itself.',
        'warning':rubric['warning']}


def consistency_audit(result, data, events, structured_sources=None, missing_proposals=None):
    structured_sources = structured_sources if structured_sources is not None else []
    ledger=build_evidence_ledger(data,events,structured_sources)
    audit={'known_evidence_categories':ledger['facts'],'evidence_states':ledger['states'],
           'removed_contradictions':[],'rewritten_absences':[],'unsupported_inferences':[],
           'reconciled_missing_proposals':[],
           'note':'Targeted deterministic audit. It catches known classes of contradictions and unsupported inferences; zero flags does not prove the narrative is consistent.'}
    for section in ('key_findings','unresolved','followup_queries'):
        original=result.get(section,[])
        result[section]=_clean_model_items(original,ledger,audit,section)
    if isinstance(result.get('summary'),str):
        sentences=re.split(r'(?<=[.!?])\s+',result['summary'].strip())
        cleaned=_clean_model_items(sentences,ledger,audit,'summary')
        result['summary']=' '.join(cleaned)
    # Reconcile Pass-2 suggestions against the same canonical evidence ledger.
    reconciled=reconcile_missing_proposals(missing_proposals or [],ledger)
    audit['reconciled_missing_proposals']=reconciled
    audit['removed_proposal_count']=sum(x['disposition']=='removed_as_already_documented' for x in reconciled)
    # Replace any stale model questions with a deterministic, nonredundant priority list.
    unresolved,queries=build_unresolved(ledger)
    result['unresolved']=list(dict.fromkeys(result.get('unresolved',[])+unresolved))[:18]
    result['followup_queries']=list(dict.fromkeys(result.get('followup_queries',[])+queries))[:12]
    # Preserve the model's original rubric language for inspection, but it cannot grade itself.
    model_rubric=result.pop('model_rubric_assessment', [])
    result['model_rubric_advisory']=model_rubric if isinstance(model_rubric,list) else []
    for row in model_rubric if isinstance(model_rubric,list) else []:
        rationale=_s(row.get('rationale')) if isinstance(row,dict) else ''
        if not rationale: continue
        if re.search(r'line (?:presence|was present|remained).{0,80}(?:culture|collection)|establish(?:es|ing)? line presence',rationale,re.I) and ledger['facts'].get('line_continuity')=='unknown':
            audit['unsupported_inferences'].append({'section':'model_rubric_assessment','original':rationale,
                'replacement':'Line insertion/removal chronology does not establish continuous presence of the same eligible line at collection.',
                'reason':'No direct continuity evidence was found.'})
        if re.search(r'\b(?:inpatient|hospital)\s+(?:calendar\s+)?day\s+\d+\b',rationale,re.I) and not ledger['facts'].get('inpatient_class_verified'):
            audit['unsupported_inferences'].append({'section':'model_rubric_assessment','original':rationale,
                'replacement':'Report inclusive calendar-day arithmetic from Encounter.period.start only; Encounter.class does not explicitly establish inpatient status.',
                'reason':'Encounter class is absent or not identified as inpatient.'})
        if re.search(r'admission date.{0,80}(?:missing|unknown|not retrieved)',rationale,re.I) and ledger['facts'].get('encounter_start'):
            audit['unsupported_inferences'].append({'section':'model_rubric_assessment','original':rationale,
                'replacement':'Encounter.period.start is present in the structured FHIR context.',
                'reason':'The previous synthesis prompt omitted a structured Encounter resource that is now passed into Pass 3.'})
    audit['evidence_ledger_version']=ledger['version']
    result['evidence_ledger']=ledger
    result['integrity_audit']=audit
    result['consistency_audit']=audit
    result['rubric']=score_rubric(model_rubric,events,ledger,audit)
    return audit
