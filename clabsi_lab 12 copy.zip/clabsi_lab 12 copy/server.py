#!/usr/bin/env python3
"""Loopback-only FHIR lab. Never use directly with PHI without approved controls."""
import base64
import json
import os
import re
import secrets
import hashlib
import sys
import shutil
import subprocess
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlencode, urlparse, urljoin, parse_qs, quote
from urllib.request import Request, build_opener, HTTPRedirectHandler, urlopen
from urllib.error import HTTPError, URLError
from clinical import classify, fixture, readable_note, ref_id, stamp, display
from synthetic import results as synthetic_results, SCENARIOS
import investigator
import rubric

HERE=Path(__file__).resolve().parent
HOST='127.0.0.1'
PORT=int(os.environ.get('PORT','8858'))
BASE=os.environ.get('FHIR_BASE_URL','').rstrip('/')
LOCAL_BASE='http://127.0.0.1:8890/fhir'  # Fixed loopback-only synthetic FHIR server
CLIENT_ID=os.environ.get('FHIR_CLIENT_ID','')
SCOPES=os.environ.get('FHIR_SCOPES','openid fhirUser launch/patient patient/Patient.read patient/Observation.read patient/DocumentReference.read patient/Binary.read patient/Encounter.read patient/DiagnosticReport.read patient/Condition.read')
REDIRECT_URI=os.environ.get('FHIR_REDIRECT_URI',f'http://{HOST}:{PORT}/oauth/callback')
AUTH={'access_token':os.environ.get('FHIR_ACCESS_TOKEN',''),'patient_id':os.environ.get('FHIR_PATIENT_ID',''),'expires':0}
PENDING={}
LOCK=threading.Lock()
MAX_BODY=24000
MAX_FETCH_BYTES=8_000_000
MAX_PAGES=40
MAX_RESOURCES=2000
MAX_NOTES=250
SESSION={"last_data":None,"source":None,"case_id":None}
LOCAL_BOOT_LOCK=threading.Lock()
LOCAL_BOOT_STATE={"status":"idle","stage":"Not started","progress":0,"message":"Local FHIR has not been started yet.","error":"","updated":time.time()}
LOCAL_BOOT_THREAD=None


def _local_boot_update(**fields):
    with LOCAL_BOOT_LOCK:
        LOCAL_BOOT_STATE.update(fields)
        LOCAL_BOOT_STATE['updated']=time.time()
        return dict(LOCAL_BOOT_STATE)


def local_boot_status():
    with LOCAL_BOOT_LOCK:
        return dict(LOCAL_BOOT_STATE)


def _find_docker_cli():
    configured=os.environ.get('CLABSI_DOCKER_BIN','').strip()
    candidates=[configured,shutil.which('docker'),'/opt/homebrew/bin/docker','/usr/local/bin/docker',
                '/Applications/Docker.app/Contents/Resources/bin/docker',
                str(Path.home()/'Applications/Docker.app/Contents/Resources/bin/docker')]
    for item in candidates:
        if item and Path(item).is_file() and os.access(item,os.X_OK): return item
    return None


def _local_command(args,timeout=180):
    result=subprocess.run(args,cwd=str(HERE),capture_output=True,text=True,timeout=timeout,
                          env={**os.environ,'PATH':os.environ.get('PATH','')+':/opt/homebrew/bin:/usr/local/bin:/Applications/Docker.app/Contents/Resources/bin'})
    if result.returncode:
        detail=((result.stderr or '')+'\n'+(result.stdout or '')).strip()[-1200:]
        raise RuntimeError(f"{Path(args[0]).name} exited {result.returncode}"+(f": {detail}" if detail else ''))
    return (result.stdout or '').strip()


def _local_fhir_metadata_ready():
    try:
        with urlopen(LOCAL_BASE+'/metadata',timeout=3) as response: meta=json.load(response)
        return meta.get('resourceType')=='CapabilityStatement' and str(meta.get('fhirVersion','')).startswith('4.0')
    except Exception: return False


def _local_boot_worker():
    """Start a lightweight, persistent synthetic-only FHIR R4 REST subset.

    No Docker dependency. An existing ready HAPI installation at the fixed
    loopback address may be reused; otherwise our native host starts on a
    free loopback port. Both paths are actual HTTP FHIR-resource round trips.
    """
    global LOCAL_BASE
    try:
        _local_boot_update(status='starting',stage='Prepare Local FHIR',progress=8,
                           message='Starting a local synthetic FHIR R4 REST service without Docker.',error='')
        from local_host import native_fhir
        # Always use our own in-process, synthetic-only FHIR listener rather
        # than accidentally inheriting an unhealthy or unrelated HAPI service.
        # If 8890 is already in use, move to the next safe loopback port.
        port=native_fhir.ensure_started()
        LOCAL_BASE=f'http://127.0.0.1:{port}/fhir'
        backend='Built-in FHIR R4 subset'
        os.environ['CLABSI_LOCAL_FHIR_BASE']=LOCAL_BASE
        _local_boot_update(stage='Verify FHIR R4 endpoint',progress=25,base=LOCAL_BASE,
                           backend=backend,message=f'{backend} is starting at {LOCAL_BASE}.')
        for check in range(20):
            if _local_fhir_metadata_ready():break
            time.sleep(0.25)
        else:raise RuntimeError('Local FHIR R4 endpoint failed its CapabilityStatement check.')

        _local_boot_update(stage='Import synthetic FHIR transaction Bundles',progress=38,
                           message='Loading seven fictional patient charts through FHIR transaction POSTs.')
        # Reuse the exact seed pipeline used for HAPI: POST Bundle(type=transaction),
        # followed by FHIR Patient reads and DocumentReference searches.
        from local_host import seed_local
        seed_local.FHIR=LOCAL_BASE
        for i,key in enumerate(seed_local.ORIGINS,1):
            bundle,pid=seed_local.convert_case(key,i)
            _,result=seed_local.req('POST',LOCAL_BASE,bundle)
            if result.get('resourceType')!='Bundle' or result.get('type')!='transaction-response':
                raise RuntimeError(f'{pid}: FHIR transaction-response missing')
            for entry in result.get('entry',[]):
                if not str(entry.get('response',{}).get('status','')).startswith(('200','201')):
                    raise RuntimeError(f'{pid}: FHIR transaction write failed')
            _,returned=seed_local.req('GET',LOCAL_BASE+'/Patient/'+pid)
            if returned.get('id')!=pid:raise RuntimeError(f'{pid}: Patient read-back did not match')
            _,docs=seed_local.req('GET',LOCAL_BASE+'/DocumentReference?patient='+pid+'&_count=50')
            if not docs.get('entry'):raise RuntimeError(f'{pid}: notes missing after FHIR import')
            _local_boot_update(stage='Import synthetic FHIR transaction Bundles',
                               progress=38+int(i/7*48),message=f'Imported and verified {i}/7 fictional FHIR patients.')

        _local_boot_update(stage='Verify FHIR Patient search',progress=92,
                           message='Checking that all seven patient IDs are searchable over FHIR REST.')
        bundle=fetch_json(trusted_url('Patient?_count=50',LOCAL_BASE))
        ids={entry.get('resource',{}).get('id') for entry in bundle.get('entry',[])
             if entry.get('resource',{}).get('resourceType')=='Patient'}
        expected={f'lab-p{i:03d}' for i in range(1,8)}
        missing=sorted(expected-ids)
        if missing:raise RuntimeError('Synthetic patient search incomplete: '+', '.join(missing))
        _local_boot_update(status='ready',stage='Local FHIR ready',progress=100,
                           base=LOCAL_BASE,backend=backend,
                           message=f'{backend} ready. Seven fictional patients verified. lab-p007 is the 27-note stress case.',error='')
    except Exception as exc:
        _local_boot_update(status='error',stage='Local FHIR startup failed',progress=0,
                           message='Local FHIR could not finish its synthetic-only startup.',error=str(exc)[:700])


def start_local_fhir():
    global LOCAL_BOOT_THREAD
    with LOCAL_BOOT_LOCK:
        state=dict(LOCAL_BOOT_STATE)
        if state.get('status')=='starting': return state
        if state.get('status')=='ready' and _local_fhir_metadata_ready():
            try:
                existing=fetch_json(trusted_url('Patient?_count=50',LOCAL_BASE))
                present={e.get('resource',{}).get('id') for e in existing.get('entry',[]) if e.get('resource',{}).get('resourceType')=='Patient'}
                if {f'lab-p{i:03d}' for i in range(1,8)}.issubset(present): return state
            except Exception: pass
        LOCAL_BOOT_STATE.update(status='starting',stage='Preparing local FHIR',progress=1,message='Preparing automatic local FHIR startup.',error='',updated=time.time())
        LOCAL_BOOT_THREAD=threading.Thread(target=_local_boot_worker,name='clabsi-local-fhir-startup',daemon=True)
        LOCAL_BOOT_THREAD.start()
        return dict(LOCAL_BOOT_STATE)

class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs): return None
OPENER=build_opener(NoRedirect)

def is_valid_base(base):
    p=urlparse(base)
    return p.scheme=='https' and bool(p.netloc) and not p.username and not p.password and not p.fragment and not p.query

def trusted_url(href,base=None):
    """Same-origin FHIR URLs only. Local HTTP allowed exclusively on the fixed loopback server."""
    if base is None: base=BASE
    local=(base==LOCAL_BASE)
    if not local and not is_valid_base(base): raise ValueError('Configure a valid HTTPS FHIR base URL')
    candidate=urljoin(base.rstrip('/')+'/',href)
    p=urlparse(candidate); b=urlparse(base)
    # The Docker server might return its internal port in a self link.
    # Rewrite only this known local Docker listener; never arbitrary hosts.
    if local and p.scheme=='http' and p.netloc in ('localhost:8080','127.0.0.1:8080','localhost:8890') and p.path.startswith('/fhir/'):
        candidate=LOCAL_BASE+p.path[len('/fhir'):]+(('?'+p.query) if p.query else '')
        p=urlparse(candidate)
    if (p.scheme!=b.scheme or p.netloc!=b.netloc or
        not (p.path==b.path or p.path.startswith(b.path.rstrip('/')+'/'))):
        raise ValueError('FHIR response points outside the configured FHIR base: blocked')
    if p.username or p.password or p.fragment: raise ValueError('Unsafe FHIR URL blocked')
    return candidate

def request_url(url,token=None,form=None,accept='application/fhir+json'):
    data=urlencode(form).encode('utf-8') if form is not None else None
    h={'Accept':accept,'User-Agent':'CLABSI-FHIR-Lab/0.1 (local pilot)'}
    if token: h['Authorization']='Bearer '+token
    if form is not None: h['Content-Type']='application/x-www-form-urlencoded'
    req=Request(url,data=data,headers=h,method='POST' if form is not None else 'GET')
    try:
        with OPENER.open(req,timeout=14) as response:
            chunk=response.read(MAX_FETCH_BYTES+1)
            if len(chunk)>MAX_FETCH_BYTES: raise ValueError('FHIR response exceeded limit')
            return response.status, dict(response.headers), chunk
    except HTTPError as e:
        # Never reflect response body or bearer token back to browser.
        raise RuntimeError('HTTP '+str(e.code)+' '+ ('authentication/permission problem' if e.code in (401,403) else 'FHIR endpoint rejected request')) from None
    except URLError as e:
        raise RuntimeError('Network/TLS error connecting to FHIR endpoint') from None

def fetch_json(url,token=None,form=None):
    code,headers,body=request_url(url,token,form)
    try: return json.loads(body)
    except json.JSONDecodeError: raise RuntimeError('Expected FHIR JSON, got non-JSON response') from None

def smart_configuration():
    if not is_valid_base(BASE): raise ValueError('Set FHIR_BASE_URL to the approved HTTPS FHIR endpoint')
    path=BASE+'/.well-known/smart-configuration'
    doc=fetch_json(path)
    for key in ('authorization_endpoint','token_endpoint'):
        target=doc.get(key,'')
        p=urlparse(target)
        if p.scheme!='https' or p.netloc!=urlparse(BASE).netloc:
            raise ValueError('SMART discovery returned untrusted '+key)
    return doc

def token():
    with LOCK:
        if AUTH['expires'] and time.time()>AUTH['expires']: return ''
        return AUTH.get('access_token','')

def search(client_resource,patient,params=None,base=None,bearer=None):
    if base is None: base=BASE
    if bearer is None and base!=LOCAL_BASE: bearer=token()
    qp={'patient':patient,'_count':'50'}
    if params: qp.update(params)
    path=client_resource+'?'+urlencode(qp)
    more=path; records=[]; pages=0
    while more and pages<MAX_PAGES and len(records)<MAX_RESOURCES:
        url=trusted_url(more,base)
        data=fetch_json(url,bearer); pages+=1
        if data.get('resourceType')=='OperationOutcome':
            raise RuntimeError('FHIR returned OperationOutcome instead of search results')
        if data.get('resourceType')!='Bundle': raise RuntimeError('Expected FHIR Bundle')
        for item in data.get('entry',[]):
            r=item.get('resource',{})
            if r.get('resourceType') not in ('OperationOutcome',None): records.append(r)
        more=next((x.get('url') for x in data.get('link',[]) if x.get('relation')=='next'),None)
    return records, pages, bool(more)

def get_note(ref,doc,base=None,bearer=None):
    if base is None: base=BASE
    if bearer is None and base!=LOCAL_BASE: bearer=token()
    """Resolve attached content, while refusing external URLs and oversized unknown media."""
    for item in doc.get('content',[]):
        att=item.get('attachment',{})
        mime=att.get('contentType','')
        if att.get('data'):
            raw=base64.b64decode(att['data'],validate=True)
            if len(raw)>600000: return {'error':'Note attachment too large'}
            if not ('text/' in mime or 'html' in mime): return {'error':'Unsupported note MIME: '+mime}
            return {'text':readable_note(raw.decode('utf-8',errors='replace'),mime),'binary':'inline'}
        url=att.get('url')
        if not url: continue
        try:
            remote=trusted_url(url,base)
            status,h,body=request_url(remote,bearer)
            if len(body)>600000: return {'error':'Note content too large'}
            try: r=json.loads(body)
            except Exception: r=None
            if isinstance(r,dict) and r.get('resourceType')=='Binary':
                mimetype=r.get('contentType',mime)
                if not ('text/' in mimetype or 'html' in mimetype): return {'error':'Unsupported MIME: '+mimetype}
                raw=base64.b64decode(r.get('data',''),validate=True)
                if len(raw)>600000: return {'error':'Note content too large'}
                return {'text':readable_note(raw.decode('utf-8',errors='replace'),mimetype),'binary':url}
            mimetype=h.get('Content-Type',mime)
            if not ('text/' in mimetype or 'html' in mimetype): return {'error':'Unsupported response MIME: '+mimetype}
            return {'text':readable_note(body.decode('utf-8',errors='replace'),mimetype),'binary':url}
        except Exception as ex:
            return {'error':str(ex)[:180]}
    return {'error':'DocumentReference has no accessible note attachment'}


def _patient_display_name(resource):
    if not isinstance(resource,dict): return 'Unknown patient'
    for item in resource.get('name',[]):
        if item.get('text'): return str(item['text'])[:180]
        parts=list(item.get('given',[]))+([item.get('family')] if item.get('family') else [])
        if parts: return ' '.join(str(x) for x in parts)[:180]
    return 'FHIR patient '+str(resource.get('id','unknown'))

def fetch_live(patient,local=False):
    base=LOCAL_BASE if local else BASE
    bearer=None if local else token()
    if not re.fullmatch(r'[A-Za-z0-9._-]{1,128}',patient): raise ValueError('Patient must be an exact FHIR ID, not an MRN or a name')
    if not local and not bearer: raise RuntimeError('No access token; connect SMART or configure a short-lived sandbox token')
    scoped=AUTH.get('patient_id','') if not local else ''
    if scoped and patient!=scoped: raise ValueError('Patient ID differs from authorized SMART patient context')
    specs=[('Encounter','Encounters',{}),('DocumentReference','Clinical notes',{}),
           ('Observation','Lab observations',{'category':'laboratory'}),
           ('Observation','Vital signs',{'category':'vital-signs'}),
           ('DiagnosticReport','Diagnostic reports',{}),('Condition','Diagnoses',{}),
           ('Device','Device / line candidates',{}),('DeviceUseStatement','Device-use candidates',{}),
           ('Procedure','Line or other procedures',{}),('Specimen','Specimen metadata',{}),('MedicationRequest','Medication orders',{})]
    all_records=[]; coverage=[]; notes={}; seen=set()
    # Direct Patient read supplies the patient name used in the downloadable report.
    try:
        patient_resource=fetch_json(trusted_url('Patient/'+patient,base),bearer)
        if patient_resource.get('resourceType')=='Patient' and patient_resource.get('id')==patient:
            all_records.append(patient_resource);seen.add(ref_id(patient_resource))
            coverage.append({'resource':'Patient','label':'Patient demographics','status':'ok','count':1,'pages':1,'query':'Patient/'+patient,'note':'Direct read of selected FHIR Patient resource'})
        else:
            coverage.append({'resource':'Patient','label':'Patient demographics','status':'error','count':0,'pages':1,'query':'Patient/'+patient,'note':'FHIR response did not match requested Patient ID'})
    except Exception as e:
        coverage.append({'resource':'Patient','label':'Patient demographics','status':'error','count':0,'pages':0,'query':'Patient/'+patient,'note':str(e)[:180]})
    for resource,label,filters in specs:
        try:
            result,pages,truncated=search(resource,patient,filters,base=base,bearer=bearer)
            for r in result:
                key=ref_id(r)
                if key not in seen: all_records.append(r); seen.add(key)
            coverage.append({'resource':resource,'label':label,'status':'incomplete' if truncated else ('ok' if result else 'empty'),
                             'count':len(result),'pages':pages,'query':resource+'?'+urlencode({'patient':patient,'_count':'50',**filters}),
                             'note':'Pagination ceiling reached' if truncated else ''})
        except Exception as e:
            coverage.append({'resource':resource,'label':label,'status':'error','count':0,'pages':0,'query':resource+'?'+urlencode({'patient':patient,'_count':'50',**filters}),'note':str(e)[:200]})
    # Some laboratory reports expose result Observation references that are absent
    # from a broad Observation search. Follow bounded, same-origin references.
    refs=[]
    for report in (r for r in all_records if r.get('resourceType')=='DiagnosticReport'):
        for link in report.get('result',[]):
            target=link.get('reference','')
            if re.fullmatch(r'Observation/[A-Za-z0-9._-]{1,128}',target) and target not in seen and target not in refs:
                refs.append(target)
    read_count=0; read_failed=0
    for target in refs[:30]:
        try:
            data=fetch_json(trusted_url(target,base),bearer)
            if data.get('resourceType')=='Observation' and data.get('subject',{}).get('reference','').split('/')[-1]==patient:
                all_records.append(data); seen.add(ref_id(data));read_count+=1
            else: read_failed+=1
        except Exception: read_failed+=1
    coverage.append({'resource':'Observation','label':'Referenced lab-result followups',
                     'status':'incomplete' if len(refs)>30 or read_failed else ('ok' if read_count else 'empty'),
                     'count':read_count,'pages':0,'note':f'{read_failed} referenced reads failed or mismatched; {max(0,len(refs)-30)} skipped by cap'})
    docs=[r for r in all_records if r.get('resourceType')=='DocumentReference']
    for doc in docs[:MAX_NOTES]:
        nid=ref_id(doc); result=get_note(nid,doc,base=base,bearer=bearer)
        notes[nid]={'title':display(doc.get('type',{})) or 'Clinical note','date':stamp(doc),
                    'text':result.get('text',''),'binary':result.get('binary',''), 'error':result.get('error','')}
    coverage.append({'resource':'Binary','label':'Readable note bodies','status':'incomplete' if len(docs)>MAX_NOTES else ('ok' if any(n.get('text') for n in notes.values()) else 'empty'),
                     'count':sum(bool(n.get('text')) for n in notes.values()), 'pages':0,
                     'note':str(len(docs)-MAX_NOTES)+' notes omitted by safety cap' if len(docs)>MAX_NOTES else 'Some notes may be unreadable or missing'})
    out=classify(all_records,notes,coverage,False)
    patient_resource=next((r for r in all_records if r.get('resourceType')=='Patient'),{})
    out['patient_id']=patient
    out['patient_name']=_patient_display_name(patient_resource)
    out['case_name']=out['patient_name']
    return out

def demo_result(key):
    data=fixture(key)
    records=[r for r in data['records'] if r.get('resourceType')!='Binary']
    coverage=[]
    for resource,label in [('Patient','Patient'),('Encounter','Encounters'),('DocumentReference','Clinical notes'),('Binary','Readable note bodies'),('Observation','Labs, vital signs & synthetic line events')]:
        coverage.append({'resource':resource,'label':label,'status':'ok','count':sum(r.get('resourceType')==resource for r in data['records']),'pages':1,'note':'Synthetic fixture'})
    if key=='missing': coverage.append({'resource':'Device','label':'Actual line device data','status':'empty','count':0,'pages':1,'note':'Intentionally missing in scenario'})
    else: coverage.append({'resource':'Device','label':'Actual line device data','status':'not-tested','count':0,'pages':0,'note':'Demo line observations are fictional custom codes, not a real device API'})
    out=classify(records,data['notes'],coverage,True)
    patient_resource=next((r for r in records if r.get('resourceType')=='Patient'),{})
    out['case_name']=data['name'];out['case_summary']=data['summary']
    out['patient_id']=patient_resource.get('id',data.get('patient_id',''))
    out['patient_name']=_patient_display_name(patient_resource)
    return out

class Handler(BaseHTTPRequestHandler):
    def log_message(self,fmt,*args):
        # No chart content, query strings, patient IDs, or access tokens in HTTP logs.
        if self.path.startswith('/api/') and 'analysis' in self.path: return
        sys.stdout.write('[local app] '+self.command+' '+self.path.split('?')[0]+' '+str(args[1] if len(args)>1 else '')+'\n')
    def reply(self,obj,status=200):
        payload=json.dumps(obj,ensure_ascii=False,default=str).encode('utf-8')
        self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Content-Length',str(len(payload)));self.end_headers();self.wfile.write(payload)
    def redirect(self,uri):
        self.send_response(302);self.send_header('Location',uri);self.send_header('Cache-Control','no-store');self.end_headers()
    def do_GET(self):
        if self.headers.get('Host','') not in (f'{HOST}:{PORT}', f'localhost:{PORT}'):
            self.reply({'error':'Unrecognized localhost Host header'},403);return
        p=urlparse(self.path);path=p.path
        if path=='/':
            payload=(HERE/'index.html').read_bytes();self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8')
            self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; base-uri 'none'; form-action 'self'")
            self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(payload);return
        if path=='/app.js':
            payload=(HERE/'app.js').read_bytes();self.send_response(200);self.send_header('Content-Type','text/javascript; charset=utf-8')
            self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(payload);return
        if path=='/api/ollama':
            self.reply(investigator.availability());return
        if path=='/api/rubric':
            self.reply(rubric.load_rubric());return
        if path=='/api/atlas':
            self.reply({'patients':[
              {'name':'Warren McGinnis','id':'e0w0LEDCYtfckT6N.CkJKCw3','resources':'Notes, labs, reports, procedures'},
              {'name':'Olivia Roberts','id':'eh2xYHuzl9nkSFVvV3osUHg3','resources':'Device records, notes'},
              {'name':'Elijah Davis','id':'egqBHVfQlt4Bw3XGXoxVxHg3','resources':'Notes, medications'},
              {'name':'Camila Lopez','id':'erXuFYUfucBZaryVksYEcMg3','resources':'Labs, reports, procedures'},
              {'name':'Linda Ross','id':'eIXesllypH3M9tAA5WdJftQ3','resources':'Diagnoses, meds, vital signs'},
            ],'note':'Official Epic sample list is not exhaustive; availability is governed by registered APIs.',
            'source':'https://fhir.epic.com/Documentation?docId=patientfacingfhirapps'});return
        if path=='/api/local/status':
            self.reply(local_boot_status());return
        if path=='/api/local_patients':
            try:
                bundle=fetch_json(trusted_url('Patient?_count=50',LOCAL_BASE))
                if bundle.get('resourceType')!='Bundle': raise ValueError('Not a FHIR search Bundle')
                people=[]
                for entry in bundle.get('entry',[]):
                    r=entry.get('resource',{})
                    if r.get('resourceType')=='Patient' and r.get('id','').startswith('lab-p'):
                        people.append({'id':r['id'],'name':'Synthetic patient '+r['id'].replace('lab-p',''),
                                       'resources':'FHIR R4 clinical chart'})
                expected={f'lab-p{i:03d}' for i in range(1,8)}
                present={person['id'] for person in people}
                missing=sorted(expected-present)
                if missing: raise RuntimeError('Synthetic FHIR seed is incomplete ('+str(len(present))+'/7 patients). Automatic startup will complete the import.')
                self.reply({'patients':sorted(people,key=lambda z:z['id']),'base':LOCAL_BASE});return
            except Exception as e:
                state=local_boot_status()
                if state.get('status')!='starting':
                    _local_boot_update(status='error',stage='Local FHIR unavailable',progress=0,
                                       message='Local FHIR is not responding. Try Start Local FHIR automatically.',
                                       error=str(e)[:300])
                self.reply({'error':'Local FHIR server unavailable: '+str(e)[:180]},503);return
        if path=='/api/job':
            jid=parse_qs(p.query).get('id',[''])[0]
            obj=investigator.get_job(jid)
            self.reply(obj if obj else {'error':'Unknown job'},200 if obj else 404);return
        if path=='/api/runs':
            self.reply({'runs':investigator.list_runs()});return
        if path=='/api/run':
            jid=parse_qs(p.query).get('id',[''])[0]
            obj=investigator.get_run(jid)
            self.reply(obj if obj else {'error':'Unknown persistent synthetic run'},200 if obj else 404);return
        if path=='/api/info':
            self.reply({'connected':bool(token()),'base':BASE if BASE else None,'local_base':LOCAL_BASE,'client_configured':bool(CLIENT_ID),
                        'smart_patient_id':AUTH.get('patient_id',''),
                         'sample_cases':[{'id':c,'name':fixture(c)['name'],'summary':fixture(c)['summary']} for c in ('possible','alternate','commensal','missing')]+
                        [{'id':'synth:'+key,'name':value[0],'summary':value[2]} for key,value in SCENARIOS.items()],
                        'note':'Synthetic demo. Live mode requires authorized access; no data is transmitted to an external AI.'});return
        if path=='/oauth/start':
            try:
                if not CLIENT_ID: raise ValueError('Set FHIR_CLIENT_ID in the startup environment')
                cfg=smart_configuration(); verifier=secrets.token_urlsafe(64); state=secrets.token_urlsafe(24)
                challenge=base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip('=')
                with LOCK:
                    PENDING.clear();PENDING[state]={'verifier':verifier,'created':time.time(),'token_endpoint':cfg['token_endpoint']}
                params={'response_type':'code','client_id':CLIENT_ID,'redirect_uri':REDIRECT_URI,'scope':SCOPES,
                        'state':state,'aud':BASE,'code_challenge':challenge,'code_challenge_method':'S256'}
                self.redirect(cfg['authorization_endpoint']+'?'+urlencode(params))
            except Exception as e: self.reply({'error':str(e)},400)
            return
        if path=='/oauth/callback':
            try:
                qp=parse_qs(p.query)
                if qp.get('error'): raise ValueError('SMART OAuth returned an error (see Epic authorization screen)')
                state=qp.get('state',[''])[0];code=qp.get('code',[''])[0]
                with LOCK: pending=PENDING.pop(state,None)
                if not pending or not code or time.time()-pending['created']>600: raise ValueError('Invalid or expired OAuth state/code')
                result=fetch_json(pending['token_endpoint'],form={'grant_type':'authorization_code','code':code,
                      'client_id':CLIENT_ID,'redirect_uri':REDIRECT_URI,'code_verifier':pending['verifier']})
                if not result.get('access_token'): raise ValueError('Token response does not contain access_token')
                with LOCK:
                    AUTH['access_token']=result['access_token'];AUTH['patient_id']=result.get('patient','');
                    AUTH['expires']=time.time()+max(0,int(result.get('expires_in',0))-30) if result.get('expires_in') else 0
                self.redirect('/?connected=1')
            except Exception as e: self.reply({'error':str(e)},400)
            return
        self.reply({'error':'Not found'},404)
    def do_POST(self):
        if self.headers.get('Host','') not in (f'{HOST}:{PORT}', f'localhost:{PORT}'):
            self.reply({'error':'Unrecognized localhost Host header'},403);return
        if urlparse(self.path).path not in ('/api/analyze','/api/investigate','/api/cancel','/api/local/start'): self.reply({'error':'Not found'},404);return
        # Same-origin localhost POST; browser does not receive or store OAuth tokens.
        if self.headers.get('Origin') not in (None,f'http://{HOST}:{PORT}'):
            self.reply({'error':'Cross-origin request rejected'},403);return
        try:
            length=int(self.headers.get('Content-Length','0'))
            if length>MAX_BODY: raise ValueError('Request too large')
            form=json.loads(self.rfile.read(length) or b'{}')
            route=urlparse(self.path).path
            if route=='/api/local/start':
                self.reply(start_local_fhir(),202);return
            if route=='/api/cancel':
                ok=investigator.cancel(str(form.get('id','')))
                self.reply({'cancel_requested':ok});return
            if route=='/api/investigate':
                if not SESSION['last_data']: raise ValueError('First retrieve a patient or choose a synthetic case')
                if SESSION['source']=='epic-sandbox' and not BASE.startswith('https://fhir.epic.com/interconnect-fhir-oauth/api/FHIR/R4'):
                    raise ValueError('Experimental Ollama mode only permits Epic developer sandbox, not institution patient data')
                jobid=investigator.start_analysis(SESSION['last_data'],SESSION['source'],SESSION['case_id'])
                self.reply({'job_id':jobid});return
            mode=form.get('mode','demo')
            if mode=='demo':
                case=form.get('case','possible')
                if str(case).startswith('synth:'):
                    result=synthetic_results(str(case).split(':',1)[1])
                else: result=demo_result(case)
                SESSION.update(last_data=result,source='synthetic',case_id=case)
            elif mode=='local':
                pid=form.get('patient_id','')
                if not str(pid).startswith('lab-p'): raise ValueError('Choose a generated synthetic patient from the local FHIR server')
                result=fetch_live(pid,local=True)
                SESSION.update(last_data=result,source='local-fhir',case_id=pid)
            elif mode=='live':
                # Developer sandbox only. No production patient retrieval in this experimental AI version.
                if not BASE.startswith('https://fhir.epic.com/interconnect-fhir-oauth/api/FHIR/R4'):
                    raise ValueError('v2 requires Epic developer sandbox; institutional live data are not supported')
                pid=form.get('patient_id') or AUTH.get('patient_id','')
                result=fetch_live(pid)
                SESSION.update(last_data=result,source='epic-sandbox',case_id=pid)
            else: raise ValueError('Invalid mode')
            self.reply(result)
        except Exception as e: self.reply({'error':str(e)[:300]},400)

if __name__=='__main__':
    if BASE and not is_valid_base(BASE): sys.exit('FHIR_BASE_URL must be an HTTPS URL with no query or fragment')
    print(f'CLABSI FHIR Lab: http://{HOST}:{PORT} — synthetic demonstration is available immediately')
    print('Starting built-in synthetic FHIR R4 subset on loopback (Docker is not required).')
    start_local_fhir()
    if BASE: print('FHIR endpoint configured; live operation requires local institutional authorization.')
    else: print('Live mode disabled until FHIR_BASE_URL is configured.')
    ThreadingHTTPServer((HOST,PORT),Handler).serve_forever()
