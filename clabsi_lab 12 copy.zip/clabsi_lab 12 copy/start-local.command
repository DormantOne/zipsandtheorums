#!/bin/bash
# Compatibility alias: start the complete turnkey CLABSI + Local FHIR stack.
cd "$(dirname "$0")" || exit 1
exec bash ./START-CLABSI.command "$@"
