#!/bin/bash
# All launchers now use the same turnkey startup.
cd "$(dirname "$0")" || exit 1
exec bash ./START-CLABSI.command "$@"
