#!/bin/sh
cd "$(dirname "$0")" || exit 1
python3 server.py &
pid=$!
trap 'kill "$pid" 2>/dev/null || true' EXIT
sleep 1
(command -v xdg-open >/dev/null && xdg-open "http://127.0.0.1:${PORT:-8858}" >/dev/null 2>&1) || true
wait "$pid"
