#!/bin/bash
# Stop the one-process built-in FHIR + CLABSI Lab runtime.
set -u
cd "$(dirname "$0")" || exit 1
bash ./stop.command
printf '\nStopped CLABSI Lab and its built-in synthetic FHIR listener.\n'
printf 'Seven fictional patient charts remain stored in local_host/synthetic_fhir.sqlite3.\n'
printf 'Docker and any separately running HAPI containers are left unchanged.\n'
