#!/bin/bash
# Stops only CLABSI Lab instances verified by working directory and command.
set -u
cd "$(dirname "$0")" || exit 1
if ! command -v lsof >/dev/null 2>&1; then
  printf 'This Mac does not have lsof; close the Terminal that launched CLABSI Lab.\n'
  read -r unused || true; exit 1
fi
stopped=0
for pid in $(lsof -nP -tiTCP:8858 -sTCP:LISTEN 2>/dev/null | sort -u); do
  cmd="$(ps -p "$pid" -o command= 2>/dev/null || true)"
  cwd="$(lsof -nP -a -p "$pid" -d cwd -Fn 2>/dev/null | sed -n 's/^n//p' | head -n 1)"
  if [[ "$cmd" == *server.py* && "$(basename "$cwd" 2>/dev/null || true)" == clabsi_lab ]]; then
    kill -TERM "$pid" 2>/dev/null || true
    stopped=1
  fi
done
if [ "$stopped" -eq 1 ]; then
  echo 'CLABSI Lab stopped.'
else
  echo 'No verified CLABSI Lab process is running on port 8858. No other processes were changed.'
fi
sleep 1
