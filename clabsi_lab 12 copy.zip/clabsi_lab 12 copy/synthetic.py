"""Fictional reproducible CLABSI test patients, using valid-ish FHIR R4 source records.
These cases are for investigative retrieval benchmarking, not validated NHSN truth labels.
"""
import base64
import hashlib
import html
from clinical import classify, obs, demo_note, ref_id

SCENARIOS = {
 'line_candidate': ('Line candidate — S. aureus', 'clinical_candidate', 'S. aureus bacteremia after central-line access; no known secondary source in chart.'),
 'urinary_source': ('Alternate-source trap — E. coli', 'competing_source', 'E. coli in blood and urine with a documented pyelonephritis workup.'),
 'single_commensal': ('Commensal trap — single culture', 'inadequate_lcbi', 'One S. epidermidis specimen; repeat is negative.'),
 'early_line': ('Timing trap — line placed late', 'line_ineligible', 'Positive blood culture before central-line placement.'),
 'missing_dates': ('Missing-date trap — PICC mention', 'unknown', 'Positive blood culture with a vague historical PICC mention.'),
 'buried_negation': ('Long-note trap — relevant text buried', 'competing_source', 'A long note says no line prior to fever; later line insertion may mislead an isolated chunk.'),
 'long_chart': ('Long chart — 31-chunk guided stress test', 'candidate_with_conflict_review', 'A 27-note fictional inpatient chart with long notes, routine noise, a buried line-care event, a copied-forward error and a later correction. Designed to exercise multi-batch retrieval; not an NHSN gold standard.'),
}

DAYS={'admit':'2026-10-01T08:30:00-04:00','placed':'2026-10-02T14:20:00-04:00','access':'2026-10-02T15:00:00-04:00',
      'culture':'2026-10-06T07:30:00-04:00','culture2':'2026-10-06T11:00:00-04:00','removed':'2026-10-07T09:10:00-04:00'}

NOISE=[
('2026-10-01T09:40:00-04:00','Admission H&P','Admitted with poor oral intake and fatigue. Full ROS reviewed. No prior antimicrobial exposure reported. Physical exam unremarkable.'),
('2026-10-02T06:20:00-04:00','Nursing progress note','Rested overnight. Appetite reduced. Ambulated with assistance. Skin intact, no new rash.'),
('2026-10-03T10:20:00-04:00','Pharmacy review','Discussed dosing schedules and medication reconciliation. Long-term medications unchanged.'),
('2026-10-04T11:10:00-04:00','Progress note','Electrolytes monitored, physical therapy consulted, treatment goals reviewed with team.'),
('2026-10-05T14:10:00-04:00','Nutrition consult','Dietary intake estimated at 60 percent. Nutrition recommendations reviewed.'),
('2026-10-06T04:10:00-04:00','Night shift','Awake periodically. Repositioned twice. Repeat morning labs planned.'),
('2026-10-07T15:00:00-04:00','Physical therapy','Patient participated in transfer training; fatigue limited session.'),
]

def make_scenario(sid):
    if sid not in SCENARIOS: raise ValueError('Unknown synthetic case')
    title,gold,summary=SCENARIOS[sid]
    pid='synth-'+sid
    records=[{'resourceType':'Patient','id':pid,'name':[{'family':'Synthetic','given':[sid.title()]}]},
             {'resourceType':'Encounter','id':'adm-'+sid,'status':'in-progress','subject':{'reference':'Patient/'+pid},'class':{'code':'IMP'},'period':{'start':DAYS['admit']}}]
    notes=list(NOISE)
    if sid=='line_candidate':
        notes += [('2026-10-02T15:03:00-04:00','Line placement note','Right IJ triple lumen CVC placed with sterile precautions; first accessed at 15:00.'),
                  ('2026-10-06T16:25:00-04:00','Infectious Diseases consult','Febrile with S. aureus in blood culture. Concern for central-line-associated infection. No other focus identified in this evaluation. Other sources remain under review.'),
                  ('2026-10-07T09:22:00-04:00','Procedure note','Right IJ central line removed on 10/07 for possible line source; tip not cultured.')]
        org='Staphylococcus aureus'
    elif sid=='urinary_source':
        notes += [('2026-10-02T15:03:00-04:00','Procedure note','Right IJ CVC inserted and accessed 10/02.'),
                  ('2026-10-06T12:10:00-04:00','Urology consult','Obstructing ureteral stone, urinary sepsis, flank tenderness. E. coli cultured from blood and urine. NHSN secondary BSI attribution requires independent UTI criteria verification.'),
                  ('2026-10-07T08:35:00-04:00','Infectious Diseases progress','Urinary infection favored. There is a central line, but a line source is not demonstrated.')]
        org='Escherichia coli'; records.append(obs('urine-culture',DAYS['culture'],'Urine culture','Escherichia coli','urine-culture'))
    elif sid=='single_commensal':
        notes += [('2026-10-02T15:03:00-04:00','Procedure note','Internal jugular CVC inserted on 10/02 and first accessed at 15:00.'),
                  ('2026-10-06T14:10:00-04:00','Progress note','One specimen with S. epidermidis. No second matching positive culture. Repeat collection shows no growth so far; assess contamination.')]
        org='Staphylococcus epidermidis'
        records.append(obs('blood-repeat',DAYS['culture2'],'Blood culture','No growth','blood-culture',False))
    elif sid=='early_line':
        notes += [('2026-10-02T09:00:00-04:00','Microbiology follow-up','Blood culture S. aureus reported after collection on 10/01 before any central catheter. Suspected community-acquired BSI.'),
                  ('2026-10-04T14:20:00-04:00','Procedure note','Central venous catheter inserted today for IV antibiotics; first accessed same afternoon.')]
        org='Staphylococcus aureus'
    elif sid=='missing_dates':
        notes += [('2026-10-06T14:30:00-04:00','Infectious Disease consult','Bacteremia with S. aureus. A prior PICC is mentioned in transfer paperwork, but insertion and removal timing unknown. Unclear whether it was accessed this admission.')]
        org='Staphylococcus aureus'
    elif sid=='long_chart':
        # 13 ordinary progress/therapy notes provide realistic irrelevant chart noise.
        routine = [
          ('2026-10-01T14:20:00-04:00','Physical Therapy evaluation','Initial mobility assessment completed. Patient transfers with one-person assistance. No acute cardiopulmonary symptoms during therapy. Home equipment needs reviewed.'),
          ('2026-10-02T08:05:00-04:00','Nursing shift assessment','Patient resting comfortably. Peripheral IV site clean and dry. Intake and output recorded. No new complaints during morning assessment.'),
          ('2026-10-03T08:40:00-04:00','Hospitalist progress note','Abdominal discomfort improved. Continue serial examinations and advance diet as tolerated. Electrolytes reviewed; repeat metabolic panel ordered.'),
          ('2026-10-03T18:10:00-04:00','Evening nursing note','Patient ambulated in hallway with assistance. Fall precautions maintained. Call bell within reach. No change in baseline mentation.'),
          ('2026-10-04T09:15:00-04:00','Pharmacy medication review','Medication reconciliation reviewed with the patient. Renal dosing and current medication list checked. No medication-related issue requiring immediate intervention.'),
          ('2026-10-04T15:30:00-04:00','Nutrition follow-up','Oral intake remains below estimated needs. Nutrition supplement offered. Patient education completed and preferences documented.'),
          ('2026-10-05T08:25:00-04:00','Nursing shift assessment','Patient alert and oriented. Mobility and skin assessments completed. Routine care plan reviewed with the bedside team.'),
          ('2026-10-05T16:40:00-04:00','Case management note','Discharge planning remains dependent on clinical progress. Family contact information verified. No new equipment request at this time.'),
          ('2026-10-06T02:15:00-04:00','Overnight nursing note','Patient slept intermittently. Vital signs reviewed. Morning laboratory collection remains scheduled. No acute event reported overnight.'),
          ('2026-10-06T05:50:00-04:00','Laboratory collection note','Routine chemistry and hematology specimens collected and sent to the laboratory. Labels and patient identifiers verified at bedside.'),
          ('2026-10-06T22:10:00-04:00','Night nursing note','Patient resting after evening medications. Intake and output updated. Continue monitoring temperature and notify team for change in condition.'),
          ('2026-10-07T12:10:00-04:00','Case management follow-up','Discharge plan deferred pending infectious evaluation and treatment plan. Family updated that additional inpatient monitoring is anticipated.'),
          ('2026-10-08T09:05:00-04:00','Hospitalist progress note','Review of systems and physical examination updated. Continue current plan while final culture interpretation and disposition are reviewed.')]
        notes += routine
        filler = ('Routine inpatient review: medication list reconciled, mobility assessed, intake and output reviewed, skin assessment completed, care plan discussed with the bedside team. ' * 45)
        long_fever = (filler[:1950] + '\n\n' +
          'TIME-CRITICAL EVENT: At 09:35 on 2026-10-06 the right internal jugular triple-lumen central venous catheter was directly observed in situ, dressing intact, lumen flushed and available for infusion. A peripheral blood culture was collected at 09:40. Temperature was 39.1 C. The line had not been documented as removed or replaced before this collection.\n\n' +
          filler[1950:3900])
        long_id = (filler[:1900] + '\n\n' +
          'INFECTIOUS DISEASE ASSESSMENT 2026-10-06: Blood culture subsequently identified Staphylococcus aureus. A possible line-associated infection is considered. Urine culture shows no growth; skin and wound examinations do not identify a source. No definite alternate source is established in this assessment, but source attribution remains under review.\n' +
          filler[1900:3800] + '\n\n' +
          'DOCUMENTATION CORRECTION: A copied-forward sentence elsewhere in the chart says the central line was removed on 2026-10-05. That statement is incorrect. The same right IJ catheter remained present on 2026-10-06 and was removed on 2026-10-07 at 06:30. This addendum supersedes the copied-forward date.')
        notes += [
          ('2026-10-02T15:03:00-04:00','Central line procedure note','Right internal jugular triple-lumen central venous catheter inserted with sterile precautions. Tip position confirmed. No immediate complication.'),
          ('2026-10-02T15:20:00-04:00','Nursing line access note','Right IJ central venous catheter accessed for infusion. Dressing clean, dry and intact. All lumens patent.'),
          ('2026-10-06T09:50:00-04:00','Nursing fever and culture note',long_fever),
          ('2026-10-06T15:30:00-04:00','Infectious Diseases consultation',long_id),
          ('2026-10-06T20:15:00-04:00','Microbiology result update','Peripheral blood culture collected 2026-10-06 at 09:40 is positive for Staphylococcus aureus. Urine culture collected the same morning reports no growth. Organism identification is preliminary; final susceptibility report pending.'),
          ('2026-10-07T07:00:00-04:00','Central line removal note','Right internal jugular central venous catheter removed at 06:30 on 2026-10-07 for suspected source control. The catheter was present during the 2026-10-06 blood culture collection. Tip culture was not obtained.'),
          ('2026-10-07T08:10:00-04:00','Addendum correcting copied-forward line date','Correction to copied-forward note: the sentence stating central line removal on 2026-10-05 is erroneous. The right IJ catheter was present on 2026-10-06 and removed on 2026-10-07 at 06:30. Use this corrected chronology.')]
        org='Staphylococcus aureus'
        records.append(obs('urine-culture',DAYS['culture'],'Urine culture','No growth','urine-culture',False))
    else:
        padding=' '.join('Daily status: tolerating oral intake, clinically stable before the later reported event.' for _ in range(120))
        notes += [('2026-10-06T12:00:00-04:00','Extensive consultant note',padding+'\nIMPORTANT CHRONOLOGY: Blood culture positive for E. coli; urine culture also positive. There was NO CENTRAL LINE BEFORE BLOOD CULTURES were collected on October 6.\n'+padding+'\nCentral line placed October 7 after bacteremia. Do not infer CLABSI because the device appears in a later note.'),
                  ('2026-10-07T13:40:00-04:00','Line placement note','Central line placed after bloodstream infection began; new catheter inserted 10/07.')]
        org='Escherichia coli'; records.append(obs('urine-culture',DAYS['culture'],'Urine culture','Escherichia coli','urine-culture'))
    if sid in ('line_candidate','urinary_source','single_commensal','long_chart'):
        records.extend([obs('line-insert',DAYS['placed'],'Central venous line inserted','Right IJ','line-insert'),
                        obs('line-firstaccess',DAYS['access'],'Central venous line first accessed','Infusion','line-access')])
    if sid in ('line_candidate','long_chart'): records.append(obs('line-removed',DAYS['removed'],'Central venous line removed','CVC','line-remove'))
    if sid=='early_line': records.extend([obs('line-insert','2026-10-04T14:20:00-04:00','Central venous line inserted','Right IJ','line-insert'),
                                          obs('line-firstaccess','2026-10-04T14:35:00-04:00','Central venous line first accessed','Infusion','line-access')])
    if sid=='buried_negation': records.append(obs('line-insert','2026-10-07T13:30:00-04:00','Central venous line inserted','Right IJ','line-insert'))
    blood_when='2026-10-01T06:10:00-04:00' if sid=='early_line' else DAYS['culture']
    records.append(obs('blood-culture',blood_when,'Blood culture',org,'blood-culture',True))
    records.append(obs('temp','2026-10-06T06:50:00-04:00','Temperature',38.8,'temperature'))
    for rec in records:
        if rec.get('resourceType')=='Observation': rec['subject']={'reference':'Patient/'+pid}
    notes_out={}
    for i,(dt,ntype,text) in enumerate(sorted(notes,key=lambda x:x[0]),1):
        did=sid+'-note-'+str(i)
        doc,binary=demo_note(did,dt,ntype,text)
        doc['subject']={'reference':'Patient/'+pid}
        records.extend([doc,binary]); notes_out['DocumentReference/'+did]={'date':dt,'title':ntype,'text':text,'binary':'Binary/'+did}
    return {'id':sid,'name':title,'gold':gold,'summary':summary,'records':records,'notes':notes_out,'patient_id':pid}

def results(sid):
    p=make_scenario(sid)
    source=[r for r in p['records'] if r.get('resourceType')!='Binary']
    coverage=[{'resource':k,'label':k,'status':'ok' if any(r['resourceType']==k for r in source) else 'empty',
               'count':sum(r['resourceType']==k for r in source),'pages':1,'note':'Fully synthetic, local test patient'} for k in ('Patient','Encounter','DocumentReference','Observation','DiagnosticReport','Device')]
    coverage.append({'resource':'Binary','label':'Note bodies','status':'ok','count':len(p['notes']),'pages':0,'note':'Synthetic inline fixture'})
    ret=classify(source,p['notes'],coverage,True)
    ret.update({'case_name':p['name'],'case_summary':p['summary'],'gold_standard':{'category':p['gold'],'explanation':p['summary'], 'scope':'Synthetic investigative target, not independently NHSN-adjudicated'}, 'synthetic_id':sid})
    return ret


def fhir_bundle(sid):
    """Export a standard FHIR R4 Bundle/collection for future local-server testing.
    This does NOT create a patient in Epic; Bundle resources are fictional.
    """
    p=make_scenario(sid)
    return {'resourceType':'Bundle','type':'collection','id':'bundle-'+sid,
            'entry':[{'fullUrl':'http://example.invalid/local-fhir/R4/'+r['resourceType']+'/'+r['id'], 'resource':r} for r in p['records']]}
