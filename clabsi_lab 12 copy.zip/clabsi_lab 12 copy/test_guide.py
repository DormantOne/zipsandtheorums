import re
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parent

class GuidedTutorialTests(unittest.TestCase):
    def setUp(self):
        self.html=(ROOT/'index.html').read_text()
        self.js=(ROOT/'app.js').read_text()

    def test_tour_controls_and_dock_exist(self):
        for ident in ('startGuide','startLocalGuide','startFullGuide','guideDock','guideDragHandle','guideAutoPlace','guideNextPreview','guideNextTitle','guideNext','guideBack','guideSkip','guideSkipStep','guideClose','guideProgressBar','guideVoice','guideSpeak','guideStopVoice','processLog','progressTrack','errorLog','downloadReport','downloadProcessLog','downloadRubric','showAllLog','modelProfileText','startLocal'):
            self.assertIn(f'id="{ident}"',self.html)
            self.assertIn(f"$('#{ident}')",self.js)

    def test_every_highlight_target_exists_in_html(self):
        targets=re.findall(r"target:'([^']+)'",self.js)
        self.assertGreaterEqual(len(targets),15)
        for selector in targets:
            if selector.startswith('#'):
                self.assertIn(f'id="{selector[1:]}"',self.html,selector)
            elif selector.startswith('[data-tab='):
                value=re.search(r'data-tab=\\?"([^"]+)',selector).group(1)
                self.assertIn(f'data-tab="{value}"',self.html,selector)
            elif selector.startswith('[data-labtab='):
                value=re.search(r'data-labtab=\\?"([^"]+)',selector).group(1)
                self.assertIn(f'data-labtab="{value}"',self.html,selector)

    def test_guided_tour_waits_for_user_actions(self):
        self.assertIn("require:()=>!!DATA",self.js)
        self.assertIn("JOB_OUTPUT.status==='complete'",self.js)
        self.assertIn('speechSynthesis',self.js)
        self.assertIn('FULL_GUIDE',self.js)
        self.assertIn('guideNextTarget',self.js)
        self.assertIn('guideTarget',self.js)
        self.assertIn('pointerdown',self.js)
        self.assertIn('synth:long_chart',self.js)
        self.assertIn('chunk_count||0)>=20',self.js)
        self.assertIn('guideNextPreview',self.html)
        self.assertIn('guideNextTarget',self.js)
        self.assertIn('function initGuideDrag()',self.js)
        self.assertIn('Long chart — 31-chunk guided stress test',self.js)
        self.assertIn('ensureLocalFHIR',self.js)
        self.assertIn('Start Local FHIR automatically',self.js)
        self.assertIn('guideSkipStep',self.js)
        self.assertIn('function renderProcessPanel()',self.js)
        self.assertIn('function buildMarkdownReport()',self.js)
        core=self.js[self.js.index('const CORE_GUIDE='):self.js.index('const LOCAL_GUIDE=')]
        full=self.js[self.js.index('const FULL_GUIDE='):self.js.index('function closeGuide()')]
        self.assertGreaterEqual(len(re.findall(r'\{title:',core)),25)
        self.assertIn('...CORE_GUIDE.slice(0,-1)',full)
        self.assertGreaterEqual(len(re.findall(r'\{title:',full)),10)
        self.assertIn('function nextGuide()',self.js)
        self.assertIn('step.require&&!step.require()',self.js)

if __name__=='__main__': unittest.main(verbosity=2)
