import json
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest.mock import patch
import investigator
from synthetic import make_scenario, results, SCENARIOS

class InvestigatorTests(unittest.TestCase):
 def test_synthetic_cases_are_fhir_and_contain_known_targets(self):
  for sid, (name,gold,summary) in SCENARIOS.items():
   case=make_scenario(sid)
   self.assertGreaterEqual(len(case['notes']),8)
   self.assertEqual(case['gold'],gold)
   self.assertTrue(all(r.get('resourceType') for r in case['records']))
   self.assertEqual(results(sid)['gold_standard']['category'],gold)
 def test_long_chart_is_a_real_multi_chunk_stress_case(self):
  case=make_scenario('long_chart')
  chunks,overflow=investigator.chunk_notes(case['notes'])
  self.assertEqual(len(case['notes']),27)
  self.assertEqual(len(chunks),31)
  self.assertEqual(overflow,0)
  self.assertGreater(len(chunks),3)
  self.assertTrue(any(len(n['text'])>3800 for n in case['notes'].values()))
 def test_chunk_overlap_and_flank(self):
  note={'DocumentReference/a':{'text':'a'*4050,'title':'Long','date':'2026-01-01'}}
  chunks,overflow=investigator.chunk_notes(note)
  self.assertEqual(overflow,0)
  self.assertEqual(chunks[0]['end'],1900)
  self.assertEqual(chunks[1]['start'],1600)
  self.assertGreater(len(chunks),2)
 def test_model_calls_high_thinking(self):
  req=[]
  def fake(path,payload,timeout=0):
   req.append((path,payload))
   if path=='/api/show':
    return {'thinking':{'values':['low','medium','high'],'default':'medium'},'capabilities':['completion','thinking'],'model_info':{'gptoss.context_length':131072}}
   return {'message':{'content':json.dumps({'items':[]}), 'thinking':'verified thinking trace'},'done_reason':'stop'}
  with patch('investigator.ollama_json',side_effect=fake):
   r,meta=investigator.model_call('sys','user')
  self.assertEqual(req[-1][1]['think'],'high')
  self.assertEqual(req[-1][1]['model'],'gpt-oss:120b')
  self.assertEqual(req[-1][1]['stream'],False)
  self.assertEqual(req[-1][1]['options']['num_ctx'],131072)
  self.assertEqual(req[-1][1]['options']['num_predict'],32768)
  self.assertIn('items',r)
 def test_full_job_with_mock_local_model_persist_synthetic(self):
  with tempfile.TemporaryDirectory() as d:
   with patch.object(investigator,'DB',Path(d)/'test.sqlite3'), patch.object(investigator,'availability',return_value={'reachable':True,'installed':True}):
    def model(system,payload,limit=0):
     if 'triage system' in system:
      chunks=json.loads(payload)
      return {'items':[{'id':r['id'],'relevant':bool(investigator.CLUE_PATTERN.search(r['text'])),'reason':'synthetic mock','flags':['line'] if 'line' in r['text'].lower() else []} for r in chunks]},{}
     if 'extracting clinical evidence' in system:
      item=json.loads(payload);text=item['text'];line='central' if 'central' in text else 'blood'
      q='line' if 'line' in text else (text[:25] if text else '')
      return {'events':[{'date':item['date'],'type':'other','claim':'Test event','quote':q,'certainty':'reported'},
                        {'date':item['date'],'type':'other','claim':'Model fabrication','quote':'NEVER QUOTED BY SOURCE','certainty':'confirmed'}], 'missing':[]},{}
     return {'summary':'Research: needs validation.','suspicion':'uncertain','key_findings':['A source is present'], 'unresolved':['NHSN rules'], 'followup_queries':[]},{}
    with patch('investigator.ollama_json',return_value={'thinking':{'values':['low','medium','high']}}), patch('investigator.model_call',side_effect=model):
     job_id=investigator.start_analysis(results('line_candidate'),'synthetic','line_candidate')
     for i in range(120):
      job=investigator.get_job(job_id)
      if job['status'] not in ('queued','running'):break
      time.sleep(.03)
     self.assertEqual(job['status'],'complete',job['errors'])
     self.assertGreater(len(job['screening']),0)
     self.assertGreaterEqual(len(job['rejected_quotes']),1)
     self.assertGreaterEqual(len(job['events']),1)
     self.assertTrue(all(e['quote'] in results('line_candidate')['notes'][e['source']]['text'] for e in job['events']))
     self.assertEqual(len(investigator.list_runs()),1)
     self.assertEqual(investigator.get_run(job_id)['status'],'complete')
     self.assertEqual(job['progress_percent'],100)
     self.assertGreater(len(job['logs']),0)
     self.assertTrue(any(x['event']=='chunk_screened' for x in job['logs']))
     self.assertTrue(any(x['event']=='rubric_guided_synthesis_started' for x in job['logs']))
     self.assertTrue(any(x['event']=='report_assembled' for x in job['logs']))
     self.assertEqual([x['seq'] for x in job['logs']],sorted(x['seq'] for x in job['logs']))
if __name__=='__main__': unittest.main(verbosity=2)
