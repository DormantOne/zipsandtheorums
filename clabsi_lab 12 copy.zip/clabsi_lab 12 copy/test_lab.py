import base64
import unittest
from unittest.mock import patch
from clinical import fixture, readable_note
from server import demo_result, trusted_url, search, get_note

class TestCLABSILab(unittest.TestCase):
    def test_cases_have_distinct_interpretations(self):
        a=demo_result('possible'); b=demo_result('alternate'); c=demo_result('commensal'); d=demo_result('missing')
        self.assertIn('Possible CLABSI',a['title'])
        self.assertIn('Competing source',b['title'])
        self.assertIn('insufficient',c['title'])
        self.assertIn('line eligibility unknown',d['title'])
    def test_notes_are_decoded_not_just_metadata(self):
        a=demo_result('possible'); self.assertEqual(len(a['notes']),3)
        self.assertTrue(any('S. aureus' in n['text'] for n in a['notes'].values()))
        self.assertEqual(readable_note('<p>A</p><script>BAD</script><p>B</p>','text/html'),'A\n\nB')
    def test_fhir_urls_are_restricted(self):
        base='https://fhir.example.test/api/FHIR/R4'
        self.assertEqual(trusted_url('Binary/abc',base),'https://fhir.example.test/api/FHIR/R4/Binary/abc')
        for target in ('https://evil.test/api/FHIR/R4/Binary/x','https://fhir.example.test/api/FHIR/OTHER/Binary/x',
                       'http://fhir.example.test/api/FHIR/R4/Binary/x'):
            with self.assertRaises(ValueError): trusted_url(target,base)
    @patch('server.BASE','https://fhir.example.test/api/FHIR/R4')
    @patch('server.token',return_value='test-only')
    def test_paginated_bundle(self,_token):
        p1={'resourceType':'Bundle','entry':[{'resource':{'resourceType':'Observation','id':'a'}}],
            'link':[{'relation':'next','url':'https://fhir.example.test/api/FHIR/R4/Observation?page=2'}]}
        p2={'resourceType':'Bundle','entry':[{'resource':{'resourceType':'Observation','id':'b'}}]}
        with patch('server.fetch_json',side_effect=[p1,p2]):
            records,pages,truncated=search('Observation','demo')
        self.assertEqual(len(records),2);self.assertEqual(pages,2);self.assertFalse(truncated)
    @patch('server.BASE','https://fhir.example.test/api/FHIR/R4')
    @patch('server.token',return_value='test-only')
    def test_attachment_binary_is_decoded(self,_token):
        body={'resourceType':'Binary','contentType':'text/html','data':base64.b64encode(b'<p>Example note</p>').decode()}
        doc={'resourceType':'DocumentReference','content':[{'attachment':{'url':'Binary/n1','contentType':'text/html'}}]}
        import json
        with patch('server.request_url',return_value=(200,{'Content-Type':'application/fhir+json'},json.dumps(body).encode())):
            result=get_note('DocumentReference/n1',doc)
        self.assertEqual(result['text'],'Example note')

if __name__=='__main__': unittest.main(verbosity=2)
