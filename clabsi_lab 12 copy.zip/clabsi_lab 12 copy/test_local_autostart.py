"""Guarantee one-click local startup never requires Docker."""
import unittest
from pathlib import Path

class LocalAutoStartTests(unittest.TestCase):
    def test_one_click_launcher_has_no_docker_requirement(self):
        root=Path(__file__).resolve().parent
        script=(root/'START-CLABSI.command').read_text()
        self.assertIn('exec "$PYTHON" -u server.py',script)
        self.assertNotIn('docker compose',script)
        self.assertNotIn('docker_ready',script)
    def test_browser_and_api_include_auto_start(self):
        root=Path(__file__).resolve().parent
        html=(root/'index.html').read_text()
        js=(root/'app.js').read_text()
        py=(root/'server.py').read_text()
        self.assertIn('id="startLocal"',html)
        self.assertIn("postJSON('/api/local/start'",js)
        self.assertIn("path=='/api/local/status'",py)
        self.assertIn("route=='/api/local/start'",py)
        self.assertIn('start_local_fhir()\n',py)
    def test_seed_files_and_local_fhir_subset_present(self):
        root=Path(__file__).resolve().parent
        self.assertTrue((root/'local_host'/'native_fhir.py').exists())
        self.assertTrue((root/'synthetic_patients'/'long_chart.json').exists())

if __name__=='__main__':unittest.main()
