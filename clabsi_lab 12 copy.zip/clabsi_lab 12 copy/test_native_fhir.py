"""Real HTTP FHIR round-trip tests for the built-in synthetic-only R4 REST subset."""
import json
import tempfile
import threading
import unittest
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request,urlopen
from unittest.mock import patch
from local_host import native_fhir, seed_local
import server


class NativeFHIRRoundtripTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory(prefix='clabsi-fhir-test-')
        cls.http=native_fhir.LoopbackServer(('127.0.0.1',0),native_fhir.create_handler(Path(cls.tmp.name)/'fhir.sqlite3'))
        cls.thread=threading.Thread(target=cls.http.serve_forever,daemon=True)
        cls.thread.start()
        cls.base=f'http://127.0.0.1:{cls.http.server_port}/fhir'
    @classmethod
    def tearDownClass(cls):
        cls.http.shutdown();cls.http.server_close();cls.thread.join(timeout=2);cls.tmp.cleanup()

    def fetch(self,url,body=None):
        payload=json.dumps(body).encode() if body is not None else None
        req=Request(url,data=payload,method='POST' if payload else 'GET',headers={'Accept':'application/fhir+json','Content-Type':'application/fhir+json'})
        with urlopen(req,timeout=15) as response:return json.load(response)

    def test_capability_and_transaction_atomicity(self):
        cap=self.fetch(self.base+'/metadata')
        self.assertEqual(cap['fhirVersion'],'4.0.1')
        self.assertEqual(cap['resourceType'],'CapabilityStatement')
        transaction={'resourceType':'Bundle','type':'transaction','entry':[
            {'resource':{'resourceType':'Patient','id':'test-atomic'},'request':{'method':'PUT','url':'Patient/test-atomic'}},
            {'resource':{'resourceType':'Patient','id':'other'},'request':{'method':'DELETE','url':'Patient/other'}}]}
        with self.assertRaises(HTTPError) as cm:self.fetch(self.base,transaction)
        self.assertEqual(cm.exception.code,400)
        with self.assertRaises(HTTPError) as cm:self.fetch(self.base+'/Patient/test-atomic')
        self.assertEqual(cm.exception.code,404)

    def test_seven_real_fhir_imports_and_note_bodies(self):
        with patch('local_host.native_fhir.ensure_started',return_value=self.http.server_port), patch.object(seed_local,'FHIR',self.base),patch.object(server,'LOCAL_BASE',self.base):
            server._local_boot_worker()
            state=server.local_boot_status()
            self.assertEqual(state['status'],'ready',state)
            self.assertEqual(state['progress'],100)
            patients=self.fetch(self.base+'/Patient?_count=50')
            self.assertEqual(patients['total'],7)
            self.assertEqual(len(patients['entry']),7)
            notes=self.fetch(self.base+'/DocumentReference?patient=lab-p007&_count=50')
            self.assertEqual(notes['total'],27)
            got=server.fetch_live('lab-p007',local=True)
            self.assertEqual(len(got['notes']),27)
            self.assertTrue(all(n['text'] for n in got['notes'].values()))
            self.assertGreaterEqual(got['count'],30)
            from investigator import chunk_notes
            chunks,overflow=chunk_notes(got['notes'])
            self.assertEqual(len(chunks),31)
            self.assertEqual(overflow,0)
            # Even the last-page case must not leak into the wrong patient.
            a=self.fetch(self.base+'/DocumentReference?patient=lab-p001&_count=1')
            self.assertTrue(a['link'][-1]['relation']=='next')
            self.assertGreater(a['total'],1)
            a2=self.fetch(a['link'][-1]['url'])
            self.assertTrue(a2['entry'])

    def test_unlisted_patient_returns_empty_search(self):
        data=self.fetch(self.base+'/DocumentReference?patient=missing-synthetic&_count=50')
        self.assertEqual(data['total'],0)


if __name__=='__main__': unittest.main(verbosity=2)
