import json
import unittest
from pathlib import Path
import rubric
from clinical import fixture
from synthetic import results
from server import demo_result

class RubricTests(unittest.TestCase):
    def test_all_domains_weight_100(self):
        r=rubric.load_rubric()
        self.assertEqual(len(r['domains']),8)
        self.assertEqual(sum(d['weight'] for d in r['domains']),100)

    def test_structured_encounter_is_passed_to_evidence_context(self):
        data=demo_result('possible')
        sources=rubric.structured_resource_sources(data)
        context=rubric.build_structured_context(data,sources)
        self.assertEqual(context['encounters'][0]['start'],'2026-10-01T13:00:00-04:00')
        self.assertEqual(context['calendar_day_context'][0]['inclusive_calendar_day_from_encounter_start'],6)
        self.assertIn('not an NHSN',context['calendar_day_context'][0]['caveat'])

    def test_line_bracketing_does_not_prove_continuity(self):
        data=demo_result('possible')
        sources=rubric.structured_resource_sources(data)
        ledger=rubric.build_evidence_ledger(data,[],sources)
        states={x['id']:x['state'] for x in ledger['states']}
        self.assertTrue(ledger['facts']['bracketed_line_chronology'])
        self.assertEqual(states['line_insertion'],'supported')
        self.assertEqual(states['line_removal'],'supported')
        self.assertEqual(states['line_continuity_at_culture'],'unknown')

    def test_uploaded_run_failure_modes_are_reconciled(self):
        # Mirrors the user's uploaded gpt-oss:120b run against Case A.
        data=demo_result('possible')
        job_path=Path('/mnt/data/clabsi_investigator_0caf2d15e807.json')
        job=json.loads(job_path.read_text())
        events=job['events']
        structured=job['structured_sources']+rubric.structured_resource_sources(data)
        result=dict(job['result'])
        result['model_rubric_assessment']=job['result']['rubric']['domains']
        audit=rubric.consistency_audit(result,data,events,structured,job['unverified_missing_proposals'])
        states={x['id']:x['state'] for x in result['evidence_ledger']['states']}
        self.assertEqual(states['blood_culture'],'supported')
        self.assertEqual(states['fever'],'supported')
        self.assertEqual(states['line_removal'],'supported')
        self.assertEqual(states['encounter_start'],'supported')
        self.assertEqual(states['inpatient_class'],'unknown')
        self.assertEqual(states['line_continuity_at_culture'],'unknown')
        self.assertFalse(any('admission date' in x.lower() for x in result['unresolved']))
        self.assertFalse(any('antibiotic' in x.lower() for x in result['unresolved']))
        self.assertTrue(any('continuous presence' in x.lower() for x in result['unresolved']))
        self.assertTrue(audit['removed_proposal_count'] >= 4)
        self.assertTrue(any(x['section']=='model_rubric_assessment' for x in audit['unsupported_inferences']))
        self.assertTrue(any('encounter class' in x['reason'].lower() for x in audit['unsupported_inferences']))
        # Calendar day 6 is recoverable from the actual Encounter resource.
        self.assertIn('day 6', result['rubric']['domains'][2]['rationale'].lower())

    def test_rubric_is_deterministic_not_model_self_graded(self):
        data=demo_result('possible')
        sources=rubric.structured_resource_sources(data)
        ledger=rubric.build_evidence_ledger(data,[],sources)
        audit={'verified_events':[{'evidence_id':'E1'}], 'removed_contradictions':[], 'unsupported_inferences':[], 'reconciled_missing_proposals':[]}
        low=[{'domain_id':x['id'],'status':'unknown','rationale':'model says unknown','evidence_ids':[]} for x in rubric.load_rubric()['domains']]
        high=[{'domain_id':x['id'],'status':'supported','rationale':'model says supported','evidence_ids':['invented']} for x in rubric.load_rubric()['domains']]
        a=rubric.score_rubric(low,[],ledger,audit)
        b=rubric.score_rubric(high,[],ledger,audit)
        self.assertEqual(a,b)
        self.assertEqual(a['scoring_method'],'Deterministic evidence-state rubric; the model does not grade itself.')
        line=next(x for x in a['domains'] if x['domain_id']=='line')
        self.assertEqual(line['status'],'partial')

    def test_pass2_missing_proposals_reconciled_against_evidence(self):
        data=demo_result('possible'); sources=rubric.structured_resource_sources(data)
        ledger=rubric.build_evidence_ledger(data,[],sources)
        rows=rubric.reconcile_missing_proposals(['culture','symptom','line insertion date not provided','line removal date not provided','antibiotic therapy not mentioned','Secondary source evaluation'],ledger)
        by={x['original']:x['disposition'] for x in rows}
        self.assertEqual(by['culture'],'removed_as_already_documented')
        self.assertEqual(by['symptom'],'removed_as_already_documented')
        self.assertEqual(by['line insertion date not provided'],'removed_as_already_documented')
        self.assertEqual(by['line removal date not provided'],'removed_as_already_documented')
        self.assertEqual(by['antibiotic therapy not mentioned'],'retained_as_context_only')
        self.assertEqual(by['Secondary source evaluation'],'rewritten_as_partial')

    def test_negative_and_missing_are_distinct(self):
        data={'cultures':[],'resources':[],'notes':{}}
        ledger=rubric.build_evidence_ledger(data,[],[])
        states={x['id']:x['state'] for x in ledger['states']}
        self.assertEqual(states['blood_culture'],'unknown')
        self.assertEqual(states['line_continuity_at_culture'],'unknown')

if __name__=='__main__': unittest.main(verbosity=2)
