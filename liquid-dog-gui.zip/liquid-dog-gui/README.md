# Liquid dog

A liquid time-constant network learns to walk a two-legged planar dog. No
gradients, no gait template, about 126 genes. Three gates in a repeating
curriculum, a population that telescopes from wide to narrow, and three
champion pools that value being different as much as being good.

## One button

**Windows** — double-click `start.bat`, or type `start` in this folder.

**macOS / Linux** — `./start.sh`

First run builds a private `.venv` and installs numpy and flask, which takes a
minute. After that it goes straight up and opens your browser at
`http://127.0.0.1:5000/`. Leave the console window open while it trains; close
it to quit.

Press **Start training**. Everything fills in as it runs. Press **Copy report**
at any point and a full plain-text summary lands on your clipboard — settings,
progress, all three pools with every member and fossil, diversity numbers,
relaxation count, recent events. That is the thing to paste back to me.

No browser wanted? `python run.py --help`.

## What is actually in here

### The body

Two legs, one front and one rear. In the sagittal plane a real dog's left and
right limbs sit on top of each other, so merging each pair into a single limb
loses nothing you can see and makes the picture legible. A horizontal torso on
a fore leg and an aft leg is still statically stable.

Eight point masses, ~9 kg, and exactly one constraint type: the distance
constraint. Bones hold a fixed length; joints are distance constraints whose
rest length comes from a target angle by the law of cosines. Since a target
angle never reaches 0 or pi, a joint can never snap through straight or fully
folded, so the direction a knee bends is fixed by the starting pose forever.
One constraint gives actuation, joint limits and handedness together.

`quadruped` is still selectable in the settings panel. It is mechanically
easier and visually worse.

### The brain

Each neuron is a leaky ODE whose time constant is gated by its own input, so a
cell can be sluggish one moment and fast the next:

```
dx/dt = -x/tau + f(x, I) * (A - x)      f = sigmoid(W_rec x + W_in I + b)
```

12 sensors, 6 interneurons, 4 motor neurons, sparse fixed wiring, 126 genes.
Motor neuron state *is* the output; there is no readout layer. **There is no
clock input and no phase input** — if a rhythm appears, it came from the
network's own evolved time constants. That is the entire reason to use a
liquid net here instead of an MLP.

### The gates, and the cycle

| | stand | footfalls | distance |
|---|---|---|---|
| rewards | upright + liveliness − slamming | footfall quality | metres per second |
| constraints | — | upright and gentle | upright, gentle, *and* rhythmic |

Gates are cumulative: clearing one demotes it to a constraint rather than
retiring it, which is what stops the distance gate from rediscovering the
belly-flop. "Liveliness" is the anti-statue clause — without it, "don't hurt
yourself" is won perfectly by locking every joint, and that dog is a genetic
dead end.

The **order never changes**, because the gates are ordered by *learnability*
rather than importance: standing is learnable from a random controller,
footfalls once you can stand, distance only once you have footfalls. What
repeats is the whole cycle. A gate promotes the moment every survivor clears
it, so revisiting "stand" costs a generation or two, and it re-applies
upright-and-gentle as a hard gate instead of a soft constraint — pulling back
whatever reliability the distance gate quietly traded away.

### The champion pools

Three archives, with different characters rather than three copies:

- **fast** — ranks on the objective, diversity breaks ties
- **sturdy** — ranks on staying upright and landing gently
- **strange** — ranks on novelty first; the explorer's pool

Admission is a 50/50 blend of how good a dog is and how differently it moves
(25/75 in `strange`). Difference is measured in **behaviour space, not genome
space**: six numbers describing cadence, duty factor, alternation, ride
height, speed and gentleness. This matters — two genomes can differ in 200
genes and produce the same gait, and two near-identical genomes can produce a
walk and a hop.

**Fossils** are frozen at the end of each cycle and can never be evicted,
however thoroughly they are later beaten, because the thing that beat them may
turn out to be a dead end. A slice of every generation's children is bred from
the pools, so a collapsed population can be rescued by its own history.

**Collapse.** If a pool's internal diversity falls below target, two pools
chosen at random have their admission standard lowered a notch per generation
— repeatedly, as far as it takes — until something genuinely different gets
in. The bar snaps back the moment it does. Lowering two of three, at random,
means there is always one pool still holding the line on quality.

### The telescope

Wide while searching, narrow while refining. A wide base finds "stand and
step" very fast; the distance gate is *tuning* a limit cycle rather than
looking for one, and tuning wants generations instead of samples.

## Where this stands, honestly

The four-legged version of this project reached **0.84 m/s from 88% of
starting poses**. The two-legged version, on the defaults as first shipped,
reached **0.05 m/s** — it learned to stand, learned a footfall rhythm around
0.7, kept its pools diverse, and went nowhere.

Three things it is *not*. The effort penalty is not swamping the reward
(measured: penalty 0.0000 against reward 0.0039). Foot friction is not the
bottleneck either — a planted foot has only 0.029 m/s of tangential grip
because PBD friction scales with penetration, but adding a baseline contact
allowance made no difference to the speed distribution of a random population,
so the search has the same gradient available with or without it. The body is
capable: a hand-coded alternating gait travels 2.5 m in nine seconds.

What it looks like instead is **fragmentation**. The four-legged result came
from 320 *uninterrupted* generations on the distance gate. Cycling chops that
into 60-to-70-generation chunks, and each chunk resets the mutation size and
the stagnation tracker and spends its first stretch re-climbing ground it
already covered. Cycling buys reliability at the cost of the long, patient
refinement that distance needs — and on a morphology where distance is hard,
the cost wins.

So the defaults now give the distance gate a much longer run in each cycle
(100 generations in the first, 150 in later ones) and a smaller wide
population to pay for it. **That configuration has not been verified end to
end** — it is about a 25 minute run and I ran out of room to watch it finish.
If you want a dog you can watch walking today, switch the body to `quadruped`
in the settings panel; that path is tested. If you want the interesting
problem, leave it on `biped` and send me the report.

Two things I would try next, in order: fewer and longer cycles (2 cycles with
200 generations of distance each, rather than 3 with 150), and carrying the
mutation size and stagnation state *across* a gate revisit instead of
resetting them, so a revisit costs a detour rather than a restart.

## Layout

```
start.bat / start.sh     the one button
app.py                   Flask: background trainer thread, status polling
run.py                   headless trainer
templates/index.html     the page
static/app.css  app.js   styling and the live charts
dogwalker/body.py        morphology + position-based-dynamics solver
dogwalker/ltc.py         the liquid network and its genome
dogwalker/gym.py         the three gates - everything the dog is told
dogwalker/pools.py       three champion pools, fossils, collapse response
dogwalker/train.py       cycling curriculum on a telescoping population
runs/                    saved runs
```

## Limits worth keeping in mind

A planar dog is much easier than a three-dimensional one: no roll, no yaw, no
lateral balance. Position-based dynamics is stable and fast but not
torque-accurate, and the "muscles" are compliant distance constraints rather
than motors with real limits. Nothing here transfers to hardware. The ground
is flat and uniform; robustness is tested only against small variations in the
starting pose. And one run is one sample — promotion times vary a lot with the
seed.
