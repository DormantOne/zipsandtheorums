"""
Flask front end. One background thread runs the trainer; the page polls it.

Start it with `start.bat` (Windows) or `./start.sh`, which is the whole point:
one command, no arguments, browser opens by itself.
"""
from __future__ import annotations

import json
import threading
import time
import webbrowser
from dataclasses import asdict, fields
from pathlib import Path

import numpy as np
from flask import Flask, jsonify, render_template, request

from dogwalker import body as B
from dogwalker.gym import DESCRIPTOR_NAMES, OBJECTIVE, rollout
from dogwalker.ltc import build_wiring
from dogwalker.train import Settings, Trainer

ROOT = Path(__file__).resolve().parent
app = Flask(__name__)

# ── the one piece of shared state ───────────────────────────────────────────
class Session:
    def __init__(self) -> None:
        self.trainer: Trainer | None = None
        self.thread: threading.Thread | None = None
        self.stop_flag = False
        self.error: str | None = None
        self.lock = threading.Lock()

    def running(self) -> bool:
        return self.thread is not None and self.thread.is_alive()

    def start(self, settings: Settings) -> None:
        if self.running():
            return
        self.stop_flag = False
        self.error = None
        self.trainer = Trainer(settings)

        def loop() -> None:
            try:
                while not self.stop_flag and not self.trainer.done:
                    with self.lock:
                        self.trainer.step()
            except Exception as exc:                       # surface it in the UI
                self.error = f"{type(exc).__name__}: {exc}"

        self.thread = threading.Thread(target=loop, daemon=True)
        self.thread.start()

    def stop(self) -> None:
        self.stop_flag = True


S = Session()


def _defaults() -> dict:
    d = asdict(Settings())
    for k in ("first_cycle_gens", "later_cycle_gens"):
        d[k] = list(d[k])
    return d


@app.get("/")
def index():
    return render_template("index.html", defaults=_defaults(),
                           descriptor_names=list(DESCRIPTOR_NAMES),
                           morphologies=list(B.MORPHOLOGIES))


@app.post("/api/start")
def api_start():
    if S.running():
        return jsonify({"ok": False, "why": "already running"})
    body = request.get_json(silent=True) or {}
    known = {f.name: f for f in fields(Settings)}
    kwargs = {}
    for k, v in body.items():
        if k not in known:
            continue
        if k in ("first_cycle_gens", "later_cycle_gens"):
            kwargs[k] = tuple(int(x) for x in v)
        elif k == "morphology":
            kwargs[k] = v if v in B.MORPHOLOGIES else "biped"
        elif isinstance(known[k].default, bool):
            kwargs[k] = bool(v)
        elif isinstance(known[k].default, int):
            kwargs[k] = int(v)
        elif isinstance(known[k].default, float):
            kwargs[k] = float(v)
    S.start(Settings(**kwargs))
    return jsonify({"ok": True})


@app.post("/api/stop")
def api_stop():
    S.stop()
    return jsonify({"ok": True})


@app.get("/api/status")
def api_status():
    if S.trainer is None:
        return jsonify({"idle": True, "running": False, "error": S.error})
    with S.lock:
        st = S.trainer.status()
    st["idle"] = False
    st["running"] = S.running()
    st["error"] = S.error
    return jsonify(st)


@app.get("/api/replay")
def api_replay():
    """A recorded rollout of one champion, for the browser to animate."""
    if S.trainer is None:
        return jsonify({"ok": False, "why": "nothing trained yet"})
    rank = int(request.args.get("rank", 1)) - 1
    seed = int(request.args.get("seed", 4242))
    with S.lock:
        champs = S.trainer.pools.champions()
        morph = S.trainer.morph
        wiring = S.trainer.wiring
        genes = None if not champs else champs[min(rank, len(champs) - 1)].genes.copy()
        summary = None if not champs else champs[min(rank, len(champs) - 1)].summary()
    if genes is None:
        return jsonify({"ok": False, "why": "no champions yet"})

    r = rollout(wiring, genes[None], OBJECTIVE.seconds, seed=seed,
                morph=morph, record=True)
    skel = B.skeleton(morph)
    far = {morph.knee(k) for k in range(morph.n_legs) if k % 2 == 1} | \
          {morph.foot(k) for k in range(morph.n_legs) if k % 2 == 1}
    bones = []
    for c in range(skel.act_start):
        a, b = int(skel.ia[c]), int(skel.ib[c])
        near = morph.n_legs == 2 or (a not in far and b not in far)
        bones.append([a, b, near])
    return jsonify({
        "ok": True, "rank": rank + 1, "summary": summary,
        "frames": [np.round(f, 4).tolist() for f in r.frames],
        "contacts": r.contacts[:, :, 0].astype(int).tolist(),
        "dt": 1.0 / 50.0, "bones": bones, "feet": list(morph.feet),
        "leg_names": list(morph.leg_names),
        "metrics": {"speed": round(float(r.speed[0]), 3),
                    "distance": round(float(r.distance[0]), 2),
                    "footfall": round(float(r.footfall_score[0]), 3),
                    "step_rate": round(float(r.step_rate[0]), 2),
                    "impact": round(float(r.impact[0]), 2),
                    "upright": round(float(r.survive[0]) * 100)},
    })


@app.get("/api/audit")
def api_audit():
    """Every champion against a spread of fresh starting poses."""
    if S.trainer is None:
        return jsonify({"ok": False, "why": "nothing trained yet"})
    seeds = int(request.args.get("seeds", 12))
    bar = float(request.args.get("bar", 0.4))
    with S.lock:
        champs = S.trainer.pools.champions()[:8]
        morph, wiring = S.trainer.morph, S.trainer.wiring
    if not champs:
        return jsonify({"ok": False, "why": "no champions yet"})
    genes = np.array([c.genes for c in champs])
    spd = np.zeros((len(champs), seeds))
    up = np.zeros_like(spd)
    for j in range(seeds):
        r = rollout(wiring, genes, OBJECTIVE.seconds, seed=1000 + 137 * j, morph=morph)
        spd[:, j], up[:, j] = r.speed, r.survive
    rows = []
    for i, c in enumerate(champs):
        rows.append({**c.summary(), "works": round(float((spd[i] > bar).mean()), 3),
                     "median": round(float(np.median(spd[i])), 3),
                     "worst": round(float(spd[i].min()), 3),
                     "best": round(float(spd[i].max()), 3),
                     "upright": round(float(up[i].mean()) * 100),
                     "per_seed": [round(float(v), 3) for v in spd[i]]})
    return jsonify({"ok": True, "bar": bar, "seeds": seeds, "rows": rows})


@app.get("/api/report")
def api_report():
    """Plain text, for the clipboard button."""
    if S.trainer is None:
        return jsonify({"ok": False, "text": "Nothing has been trained yet."})
    with S.lock:
        st = S.trainer.status()
        s = asdict(S.trainer.s)
    L: list[str] = []
    L.append("LIQUID DOG RUN REPORT")
    L.append(f"{st['morphology']} | {st['wiring']}")
    L.append(f"cycle {st['cycle']}/{st['cycles']}, gate '{st['gate']}', "
             f"generation {st['generation']} of ~{st['total_gens']}, "
             f"population {st['population']}, {st['minutes']:.1f} min")
    L.append("")
    L.append("SETTINGS")
    for k in sorted(s):
        L.append(f"  {k} = {s[k]}")
    L.append("")
    L.append("PROGRESS (every 10th generation)")
    L.append("  cycle  gen  gate        pop   best   pass   speed  footfall  diversity")
    for t in st["history"][::10]:
        L.append(f"  {t['cycle']:>5}  {t['gen']:>4} {t['gate']:<11} "
                 f"{t['population']:>4} {t['best']:>6.3f} {t['passing']:>6} "
                 f"{t['speed']:>7.3f} {t['footfall']:>9.3f} {t['diversity']:>10.3f}")
    L.append("")
    L.append("CHAMPION POOLS   (descriptor: " + ", ".join(DESCRIPTOR_NAMES) + ")")
    for p in st["pools"]["pools"]:
        flag = "  COLLAPSED" if p["collapsed"] else ""
        L.append(f"  [{p['kind']}] {p['blurb']}")
        L.append(f"    diversity {p['diversity']:.3f} (target {p['target']}), "
                 f"bar {p['bar']:+.3f}, lowered {p['bar_drops']}x, "
                 f"{p['admits']} admissions{flag}")
        for m in p["members"]:
            tag = "FOSSIL" if m["fossil"] else "      "
            L.append(f"    {tag} score {m['score']:+.3f} speed {m['speed']:+.3f} "
                     f"foot {m['footfall']:.2f} sturdy {m['sturdiness']:+.3f} "
                     f"c{m['cycle']}g{m['gen']} desc {m['descriptor']}")
    L.append(f"  diversity relaxations so far: {st['pools']['relaxations']}")
    L.append("")
    L.append("RECENT EVENTS")
    for e in st["pools"]["events"][:10]:
        L.append(f"  {e}")
    for n in st["notes"]:
        L.append(f"  {n}")
    return jsonify({"ok": True, "text": "\n".join(L)})


@app.post("/api/save")
def api_save():
    if S.trainer is None:
        return jsonify({"ok": False, "why": "nothing to save"})
    name = (request.get_json(silent=True) or {}).get("name") or time.strftime("run-%H%M")
    safe = "".join(c for c in name if c.isalnum() or c in "-_")
    with S.lock:
        path = S.trainer.save(ROOT / "runs" / safe)
    return jsonify({"ok": True, "path": str(path)})


def main() -> None:
    port = 5000
    url = f"http://127.0.0.1:{port}/"
    threading.Timer(1.2, lambda: webbrowser.open(url)).start()
    print(f"\n  Liquid dog is running at {url}")
    print("  Leave this window open. Close it to quit.\n")
    app.run(host="127.0.0.1", port=port, debug=False, threaded=True)


if __name__ == "__main__":
    main()
