"""
2-D sagittal-plane dog, simulated with position-based dynamics (PBD).

Two morphologies:

  biped (default)  one front leg, one rear leg. In the sagittal plane a real
                   dog's left and right limbs sit on top of each other, so
                   merging each pair into a single limb loses nothing you can
                   see and makes the picture legible. A horizontal torso on a
                   fore leg and an aft leg is still statically stable.

  quadruped        all four limbs, independently controlled. Mechanically
                   richer, visually confusing: the near and far limbs overlap.

Everything is a distance constraint. Bones hold a fixed length; joints are
distance constraints whose rest length comes from a target angle via the law
of cosines. Because a target angle never reaches 0 or pi, a joint can never
snap through straight or fully folded, so the direction a knee bends is fixed
by the starting pose forever. One constraint type gives actuation, joint
limits and handedness together.

The whole population is stepped in lockstep: arrays are (n_points, batch, 2).
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

# ── geometry, in metres and kilograms ───────────────────────────────────────
L_TORSO = 0.50
H_REST = 0.42
L_THIGH = 0.22
L_SHANK = 0.22

HIP_RANGE = (np.deg2rad(45.0), np.deg2rad(115.0))
KNEE_RANGE = (np.deg2rad(60.0), np.deg2rad(168.0))
HIP_REST = np.deg2rad(74.0)
KNEE_REST = np.deg2rad(145.0)

SHOULDER, HIP, HEAD, TAIL = 0, 1, 2, 3
TORSO_POINTS = (SHOULDER, HIP, HEAD)

GRAVITY = -9.81
SUBSTEP_HZ = 400.0
SOLVER_ITERS = 4
VEL_DAMP = 0.6
VEL_CLAMP = 25.0

# A planted foot barely penetrates the ground, and PBD friction is proportional
# to penetration, so without a small baseline allowance the feet slide almost
# freely and nothing can push off. Four legs can load hard enough to generate
# grip; two cannot. This stands in for a contact patch of a millimetre or two.
CONTACT_EPS = 0.0   # measured: no effect on the search gradient, so off by default


def _rot(v: np.ndarray, ang: float) -> np.ndarray:
    c, s = np.cos(ang), np.sin(ang)
    return np.array([c * v[0] - s * v[1], s * v[0] + c * v[1]])


@dataclass(frozen=True)
class Morphology:
    """Which limbs exist, and everything derived from that."""
    name: str
    legs: tuple                      # (attach point, opposite torso point, side)
    leg_names: tuple

    @property
    def n_legs(self) -> int:
        return len(self.legs)

    @property
    def n_points(self) -> int:
        return 4 + 2 * self.n_legs

    @property
    def n_actuators(self) -> int:
        return 2 * self.n_legs

    @property
    def n_sensors(self) -> int:
        # pitch sin/cos, pitch rate, height, vx, vy, then contact + hip + knee
        return 6 + 3 * self.n_legs

    def knee(self, k: int) -> int:
        return 4 + 2 * k

    def foot(self, k: int) -> int:
        return 5 + 2 * k

    @property
    def feet(self) -> tuple:
        return tuple(self.foot(k) for k in range(self.n_legs))

    @property
    def mass(self) -> np.ndarray:
        # a merged limb carries the pair's share, so biped legs are heavier
        leg = 0.50 if self.n_legs == 2 else 0.35
        return np.array([3.0, 3.0, 1.2, 0.4] + [leg, leg * 0.7] * self.n_legs)

    @property
    def friction(self) -> np.ndarray:
        return np.array([0.5, 0.5, 0.5, 0.4] + [0.6, 1.2] * self.n_legs)

    def rest_pose(self, hip_ang: float = HIP_REST, knee_ang: float = KNEE_REST):
        p = np.zeros((self.n_points, 2))
        p[SHOULDER] = (0.5 * L_TORSO, H_REST)
        p[HIP] = (-0.5 * L_TORSO, H_REST)
        p[HEAD] = p[SHOULDER] + (0.17, 0.13)
        p[TAIL] = p[HIP] + (-0.17, 0.08)
        for k, (att, opp, side) in enumerate(self.legs):
            u = p[opp] - p[att]
            u = u / np.linalg.norm(u)
            thigh = _rot(u, side * hip_ang)
            p[self.knee(k)] = p[att] + L_THIGH * thigh
            p[self.foot(k)] = p[self.knee(k)] + L_SHANK * _rot(-thigh, -side * knee_ang)
        return p


BIPED = Morphology(
    name="biped",
    legs=((SHOULDER, HIP, +1), (HIP, SHOULDER, -1)),
    leg_names=("front", "rear"),
)
QUADRUPED = Morphology(
    name="quadruped",
    legs=((SHOULDER, HIP, +1), (SHOULDER, HIP, +1),
          (HIP, SHOULDER, -1), (HIP, SHOULDER, -1)),
    leg_names=("front-left", "front-right", "rear-left", "rear-right"),
)
MORPHOLOGIES = {m.name: m for m in (BIPED, QUADRUPED)}


def law_of_cosines(a: float, b: float, ang: np.ndarray) -> np.ndarray:
    return np.sqrt(a * a + b * b - 2.0 * a * b * np.cos(ang))


def joint_angle(p_a: np.ndarray, p_v: np.ndarray, p_b: np.ndarray) -> np.ndarray:
    u, w = p_a - p_v, p_b - p_v
    nu = np.linalg.norm(u, axis=-1) + 1e-9
    nw = np.linalg.norm(w, axis=-1) + 1e-9
    return np.arccos(np.clip((u * w).sum(-1) / (nu * nw), -1.0, 1.0))


class Skeleton:
    """Constraint topology for one morphology. Built once, shared by everyone."""

    def __init__(self, morph: Morphology):
        self.morph = morph
        p0 = morph.rest_pose()
        ia, ib, rest, stiff = [], [], [], []

        def bone(i, j, k=1.0):
            ia.append(i); ib.append(j)
            rest.append(float(np.linalg.norm(p0[i] - p0[j]))); stiff.append(k)

        bone(SHOULDER, HIP, 1.0)                    # spine
        bone(SHOULDER, HEAD, 1.0)
        bone(HIP, HEAD, 0.55)                       # holds the neck angle
        bone(HIP, TAIL, 1.0)
        bone(SHOULDER, TAIL, 0.25)                  # floppy tail
        for k in range(morph.n_legs):
            att, _opp, _s = morph.legs[k]
            bone(att, morph.knee(k), 1.0)           # thigh
            bone(morph.knee(k), morph.foot(k), 1.0)  # shank

        self.act_start = len(ia)
        for k in range(morph.n_legs):               # hip swing
            _att, opp, _s = morph.legs[k]
            ia.append(opp); ib.append(morph.knee(k))
            rest.append(float(law_of_cosines(L_TORSO, L_THIGH, HIP_REST)))
            stiff.append(0.35)
        for k in range(morph.n_legs):               # knee flexion
            att, _opp, _s = morph.legs[k]
            ia.append(att); ib.append(morph.foot(k))
            rest.append(float(law_of_cosines(L_THIGH, L_SHANK, KNEE_REST)))
            stiff.append(0.50)

        self.ia = np.array(ia)
        self.ib = np.array(ib)
        self.rest0 = np.array(rest)
        self.stiff = np.array(stiff)[:, None]
        self.n_cons = len(ia)

        w = 1.0 / morph.mass
        count = np.bincount(np.concatenate([self.ia, self.ib]),
                            minlength=morph.n_points)
        scat = np.zeros((morph.n_points, self.n_cons))
        for c in range(self.n_cons):
            a, b = self.ia[c], self.ib[c]
            denom = w[a] + w[b]
            scat[a, c] += w[a] / denom / max(count[a], 1)
            scat[b, c] -= w[b] / denom / max(count[b], 1)
        self.scatter = scat


_SKELETONS: dict = {}


def skeleton(morph: Morphology) -> Skeleton:
    if morph.name not in _SKELETONS:
        _SKELETONS[morph.name] = Skeleton(morph)
    return _SKELETONS[morph.name]


class BatchBody:
    """`batch` independent dogs stepped together."""

    def __init__(self, batch: int, rng: np.random.Generator,
                 morph: Morphology = BIPED, jitter: float = 1.0):
        self.B = batch
        self.m = morph
        self.skel = skeleton(morph)
        P = morph.n_points

        hip = HIP_REST + rng.normal(0, np.deg2rad(4.0) * jitter, batch)
        knee = KNEE_REST + rng.normal(0, np.deg2rad(4.0) * jitter, batch)
        pos = np.stack([morph.rest_pose(h, k) for h, k in zip(hip, knee)], axis=1)
        pos[:, :, 1] += rng.uniform(0.0, 0.02 * jitter, batch)
        self.pos = np.ascontiguousarray(pos)
        self.vel = np.zeros_like(self.pos)
        self.vel[:, :, 0] += rng.normal(0, 0.05 * jitter, batch)

        self.rest = np.repeat(self.skel.rest0[:, None], batch, axis=1).copy()
        self.dt = 1.0 / SUBSTEP_HZ
        self.friction = morph.friction[:, None]
        self.touchdown_impact = np.zeros(batch)
        self._P = P

    # ── sensing ─────────────────────────────────────────────────────────────
    def hip_angles(self) -> np.ndarray:
        out = np.empty((self.m.n_legs, self.B))
        for k, (att, opp, _s) in enumerate(self.m.legs):
            out[k] = joint_angle(self.pos[opp], self.pos[att], self.pos[self.m.knee(k)])
        return out

    def knee_angles(self) -> np.ndarray:
        out = np.empty((self.m.n_legs, self.B))
        for k, (att, _opp, _s) in enumerate(self.m.legs):
            out[k] = joint_angle(self.pos[att], self.pos[self.m.knee(k)],
                                 self.pos[self.m.foot(k)])
        return out

    def foot_contacts(self) -> np.ndarray:
        return self.pos[list(self.m.feet), :, 1] < 0.015

    def torso_centre(self) -> np.ndarray:
        return 0.5 * (self.pos[SHOULDER] + self.pos[HIP])

    def pitch(self) -> np.ndarray:
        d = self.pos[SHOULDER] - self.pos[HIP]
        return np.arctan2(d[:, 1], d[:, 0])

    def height(self) -> np.ndarray:
        return 0.5 * (self.pos[SHOULDER, :, 1] + self.pos[HIP, :, 1])

    # ── actuation ───────────────────────────────────────────────────────────
    def set_targets(self, u: np.ndarray) -> None:
        """u: (2 * n_legs, B) in [-1, 1]. Hip swings first, then knee flexions."""
        n = self.m.n_legs
        u = np.clip(u, -1.0, 1.0)
        lo, hi = HIP_RANGE
        hip_ang = 0.5 * (lo + hi) + 0.5 * (hi - lo) * u[:n]
        lo, hi = KNEE_RANGE
        knee_ang = 0.5 * (lo + hi) + 0.5 * (hi - lo) * u[n:]
        s = self.skel.act_start
        self.rest[s:s + n] = law_of_cosines(L_TORSO, L_THIGH, hip_ang)
        self.rest[s + n:] = law_of_cosines(L_THIGH, L_SHANK, knee_ang)

    # ── integration ─────────────────────────────────────────────────────────
    def substep(self) -> None:
        dt = self.dt
        self.vel[:, :, 1] += GRAVITY * dt
        self.vel *= 1.0 - VEL_DAMP * dt
        np.clip(self.vel, -VEL_CLAMP, VEL_CLAMP, out=self.vel)

        start = self.pos
        pred = self.pos + self.vel * dt
        ia, ib = self.skel.ia, self.skel.ib
        for _ in range(SOLVER_ITERS):
            d = pred[ib] - pred[ia]
            length = np.sqrt((d * d).sum(-1)) + 1e-9
            corr = (self.skel.stiff * (length - self.rest) / length)[:, :, None] * d
            pred = pred + (self.skel.scatter @ corr.reshape(self.skel.n_cons, -1)
                           ).reshape(self._P, self.B, 2)

        pen = np.maximum(-pred[:, :, 1], 0.0)
        hit = pen > 0.0
        was_air = ~(start[:, :, 1] < 1e-4)
        pred[:, :, 1] = np.where(hit, 0.0, pred[:, :, 1])
        slide = pred[:, :, 0] - start[:, :, 0]
        budget = self.friction * (pen + CONTACT_EPS)
        pred[:, :, 0] -= np.where(hit, np.clip(slide, -budget, budget), 0.0)

        self.vel = (pred - start) / dt
        np.clip(self.vel, -VEL_CLAMP, VEL_CLAMP, out=self.vel)
        self.pos = pred

        for f in self.m.feet:
            fresh = hit[f] & was_air[f]
            landing = np.where(fresh, np.abs((start[f, :, 1] - pred[f, :, 1]) / dt), 0.0)
            self.touchdown_impact = np.maximum(self.touchdown_impact, landing)

    def step(self, n: int) -> None:
        for _ in range(n):
            self.substep()

    def fallen(self) -> np.ndarray:
        down = np.zeros(self.B, dtype=bool)
        for i in TORSO_POINTS:
            down |= self.pos[i, :, 1] < 0.08
        down |= np.abs(self.pitch()) > np.deg2rad(60.0)
        down |= self.height() < 0.55 * H_REST
        down |= ~np.isfinite(self.pos).all(axis=(0, 2))
        return down
