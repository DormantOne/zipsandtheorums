"""
The gym: one rollout function, three gates, and a behaviour descriptor.

Everything the dog is told about what "good" means lives in GATES at the
bottom of this file. It is deliberately short. Gate 1 never mentions distance;
gate 2 never mentions a gait pattern; no gate mentions a phase, a period, a
target speed or a reference trajectory.

Gates are cumulative: clearing one demotes it to a constraint on everything
after, which is what stops the distance gate from rediscovering the
belly-flop.

The descriptor is separate from all of that. It says what a dog *does*, not
how good it is, and it is what the champion pools use to measure diversity.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from . import body as B
from .ltc import Brains, Wiring

CONTROL_HZ = 50.0
SUBSTEPS_PER_TICK = int(round(B.SUBSTEP_HZ / CONTROL_HZ))

# ── the few numbers that define "hurt yourself", "awake" and "a footfall" ───
IMPACT_LIMIT = 3.0       # m/s foot-strike closing speed; above this is a slam
WOBBLE_LIMIT = 2.5       # rad/s rms torso pitch rate
TRAVEL_TARGET = 0.9      # rad/s mean joint speed; below this you are a statue
STEP_SAT = 1.2           # clean footfalls/s/foot where the step reward maxes out
DUTY_OK = (0.20, 0.90)   # ground-contact fraction that counts as real stepping
FOOTFALL_PASS = 0.72     # gate 2's bar, and the floor gate 3 keeps holding

# What counts as a footfall rather than a foot vibrating on the spot: clear of
# the ground for a moment, then carrying weight for a moment. Nothing here
# says *when* it should happen.
MIN_STANCE_S = 0.10
MIN_AIR_S = 0.06

DESCRIPTOR_NAMES = ("cadence", "duty", "alternation", "ride height", "speed",
                    "gentleness")


def sense(bod: B.BatchBody, prev_pitch: np.ndarray, dt: float):
    """Proprioception only. No clock, no phase, no target."""
    m = bod.m
    pitch = bod.pitch()
    rate = (pitch - prev_pitch) / dt
    vel = 0.5 * (bod.vel[B.SHOULDER] + bod.vel[B.HIP])
    lo, hi = B.HIP_RANGE
    hip_n = 2.0 * (bod.hip_angles() - lo) / (hi - lo) - 1.0
    lo, hi = B.KNEE_RANGE
    knee_n = 2.0 * (bod.knee_angles() - lo) / (hi - lo) - 1.0
    n = m.n_legs
    u = np.empty((m.n_sensors, bod.B))
    u[0] = np.sin(pitch)
    u[1] = np.cos(pitch)
    u[2] = np.clip(rate / 5.0, -3.0, 3.0)
    u[3] = 2.0 * (bod.height() / B.H_REST - 1.0)
    u[4] = np.clip(vel[:, 0] / 2.0, -3.0, 3.0)
    u[5] = np.clip(vel[:, 1] / 2.0, -3.0, 3.0)
    u[6:6 + n] = bod.foot_contacts()
    u[6 + n:6 + 2 * n] = hip_n
    u[6 + 2 * n:6 + 3 * n] = knee_n
    return u, pitch


@dataclass
class Rollout:
    survive: np.ndarray
    travel: np.ndarray
    impact: np.ndarray
    wobble: np.ndarray
    step_rate: np.ndarray
    step_term: np.ndarray
    regularity: np.ndarray
    duty: np.ndarray
    duty_mean: np.ndarray
    spread: np.ndarray
    distance: np.ndarray
    speed: np.ndarray
    effort: np.ndarray
    frames: list = field(default_factory=list)
    contacts: np.ndarray | None = None

    @property
    def impact_norm(self):
        return np.maximum(self.impact / IMPACT_LIMIT, self.wobble / WOBBLE_LIMIT)

    @property
    def slam(self):
        """Hinged injury cost: gentle contact is free, slamming is not."""
        return np.maximum(0.0, self.impact_norm - 0.5)

    @property
    def liveliness(self):
        return np.minimum(1.0, self.travel / TRAVEL_TARGET)

    @property
    def footfall_score(self):
        # multiplicative on purpose: no credit for rhythm or alternation unless
        # feet are actually leaving the ground and coming back
        return self.step_term * (0.45 + 0.25 * self.regularity
                                 + 0.15 * self.duty + 0.15 * self.spread)

    def descriptor(self) -> np.ndarray:
        """(batch, 6) in roughly [0, 1]. What the dog does, not how good it is.

        Used only for diversity. Speed is in here, so two dogs at different
        speeds count as different behaviours, but it is one axis of six -- a
        pool cannot fill up with six copies of the same fast gait.
        """
        return np.stack([
            np.clip(self.step_rate / 4.0, 0, 1),
            np.clip(self.duty_mean, 0, 1),
            np.clip(self.spread, 0, 1),
            np.clip(self.travel / 3.0, 0, 1),
            np.clip(self.speed / 1.2, -1, 1) * 0.5 + 0.5,
            np.clip(1.0 - self.impact_norm, 0, 1),
        ], axis=1)


def rollout(wiring: Wiring, genes: np.ndarray, seconds: float, seed: int,
            morph: B.Morphology = B.BIPED, record: bool = False) -> Rollout:
    genes = np.atleast_2d(genes)
    pop = genes.shape[0]
    ticks = int(round(seconds * CONTROL_HZ))
    dt = 1.0 / CONTROL_HZ
    bod = B.BatchBody(pop, np.random.default_rng(seed), morph)
    brains = Brains(wiring, genes)
    n_legs = morph.n_legs

    alive = np.ones(pop, dtype=bool)
    t_alive = np.zeros(pop)
    x0 = bod.torso_centre()[:, 0].copy()
    x_last = x0.copy()
    impact = np.zeros(pop)
    wob2 = np.zeros(pop)
    travel = np.zeros(pop)
    effort = np.zeros(pop)
    contacts = np.zeros((ticks, n_legs, pop), dtype=bool)

    prev_pitch = bod.pitch()
    prev_hip, prev_knee = bod.hip_angles(), bod.knee_angles()
    prev_u = np.zeros((morph.n_actuators, pop))
    frames: list = []

    for t in range(ticks):
        u, pitch = sense(bod, prev_pitch, dt)
        rate = (pitch - prev_pitch) / dt
        prev_pitch = pitch
        act = brains.step(u, dt)
        bod.set_targets(act)
        bod.step(SUBSTEPS_PER_TICK)

        hip, knee = bod.hip_angles(), bod.knee_angles()
        moved = 0.5 * (np.abs(hip - prev_hip).mean(0) + np.abs(knee - prev_knee).mean(0))
        prev_hip, prev_knee = hip, knee

        alive &= ~bod.fallen()
        t_alive += alive * dt
        travel += np.where(alive, moved / dt, 0.0)
        effort += np.where(alive, np.abs(act - prev_u).mean(0), 0.0)
        prev_u = act
        wob2 += np.where(alive, rate * rate, 0.0)
        impact = np.maximum(impact, np.where(alive, bod.touchdown_impact, 0.0))
        x_last = np.where(alive, bod.torso_centre()[:, 0], x_last)
        contacts[t] = bod.foot_contacts() & alive
        if record:
            frames.append(bod.pos[:, 0, :].copy())

    live = np.maximum(t_alive * CONTROL_HZ, 1.0)
    return Rollout(
        survive=t_alive / seconds, travel=travel / live, impact=impact,
        wobble=np.sqrt(wob2 / live), distance=x_last - x0,
        speed=(x_last - x0) / seconds, effort=effort / live,
        frames=frames, contacts=contacts if record else None,
        **_footfall_stats(contacts, live, dt))


def _footfall_stats(contacts: np.ndarray, live: np.ndarray, dt: float) -> dict:
    """Clean footfalls, regularity, duty factor, alternation. Whole batch at once."""
    ticks, n_legs, pop = contacts.shape
    min_st = max(1, round(MIN_STANCE_S / dt))
    min_air = max(1, round(MIN_AIR_S / dt))
    shape = (n_legs, pop)

    in_c = contacts[0].copy()
    run = np.ones(shape)
    air_before = np.full(shape, 1e6)
    onset_t = np.zeros(shape)
    clean = np.zeros(shape)
    last = np.full(shape, -1.0)
    n_int = np.zeros(shape)
    s1 = np.zeros(shape)
    s2 = np.zeros(shape)

    for t in range(1, ticks):
        c = contacts[t]
        rise = c & ~in_c
        fall = ~c & in_c
        good = fall & (run >= min_st) & (air_before >= min_air)
        gap = onset_t - last
        ok = good & (last >= 0)
        n_int += ok
        s1 += np.where(ok, gap, 0.0)
        s2 += np.where(ok, gap * gap, 0.0)
        last = np.where(good, onset_t, last)
        clean += good
        air_before = np.where(rise, run, air_before)
        onset_t = np.where(rise, float(t), onset_t)
        run = np.where(rise | fall, 1.0, run + 1.0)
        in_c = c

    rate = clean / (live / CONTROL_HZ)
    mean_int = s1 / np.maximum(n_int, 1.0)
    var = np.maximum(s2 / np.maximum(n_int, 1.0) - mean_int ** 2, 0.0)
    cv = np.sqrt(var) / np.maximum(mean_int, 1e-6)
    down = contacts.sum(1)
    frac = contacts.sum(0) / live
    lo, hi = DUTY_OK
    return {
        "step_rate": rate.mean(0),
        # saturate each foot separately, *then* average, so one buzzing foot
        # cannot stand in for the whole set
        "step_term": np.minimum(1.0, rate / STEP_SAT).mean(0),
        "regularity": np.where(n_int >= 3, 1.0 - np.clip(cv, 0.0, 1.0), 0.0).mean(0),
        "duty": ((frac > lo) & (frac < hi)).mean(0),
        "duty_mean": frac.mean(0),
        # feet taking turns: for two legs this is "exactly one foot down",
        # which separates walking from hopping without naming either
        "spread": ((down > 0) & (down < n_legs)).sum(0) / live,
    }


# ── the gates ───────────────────────────────────────────────────────────────
@dataclass
class Gate:
    name: str
    blurb: str
    seconds: float

    def score(self, r: Rollout) -> np.ndarray: ...
    def passed(self, r: Rollout) -> np.ndarray: ...


class StandGate(Gate):
    """Stay upright, stay awake, don't slam into anything.

    No reward for going anywhere. Surviving the whole episode is worth exactly
    1.0 and not a point more, so among dogs that can stand, selection is driven
    only by liveliness and gentleness and diversity survives into the next
    gate. The liveliness term is the anti-statue clause: without it this gate
    is won by locking every joint, and that dog is a genetic dead end.
    """

    def score(self, r):
        return r.survive + 0.60 * r.liveliness - 0.50 * r.slam

    def passed(self, r):
        return (r.survive >= 0.999) & (r.liveliness >= 1.0) & (r.impact_norm <= 1.25)


class FootfallGate(Gate):
    """Distinct, repeating footfalls. Still no reward for distance.

    Rhythm is rewarded but no *particular* rhythm. Only that feet leave the
    ground, come back, take turns, and do it at fairly even intervals.
    """

    def score(self, r):
        alive = np.where(r.survive >= 0.999, 1.0, 0.15 * r.survive)
        return alive * r.footfall_score - 0.35 * r.slam

    def passed(self, r):
        return ((r.survive >= 0.999) & (r.footfall_score >= FOOTFALL_PASS)
                & (r.impact_norm <= 1.25))


class DistanceGate(Gate):
    """Now go somewhere, while keeping gates 1 and 2 satisfied.

    Both earlier gates return as multiplicative constraints, so falling over
    or dissolving into a rhythmless scrabble costs most of the reward instead
    of being quietly forgiven. Distance itself is raw: no target speed, no
    style bonus, just metres per second and a token penalty on thrashing.
    """

    floor = FOOTFALL_PASS

    def score(self, r):
        alive = np.where(r.survive >= 0.999, 1.0, 0.10 * r.survive)
        gait = np.clip(r.footfall_score / self.floor, 0.25, 1.0)
        safe = np.clip(1.6 - r.impact_norm, 0.25, 1.0)
        return alive * gait * safe * r.speed - 0.05 * r.effort

    def passed(self, r):
        return ((r.survive >= 0.999) & (r.speed >= 0.6)
                & (r.footfall_score >= self.floor))


GATES: tuple[Gate, ...] = (
    StandGate("stand", "upright, awake, no slamming", seconds=5.0),
    FootfallGate("footfalls", "distinct repeating footfalls", seconds=7.0),
    DistanceGate("distance", "cover ground, keep the gait", seconds=9.0),
)
OBJECTIVE = GATES[-1]        # what a champion is judged on, always
