"""
A small liquid time-constant (LTC) network.

Each neuron is a leaky ODE whose time constant is *itself* gated by the current
input and state:

    dx/dt = -x / tau + f(x, I) * (A - x),     f = sigmoid(W_rec x + W_in I + b)

so the effective time constant is tau_eff = tau / (1 + tau * f). A neuron can
be sluggish one moment and fast the next, which is what lets a handful of cells
hold a rhythm without anyone giving them a clock signal. There is no phase
input and no gait template anywhere in this file.

Integration uses the fused implicit Euler step from Hasani et al. (2020):

    x <- (x + dt * f * A) / (1 + dt * (1/tau + f))

which cannot blow up for positive dt, tau, f.

Wiring is sparse and *fixed* — evolution tunes synapse strengths, time
constants and reversal potentials, never the topology. The last `n_motor`
neurons are the motor neurons; their state is read out directly, so there is no
separate output layer.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

TAU_MIN, TAU_MAX = 0.03, 2.0


@dataclass(frozen=True)
class Wiring:
    n_in: int
    n_inter: int
    n_motor: int
    in_rows: np.ndarray
    in_cols: np.ndarray
    rec_rows: np.ndarray
    rec_cols: np.ndarray

    @property
    def n(self) -> int:
        return self.n_inter + self.n_motor

    @property
    def n_syn_in(self) -> int:
        return len(self.in_rows)

    @property
    def n_syn_rec(self) -> int:
        return len(self.rec_rows)

    @property
    def genome_size(self) -> int:
        return self.n_syn_in + self.n_syn_rec + 3 * self.n + 2 * self.n_motor

    def describe(self) -> str:
        return (
            f"{self.n_in} sensors -> {self.n_inter} interneurons + "
            f"{self.n_motor} motor neurons | {self.n_syn_in} sensory synapses, "
            f"{self.n_syn_rec} recurrent synapses | {self.genome_size} genes"
        )


def build_wiring(
    n_in: int,
    n_inter: int = 6,
    n_motor: int = 8,
    sensor_density: float = 0.45,
    recurrent_density: float = 0.40,
    seed: int = 7,
) -> Wiring:
    rng = np.random.default_rng(seed)
    n = n_inter + n_motor

    m_in = rng.random((n, n_in)) < sensor_density
    m_rec = rng.random((n, n)) < recurrent_density
    np.fill_diagonal(m_rec, False)          # self-decay is what tau is for
    # a neuron with no afferents is dead weight; give every cell at least two
    for i in range(n):
        while m_in[i].sum() + m_rec[i].sum() < 2:
            if rng.random() < 0.5:
                m_in[i, rng.integers(n_in)] = True
            else:
                j = rng.integers(n)
                if j != i:
                    m_rec[i, j] = True

    ir, ic = np.nonzero(m_in)
    rr, rc = np.nonzero(m_rec)
    return Wiring(n_in, n_inter, n_motor, ir, ic, rr, rc)


class Brains:
    """One LTC per population member, all stepped together."""

    def __init__(self, wiring: Wiring, genes: np.ndarray):
        self.w = wiring
        g = np.atleast_2d(np.asarray(genes, dtype=np.float64))
        self.B = g.shape[0]
        n, nin = wiring.n, wiring.n_in

        o = 0
        self.W_in = np.zeros((self.B, n, nin))
        self.W_in[:, wiring.in_rows, wiring.in_cols] = g[:, o:o + wiring.n_syn_in]
        o += wiring.n_syn_in

        self.W_rec = np.zeros((self.B, n, n))
        self.W_rec[:, wiring.rec_rows, wiring.rec_cols] = g[:, o:o + wiring.n_syn_rec]
        o += wiring.n_syn_rec

        self.bias = g[:, o:o + n].T.copy(); o += n
        tau = np.exp(np.clip(g[:, o:o + n], np.log(TAU_MIN), np.log(TAU_MAX)))
        self.inv_tau = (1.0 / tau).T.copy(); o += n
        self.A = np.clip(g[:, o:o + n], -2.0, 2.0).T.copy(); o += n
        self.gain = g[:, o:o + wiring.n_motor].T.copy(); o += wiring.n_motor
        self.offset = g[:, o:o + wiring.n_motor].T.copy(); o += wiring.n_motor
        assert o == wiring.genome_size

        self.x = np.zeros((n, self.B))

    def reset(self) -> None:
        self.x[:] = 0.0

    def step(self, u: np.ndarray, dt: float, unfolds: int = 2) -> np.ndarray:
        """u: (n_in, B) sensors. Returns motor outputs (n_motor, B) in [-1, 1]."""
        h = dt / unfolds
        drive = np.einsum("bij,jb->ib", self.W_in, u) + self.bias
        for _ in range(unfolds):
            pre = np.einsum("bij,jb->ib", self.W_rec, self.x) + drive
            f = 1.0 / (1.0 + np.exp(-np.clip(pre, -30.0, 30.0)))
            self.x = (self.x + h * f * self.A) / (1.0 + h * (self.inv_tau + f))
        np.clip(self.x, -8.0, 8.0, out=self.x)
        m = self.x[self.w.n_inter:]
        return np.tanh(self.gain * m + self.offset)


# ── genomes ─────────────────────────────────────────────────────────────────
def random_genomes(wiring: Wiring, count: int, rng: np.random.Generator) -> np.ndarray:
    n, nm = wiring.n, wiring.n_motor
    parts = [
        rng.normal(0.0, 0.7, (count, wiring.n_syn_in)),
        rng.normal(0.0, 0.7, (count, wiring.n_syn_rec)),
        rng.normal(0.0, 0.4, (count, n)),                              # bias
        rng.uniform(np.log(0.06), np.log(0.7), (count, n)),            # log tau
        rng.normal(0.0, 0.9, (count, n)),                              # A
        rng.normal(1.0, 0.3, (count, nm)),                             # gain
        rng.normal(0.0, 0.2, (count, nm)),                             # offset
    ]
    return np.concatenate(parts, axis=1)


def mutate(
    genes: np.ndarray,
    rng: np.random.Generator,
    rate: float = 0.18,
    sigma: float = 0.14,
    jolt_prob: float = 0.08,
) -> np.ndarray:
    """Sparse Gaussian mutation, with the occasional larger kick."""
    out = np.array(genes, dtype=np.float64, copy=True)
    if out.ndim == 1:
        out = out[None]
    for i in range(out.shape[0]):
        s = sigma * (5.0 if rng.random() < jolt_prob else 1.0)
        hit = rng.random(out.shape[1]) < rate
        if not hit.any():
            hit[rng.integers(out.shape[1])] = True
        out[i, hit] += rng.normal(0.0, s, hit.sum())
    return out


def crossover(a: np.ndarray, b: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    take = rng.random(a.shape[-1]) < 0.5
    return np.where(take, a, b)
