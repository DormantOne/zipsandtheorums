"""
Three champion pools, where being different counts as much as being good.

A single hall of fame ranked by score fills up with six near-copies of
whatever is winning this week, and when the population later gets stuck there
is nothing in the archive to go back to. These pools are the fix. Each one
keeps a handful of champions and each admits on a 50/50 blend of

    how good it is        (its score on the real objective)
    how different it is   (distance from everything already in the pool, in
                           behaviour space, not genome space)

Behaviour space matters: two genomes can differ in 200 genes and produce the
same trot, and two near-identical genomes can produce a walk and a hop. The
descriptor is six numbers describing what the dog *does* -- cadence, duty
factor, alternation, ride height, speed, gentleness.

The three pools have different characters rather than being three copies:

    fast     ranks on the objective, diversity as tiebreak
    sturdy   ranks on staying upright and landing gently
    strange  ranks on novelty first; the explorer's pool

Fossils. Every pool reserves slots for champions that can never be evicted,
filled at the end of each curriculum cycle. A fossil is a snapshot of what
the best dog looked like at that moment, kept even after it has been
comprehensively beaten, because the thing that beat it may turn out to be a
dead end.

Collapse. If a pool's internal diversity falls below target, two pools chosen
at random have their admission standard lowered a notch per generation --
repeatedly, as far as it takes -- until something genuinely different gets in.
The bar snaps back the moment it does. Lowering two of three, at random,
rather than all of them means there is always at least one pool still holding
the line on quality.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

KINDS = ("fast", "sturdy", "strange")
KIND_BLURB = {
    "fast": "ranks on the objective, diversity breaks ties",
    "sturdy": "ranks on staying upright and landing gently",
    "strange": "ranks on novelty first",
}


@dataclass(eq=False)   # numpy fields make generated __eq__ ambiguous; identity is
class Member:          # what the pool actually wants when it swaps members
    genes: np.ndarray
    descriptor: np.ndarray
    score: float          # score on the real objective
    sturdiness: float
    speed: float
    footfall: float
    gen: int
    cycle: int
    fossil: bool = False

    def summary(self) -> dict:
        return {"score": round(self.score, 4), "speed": round(self.speed, 3),
                "footfall": round(self.footfall, 3),
                "sturdiness": round(self.sturdiness, 3),
                "gen": self.gen, "cycle": self.cycle, "fossil": self.fossil,
                "descriptor": [round(float(v), 3) for v in self.descriptor]}


def _merit(m: Member, kind: str) -> float:
    if kind == "sturdy":
        return m.sturdiness
    return m.score


@dataclass
class Pool:
    kind: str
    size: int = 6
    fossil_slots: int = 3
    min_gap: float = 0.10          # behaviour distance that counts as different
    diversity_target: float = 0.18
    members: list = field(default_factory=list)
    bar: float = 0.0               # current admission standard
    bar_drops: int = 0             # how far it has been lowered
    admits: int = 0

    # ── measurements ────────────────────────────────────────────────────────
    def diversity(self) -> float:
        """Mean pairwise behaviour distance. 0 means everyone is the same dog."""
        if len(self.members) < 2:
            return 0.0
        d = np.array([m.descriptor for m in self.members])
        gaps = [np.linalg.norm(d[i] - d[j])
                for i in range(len(d)) for j in range(i + 1, len(d))]
        return float(np.mean(gaps))

    def collapsed(self) -> bool:
        return len(self.members) >= 3 and self.diversity() < self.diversity_target

    def novelty(self, descriptor: np.ndarray) -> float:
        if not self.members:
            return 1.0
        d = np.array([m.descriptor for m in self.members])
        return float(np.min(np.linalg.norm(d - descriptor, axis=1)))

    def best(self) -> Member | None:
        return max(self.members, key=lambda m: _merit(m, self.kind)) if self.members else None

    # ── admission ───────────────────────────────────────────────────────────
    def offer(self, cand: Member) -> str:
        """Try to admit. Returns what happened, for the log."""
        merit = _merit(cand, self.kind)
        nov = self.novelty(cand.descriptor)

        if merit < self.bar and self.kind != "strange":
            return ""
        if len(self.members) < self.size:
            self.members.append(cand)
            self.admits += 1
            self._reset_bar()
            return "admitted"

        # Full. Something has to go, and fossils never do.
        evictable = [m for m in self.members if not m.fossil]
        if not evictable:
            return ""

        if nov < self.min_gap:
            # near-duplicate of something already here: only a straight
            # improvement on its nearest neighbour gets in, and it replaces it
            d = np.array([m.descriptor for m in self.members])
            near = self.members[int(np.argmin(np.linalg.norm(d - cand.descriptor, axis=1)))]
            if near.fossil or _merit(cand, self.kind) <= _merit(near, self.kind):
                return ""
            self.members[self.members.index(near)] = cand
            self.admits += 1
            self._reset_bar()
            return "replaced a near-twin"

        # Genuinely different: compete on the blend. Being different counts as
        # much as being good -- that is what the 0.5/0.5 is.
        w = 0.25 if self.kind == "strange" else 0.5
        merits = np.array([_merit(m, self.kind) for m in self.members])
        lo, hi = merits.min(), merits.max()
        span = (hi - lo) or 1.0

        def blend(m: Member, novelty: float) -> float:
            return w * (_merit(m, self.kind) - lo) / span + (1.0 - w) * novelty

        cand_blend = blend(cand, min(1.0, nov / max(self.min_gap * 4, 1e-6)))
        worst, worst_blend = None, 1e9
        for m in evictable:
            others = [o for o in self.members if o is not m]
            d = np.array([o.descriptor for o in others])
            own_nov = float(np.min(np.linalg.norm(d - m.descriptor, axis=1))) if others else 1.0
            b = blend(m, min(1.0, own_nov / max(self.min_gap * 4, 1e-6)))
            if b < worst_blend:
                worst, worst_blend = m, b
        if worst is not None and cand_blend > worst_blend:
            self.members[self.members.index(worst)] = cand
            self.admits += 1
            self._reset_bar()
            return "displaced the least distinctive"
        return ""

    def _reset_bar(self) -> None:
        if self.bar_drops:
            self.bar_drops = 0
        if self.members:
            merits = sorted(_merit(m, self.kind) for m in self.members)
            self.bar = merits[len(merits) // 3]      # back to the lower third

    def lower_bar(self) -> None:
        """Drop the standard a notch to let something different in."""
        self.bar_drops += 1
        self.bar = self.bar * 0.8 - 0.02 if self.bar > 0 else self.bar - 0.02

    def fossilise(self, cycle: int) -> Member | None:
        """Freeze the current best so it survives whatever comes next."""
        b = self.best()
        if b is None:
            return None
        n_fossils = sum(1 for m in self.members if m.fossil)
        if n_fossils >= self.fossil_slots:
            return None
        clone = Member(b.genes.copy(), b.descriptor.copy(), b.score, b.sturdiness,
                       b.speed, b.footfall, b.gen, cycle, fossil=True)
        if len(self.members) >= self.size:
            evictable = [m for m in self.members if not m.fossil]
            if evictable:
                worst = min(evictable, key=lambda m: _merit(m, self.kind))
                self.members[self.members.index(worst)] = clone
            else:
                return None
        else:
            self.members.append(clone)
        return clone

    def report(self) -> dict:
        return {"kind": self.kind, "blurb": KIND_BLURB[self.kind],
                "diversity": round(self.diversity(), 4),
                "target": self.diversity_target,
                "collapsed": self.collapsed(),
                "bar": round(self.bar, 4), "bar_drops": self.bar_drops,
                "admits": self.admits,
                "members": [m.summary() for m in
                            sorted(self.members, key=lambda m: -_merit(m, self.kind))]}


class PoolSet:
    """The three pools plus the collapse response."""

    def __init__(self, size: int = 6, seed: int = 0, min_gap: float = 0.10,
                 diversity_target: float = 0.18):
        self.pools = {k: Pool(k, size=size, min_gap=min_gap,
                              diversity_target=diversity_target) for k in KINDS}
        self.rng = np.random.default_rng(seed)
        self.relaxations = 0
        self.events: list[str] = []

    def offer(self, cand: Member) -> None:
        for p in self.pools.values():
            what = p.offer(cand)
            if what:
                self._note(f"gen {cand.gen}: {p.kind} pool {what} "
                           f"(speed {cand.speed:.2f}, score {cand.score:.3f})")

    def maintain(self, gen: int) -> None:
        """Once per generation: if diversity has collapsed, lower two bars."""
        collapsed = [k for k, p in self.pools.items() if p.collapsed()]
        if not collapsed:
            return
        picks = self.rng.choice(KINDS, size=2, replace=False)
        for k in picks:
            self.pools[k].lower_bar()
        self.relaxations += 1
        self._note(f"gen {gen}: diversity collapsed in {', '.join(collapsed)} - "
                   f"lowered the {picks[0]} and {picks[1]} bars "
                   f"(relaxation #{self.relaxations})")

    def fossilise(self, cycle: int) -> None:
        for p in self.pools.values():
            if p.fossilise(cycle) is not None:
                self._note(f"cycle {cycle}: fossilised the {p.kind} pool's best")

    def seeds(self, count: int) -> list[np.ndarray]:
        """Genomes to inject back into the population, spread across pools."""
        everyone = [m for p in self.pools.values() for m in p.members]
        if not everyone:
            return []
        picks = self.rng.choice(len(everyone), size=min(count, len(everyone)),
                                replace=False)
        return [everyone[i].genes for i in picks]

    def champions(self) -> list[Member]:
        seen, out = set(), []
        for p in self.pools.values():
            for m in sorted(p.members, key=lambda m: -m.score):
                key = tuple(np.round(m.descriptor, 3))
                if key not in seen:
                    seen.add(key)
                    out.append(m)
        return sorted(out, key=lambda m: -m.score)

    def _note(self, msg: str) -> None:
        self.events.append(msg)
        del self.events[:-40]

    def report(self) -> dict:
        return {"pools": [self.pools[k].report() for k in KINDS],
                "relaxations": self.relaxations,
                "events": list(reversed(self.events[-12:]))}
