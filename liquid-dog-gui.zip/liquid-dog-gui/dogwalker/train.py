"""
The trainer: a cycling curriculum on a telescoping population.

Curriculum order is never altered -- stand, then footfalls, then distance --
because the gates are ordered by *learnability*, not importance. Standing is
learnable from a random controller; footfalls once you can stand; distance
only once you have footfalls. Shuffling that order turns the biggest cut of
the generation into a coin flip. (Tried it. The run went flat for 65
generations.)

What does repeat is the whole cycle. After the distance gate has had its turn,
the curriculum starts again at stand. Revisits are nearly free, because a gate
promotes as soon as the surviving cohort clears it and a population that can
already stand clears gate 1 in a generation or two -- but they are not
pointless, because each revisit re-applies "upright, awake, gentle" as a hard
gate rather than a soft constraint, and pulls back whatever reliability the
distance gate quietly traded away.

The population telescopes: wide while searching, narrow while refining. A wide
base finds "stand and step" very fast, but the distance gate is tuning a limit
cycle rather than looking for one, and tuning wants generations instead of
samples.

Champion pools run alongside all of it, and a slice of each generation's
children are drawn from them, so a collapsed population can be rescued by its
own fossils.
"""
from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path

import numpy as np

from . import body as B
from .gym import GATES, OBJECTIVE, Rollout, rollout
from .ltc import build_wiring, crossover, mutate, random_genomes
from .pools import Member, PoolSet


@dataclass
class Settings:
    morphology: str = "biped"
    cycles: int = 3
    wide_population: int = 320
    narrow_population: int = 140
    telescope_after: int = 1        # cycle at which the population narrows
    elite_frac: float = 0.20
    pool_seed_frac: float = 0.10    # children drawn from the champion pools
    trials: int = 2                 # starting poses per individual per generation
    crossover_prob: float = 0.25
    mutation_rate: float = 0.18
    sigma: float = 0.14
    interneurons: int = 6
    pool_size: int = 6
    min_gap: float = 0.10
    diversity_target: float = 0.18
    first_cycle_gens: tuple = (20, 30, 100)
    later_cycle_gens: tuple = (6, 10, 150)
    seed: int = 1
    wiring_seed: int = 7

    def total_gens(self) -> int:
        return sum(self.first_cycle_gens) + (self.cycles - 1) * sum(self.later_cycle_gens)


@dataclass
class Tick:
    """One generation's worth of numbers, for the chart."""
    gen: int
    cycle: int
    gate: str
    population: int
    best: float
    cohort: float
    passing: int
    speed: float
    footfall: float
    survive: float
    impact: float
    diversity: float
    sigma: float


class Trainer:
    """Runnable a generation at a time, so a GUI can poll it."""

    def __init__(self, s: Settings):
        self.s = s
        self.morph = B.MORPHOLOGIES[s.morphology]
        self.rng = np.random.default_rng(s.seed)
        self.wiring = build_wiring(self.morph.n_sensors, n_inter=s.interneurons,
                                   n_motor=self.morph.n_actuators, seed=s.wiring_seed)
        self.pop = random_genomes(self.wiring, s.wide_population, self.rng)
        self.pools = PoolSet(size=s.pool_size, seed=s.seed, min_gap=s.min_gap,
                             diversity_target=s.diversity_target)
        self.history: list[Tick] = []
        self.gen = 0
        self.cycle = 1
        self.gate_index = 0
        self.gate_gen = 0
        self.sigma = s.sigma
        self.best_cohort = -1e9
        self.stale = 0
        self.done = False
        self.started = time.time()
        self.notes: list[str] = []

    # ── plumbing ────────────────────────────────────────────────────────────
    @property
    def gate(self):
        return GATES[self.gate_index]

    def budget(self) -> int:
        buds = self.s.first_cycle_gens if self.cycle == 1 else self.s.later_cycle_gens
        return int(buds[self.gate_index])

    def target_population(self) -> int:
        return (self.s.wide_population if self.cycle <= self.s.telescope_after
                else self.s.narrow_population)

    def _resize(self) -> None:
        want = self.target_population()
        have = self.pop.shape[0]
        if want == have:
            return
        if want < have:
            self.pop = self.pop[:want]          # stored elites-first
        else:
            extra = self.pop[self.rng.integers(0, have, want - have)]
            self.pop = np.concatenate(
                [self.pop, mutate(extra, self.rng, self.s.mutation_rate, self.sigma)])
        self._note(f"population {have} -> {want} entering cycle {self.cycle}")

    def _note(self, msg: str) -> None:
        self.notes.append(msg)
        del self.notes[:-30]

    # ── one generation ──────────────────────────────────────────────────────
    def step(self) -> Tick:
        s = self.s
        self._resize()
        pop = self.pop
        n = pop.shape[0]
        n_elite = max(2, int(round(n * s.elite_frac)))

        scores = np.zeros(n)
        passes = np.ones(n, dtype=bool)
        last: Rollout | None = None
        for k in range(s.trials):
            r = rollout(self.wiring, pop, self.gate.seconds,
                        seed=(s.seed + self.gen) * 7919 + k, morph=self.morph)
            scores += self.gate.score(r)
            passes &= self.gate.passed(r)
            last = r
        scores /= s.trials

        order = np.argsort(-scores)
        elite = order[:n_elite]
        top = int(order[0])

        # Champions are always judged on the real objective, whatever gate is
        # currently active -- otherwise the pools would fill with dogs that
        # were merely good at standing.
        obj = rollout(self.wiring, pop[elite[:max(4, n_elite // 4)]],
                      OBJECTIVE.seconds, seed=(s.seed + self.gen) * 31,
                      morph=self.morph)
        obj_score = OBJECTIVE.score(obj)
        desc = obj.descriptor()
        sturdy = obj.survive - 0.5 * obj.slam + 0.3 * obj.liveliness
        for i in range(len(obj_score)):
            self.pools.offer(Member(
                genes=pop[elite[i]].copy(), descriptor=desc[i],
                score=float(obj_score[i]), sturdiness=float(sturdy[i]),
                speed=float(obj.speed[i]), footfall=float(obj.footfall_score[i]),
                gen=self.gen, cycle=self.cycle))
        self.pools.maintain(self.gen)

        div = float(np.mean([p.diversity() for p in self.pools.pools.values()]))
        tick = Tick(self.gen, self.cycle, self.gate.name, n,
                    float(scores[top]), float(scores[elite].mean()),
                    int(passes.sum()), float(obj.speed.max()),
                    float(last.footfall_score[top]), float(last.survive[top]),
                    float(last.impact[top]), div, self.sigma)
        self.history.append(tick)

        cohort = float(scores[elite].mean())
        if cohort > self.best_cohort + 1e-4:
            self.best_cohort, self.stale = cohort, 0
            self.sigma = max(s.sigma, self.sigma * 0.8)
        else:
            self.stale += 1
            if self.stale >= 15:
                self.sigma = min(s.sigma * 2.5, self.sigma * 1.25)
                self.stale = 0

        promote = bool(passes[elite].all())
        self.gen += 1
        self.gate_gen += 1
        spent = self.gate_gen >= self.budget()

        # breed: elites untouched, then children of elites, then pool seeds
        n_seed = int(round(n * s.pool_seed_frac))
        seeds = self.pools.seeds(n_seed)
        elites = pop[elite]
        kids = []
        for _ in range(n - n_elite - len(seeds)):
            a = elites[self.rng.integers(n_elite)]
            if self.rng.random() < s.crossover_prob:
                a = crossover(a, elites[self.rng.integers(n_elite)], self.rng)
            kids.append(a)
        blocks = [elites]
        if kids:
            blocks.append(mutate(np.array(kids), self.rng, s.mutation_rate, self.sigma))
        if seeds:
            blocks.append(mutate(np.array(seeds), self.rng, s.mutation_rate, self.sigma))
        self.pop = np.concatenate(blocks, axis=0)

        if promote or spent:
            why = "cohort cleared it" if promote else "budget spent"
            self._note(f"gen {self.gen}: leaving '{self.gate.name}' after "
                       f"{self.gate_gen} gens ({why})")
            self.gate_gen = 0
            self.gate_index += 1
            self.best_cohort = -1e9
            self.sigma = s.sigma
            if self.gate_index >= len(GATES):
                self.pools.fossilise(self.cycle)
                self.gate_index = 0
                self.cycle += 1
                if self.cycle > s.cycles:
                    self.done = True
                    self._note("finished all cycles")
        return tick

    # ── output ──────────────────────────────────────────────────────────────
    def status(self) -> dict:
        h = self.history
        return {
            "generation": self.gen, "cycles": self.s.cycles,
            "cycle": min(self.cycle, self.s.cycles),
            "gate": self.gate.name, "gate_blurb": self.gate.blurb,
            "gate_gen": self.gate_gen, "gate_budget": self.budget(),
            "population": self.pop.shape[0],
            "total_gens": self.s.total_gens(),
            "done": self.done, "minutes": (time.time() - self.started) / 60.0,
            "genes": self.wiring.genome_size,
            "wiring": self.wiring.describe(),
            "morphology": self.morph.name,
            "best_speed": max((t.speed for t in h), default=0.0),
            "history": [asdict(t) for t in h[-400:]],
            "pools": self.pools.report(),
            "notes": list(reversed(self.notes[-8:])),
        }

    def save(self, out: Path) -> Path:
        out.mkdir(parents=True, exist_ok=True)
        champs = self.pools.champions()
        meta = {"settings": asdict(self.s), "generations": self.gen,
                "minutes": (time.time() - self.started) / 60.0,
                "wiring": {"n_in": self.wiring.n_in, "n_inter": self.wiring.n_inter,
                           "n_motor": self.wiring.n_motor, "seed": self.s.wiring_seed,
                           "description": self.wiring.describe()},
                "pools": self.pools.report(),
                "champions": [{**m.summary(), "genes": m.genes.tolist()}
                              for m in champs]}
        (out / "champions.json").write_text(json.dumps(meta, indent=1),
                                            encoding="utf-8")
        np.save(out / "population.npy", self.pop)
        with (out / "history.csv").open("w", encoding="utf-8") as fh:
            fh.write(",".join(Tick.__dataclass_fields__) + "\n")
            for t in self.history:
                fh.write(",".join(f"{v:.4f}" if isinstance(v, float) else str(v)
                                  for v in asdict(t).values()) + "\n")
        return out / "champions.json"

    def run(self, verbose: bool = True) -> None:
        while not self.done:
            t = self.step()
            if verbose and t.gen % 5 == 0:
                print(f"  c{t.cycle} gen {t.gen:4d} {t.gate:<10} n={t.population:<4d} "
                      f"best {t.best:7.3f} pass {t.passing:4d} "
                      f"spd {t.speed:5.2f} foot {t.footfall:4.2f} "
                      f"div {t.diversity:5.3f}")
