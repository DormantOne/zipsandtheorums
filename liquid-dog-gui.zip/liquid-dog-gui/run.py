#!/usr/bin/env python3
"""Headless trainer, for when you don't want the browser.

    python run.py                          the shipped defaults
    python run.py --cycles 5 --wide 800
    python run.py --morphology quadruped
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from dogwalker.train import Settings, Trainer


def main() -> None:
    # Windows consoles cannot encode the block characters in the charts once
    # output is redirected to a file; this is cheaper than asking anyone to
    # set PYTHONIOENCODING by hand.
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass

    d = Settings()
    ap = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out", default="runs/headless")
    ap.add_argument("--morphology", choices=("biped", "quadruped"), default=d.morphology)
    ap.add_argument("--cycles", type=int, default=d.cycles)
    ap.add_argument("--wide", type=int, default=d.wide_population)
    ap.add_argument("--narrow", type=int, default=d.narrow_population)
    ap.add_argument("--trials", type=int, default=d.trials)
    ap.add_argument("--sigma", type=float, default=d.sigma)
    ap.add_argument("--interneurons", type=int, default=d.interneurons)
    ap.add_argument("--pool-size", type=int, default=d.pool_size)
    ap.add_argument("--seed", type=int, default=d.seed)
    ap.add_argument("--first-gens", type=int, nargs=3, default=list(d.first_cycle_gens),
                    help="generations for stand / footfalls / distance, first cycle")
    ap.add_argument("--later-gens", type=int, nargs=3, default=list(d.later_cycle_gens))
    a = ap.parse_args()

    s = Settings(morphology=a.morphology, cycles=a.cycles, wide_population=a.wide,
                 narrow_population=a.narrow, trials=a.trials, sigma=a.sigma,
                 interneurons=a.interneurons, pool_size=a.pool_size, seed=a.seed,
                 first_cycle_gens=tuple(a.first_gens),
                 later_cycle_gens=tuple(a.later_gens))
    t = Trainer(s)
    print(f"{s.morphology} | {t.wiring.describe()}")
    print(f"{s.cycles} cycles, ~{s.total_gens()} generations, population "
          f"{s.wide_population} then {s.narrow_population}\n")
    t.run()

    path = t.save(Path(a.out))
    print(f"\nwrote {path}")
    champs = t.pools.champions()
    if champs:
        c = champs[0]
        print(f"best champion: {c.speed:.2f} m/s, footfall {c.footfall:.2f}, "
              f"found in cycle {c.cycle} at generation {c.gen}")
    for p in t.pools.report()["pools"]:
        fossils = sum(m["fossil"] for m in p["members"])
        print(f"  {p['kind']:<8} diversity {p['diversity']:.3f} "
              f"{'COLLAPSED' if p['collapsed'] else '         '} "
              f"{p['admits']:>4} admissions, {fossils} fossils")
    print(f"  diversity relaxations: {t.pools.relaxations}")


if __name__ == "__main__":
    main()
