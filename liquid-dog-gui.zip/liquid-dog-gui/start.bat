@echo off
REM ---- The one button. Double-click this file, or type: start
cd /d "%~dp0"
title Liquid dog

where python >nul 2>nul
if errorlevel 1 (
  echo.
  echo   Python was not found on your PATH.
  echo   Install Python 3.10 or newer from python.org, tick "Add python.exe to PATH",
  echo   then double-click this file again.
  echo.
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo   First run: building a private environment in .venv ...
  python -m venv .venv || goto fail
)

set PY=.venv\Scripts\python.exe
"%PY%" -c "import flask, numpy" >nul 2>nul
if errorlevel 1 (
  echo   Installing numpy and flask ...
  "%PY%" -m pip install --quiet --upgrade pip
  "%PY%" -m pip install --quiet -r requirements.txt || goto fail
)

echo.
echo   Starting. Your browser will open in a moment.
echo   Leave this window open while it trains. Close it to quit.
echo.
set PYTHONIOENCODING=utf-8
"%PY%" app.py
exit /b 0

:fail
echo.
echo   Setup failed. The messages above say why.
pause
exit /b 1
