#!/usr/bin/env bash
# ---- The one button, for macOS and Linux:  ./start.sh
set -e
cd "$(dirname "$0")"
if [ ! -x ".venv/bin/python" ]; then
  echo "  First run: building a private environment in .venv ..."
  python3 -m venv .venv
fi
PY=.venv/bin/python
if ! $PY -c "import flask, numpy" 2>/dev/null; then
  echo "  Installing numpy and flask ..."
  $PY -m pip install --quiet --upgrade pip
  $PY -m pip install --quiet -r requirements.txt
fi
echo
echo "  Starting. Your browser will open in a moment."
echo "  Leave this window open while it trains. Ctrl-C to quit."
echo
PYTHONIOENCODING=utf-8 exec $PY app.py
