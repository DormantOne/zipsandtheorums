const NS = 'http://www.w3.org/2000/svg';
const $ = id => document.getElementById(id);
const el = (n, a) => { const e = document.createElementNS(NS, n);
  for (const k in a) e.setAttribute(k, a[k]); return e; };

let poll = null, replay = null, frame = 0, playing = false, lastT = 0, acc = 0;

// ── settings ────────────────────────────────────────────────────────────────
function readSettings() {
  const out = {};
  document.querySelectorAll('#settings [name]').forEach(f => {
    const v = f.value.trim();
    if (f.name.endsWith('_gens')) {
      const nums = v.split(/[,\s]+/).filter(Boolean).map(Number);
      if (nums.length === 3 && nums.every(n => Number.isFinite(n) && n >= 0)) out[f.name] = nums;
    } else if (f.type === 'number') {
      if (v !== '' && Number.isFinite(+v)) out[f.name] = +v;
    } else {
      out[f.name] = v;
    }
  });
  return out;
}

$('go').addEventListener('click', async () => {
  $('go').disabled = true;
  $('s-hint').textContent = 'Starting up — the first generation takes a moment.';
  const r = await fetch('/api/start', {
    method: 'POST', headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(readSettings())
  }).then(r => r.json()).catch(() => ({ok: false, why: 'could not reach the server'}));
  if (!r.ok) { $('s-hint').textContent = 'Did not start: ' + (r.why || 'unknown'); $('go').disabled = false; return; }
  $('halt').disabled = false;
  if (!poll) poll = setInterval(tick, 1200);
  tick();
});

$('halt').addEventListener('click', async () => {
  $('halt').disabled = true;
  await fetch('/api/stop', {method: 'POST'});
  $('s-hint').textContent = 'Stopping after the current generation. Champions are kept.';
});

$('copy').addEventListener('click', async () => {
  const r = await fetch('/api/report').then(r => r.json());
  const text = r.text || 'Nothing to report yet.';
  let ok = false;
  try { await navigator.clipboard.writeText(text); ok = true; } catch (e) { ok = false; }
  if (!ok) {                                   // clipboard blocked: fall back
    const ta = document.createElement('textarea');
    ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select();
    try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
    ta.remove();
  }
  const b = $('copy');
  b.textContent = ok ? 'Copied — paste it to Claude' : 'Copy failed, see console';
  if (!ok) console.log(text);
  b.classList.toggle('copied', ok);
  setTimeout(() => { b.textContent = 'Copy report'; b.classList.remove('copied'); }, 2600);
});

// ── status polling ──────────────────────────────────────────────────────────
async function tick() {
  const st = await fetch('/api/status').then(r => r.json()).catch(() => null);
  if (!st || st.idle) return;
  $('s-cycle').textContent = st.cycle + ' / ' + st.cycles;
  $('s-gate').textContent = st.gate;
  $('s-gen').textContent = st.generation;
  $('s-pop').textContent = st.population;
  $('s-speed').textContent = st.best_speed.toFixed(2) + ' m/s';
  $('s-min').textContent = st.minutes.toFixed(1) + ' min';
  const frac = Math.min(1, st.generation / Math.max(1, st.total_gens));
  $('s-prog').style.width = (frac * 100).toFixed(1) + '%';

  let hint = st.gate_blurb + ' — generation ' + st.gate_gen + ' of up to ' + st.gate_budget +
             ' on this gate. ' + st.wiring + '.';
  if (st.error) hint = 'Error: ' + st.error;
  else if (st.done) hint = 'Finished all cycles. Load a champion below, or copy the report.';
  else if (!st.running) hint = 'Stopped at generation ' + st.generation + '. Champions are kept.';
  $('s-hint').textContent = hint;
  $('go').disabled = st.running;
  $('halt').disabled = !st.running;
  if (!st.running && poll) { clearInterval(poll); poll = null; }

  drawChart(st.history);
  drawPools(st.pools);
  fillRanks(st.pools);
}

// ── progress chart ──────────────────────────────────────────────────────────
function drawChart(h) {
  const svg = $('chart'); svg.replaceChildren();
  if (!h || h.length < 2) return;
  const W = 900, H = 260, L = 44, R = 12, T = 12, Bm = 28;
  const x = i => L + (W - L - R) * i / (h.length - 1);
  const maxSpeed = Math.max(0.4, ...h.map(t => t.speed));
  const ys = v => H - Bm - (H - Bm - T) * Math.min(1, v / maxSpeed);
  const y01 = v => H - Bm - (H - Bm - T) * Math.min(1, Math.max(0, v));

  for (let i = 1; i < h.length; i++)           // gate changes
    if (h[i].gate !== h[i - 1].gate)
      svg.appendChild(el('line', {x1: x(i), y1: T, x2: x(i), y2: H - Bm,
        stroke: 'var(--rule)', 'stroke-width': 1}));

  const line = (pts, stroke, width) => {
    let d = '';
    pts.forEach((p, i) => { d += (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1); });
    svg.appendChild(el('path', {d, fill: 'none', stroke, 'stroke-width': width}));
  };
  svg.appendChild(el('line', {x1: L, y1: H - Bm, x2: W - R, y2: H - Bm,
    stroke: 'var(--ink)', 'stroke-width': 1}));
  line(h.map((t, i) => [x(i), y01(t.diversity)]), 'var(--ok)', 1.4);
  line(h.map((t, i) => [x(i), y01(t.footfall)]), 'var(--strike)', 1.6);
  line(h.map((t, i) => [x(i), ys(t.speed)]), 'var(--trace)', 2.2);

  const txt = (s, xx, yy, anchor) => {
    const t = el('text', {x: xx, y: yy, fill: 'var(--soft)', 'font-size': 12,
      'text-anchor': anchor || 'start'});
    t.textContent = s; svg.appendChild(t);
  };
  txt(maxSpeed.toFixed(2), L - 6, T + 10, 'end');
  txt('0', L - 6, H - Bm + 4, 'end');
  txt('gen ' + h[0].gen, L, H - 8);
  txt('gen ' + h[h.length - 1].gen, W - R, H - 8, 'end');
}

// ── pools ───────────────────────────────────────────────────────────────────
function drawPools(p) {
  if (!p) return;
  const wrap = $('pools'); wrap.replaceChildren();
  p.pools.forEach(pool => {
    const card = document.createElement('div');
    card.className = 'pool' + (pool.collapsed ? ' collapsed' : '');
    const frac = Math.min(1, pool.diversity / Math.max(pool.target * 2, 1e-6));
    const markAt = (pool.target / Math.max(pool.target * 2, 1e-6)) * 100;
    card.innerHTML =
      '<h3>' + pool.kind + '</h3>' +
      '<p class="blurb">' + pool.blurb + '</p>' +
      '<div class="meter"><i style="width:' + (frac * 100).toFixed(1) + '%"></i>' +
        '<u style="left:' + markAt.toFixed(1) + '%"></u></div>' +
      '<div class="div">diversity ' + pool.diversity.toFixed(3) +
        ' (target ' + pool.target + ')' +
        (pool.collapsed ? ' — collapsed, standards dropping' : '') +
        ' · bar ' + (pool.bar >= 0 ? '+' : '') + pool.bar.toFixed(2) +
        (pool.bar_drops ? ' lowered ' + pool.bar_drops + '×' : '') +
        ' · ' + pool.admits + ' admissions</div>';
    const ul = document.createElement('ul');
    pool.members.forEach(m => {
      const li = document.createElement('li');
      li.innerHTML = '<b>' + m.speed.toFixed(2) + ' m/s</b>' +
        '<span>foot ' + m.footfall.toFixed(2) + '</span>' +
        (m.fossil ? '<span class="fossil">FOSSIL</span>' : '') +
        '<span class="desc">c' + m.cycle + ' g' + m.gen + '</span>';
      li.title = window.DESCRIPTOR_NAMES.map((n, i) => n + ' ' + m.descriptor[i]).join(', ');
      ul.appendChild(li);
    });
    card.appendChild(ul);
    wrap.appendChild(card);
  });
  const ev = p.events && p.events.length ? p.events[0] : '—';
  $('relax').textContent = 'Diversity relaxations: ' + p.relaxations + '. Latest: ' + ev;
}

function fillRanks(p) {
  if (!p) return;
  const n = p.pools.reduce((a, x) => a + x.members.length, 0);
  const sel = $('rank');
  const want = Math.max(1, Math.min(8, n));
  if (sel.options.length === want) return;
  sel.replaceChildren();
  for (let i = 1; i <= want; i++) {
    const o = document.createElement('option');
    o.value = i; o.textContent = 'champion ' + i;
    sel.appendChild(o);
  }
}

// ── champion replay ─────────────────────────────────────────────────────────
$('load').addEventListener('click', async () => {
  $('load').disabled = true;
  $('readout').textContent = 'Running a fresh rollout…';
  const r = await fetch('/api/replay?rank=' + $('rank').value + '&seed=' + $('poseseed').value)
    .then(r => r.json()).catch(() => ({ok: false, why: 'request failed'}));
  $('load').disabled = false;
  if (!r.ok) { $('readout').textContent = r.why || 'no champion yet'; return; }
  replay = r; frame = 0; playing = true; $('play').disabled = false;
  $('play').textContent = 'Pause';
  const m = r.metrics;
  $('readout').innerHTML =
    '<span>speed <b>' + m.speed.toFixed(2) + '</b> m/s</span>' +
    '<span>distance <b>' + m.distance.toFixed(2) + '</b> m</span>' +
    '<span>footfall score <b>' + m.footfall.toFixed(2) + '</b></span>' +
    '<span>cadence <b>' + m.step_rate.toFixed(2) + '</b> /s per foot</span>' +
    '<span>worst landing <b>' + m.impact.toFixed(2) + '</b> m/s</span>' +
    '<span>upright <b>' + m.upright + '%</b> of the episode</span>';
  drawGait();
  draw(0);
});

$('play').addEventListener('click', e => {
  playing = !playing;
  e.target.textContent = playing ? 'Pause' : 'Play';
});

function draw(k) {
  if (!replay) return;
  const svg = $('stage'); svg.replaceChildren();
  const p = replay.frames[k], SC = 210, GY = 232, CAM = 1.8;
  const cam = p[0][0] - CAM;
  const X = v => (v - cam) * SC + 50, Y = v => GY - v * SC;

  const g = el('g', {stroke: 'var(--near)', 'stroke-width': 1});
  g.appendChild(el('line', {x1: 0, y1: GY, x2: 900, y2: GY, 'stroke-width': 1.5}));
  for (let m = Math.floor(cam * 4) / 4 - 0.5; m < cam + 4.6; m += 0.25) {
    const big = Math.abs(m % 1) < 1e-6;
    g.appendChild(el('line', {x1: X(m), y1: GY, x2: X(m), y2: GY + (big ? 14 : 7)}));
  }
  svg.appendChild(g);

  let d = '';
  for (let j = Math.max(0, k - 90); j <= k; j++)
    d += (d ? 'L' : 'M') + X(replay.frames[j][0][0]).toFixed(1) + ' ' +
         Y(replay.frames[j][0][1]).toFixed(1);
  svg.appendChild(el('path', {d, fill: 'none', stroke: 'var(--near)',
    'stroke-width': 1, 'stroke-dasharray': '1 3'}));

  replay.bones.forEach(b => {
    svg.appendChild(el('line', {x1: X(p[b[0]][0]), y1: Y(p[b[0]][1]),
      x2: X(p[b[1]][0]), y2: Y(p[b[1]][1]),
      stroke: b[2] ? 'var(--trace)' : 'var(--near)',
      'stroke-width': b[2] ? 4.5 : 3, 'stroke-linecap': 'round'}));
  });
  replay.feet.forEach((f, n) => {
    const down = replay.contacts[k][n];
    svg.appendChild(el('circle', {cx: X(p[f][0]), cy: Y(p[f][1]),
      r: down ? 6 : 4.5, fill: down ? 'var(--strike)' : 'var(--card)',
      stroke: 'var(--trace)', 'stroke-width': 2}));
  });
  svg.appendChild(el('circle', {cx: X(p[2][0]), cy: Y(p[2][1]), r: 9,
    fill: 'var(--trace)'}));

  const head = $('playhead');
  if (head) {
    const xx = 96 + 780 * k / replay.contacts.length;
    head.setAttribute('x1', xx); head.setAttribute('x2', xx);
  }
}

function drawGait() {
  const svg = $('gait'); svg.replaceChildren();
  if (!replay) return;
  const C = replay.contacts, n = C.length, W = 780, L = 96, H = 24, GAP = 9;
  replay.leg_names.forEach((name, r) => {
    const y = 8 + r * (H + GAP);
    const t = el('text', {x: 0, y: y + 16, fill: 'var(--soft)', 'font-size': 13});
    t.textContent = name; svg.appendChild(t);
    svg.appendChild(el('rect', {x: L, y, width: W, height: H, fill: 'none',
      stroke: 'var(--rule)'}));
    let run = -1;
    for (let k = 0; k <= n; k++) {
      const on = k < n && C[k][r];
      if (on && run < 0) run = k;
      if (!on && run >= 0) {
        svg.appendChild(el('rect', {x: L + W * run / n, y: y + 2,
          width: Math.max(1.2, W * (k - run) / n), height: H - 4,
          fill: 'var(--strike)'}));
        run = -1;
      }
    }
  });
  const y2 = 8 + replay.leg_names.length * (H + GAP);
  const secs = Math.round(n * replay.dt);
  svg.appendChild(el('line', {x1: L, y1: y2, x2: L + W, y2: y2, stroke: 'var(--rule)'}));
  for (let s = 0; s <= secs; s++) {
    const xx = L + W * s / secs;
    svg.appendChild(el('line', {x1: xx, y1: y2, x2: xx, y2: y2 + 6, stroke: 'var(--rule)'}));
    const t = el('text', {x: xx, y: y2 + 20, fill: 'var(--soft)', 'font-size': 12,
      'text-anchor': 'middle'});
    t.textContent = s === secs ? s + ' s' : s; svg.appendChild(t);
  }
  svg.appendChild(el('line', {id: 'playhead', x1: L, y1: 2, x2: L, y2: y2,
    stroke: 'var(--ink)', 'stroke-width': 1.5}));
  svg.setAttribute('viewBox', '0 0 900 ' + (y2 + 30));
}

function loop(now) {
  if (replay && playing) {
    acc += now - lastT;
    const ms = replay.dt * 1000;
    while (acc > ms) { acc -= ms; frame = (frame + 1) % replay.frames.length; draw(frame); }
  } else { acc = 0; }
  lastT = now;
  requestAnimationFrame(loop);
}
requestAnimationFrame(now => { lastT = now; loop(now); });

// ── audit ───────────────────────────────────────────────────────────────────
$('auditbtn').addEventListener('click', async () => {
  const btn = $('auditbtn'); btn.disabled = true; btn.textContent = 'Auditing…';
  const r = await fetch('/api/audit?seeds=12').then(r => r.json())
    .catch(() => ({ok: false, why: 'request failed'}));
  btn.disabled = false; btn.textContent = 'Audit all champions';
  const box = $('audit'); box.replaceChildren();
  if (!r.ok) { box.textContent = r.why || 'nothing to audit'; return; }
  const h2 = document.createElement('p');
  h2.className = 'chart-title';
  h2.textContent = 'Each champion from ' + r.seeds +
    ' fresh starting poses. "Works" is how often the gait starts at all (over ' +
    r.bar + ' m/s).';
  box.appendChild(h2);
  const tb = document.createElement('table');
  tb.innerHTML = '<thead><tr><th>champion</th><th>works</th><th>median</th>' +
    '<th>best</th><th>worst</th><th>upright</th><th>per pose</th></tr></thead>';
  const body = document.createElement('tbody');
  r.rows.forEach((row, i) => {
    const spark = row.per_seed.map(v => v > r.bar ? '\u2588' : (v > r.bar / 2 ? '\u2592' : '\u00b7')).join('');
    const tr = document.createElement('tr');
    tr.innerHTML = '<td>' + (i + 1) + (row.fossil ? ' (fossil)' : '') + '</td>' +
      '<td>' + Math.round(row.works * 100) + '%</td>' +
      '<td>' + row.median.toFixed(2) + '</td><td>' + row.best.toFixed(2) + '</td>' +
      '<td>' + row.worst.toFixed(2) + '</td><td>' + row.upright + '%</td>' +
      '<td class="spark">' + spark + '</td>';
    body.appendChild(tr);
  });
  tb.appendChild(body); box.appendChild(tb);
});

tick();
