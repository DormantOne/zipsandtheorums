import { useState, useEffect, useRef, useCallback } from 'react';
import { EvolutionEngine } from './engine/evolutionEngine';
import { AudioSynthEngine } from './engine/audioSynth';
import { DEFAULT_THEORY_CONFIG } from './engine/musicTheory';
import { CandidateSnippet, EvolutionConfig, NoteEvent, SynthInstrument, TheoryConfig } from './types/music';
import { Header } from './components/Header';
import { ContinuousPlayer } from './components/ContinuousPlayer';
import { PianoRoll } from './components/PianoRoll';
import { CandidateList } from './components/CandidateList';
import { FitnessChart } from './components/FitnessChart';
import { TheorySettings } from './components/TheorySettings';
import { GruInspector } from './components/GruInspector';

export function App() {
  // Engine references
  const audioSynthRef = useRef<AudioSynthEngine | null>(null);
  const evoEngineRef = useRef<EvolutionEngine | null>(null);

  // App UI State
  const [activeTab, setActiveTab] = useState<'stage' | 'tournament' | 'settings' | 'inspector'>('stage');
  const [isQuietMode, setIsQuietMode] = useState<boolean>(true);
  const [generation, setGeneration] = useState<number>(0);
  const [bestFitness, setBestFitness] = useState<number>(0);
  const [bpm, setBpm] = useState<number>(112);
  const [instrument, setInstrument] = useState<SynthInstrument>('rhodes');
  const [volume, setVolume] = useState<number>(0.6);
  const [isMuted, setIsMuted] = useState<boolean>(false);

  // Active Snippets & Candidates
  const [selectedSnippet, setSelectedSnippet] = useState<CandidateSnippet | null>(null);
  const [championSnippet, setChampionSnippet] = useState<CandidateSnippet | null>(null);
  const [candidates, setCandidates] = useState<CandidateSnippet[]>([]);
  const [hallOfFame, setHallOfFame] = useState<CandidateSnippet[]>([]);
  const [history, setHistory] = useState(evoEngineRef.current?.history || []);

  // Audition playback state
  const [auditioningSnippetId, setAuditioningSnippetId] = useState<string | null>(null);
  const [auditionPlayheadStep, setAuditionPlayheadStep] = useState<number>(-1);

  // Continuous champion stream state
  const [isContinuousPlaying, setIsContinuousPlaying] = useState<boolean>(false);
  const [continuousNotes, setContinuousNotes] = useState<NoteEvent[]>([]);
  const [currentContinuousNote, setCurrentContinuousNote] = useState<NoteEvent | null>(null);
  const [currentChord, setCurrentChord] = useState<string>('');
  const [continuousTemperature, setContinuousTemperature] = useState<number>(0.92);

  // Theory & Evolution Configs
  const [theoryConfig, setTheoryConfig] = useState<TheoryConfig>(DEFAULT_THEORY_CONFIG);
  const [evoConfig, setEvoConfig] = useState<EvolutionConfig>({
    populationSize: 16,
    snippetLengthSteps: 32,
    mutationRate: 0.12,
    mutationStrength: 0.2,
    temperature: 0.95,
    crossoverRate: 0.4,
    eliteCount: 3,
    complexityTarget: 'complex',
    survivalThreshold: 68,
  });

  // Initialize Engines on mount
  useEffect(() => {
    const synth = new AudioSynthEngine();
    synth.setVolume(0.6);
    audioSynthRef.current = synth;

    const evo = new EvolutionEngine(DEFAULT_THEORY_CONFIG, evoConfig);
    evoEngineRef.current = evo;

    // Callbacks from continuous streaming
    synth.onContinuousEvent = (note, _step, chord) => {
      setCurrentContinuousNote(note);
      if (chord) setCurrentChord(chord);
      setContinuousNotes(prev => [...prev.slice(-32), note]);
    };

    // Update state from initial generation
    syncEngineState();

    // Start in quiet mode initially so the recurrent model evolves rapidly
    evo.startQuietMode(6);

    return () => {
      synth.stopContinuous();
      synth.stopAudition();
      evo.stopQuietMode();
    };
  }, []);

  // Sync React state with Evolution Engine
  const syncEngineState = useCallback(() => {
    const evo = evoEngineRef.current;
    if (!evo) return;

    setGeneration(evo.generation);
    const champ = evo.championSnippet;
    setChampionSnippet(champ);
    if (champ) {
      setBestFitness(champ.fitness);
      if (!selectedSnippet) {
        setSelectedSnippet(champ);
      }
    }

    const currentCandidates = evo.population
      .map(p => p.currentSnippet)
      .filter((s): s is CandidateSnippet => s !== null);

    setCandidates([...currentCandidates]);
    setHallOfFame([...evo.hallOfFame]);
    setHistory([...evo.history]);
  }, [selectedSnippet]);

  // Periodic state refresh if quiet mode is evolving in background
  useEffect(() => {
    if (!isQuietMode) return;
    const interval = setInterval(() => {
      syncEngineState();
    }, 250);
    return () => clearInterval(interval);
  }, [isQuietMode, syncEngineState]);

  // Handle Quiet Mode Toggle
  const handleToggleQuietMode = () => {
    const evo = evoEngineRef.current;
    if (!evo) return;

    if (isQuietMode) {
      evo.stopQuietMode();
      setIsQuietMode(false);
    } else {
      evo.startQuietMode(7);
      setIsQuietMode(true);
    }
  };

  // Turbo Evolve N generations silently
  const handleTurboEvolve = (gens: number) => {
    const evo = evoEngineRef.current;
    if (!evo) return;
    evo.turboEvolve(gens);
    syncEngineState();
  };

  // Synth Controls
  const handleBpmChange = (newBpm: number) => {
    setBpm(newBpm);
    if (audioSynthRef.current) {
      audioSynthRef.current.continuousBpm = newBpm;
    }
  };

  const handleInstrumentChange = (inst: SynthInstrument) => {
    setInstrument(inst);
    if (audioSynthRef.current) {
      audioSynthRef.current.setInstrument(inst);
    }
  };

  const handleVolumeChange = (vol: number) => {
    setVolume(vol);
    if (audioSynthRef.current) {
      audioSynthRef.current.setVolume(vol);
    }
  };

  const handleToggleMute = () => {
    const newMuted = !isMuted;
    setIsMuted(newMuted);
    if (audioSynthRef.current) {
      audioSynthRef.current.setMuted(newMuted);
    }
  };

  // Audition Snippet
  const handleAuditionSnippet = (snippet: CandidateSnippet) => {
    const synth = audioSynthRef.current;
    if (!synth) return;

    // Stop continuous stream if playing
    if (isContinuousPlaying) {
      synth.stopContinuous();
      setIsContinuousPlaying(false);
    }

    setSelectedSnippet(snippet);
    setAuditioningSnippetId(snippet.id);
    setAuditionPlayheadStep(0);

    synth.playSnippet(
      snippet.id,
      snippet.notes,
      bpm,
      step => {
        setAuditionPlayheadStep(step);
      },
      () => {
        setAuditioningSnippetId(null);
        setAuditionPlayheadStep(-1);
      }
    );
  };

  const handleStopAudition = () => {
    const synth = audioSynthRef.current;
    if (!synth) return;
    synth.stopAudition();
    setAuditioningSnippetId(null);
    setAuditionPlayheadStep(-1);
  };

  // Single Note Click Preview
  const handleNoteClick = (pitch: number) => {
    const synth = audioSynthRef.current;
    if (!synth) return;
    synth.triggerNote(pitch, 0.4, 0.85);
  };

  // Continuous Champion Stream
  const handleToggleContinuous = () => {
    const synth = audioSynthRef.current;
    const evo = evoEngineRef.current;
    if (!synth || !evo) return;

    if (isContinuousPlaying) {
      synth.stopContinuous();
      setIsContinuousPlaying(false);
      setCurrentContinuousNote(null);
    } else {
      // Stop snippet audition if active
      handleStopAudition();
      setIsContinuousPlaying(true);
      setContinuousNotes([]);

      synth.startContinuous(
        evo.championModel,
        bpm,
        theoryConfig,
        continuousTemperature
      );
    }
  };

  // Generate Long Snippet from Champion Model
  const handleGenerateLongSnippet = (bars: number) => {
    const evo = evoEngineRef.current;
    if (!evo) return;

    const steps = bars * 16;
    const longSnippet = evo.generateLongChampionSnippet(steps);
    setSelectedSnippet(longSnippet);
    setActiveTab('stage');
    // Start auditioning immediately
    handleAuditionSnippet(longSnippet);
  };

  // Crown snippet as champion override
  const handleCrownChampion = (snippet: CandidateSnippet) => {
    const evo = evoEngineRef.current;
    if (!evo) return;
    evo.crownAsChampion(snippet);
    syncEngineState();
  };

  // Update Theory Configuration
  const handleUpdateTheoryConfig = (newTheory: TheoryConfig) => {
    setTheoryConfig(newTheory);
    const evo = evoEngineRef.current;
    if (!evo) return;
    evo.theoryConfig = newTheory;
    evo.evaluateGeneration();
    syncEngineState();
  };

  // Update Evolution Configuration
  const handleUpdateEvoConfig = (newEvo: EvolutionConfig) => {
    setEvoConfig(newEvo);
    const evo = evoEngineRef.current;
    if (!evo) return;
    evo.evoConfig = newEvo;
  };

  // Reset Evolutionary Lineage
  const handleResetEvolution = () => {
    const evo = evoEngineRef.current;
    if (!evo) return;
    evo.initPopulation();
    syncEngineState();
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-slate-950">
      {/* Top Header */}
      <Header
        generation={generation}
        bestFitness={bestFitness}
        isQuietMode={isQuietMode}
        onToggleQuietMode={handleToggleQuietMode}
        onTurboEvolve={handleTurboEvolve}
        bpm={bpm}
        onBpmChange={handleBpmChange}
        instrument={instrument}
        onInstrumentChange={handleInstrumentChange}
        volume={volume}
        onVolumeChange={handleVolumeChange}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
        activeTab={activeTab}
        onTabChange={setActiveTab}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 flex flex-col gap-6">
        {/* Fitness Evolution Chart with Pass Threshold and Melodic Complexity */}
        <FitnessChart history={history} survivalThreshold={evoConfig.survivalThreshold} />

        {/* TAB 1: Champion Stage & Continuous Music Player */}
        {activeTab === 'stage' && (
          <div className="flex flex-col gap-6">
            {/* Continuous Player */}
            {evoEngineRef.current && (
              <ContinuousPlayer
                championModel={evoEngineRef.current.championModel}
                isContinuousPlaying={isContinuousPlaying}
                onToggleContinuous={handleToggleContinuous}
                recentNotes={continuousNotes}
                currentNote={currentContinuousNote}
                currentChord={currentChord}
                theoryConfig={theoryConfig}
                bpm={bpm}
                onGenerateLongSnippet={handleGenerateLongSnippet}
                temperature={continuousTemperature}
                onTemperatureChange={setContinuousTemperature}
              />
            )}

            {/* Piano Roll of Champion or Selected Snippet */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-sm font-semibold text-slate-300">
                  {selectedSnippet?.id === championSnippet?.id
                    ? 'Champion Model Snippet Studio'
                    : 'Selected Candidate Snippet Studio'}
                </h3>
                {selectedSnippet && (
                  <span className="text-xs font-mono text-slate-400">
                    ID: {selectedSnippet.id}
                  </span>
                )}
              </div>
              <PianoRoll
                snippet={selectedSnippet || championSnippet}
                theoryConfig={theoryConfig}
                isPlaying={auditioningSnippetId !== null}
                currentPlayheadStep={auditionPlayheadStep}
                bpm={bpm}
                onPlay={handleAuditionSnippet}
                onStop={handleStopAudition}
                onNoteClick={handleNoteClick}
                onPromoteChampion={handleCrownChampion}
                isChampionSnippet={selectedSnippet?.id === championSnippet?.id}
              />
            </div>
          </div>
        )}

        {/* TAB 2: Candidate Tournament & Lineage */}
        {activeTab === 'tournament' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-6 flex flex-col gap-4">
              <CandidateList
                candidates={candidates}
                hallOfFame={hallOfFame}
                championSnippet={championSnippet}
                activeAuditionId={auditioningSnippetId}
                bpm={bpm}
                onAudition={handleAuditionSnippet}
                onStopAudition={handleStopAudition}
                onSelectSnippetForView={s => setSelectedSnippet(s)}
                onCrownChampion={handleCrownChampion}
              />
            </div>

            <div className="lg:col-span-6 flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold text-slate-300">
                  Inspected Candidate Piano Roll &amp; Adjudicator Breakdown
                </h3>
                {selectedSnippet && (
                  <span className="text-xs font-mono text-emerald-400">
                    Score: {selectedSnippet.fitness}% ({selectedSnippet.passed ? 'PASSED' : 'FAILED'})
                  </span>
                )}
              </div>
              <PianoRoll
                snippet={selectedSnippet || championSnippet}
                theoryConfig={theoryConfig}
                isPlaying={auditioningSnippetId !== null}
                currentPlayheadStep={auditionPlayheadStep}
                bpm={bpm}
                onPlay={handleAuditionSnippet}
                onStop={handleStopAudition}
                onNoteClick={handleNoteClick}
                onPromoteChampion={handleCrownChampion}
                isChampionSnippet={selectedSnippet?.id === championSnippet?.id}
              />
            </div>
          </div>
        )}

        {/* TAB 3: Theory Rules & Scale Configuration */}
        {activeTab === 'settings' && (
          <TheorySettings
            theoryConfig={theoryConfig}
            evoConfig={evoConfig}
            onUpdateTheoryConfig={handleUpdateTheoryConfig}
            onUpdateEvoConfig={handleUpdateEvoConfig}
            onResetEvolution={handleResetEvolution}
          />
        )}

        {/* TAB 4: Recurrent GRU Neural Brain Inspector */}
        {activeTab === 'inspector' && evoEngineRef.current && (
          <GruInspector
            championModel={evoEngineRef.current.championModel}
            onAuditionSnippet={notes => {
              if (selectedSnippet) {
                const tempSnippet: CandidateSnippet = {
                  ...selectedSnippet,
                  id: `prompt_continuation_${Date.now()}`,
                  notes,
                  lengthSteps: 32,
                };
                handleAuditionSnippet(tempSnippet);
              }
            }}
            onStopAudition={handleStopAudition}
            isPlaying={auditioningSnippetId !== null}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-4 px-6 text-center text-xs text-slate-500">
        <p>
          EvoHarmonics &bull; Neural Recurrent Gated Unit (GRU) Continuous Composition &bull;
          Sophisticated Music Theory Adjudicator of Fitness
        </p>
      </footer>
    </div>
  );
}

export default App;
