import React, { useState } from 'react';
import { CandidateSnippet } from '../types/music';
import { Play, Square, Award, Download, Trophy, Users, Check, ShieldCheck, XCircle, Sparkles } from 'lucide-react';
import { midiToNoteName } from '../engine/musicTheory';
import { downloadMidiFile } from '../utils/midiExport';

interface CandidateListProps {
  candidates: CandidateSnippet[];
  hallOfFame: CandidateSnippet[];
  championSnippet: CandidateSnippet | null;
  activeAuditionId: string | null;
  bpm: number;
  onAudition: (snippet: CandidateSnippet) => void;
  onStopAudition: () => void;
  onSelectSnippetForView: (snippet: CandidateSnippet) => void;
  onCrownChampion: (snippet: CandidateSnippet) => void;
}

export const CandidateList: React.FC<CandidateListProps> = ({
  candidates,
  hallOfFame,
  championSnippet,
  activeAuditionId,
  bpm,
  onAudition,
  onStopAudition,
  onSelectSnippetForView,
  onCrownChampion,
}) => {
  const [tab, setTab] = useState<'current' | 'hallOfFame' | 'passedOnly'>('current');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const displayList =
    tab === 'current'
      ? candidates
      : tab === 'passedOnly'
      ? candidates.filter(c => c.passed)
      : hallOfFame;

  const handleCopySummary = (s: CandidateSnippet) => {
    const summary = `EvoHarmonics Snippet (Gen ${s.generation}, Score: ${s.fitness}%, ${
      s.passed ? 'PASSED' : 'FAILED'
    })\nNotes: ${s.notes
      .filter(n => n.pitch > 0)
      .map(n => midiToNoteName(n.pitch))
      .join(', ')}`;
    navigator.clipboard.writeText(summary);
    setCopiedId(s.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col shadow-xl backdrop-blur">
      {/* Tab Switcher & Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800 gap-2 flex-wrap">
        <div className="flex items-center gap-1.5 flex-wrap">
          <button
            onClick={() => setTab('current')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              tab === 'current'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            Active Population ({candidates.length})
          </button>

          <button
            onClick={() => setTab('passedOnly')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              tab === 'passedOnly'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            Adjudicator Passed ({candidates.filter(c => c.passed).length})
          </button>

          <button
            onClick={() => setTab('hallOfFame')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              tab === 'hallOfFame'
                ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40 shadow'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Trophy className="w-3.5 h-3.5 text-amber-400" />
            Hall of Fame ({hallOfFame.length})
          </button>
        </div>

        <span className="text-[11px] text-slate-400 font-mono">
          Adjudicator strictly filters survivors
        </span>
      </div>

      {/* Candidate Cards List */}
      <div className="flex flex-col gap-2.5 mt-3 max-h-[520px] overflow-y-auto pr-1">
        {displayList.length === 0 ? (
          <div className="text-center py-8 text-xs text-slate-500">
            {tab === 'passedOnly'
              ? 'No candidates have passed the music theory adjudicator in this generation yet. Quiet evolve for more generations!'
              : 'No snippets in this category yet.'}
          </div>
        ) : (
          displayList.map((snippet, idx) => {
            const isPlaying = activeAuditionId === snippet.id;
            const isChamp = championSnippet?.id === snippet.id;
            const activeNotes = snippet.notes.filter(n => n.pitch > 0);

            return (
              <div
                key={snippet.id}
                className={`p-3 rounded-xl border transition-all ${
                  isChamp
                    ? 'bg-amber-950/20 border-amber-500/50 shadow-lg'
                    : isPlaying
                    ? 'bg-slate-800/90 border-sky-500/60 shadow'
                    : snippet.passed
                    ? 'bg-emerald-950/15 border-emerald-900/40 hover:border-emerald-600/50'
                    : 'bg-slate-950/60 border-slate-800/80 hover:border-slate-700 opacity-75'
                }`}
              >
                <div className="flex items-center justify-between gap-3 flex-wrap">
                  {/* Left info: rank badge, generation, audition play button */}
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => (isPlaying ? onStopAudition() : onAudition(snippet))}
                      className={`w-9 h-9 rounded-lg flex items-center justify-center transition-all ${
                        isPlaying
                          ? 'bg-rose-600 text-white animate-pulse'
                          : 'bg-emerald-500/20 hover:bg-emerald-500 text-emerald-400 hover:text-slate-950 border border-emerald-500/40'
                      }`}
                      title={isPlaying ? 'Stop playback' : 'Audition this candidate'}
                    >
                      {isPlaying ? (
                        <Square className="w-4 h-4 fill-current" />
                      ) : (
                        <Play className="w-4 h-4 fill-current" />
                      )}
                    </button>

                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold font-mono text-slate-200">
                          #{idx + 1}
                        </span>
                        <span className="text-[11px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
                          Gen {snippet.generation}
                        </span>
                        {/* Passed badge */}
                        <span
                          className={`flex items-center gap-1 text-[10px] font-bold px-1.5 py-0.5 rounded border ${
                            snippet.passed
                              ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                              : 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                          }`}
                        >
                          {snippet.passed ? (
                            <>
                              <ShieldCheck className="w-2.5 h-2.5" /> Passed
                            </>
                          ) : (
                            <>
                              <XCircle className="w-2.5 h-2.5" /> Failed
                            </>
                          )}
                        </span>

                        {isChamp && (
                          <span className="flex items-center gap-1 text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40">
                            <Award className="w-2.5 h-2.5" /> Champion
                          </span>
                        )}
                      </div>

                      <div className="text-[11px] text-slate-400 font-mono mt-0.5 flex items-center gap-2">
                        <span>{activeNotes.length} notes</span>
                        <span>&bull;</span>
                        <span className="text-purple-300 flex items-center gap-1">
                          <Sparkles className="w-2.5 h-2.5" /> Complexity: {snippet.complexityScore || 50}/100
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Middle: Mini note preview sequence */}
                  <div className="hidden sm:flex items-center gap-1 max-w-[200px] overflow-hidden text-[10px] font-mono text-slate-400 bg-slate-900/80 px-2 py-1 rounded border border-slate-800">
                    {activeNotes.slice(0, 6).map((n, i) => (
                      <span key={i} className="text-slate-300">
                        {midiToNoteName(n.pitch)}
                      </span>
                    ))}
                    {activeNotes.length > 6 && <span className="text-slate-500">...</span>}
                  </div>

                  {/* Right scores & actions */}
                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <div className="text-sm font-bold font-mono text-emerald-400">
                        {snippet.fitness}%
                      </div>
                      <div className="text-[10px] text-slate-400 flex items-center gap-1.5">
                        <span title="Scale match">S:{snippet.breakdown.scaleFidelity}%</span>
                        <span title="Voice leading">V:{snippet.breakdown.voiceLeading}%</span>
                        <span title="Cadence arrival">C:{snippet.breakdown.cadenceResolution}%</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => onSelectSnippetForView(snippet)}
                        className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-xs transition-colors border border-slate-700"
                        title="Open in Piano Roll view"
                      >
                        Inspect
                      </button>

                      {!isChamp && (
                        <button
                          onClick={() => onCrownChampion(snippet)}
                          className="p-1 text-slate-400 hover:text-amber-400 hover:bg-slate-800 rounded transition-colors"
                          title="Crown as new lineage champion"
                        >
                          <Award className="w-4 h-4" />
                        </button>
                      )}

                      <button
                        onClick={() => downloadMidiFile(snippet.notes, `Candidate_g${snippet.generation}_${snippet.fitness}`, bpm)}
                        className="p-1 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded transition-colors"
                        title="Download MIDI"
                      >
                        <Download className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => handleCopySummary(snippet)}
                        className="p-1 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded transition-colors text-[10px]"
                        title="Copy note sequence"
                      >
                        {copiedId === snippet.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : 'Copy'}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Theory comments snippet pill */}
                {snippet.theoryNotes.length > 0 && (
                  <div className="mt-2 text-[10px] text-slate-400 flex items-center gap-2 border-t border-slate-800/60 pt-1.5">
                    <span className="text-emerald-400/90 font-medium font-sans">Adjudicator:</span>
                    <span className="truncate">{snippet.theoryNotes[0]}</span>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
