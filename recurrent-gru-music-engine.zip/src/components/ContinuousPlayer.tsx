import React, { useState } from 'react';
import { RecurrentGRUModel, HIDDEN_SIZE, NUM_PITCH_TOKENS, MIN_MIDI } from '../engine/gru';
import { midiToNoteName } from '../engine/musicTheory';
import { Play, Square, Activity, Cpu, Sparkles, Sliders, Music2 } from 'lucide-react';
import { NoteEvent, TheoryConfig } from '../types/music';

interface ContinuousPlayerProps {
  championModel: RecurrentGRUModel;
  isContinuousPlaying: boolean;
  onToggleContinuous: () => void;
  recentNotes: NoteEvent[];
  currentNote: NoteEvent | null;
  currentChord: string;
  theoryConfig: TheoryConfig;
  bpm: number;
  onGenerateLongSnippet: (bars: number) => void;
  temperature: number;
  onTemperatureChange: (val: number) => void;
}

export const ContinuousPlayer: React.FC<ContinuousPlayerProps> = ({
  championModel,
  isContinuousPlaying,
  onToggleContinuous,
  recentNotes,
  currentNote,
  currentChord,
  theoryConfig: _theoryConfig,
  bpm: _bpm,
  onGenerateLongSnippet,
  temperature,
  onTemperatureChange,
}) => {
  const [selectedLongBars, setSelectedLongBars] = useState<number>(4);

  // Activations from the champion model
  const hidden = championModel.lastActivations?.hidden || new Array(HIDDEN_SIZE).fill(0);
  const rGate = championModel.lastActivations?.rGate || new Array(HIDDEN_SIZE).fill(0.5);
  const zGate = championModel.lastActivations?.zGate || new Array(HIDDEN_SIZE).fill(0.5);
  const pitchProbs = championModel.lastActivations?.pitchProbs || new Array(NUM_PITCH_TOKENS).fill(0);

  // Top 6 predicted pitches from softmax
  const topPitchIndices = pitchProbs
    .map((prob, idx) => ({ idx, prob }))
    .sort((a, b) => b.prob - a.prob)
    .slice(0, 5);

  return (
    <div className="bg-gradient-to-b from-slate-900 via-slate-900/95 to-slate-950 border border-slate-800 rounded-2xl p-5 shadow-2xl relative overflow-hidden">
      {/* Decorative background glow */}
      <div
        className={`absolute -top-24 -right-24 w-80 h-80 rounded-full blur-3xl pointer-events-none transition-opacity duration-1000 ${
          isContinuousPlaying ? 'opacity-30 bg-emerald-500' : 'opacity-10 bg-indigo-500'
        }`}
      />

      {/* Main Champion Header */}
      <div className="relative z-10 flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800/80">
        <div className="flex items-center gap-3">
          <div
            className={`w-10 h-10 rounded-xl flex items-center justify-center border shadow-inner transition-colors ${
              isContinuousPlaying
                ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300 ring-4 ring-emerald-500/10 animate-pulse'
                : 'bg-slate-800 border-slate-700 text-slate-300'
            }`}
          >
            <Activity className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-bold text-slate-100">
                Champion Model Continuous Music Stream
              </h2>
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Recurrent GRU
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Infinite generation via recurrent hidden memory state feedback loop
            </p>
          </div>
        </div>

        {/* Play/Stop Button */}
        <div className="flex items-center gap-3">
          <button
            onClick={onToggleContinuous}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-sm shadow-xl transition-all transform active:scale-95 ${
              isContinuousPlaying
                ? 'bg-rose-600 hover:bg-rose-500 text-white ring-4 ring-rose-500/20 shadow-rose-900/40'
                : 'bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 ring-4 ring-emerald-500/20 shadow-emerald-950/50'
            }`}
          >
            {isContinuousPlaying ? (
              <>
                <Square className="w-4 h-4 fill-current" /> Stop Stream
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" /> Start Continuous Stream
              </>
            )}
          </button>
        </div>
      </div>

      {/* Live Stream Stage: Active Note & Visual Tape */}
      <div className="relative z-10 grid grid-cols-1 lg:grid-cols-3 gap-5 mt-5">
        {/* Left Column: Live Note Stream & Chord status */}
        <div className="lg:col-span-2 flex flex-col gap-4">
          <div className="bg-slate-950/80 border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between relative overflow-hidden">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <Music2 className="w-4 h-4 text-emerald-400" />
                Live Champion Melody Stream
              </span>
              <div className="flex items-center gap-2">
                {currentChord && (
                  <span className="text-xs font-mono px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                    Harmony: {currentChord}
                  </span>
                )}
                <span
                  className={`text-[11px] font-mono px-2 py-0.5 rounded ${
                    isContinuousPlaying
                      ? 'bg-emerald-500/20 text-emerald-300 animate-pulse'
                      : 'bg-slate-800 text-slate-500'
                  }`}
                >
                  {isContinuousPlaying ? 'STREAMING' : 'STANDBY'}
                </span>
              </div>
            </div>

            {/* Note Waterfall / Tape */}
            <div className="h-28 bg-slate-900/90 rounded-lg p-2.5 border border-slate-800 flex items-center gap-2 overflow-x-auto select-none">
              {recentNotes.length === 0 ? (
                <div className="w-full text-center text-xs text-slate-500 flex flex-col items-center justify-center">
                  <span>Press "Start Continuous Stream" to ignite recurrent live composition.</span>
                </div>
              ) : (
                recentNotes.slice(-16).map((n, i) => {
                  const isCurrent = currentNote && currentNote.time === n.time;
                  const isRest = n.pitch === 0;
                  return (
                    <div
                      key={i}
                      className={`flex-shrink-0 flex flex-col items-center justify-center rounded-lg px-2.5 py-1.5 transition-all duration-150 ${
                        isRest
                          ? 'bg-slate-800/40 border border-slate-800 text-slate-500'
                          : isCurrent
                          ? 'bg-emerald-500 text-slate-950 border border-emerald-300 shadow-lg shadow-emerald-500/30 scale-110 z-10'
                          : 'bg-slate-800/90 border border-slate-700 text-slate-200'
                      }`}
                      style={{
                        minWidth: `${Math.max(42, n.duration * 18)}px`,
                        height: '70px',
                      }}
                    >
                      <span className="text-xs font-bold font-mono">
                        {isRest ? 'Rest' : midiToNoteName(n.pitch)}
                      </span>
                      <span className="text-[10px] opacity-75 font-mono">
                        {n.duration} {n.duration === 1 ? '16th' : 'steps'}
                      </span>
                    </div>
                  );
                })
              )}
            </div>

            {/* Continuous Settings Bar: Temperature & Long Snippet */}
            <div className="mt-4 pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <span className="text-xs text-slate-400 flex items-center gap-1">
                  <Sliders className="w-3.5 h-3.5 text-slate-400" />
                  Entropy (Temp):
                </span>
                <input
                  type="range"
                  min="0.3"
                  max="1.5"
                  step="0.05"
                  value={temperature}
                  onChange={e => onTemperatureChange(parseFloat(e.target.value))}
                  className="w-24 accent-emerald-400 cursor-pointer"
                />
                <span className="text-xs font-mono text-emerald-400 font-bold">
                  {temperature.toFixed(2)}
                </span>
              </div>

              {/* Long snippet generation */}
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-400 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  Long Snippet:
                </span>
                <select
                  value={selectedLongBars}
                  onChange={e => setSelectedLongBars(parseInt(e.target.value, 10))}
                  className="bg-slate-900 border border-slate-700 text-slate-200 rounded px-2 py-1 text-xs font-mono focus:outline-none"
                >
                  <option value={2}>2 Bars (32 steps)</option>
                  <option value={4}>4 Bars (64 steps)</option>
                  <option value={8}>8 Bars (128 steps)</option>
                  <option value={16}>16 Bars (256 steps)</option>
                </select>
                <button
                  onClick={() => onGenerateLongSnippet(selectedLongBars)}
                  className="px-3 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded text-xs transition-colors shadow"
                >
                  Generate & Audition
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: GRU Neural Brain Activations */}
        <div className="bg-slate-950/80 border border-slate-800/80 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <Cpu className="w-4 h-4 text-sky-400" />
                GRU Hidden State ($h_t$) Neurons
              </span>
              <span className="text-[10px] font-mono text-slate-400">
                {HIDDEN_SIZE} recurrent units
              </span>
            </div>

            {/* 32 Hidden Neuron Activation Matrix */}
            <div className="grid grid-cols-8 gap-1.5 p-2 bg-slate-900 rounded-lg border border-slate-800">
              {hidden.map((val, idx) => {
                // val is tanh activation (-1.0 to 1.0)
                const clamped = Math.max(-1, Math.min(1, val));
                const isPos = clamped >= 0;
                const intensity = Math.abs(clamped);

                return (
                  <div
                    key={idx}
                    title={`Neuron #${idx}: ${clamped.toFixed(3)}`}
                    className="h-6 rounded flex items-center justify-center text-[8px] font-mono font-bold transition-all duration-100"
                    style={{
                      backgroundColor: isPos
                        ? `rgba(16, 185, 129, ${0.15 + intensity * 0.85})`
                        : `rgba(56, 189, 248, ${0.15 + intensity * 0.85})`,
                      color: intensity > 0.4 ? '#ffffff' : '#94a3b8',
                      boxShadow:
                        intensity > 0.6
                          ? isPos
                            ? '0 0 6px rgba(16, 185, 129, 0.6)'
                            : '0 0 6px rgba(56, 189, 248, 0.6)'
                          : 'none',
                    }}
                  >
                    {idx}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Gate status averages */}
          <div className="mt-4 pt-3 border-t border-slate-800/80 flex flex-col gap-2">
            <div className="flex items-center justify-between text-[11px] font-mono">
              <span className="text-slate-400">Reset Gate (r_t):</span>
              <span className="text-slate-200">
                {(rGate.reduce((a, b) => a + b, 0) / rGate.length).toFixed(2)}
              </span>
            </div>
            <div className="flex items-center justify-between text-[11px] font-mono">
              <span className="text-slate-400">Update Gate (z_t):</span>
              <span className="text-slate-200">
                {(zGate.reduce((a, b) => a + b, 0) / zGate.length).toFixed(2)}
              </span>
            </div>

            {/* Softmax Next-Note Distribution */}
            <div className="mt-2">
              <span className="text-[10px] text-slate-400 block mb-1">
                Softmax Next-Pitch Probabilities:
              </span>
              <div className="flex items-center gap-1">
                {topPitchIndices.map(({ idx, prob }) => {
                  const pitchName = idx === 0 ? 'Rest' : midiToNoteName(MIN_MIDI + idx - 1);
                  return (
                    <div
                      key={idx}
                      className="flex-1 bg-slate-900 border border-slate-800 rounded p-1 text-center"
                    >
                      <div className="text-[9px] font-mono text-slate-300 truncate">{pitchName}</div>
                      <div className="text-[9px] font-mono text-emerald-400 font-bold">
                        {(prob * 100).toFixed(0)}%
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
