import React, { useRef, useEffect } from 'react';
import { GenerationHistoryPoint } from '../types/music';

interface FitnessChartProps {
  history: GenerationHistoryPoint[];
  survivalThreshold?: number;
}

export const FitnessChart: React.FC<FitnessChartProps> = ({ history, survivalThreshold = 68 }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Handle high DPI
    const dpr = window.devicePixelRatio || 1;
    const width = canvas.clientWidth;
    const height = canvas.clientHeight;
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    ctx.scale(dpr, dpr);

    // Clear
    ctx.clearRect(0, 0, width, height);

    if (history.length < 2) {
      ctx.fillStyle = '#64748b';
      ctx.font = '12px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('Evolution trajectory will appear as generations progress...', width / 2, height / 2);
      return;
    }

    const padding = { top: 16, right: 16, bottom: 24, left: 36 };
    const chartW = width - padding.left - padding.right;
    const chartH = height - padding.top - padding.bottom;

    // Grid lines (0, 25, 50, 75, 100)
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 1;
    ctx.setLineDash([4, 4]);

    for (let score = 0; score <= 100; score += 25) {
      const y = padding.top + chartH - (score / 100) * chartH;
      ctx.beginPath();
      ctx.moveTo(padding.left, y);
      ctx.lineTo(width - padding.right, y);
      ctx.stroke();

      ctx.fillStyle = '#64748b';
      ctx.font = '10px monospace';
      ctx.textAlign = 'right';
      ctx.fillText(`${score}`, padding.left - 6, y + 3);
    }
    ctx.setLineDash([]);

    // Adjudicator Survival Threshold Line (Amber dashed line)
    const threshY = padding.top + chartH - (survivalThreshold / 100) * chartH;
    ctx.strokeStyle = 'rgba(245, 158, 11, 0.75)';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([6, 3]);
    ctx.beginPath();
    ctx.moveTo(padding.left, threshY);
    ctx.lineTo(width - padding.right, threshY);
    ctx.stroke();
    ctx.setLineDash([]);

    ctx.fillStyle = '#f59e0b';
    ctx.font = '9px monospace';
    ctx.textAlign = 'left';
    ctx.fillText(`Adjudicator Pass Threshold (${survivalThreshold}%)`, padding.left + 6, threshY - 4);

    const minGen = history[0].generation;
    const maxGen = Math.max(minGen + 1, history[history.length - 1].generation);

    const getX = (gen: number) => padding.left + ((gen - minGen) / (maxGen - minGen)) * chartW;
    const getY = (score: number) => padding.top + chartH - (Math.max(0, Math.min(100, score)) / 100) * chartH;

    // Gradient fill under champion best fitness
    const gradient = ctx.createLinearGradient(0, padding.top, 0, height - padding.bottom);
    gradient.addColorStop(0, 'rgba(16, 185, 129, 0.28)');
    gradient.addColorStop(1, 'rgba(16, 185, 129, 0.01)');

    ctx.beginPath();
    ctx.moveTo(getX(history[0].generation), padding.top + chartH);
    for (const pt of history) {
      ctx.lineTo(getX(pt.generation), getY(pt.bestFitness));
    }
    ctx.lineTo(getX(history[history.length - 1].generation), padding.top + chartH);
    ctx.closePath();
    ctx.fillStyle = gradient;
    ctx.fill();

    // Line 1: Average Fitness (Cyan)
    ctx.beginPath();
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 1.8;
    for (let i = 0; i < history.length; i++) {
      const x = getX(history[i].generation);
      const y = getY(history[i].avgFitness);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();

    // Line 2: Melodic Complexity (Purple)
    ctx.beginPath();
    ctx.strokeStyle = '#a855f7';
    ctx.lineWidth = 1.6;
    for (let i = 0; i < history.length; i++) {
      const x = getX(history[i].generation);
      const y = getY(history[i].avgComplexity || 40);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();

    // Line 3: Best Champion Fitness (Emerald)
    ctx.beginPath();
    ctx.strokeStyle = '#10b981';
    ctx.lineWidth = 2.5;
    for (let i = 0; i < history.length; i++) {
      const x = getX(history[i].generation);
      const y = getY(history[i].bestFitness);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();

    // Highlight latest point
    const latest = history[history.length - 1];
    const lx = getX(latest.generation);
    const ly = getY(latest.bestFitness);

    ctx.beginPath();
    ctx.arc(lx, ly, 4.5, 0, Math.PI * 2);
    ctx.fillStyle = '#10b981';
    ctx.fill();
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Gen axis label
    ctx.fillStyle = '#94a3b8';
    ctx.font = '10px monospace';
    ctx.textAlign = 'left';
    ctx.fillText(`Gen ${minGen}`, padding.left, height - 6);
    ctx.textAlign = 'right';
    ctx.fillText(`Gen ${maxGen}`, width - padding.right, height - 6);
  }, [history, survivalThreshold]);

  const latest = history.length > 0 ? history[history.length - 1] : null;
  const latestBest = latest ? latest.bestFitness : 0;
  const latestAvg = latest ? latest.avgFitness : 0;
  const latestPassRate = latest ? latest.passRate : 0;
  const latestComplexity = latest ? latest.avgComplexity : 0;

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col shadow-lg backdrop-blur">
      <div className="flex items-center justify-between mb-2 flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
          <h3 className="text-sm font-semibold text-slate-200">
            Evolution &amp; Adjudicator Trajectory
          </h3>
          <span className="text-xs text-slate-400">({history.length} Gens tracked)</span>
        </div>
        <div className="flex items-center gap-4 text-xs font-mono flex-wrap">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 inline-block" />
            <span className="text-slate-300">Champion:</span>
            <span className="text-emerald-400 font-bold">{latestBest.toFixed(1)}%</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-sky-400 inline-block" />
            <span className="text-slate-300">Pop Avg:</span>
            <span className="text-sky-400 font-bold">{latestAvg.toFixed(1)}%</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-purple-400 inline-block" />
            <span className="text-slate-300">Complexity:</span>
            <span className="text-purple-400 font-bold">{latestComplexity.toFixed(0)}/100</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400 inline-block" />
            <span className="text-slate-300">Adjudicator Pass Rate:</span>
            <span className="text-amber-400 font-bold">{latestPassRate}%</span>
          </div>
        </div>
      </div>
      <div className="relative w-full h-36">
        <canvas ref={canvasRef} className="w-full h-full block" />
      </div>
    </div>
  );
};
