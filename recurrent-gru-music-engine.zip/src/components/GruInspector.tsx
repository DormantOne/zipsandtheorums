import React, { useState } from 'react';
import { RecurrentGRUModel, HIDDEN_SIZE, INPUT_SIZE, OUTPUT_SIZE } from '../engine/gru';
import { NOTE_NAMES } from '../engine/musicTheory';
import { Cpu, Play, Square, Sparkles, Terminal } from 'lucide-react';
import { NoteEvent } from '../types/music';

interface GruInspectorProps {
  championModel: RecurrentGRUModel;
  onAuditionSnippet: (notes: NoteEvent[]) => void;
  onStopAudition: () => void;
  isPlaying: boolean;
}

export const GruInspector: React.FC<GruInspectorProps> = ({
  championModel,
  onAuditionSnippet,
  onStopAudition,
  isPlaying,
}) => {
  // 4-note prompt seed
  const [promptNotes, setPromptNotes] = useState<number[]>([60, 64, 67, 71]); // C4, E4, G4, B4
  const [generatedContinuation, setGeneratedContinuation] = useState<NoteEvent[] | null>(null);

  const handleUpdatePromptNote = (index: number, newPitch: number) => {
    const updated = [...promptNotes];
    updated[index] = newPitch;
    setPromptNotes(updated);
  };

  const handleRunContinuation = () => {
    // Clone model so we don't dirty champion live state
    const runner = championModel.clone('prompt_runner');
    runner.resetHidden();

    const sequence: NoteEvent[] = [];
    let step = 0;

    // 1. Ingest prompt notes into GRU hidden memory
    for (const pitch of promptNotes) {
      sequence.push({
        pitch,
        time: step,
        duration: 2, // 8th note
        velocity: 0.8,
      });
      const inputVector = runner.buildInputVector(pitch, step, 2);
      runner.step(inputVector);
      step += 2;
    }

    // 2. Autoregressively continue generating 24 steps
    let lastPitch = promptNotes[promptNotes.length - 1];
    let lastDur = 2;
    const targetSteps = 32;

    while (step < targetSteps) {
      const note = runner.generateNextNote(step, lastPitch, lastDur, 0.85);
      // Bound
      if (step + note.duration > targetSteps) {
        note.duration = targetSteps - step;
      }
      sequence.push(note);
      lastPitch = note.pitch;
      lastDur = note.duration;
      step += note.duration;
    }

    setGeneratedContinuation(sequence);
    onAuditionSnippet(sequence);
  };

  // Compute weight stats
  const countWeights =
    HIDDEN_SIZE * INPUT_SIZE * 3 + // Wxr, Wxz, Wxh
    HIDDEN_SIZE * HIDDEN_SIZE * 3 + // Whr, Whz, Whh
    HIDDEN_SIZE * 3 + // br, bz, bh
    OUTPUT_SIZE * HIDDEN_SIZE + // Why
    OUTPUT_SIZE; // by

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 flex flex-col gap-5 shadow-xl backdrop-blur">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <Cpu className="w-5 h-5 text-sky-400" />
          <h3 className="text-base font-semibold text-slate-100">
            Recurrent GRU Architecture & Neural Memory
          </h3>
        </div>
        <span className="text-xs font-mono px-2 py-0.5 rounded bg-sky-500/20 text-sky-300 border border-sky-500/30">
          {countWeights.toLocaleString()} Parameters
        </span>
      </div>

      {/* Equations and Gating Diagram */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-slate-950/80 border border-slate-800 rounded-lg p-3.5 flex flex-col justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-300 block mb-2 flex items-center gap-1.5">
              <Terminal className="w-3.5 h-3.5 text-emerald-400" />
              Recurrent Gating Equations
            </span>
            <div className="space-y-1.5 font-mono text-[11px] text-slate-300 bg-slate-900/90 p-2.5 rounded border border-slate-800">
              <p className="text-sky-300">
                r_t = &sigma;(W_xr &bull; x_t + W_hr &bull; h_t-1 + b_r){' '}
                <span className="text-slate-500">// Reset gate</span>
              </p>
              <p className="text-indigo-300">
                z_t = &sigma;(W_xz &bull; x_t + W_hz &bull; h_t-1 + b_z){' '}
                <span className="text-slate-500">// Update gate</span>
              </p>
              <p className="text-amber-300">
                h_cand = tanh(W_xh &bull; x_t + W_hh &bull; (r_t &odot; h_t-1) + b_h)
              </p>
              <p className="text-emerald-300">
                h_t = (1 - z_t) &odot; h_t-1 + z_t &odot; h_cand{' '}
                <span className="text-slate-500">// Memory update</span>
              </p>
              <p className="text-purple-300">
                logits = W_hy &bull; h_t + b_y{' '}
                <span className="text-slate-500">// Note token projection</span>
              </p>
            </div>
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            The recurrent hidden state maintains melodic theme persistence across bars, while reset
            and update gates regulate how long motifs are remembered.
          </p>
        </div>

        {/* Neural Dimensions Overview */}
        <div className="bg-slate-950/80 border border-slate-800 rounded-lg p-3.5 flex flex-col justify-between">
          <span className="text-xs font-semibold text-slate-300 block mb-2">
            Layer Dimensions:
          </span>
          <div className="grid grid-cols-2 gap-2 text-xs font-mono">
            <div className="p-2 bg-slate-900 rounded border border-slate-800">
              <span className="text-slate-400 block text-[10px]">Input Vector (x_t)</span>
              <span className="text-slate-200 font-bold">{INPUT_SIZE} dims</span>
              <span className="text-[9px] text-slate-500 block">Pitches + Metric phase</span>
            </div>
            <div className="p-2 bg-slate-900 rounded border border-slate-800">
              <span className="text-slate-400 block text-[10px]">Hidden State (h_t)</span>
              <span className="text-sky-400 font-bold">{HIDDEN_SIZE} recurrent units</span>
              <span className="text-[9px] text-slate-500 block">Internal musical memory</span>
            </div>
            <div className="p-2 bg-slate-900 rounded border border-slate-800">
              <span className="text-slate-400 block text-[10px]">Output Logits (y_t)</span>
              <span className="text-emerald-400 font-bold">{OUTPUT_SIZE} tokens</span>
              <span className="text-[9px] text-slate-500 block">Pitch & Durations</span>
            </div>
            <div className="p-2 bg-slate-900 rounded border border-slate-800">
              <span className="text-slate-400 block text-[10px]">Selection Engine</span>
              <span className="text-amber-400 font-bold">Music Theory</span>
              <span className="text-[9px] text-slate-500 block">Fitness survival filter</span>
            </div>
          </div>
          <div className="mt-3 text-[11px] text-slate-400 font-mono">
            Active Champion ID: <span className="text-slate-300">{championModel.id}</span>
          </div>
        </div>
      </div>

      {/* Interactive Prompting: Seed Motif Injection */}
      <div className="pt-3 border-t border-slate-800 flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-amber-400" />
              Prompt the Champion GRU with a Seed Motif:
            </span>
            <p className="text-[11px] text-slate-400">
              Set 4 starting notes. The champion model will absorb this seed into its recurrent
              hidden state and continue the composition!
            </p>
          </div>
          <button
            onClick={isPlaying ? onStopAudition : handleRunContinuation}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all shadow ${
              isPlaying
                ? 'bg-rose-600 text-white'
                : 'bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950'
            }`}
          >
            {isPlaying ? (
              <>
                <Square className="w-3.5 h-3.5 fill-current" /> Stop
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-current" /> Continue From Seed
              </>
            )}
          </button>
        </div>

        {/* 4 Seed Notes Selectors */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {promptNotes.map((pitch, idx) => (
            <div key={idx} className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
              <span className="text-[10px] text-slate-400 block mb-1">
                Seed Note #{idx + 1}:
              </span>
              <select
                value={pitch}
                onChange={e => handleUpdatePromptNote(idx, parseInt(e.target.value, 10))}
                className="w-full bg-slate-900 border border-slate-700 text-slate-200 rounded p-1 text-xs font-mono"
              >
                {Array.from({ length: 25 }).map((_, i) => {
                  const m = 48 + i; // C3 to C5
                  const noteName = NOTE_NAMES[m % 12];
                  const octave = Math.floor(m / 12) - 1;
                  return (
                    <option key={m} value={m}>
                      {noteName}{octave} (MIDI {m})
                    </option>
                  );
                })}
              </select>
            </div>
          ))}
        </div>

        {/* Continuation Preview if generated */}
        {generatedContinuation && (
          <div className="bg-slate-950/90 border border-slate-800 rounded-lg p-2.5 flex items-center justify-between text-xs font-mono">
            <span className="text-slate-400">Continuation generated:</span>
            <span className="text-emerald-400">
              {generatedContinuation.filter(n => n.pitch > 0).length} notes generated from hidden
              state
            </span>
          </div>
        )}
      </div>
    </div>
  );
};
