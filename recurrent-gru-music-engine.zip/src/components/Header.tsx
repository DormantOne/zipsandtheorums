import React from 'react';
import { Volume2, VolumeX, FastForward, Zap, Sparkles, Sliders } from 'lucide-react';
import { SynthInstrument } from '../types/music';

interface HeaderProps {
  generation: number;
  bestFitness: number;
  isQuietMode: boolean;
  onToggleQuietMode: () => void;
  onTurboEvolve: (gens: number) => void;
  bpm: number;
  onBpmChange: (bpm: number) => void;
  instrument: SynthInstrument;
  onInstrumentChange: (inst: SynthInstrument) => void;
  volume: number;
  onVolumeChange: (vol: number) => void;
  isMuted: boolean;
  onToggleMute: () => void;
  activeTab: 'stage' | 'tournament' | 'settings' | 'inspector';
  onTabChange: (tab: 'stage' | 'tournament' | 'settings' | 'inspector') => void;
}

export const Header: React.FC<HeaderProps> = ({
  generation,
  bestFitness,
  isQuietMode,
  onToggleQuietMode,
  onTurboEvolve,
  bpm,
  onBpmChange,
  instrument,
  onInstrumentChange,
  volume,
  onVolumeChange,
  isMuted,
  onToggleMute,
  activeTab,
  onTabChange,
}) => {
  return (
    <header className="sticky top-0 z-50 bg-slate-950/95 border-b border-slate-800 backdrop-blur-md shadow-2xl">
      <div className="max-w-7xl mx-auto px-4 py-3 flex flex-col gap-3">
        {/* Top Bar: Brand, Generation & Fitness, Quiet Mode Toggle, Audio Controls */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 via-teal-400 to-sky-400 flex items-center justify-center text-slate-950 shadow-lg shadow-emerald-500/20">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-black tracking-tight text-white">
                  EvoHarmonics
                </h1>
                <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  Recurrent GRU
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">
                Music Theory Survival Selection &amp; Continuous Generative Stream
              </p>
            </div>
          </div>

          {/* Center Stats: Gen & Fitness */}
          <div className="flex items-center gap-3 bg-slate-900/90 border border-slate-800 px-3 py-1.5 rounded-xl">
            <div className="text-center px-1">
              <span className="text-[10px] text-slate-400 block font-sans">Generation</span>
              <span className="text-sm font-bold font-mono text-slate-100">{generation}</span>
            </div>
            <div className="w-[1px] h-6 bg-slate-800" />
            <div className="text-center px-1">
              <span className="text-[10px] text-slate-400 block font-sans">Best Fitness</span>
              <span className="text-sm font-bold font-mono text-emerald-400">
                {bestFitness.toFixed(1)}%
              </span>
            </div>
          </div>

          {/* Quiet Mode & Turbo Actions */}
          <div className="flex items-center gap-2 flex-wrap">
            {/* Quiet Mode Button */}
            <button
              onClick={onToggleQuietMode}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all shadow ${
                isQuietMode
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/50 shadow-emerald-950/40'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
              }`}
              title="Quiet Mode runs generations silently in background at maximum computational speed"
            >
              <Zap
                className={`w-3.5 h-3.5 ${
                  isQuietMode ? 'text-emerald-400 fill-emerald-400 animate-pulse' : 'text-slate-400'
                }`}
              />
              <span>Quiet Mode: {isQuietMode ? 'ON' : 'OFF'}</span>
            </button>

            {/* Turbo Evolve Buttons */}
            <button
              onClick={() => onTurboEvolve(10)}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
              title="Silently evolve 10 generations"
            >
              <FastForward className="w-3.5 h-3.5 text-sky-400" />
              <span>+10 Gen</span>
            </button>
            <button
              onClick={() => onTurboEvolve(50)}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
              title="Silently evolve 50 generations"
            >
              <FastForward className="w-3.5 h-3.5 text-amber-400" />
              <span>+50 Gen</span>
            </button>
          </div>

          {/* Synth & Audio Controls */}
          <div className="flex items-center gap-3">
            {/* Instrument Selector */}
            <div className="hidden md:flex items-center gap-1.5">
              <span className="text-[11px] text-slate-400">Timbre:</span>
              <select
                value={instrument}
                onChange={e => onInstrumentChange(e.target.value as SynthInstrument)}
                className="bg-slate-900 border border-slate-700 text-slate-200 text-xs rounded-lg px-2 py-1 focus:outline-none focus:border-emerald-500"
              >
                <option value="rhodes">Warm Rhodes</option>
                <option value="piano">Acoustic Piano</option>
                <option value="analog_synth">Analog Synth</option>
                <option value="ambient_chime">Ambient Chime</option>
                <option value="marimba">Wood Marimba</option>
              </select>
            </div>

            {/* BPM */}
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] text-slate-400">BPM:</span>
              <input
                type="number"
                min="60"
                max="180"
                value={bpm}
                onChange={e => onBpmChange(Math.max(60, Math.min(180, parseInt(e.target.value) || 108)))}
                className="w-14 bg-slate-900 border border-slate-700 text-slate-200 text-xs rounded-lg px-1.5 py-1 font-mono text-center"
              />
            </div>

            {/* Volume & Mute */}
            <div className="flex items-center gap-1.5">
              <button
                onClick={onToggleMute}
                className="text-slate-400 hover:text-slate-200 p-1"
                title={isMuted ? 'Unmute' : 'Mute'}
              >
                {isMuted ? (
                  <VolumeX className="w-4 h-4 text-rose-400" />
                ) : (
                  <Volume2 className="w-4 h-4" />
                )}
              </button>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={isMuted ? 0 : volume}
                onChange={e => onVolumeChange(parseFloat(e.target.value))}
                className="w-16 accent-emerald-400 cursor-pointer hidden sm:block"
                title="Master Volume"
              />
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <nav className="flex items-center gap-1 overflow-x-auto pt-1 border-t border-slate-800/80">
          <button
            onClick={() => onTabChange('stage')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'stage'
                ? 'bg-emerald-500 text-slate-950 font-bold shadow'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <span>Champion Stage &amp; Continuous Player</span>
          </button>
          <button
            onClick={() => onTabChange('tournament')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'tournament'
                ? 'bg-emerald-500 text-slate-950 font-bold shadow'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <span>Candidate Tournament &amp; Lineage</span>
          </button>
          <button
            onClick={() => onTabChange('settings')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'settings'
                ? 'bg-emerald-500 text-slate-950 font-bold shadow'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Music Theory Rules &amp; Scales</span>
          </button>
          <button
            onClick={() => onTabChange('inspector')}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'inspector'
                ? 'bg-emerald-500 text-slate-950 font-bold shadow'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <span>GRU Neural Brain Inspector</span>
          </button>
        </nav>
      </div>
    </header>
  );
};
