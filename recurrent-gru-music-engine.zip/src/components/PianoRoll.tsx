import React from 'react';
import { CandidateSnippet, TheoryConfig } from '../types/music';
import { midiToNoteName, isScalePitch, getScaleDegree } from '../engine/musicTheory';
import { Play, Square, Download, Award, CheckCircle, XCircle, Sparkles, Music, ShieldCheck } from 'lucide-react';
import { downloadMidiFile } from '../utils/midiExport';

interface PianoRollProps {
  snippet: CandidateSnippet | null;
  theoryConfig: TheoryConfig;
  isPlaying: boolean;
  currentPlayheadStep: number;
  bpm: number;
  onPlay: (snippet: CandidateSnippet) => void;
  onStop: () => void;
  onNoteClick?: (pitch: number) => void;
  onPromoteChampion?: (snippet: CandidateSnippet) => void;
  isChampionSnippet?: boolean;
}

export const PianoRoll: React.FC<PianoRollProps> = ({
  snippet,
  theoryConfig,
  isPlaying,
  currentPlayheadStep,
  bpm,
  onPlay,
  onStop,
  onNoteClick,
  onPromoteChampion,
  isChampionSnippet,
}) => {
  if (!snippet || snippet.notes.length === 0) {
    return (
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 text-center text-slate-500">
        <Music className="w-12 h-12 mx-auto mb-3 opacity-40" />
        <p className="text-sm">Select or generate a candidate snippet to view its piano roll and theory metrics.</p>
      </div>
    );
  }

  // Find min and max pitch present in snippet, with padding
  const activeNotes = snippet.notes.filter(n => n.pitch > 0);
  const pitches = activeNotes.map(n => n.pitch);
  const minMidi = Math.max(48, (pitches.length > 0 ? Math.min(...pitches) : 60) - 2);
  const maxMidi = Math.min(84, (pitches.length > 0 ? Math.max(...pitches) : 72) + 2);
  const totalSteps = snippet.lengthSteps;

  // Build rows from maxMidi down to minMidi
  const rows: number[] = [];
  for (let p = maxMidi; p >= minMidi; p--) {
    rows.push(p);
  }

  const isScale = (pitch: number) => isScalePitch(pitch, theoryConfig.rootNote, theoryConfig.scale);

  const getNoteColor = (pitch: number) => {
    const deg = getScaleDegree(pitch, theoryConfig.rootNote, theoryConfig.scale);
    if (deg === 1) return 'bg-emerald-500 border-emerald-300 text-slate-950 font-bold'; // Tonic
    if (deg === 5) return 'bg-sky-500 border-sky-300 text-slate-950 font-bold'; // Dominant
    if (deg === 3) return 'bg-amber-500 border-amber-300 text-slate-950 font-bold'; // Mediant
    if (isScale(pitch)) return 'bg-indigo-500 border-indigo-300 text-white'; // Diatonic
    return 'bg-fuchsia-600 border-fuchsia-300 text-white shadow-fuchsia-900/50'; // Justified/Chromatic note
  };

  const handleDownload = () => {
    downloadMidiFile(
      snippet.notes,
      `Snippet_Gen${snippet.generation}_Score${Math.round(snippet.fitness)}`,
      bpm
    );
  };

  return (
    <div className="bg-slate-900/95 border border-slate-800 rounded-xl shadow-xl overflow-hidden flex flex-col">
      {/* Top Header / Bar */}
      <div className="px-4 py-3 bg-slate-950/80 border-b border-slate-800/80 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <button
            onClick={() => (isPlaying ? onStop() : onPlay(snippet))}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold shadow-md transition-all ${
              isPlaying
                ? 'bg-rose-600 hover:bg-rose-500 text-white ring-2 ring-rose-400/50'
                : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold hover:shadow-emerald-500/20'
            }`}
          >
            {isPlaying ? (
              <>
                <Square className="w-3.5 h-3.5 fill-current" /> Stop Audition
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-current" /> Audition Snippet
              </>
            )}
          </button>

          <div className="flex items-center gap-2">
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
              Gen {snippet.generation}
            </span>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-800/80 text-slate-400">
              {totalSteps / 16} {totalSteps / 16 === 1 ? 'Measure' : 'Measures'} ({totalSteps} steps)
            </span>

            {/* Adjudicator Pass/Fail Badge */}
            <span
              className={`flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded border ${
                snippet.passed
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                  : 'bg-rose-500/20 text-rose-300 border-rose-500/40'
              }`}
            >
              {snippet.passed ? (
                <>
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> Adjudicator PASSED
                </>
              ) : (
                <>
                  <XCircle className="w-3.5 h-3.5 text-rose-400" /> Adjudicator FAILED
                </>
              )}
            </span>

            {/* Melodic Complexity Badge */}
            <span className="flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/40">
              <Sparkles className="w-3 h-3" /> Complexity {snippet.complexityScore || 50}/100
            </span>

            {isChampionSnippet && (
              <span className="flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40">
                <Award className="w-3 h-3" /> Champion Model
              </span>
            )}
          </div>
        </div>

        {/* Right buttons */}
        <div className="flex items-center gap-2">
          {onPromoteChampion && !isChampionSnippet && (
            <button
              onClick={() => onPromoteChampion(snippet)}
              title="Promote this candidate to be the lineage champion"
              className="flex items-center gap-1.5 px-2.5 py-1 text-xs rounded bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 transition-colors"
            >
              <Award className="w-3.5 h-3.5" /> Make Champion
            </button>
          )}

          <button
            onClick={handleDownload}
            title="Download Standard MIDI File"
            className="flex items-center gap-1.5 px-2.5 py-1 text-xs rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
          >
            <Download className="w-3.5 h-3.5" /> MIDI
          </button>

          <div className="flex items-center gap-1.5 bg-emerald-500/10 border border-emerald-500/30 px-3 py-1 rounded-lg">
            <span className="text-xs text-emerald-400 font-medium">Theory Score:</span>
            <span className="text-sm font-bold text-emerald-300 font-mono">{snippet.fitness}%</span>
          </div>
        </div>
      </div>

      {/* Main Piano Roll Grid */}
      <div className="relative overflow-x-auto select-none bg-slate-950 p-3">
        {/* Playhead line */}
        {isPlaying && currentPlayheadStep >= 0 && (
          <div
            className="absolute top-0 bottom-0 z-20 pointer-events-none transition-all duration-75"
            style={{
              left: `calc(4rem + ${(currentPlayheadStep / totalSteps) * 100}% * (1 - 4rem / 100%))`,
              width: '2px',
              backgroundColor: '#38bdf8',
              boxShadow: '0 0 10px #38bdf8, 0 0 20px #38bdf8',
            }}
          >
            <div className="w-3 h-3 -ml-[5px] -mt-1 bg-sky-400 rounded-full shadow-lg" />
          </div>
        )}

        <div className="min-w-[620px] flex flex-col">
          {/* Timeline Bar Header */}
          <div className="flex h-6 border-b border-slate-800 text-[10px] text-slate-400 font-mono">
            <div className="w-16 flex-shrink-0 text-slate-500 flex items-center justify-center font-sans">
              Pitch
            </div>
            <div className="flex-1 relative flex">
              {Array.from({ length: Math.ceil(totalSteps / 16) }).map((_, barIdx) => (
                <div
                  key={barIdx}
                  className="flex-1 border-l border-slate-700/80 px-1.5 flex items-center font-bold text-slate-400"
                >
                  Bar {barIdx + 1}
                </div>
              ))}
            </div>
          </div>

          {/* Note Rows */}
          {rows.map(pitch => {
            const inKey = isScale(pitch);
            const deg = getScaleDegree(pitch, theoryConfig.rootNote, theoryConfig.scale);
            const isTonic = deg === 1;

            return (
              <div
                key={pitch}
                className={`flex h-6 border-b border-slate-900 group ${
                  isTonic
                    ? 'bg-emerald-950/20'
                    : inKey
                    ? 'bg-slate-900/40'
                    : 'bg-slate-950/80 opacity-60'
                }`}
              >
                {/* Note Label */}
                <button
                  type="button"
                  onClick={() => onNoteClick && onNoteClick(pitch)}
                  className={`w-16 flex-shrink-0 text-[11px] font-mono px-2 flex items-center justify-between border-r border-slate-800 cursor-pointer hover:bg-slate-800/80 transition-colors ${
                    isTonic
                      ? 'text-emerald-400 font-bold'
                      : inKey
                      ? 'text-slate-300'
                      : 'text-fuchsia-400/80 italic'
                  }`}
                  title={`Click to preview ${midiToNoteName(pitch)}`}
                >
                  <span>{midiToNoteName(pitch)}</span>
                  {deg ? (
                    <span className="text-[9px] text-slate-500 font-sans">^{deg}</span>
                  ) : (
                    <span className="text-[8px] text-fuchsia-400 font-sans">chrom</span>
                  )}
                </button>

                {/* Grid columns */}
                <div className="flex-1 relative flex">
                  {/* Measure grid subdivisions */}
                  {Array.from({ length: totalSteps }).map((_, stepIdx) => (
                    <div
                      key={stepIdx}
                      className={`flex-1 border-r ${
                        stepIdx % 16 === 15
                          ? 'border-slate-700/90'
                          : stepIdx % 4 === 3
                          ? 'border-slate-800/70'
                          : 'border-slate-900/40'
                      }`}
                    />
                  ))}

                  {/* Render note blocks positioned absolutely over this row */}
                  {snippet.notes
                    .filter(n => n.pitch === pitch)
                    .map((n, i) => {
                      const leftPercent = (n.time / totalSteps) * 100;
                      const widthPercent = (n.duration / totalSteps) * 100;
                      const isCurrent = isPlaying && currentPlayheadStep >= n.time && currentPlayheadStep < n.time + n.duration;

                      return (
                        <div
                          key={i}
                          onClick={() => onNoteClick && onNoteClick(n.pitch)}
                          style={{
                            left: `${leftPercent}%`,
                            width: `calc(${widthPercent}% - 2px)`,
                          }}
                          className={`absolute top-0.5 bottom-0.5 rounded px-1.5 flex items-center overflow-hidden text-[10px] font-mono font-semibold shadow border cursor-pointer transition-transform ${getNoteColor(
                            n.pitch
                          )} ${
                            isCurrent
                              ? 'ring-2 ring-white scale-105 z-10 brightness-125'
                              : 'hover:brightness-110'
                          }`}
                        >
                          <span className="truncate">{midiToNoteName(n.pitch)}</span>
                        </div>
                      );
                    })}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Theory Score Breakdown & Sophisticated Adjudication Diagnostics */}
      <div className="p-3 bg-slate-950/90 border-t border-slate-800/80 flex flex-col gap-3">
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2">
          <div className="bg-slate-900 border border-slate-800/80 rounded-lg p-2 text-center">
            <span className="text-[10px] text-slate-400 block">Scale Grammar</span>
            <span className="text-sm font-bold text-emerald-400 font-mono">
              {snippet.breakdown.scaleFidelity}%
            </span>
          </div>
          <div className="bg-slate-900 border border-slate-800/80 rounded-lg p-2 text-center">
            <span className="text-[10px] text-slate-400 block">Voice Leading</span>
            <span className="text-sm font-bold text-sky-400 font-mono">
              {snippet.breakdown.voiceLeading}%
            </span>
          </div>
          <div className="bg-slate-900 border border-slate-800/80 rounded-lg p-2 text-center">
            <span className="text-[10px] text-slate-400 block">Cadence Finish</span>
            <span className="text-sm font-bold text-amber-400 font-mono">
              {snippet.breakdown.cadenceResolution}%
            </span>
          </div>
          <div className="bg-slate-900 border border-slate-800/80 rounded-lg p-2 text-center">
            <span className="text-[10px] text-slate-400 block">Rhythmic Groove</span>
            <span className="text-sm font-bold text-indigo-400 font-mono">
              {snippet.breakdown.rhythmicVariety}%
            </span>
          </div>
          <div className="bg-slate-900 border border-slate-800/80 rounded-lg p-2 text-center">
            <span className="text-[10px] text-slate-400 block">Consonance</span>
            <span className="text-sm font-bold text-teal-400 font-mono">
              {snippet.breakdown.harmonicConsonance}%
            </span>
          </div>
          <div className="bg-slate-900 border border-slate-800/80 rounded-lg p-2 text-center">
            <span className="text-[10px] text-slate-400 block">Motif Recall</span>
            <span className="text-sm font-bold text-purple-400 font-mono">
              {snippet.breakdown.motifCoherence}%
            </span>
          </div>
        </div>

        {/* Sophisticated Adjudicator Comments */}
        {snippet.adjudicatorComments && snippet.adjudicatorComments.length > 0 && (
          <div className="bg-slate-900/80 rounded-lg p-2.5 border border-slate-800 flex flex-col gap-1.5">
            <span className="text-[11px] font-semibold text-slate-300 flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              Music Theory Adjudicator Itemized Analysis:
            </span>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
              {snippet.adjudicatorComments.map((item, idx) => (
                <div
                  key={idx}
                  className={`p-2 rounded border flex items-start gap-2 ${
                    item.status === 'pass'
                      ? 'bg-emerald-950/20 border-emerald-500/30 text-emerald-200'
                      : item.status === 'bonus'
                      ? 'bg-purple-950/20 border-purple-500/30 text-purple-200'
                      : 'bg-rose-950/20 border-rose-500/30 text-rose-200'
                  }`}
                >
                  {item.status === 'pass' ? (
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0 mt-0.5" />
                  ) : item.status === 'bonus' ? (
                    <Sparkles className="w-3.5 h-3.5 text-purple-400 flex-shrink-0 mt-0.5" />
                  ) : (
                    <XCircle className="w-3.5 h-3.5 text-rose-400 flex-shrink-0 mt-0.5" />
                  )}
                  <div>
                    <span className="font-bold text-[11px] block">{item.rule}</span>
                    <span className="text-[10px] opacity-90">{item.detail}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
