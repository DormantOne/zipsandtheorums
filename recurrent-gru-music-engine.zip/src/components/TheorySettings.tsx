import React from 'react';
import { TheoryConfig, EvolutionConfig, ScaleType } from '../types/music';
import { NOTE_NAMES, SCALES } from '../engine/musicTheory';
import { Sliders, Settings2, RefreshCw, ShieldCheck, Zap, Sparkles } from 'lucide-react';

interface TheorySettingsProps {
  theoryConfig: TheoryConfig;
  evoConfig: EvolutionConfig;
  onUpdateTheoryConfig: (newConfig: TheoryConfig) => void;
  onUpdateEvoConfig: (newConfig: EvolutionConfig) => void;
  onResetEvolution: () => void;
}

interface StylePreset {
  name: string;
  desc: string;
  scale: ScaleType;
  complexityTarget: 'moderate' | 'complex' | 'virtuoso';
  survivalThreshold: number;
  weights: TheoryConfig['weights'];
  temperature: number;
}

const PRESETS: StylePreset[] = [
  {
    name: 'Virtuoso Bebop & Modern Jazz',
    desc: 'Very complex chromatic passing tones, arpeggiated upper extensions (9ths/11ths), syncopated polyrhythms, strict cadence adjudication.',
    scale: 'dorian',
    complexityTarget: 'virtuoso',
    survivalThreshold: 70,
    weights: {
      scaleFidelity: 0.2,
      voiceLeading: 0.22,
      rhythmicVariety: 0.24,
      cadenceResolution: 0.16,
      motifCoherence: 0.1,
      harmonicConsonance: 0.08,
    },
    temperature: 1.15,
  },
  {
    name: 'Bach Polyphonic Invention',
    desc: 'Intricate counterpoint, arpeggiated broken chords, leap compensation, motivic inversions and authentic cadence arrivals.',
    scale: 'harmonic_minor',
    complexityTarget: 'complex',
    survivalThreshold: 72,
    weights: {
      scaleFidelity: 0.28,
      voiceLeading: 0.28,
      rhythmicVariety: 0.14,
      cadenceResolution: 0.16,
      motifCoherence: 0.14,
      harmonicConsonance: 0.1,
    },
    temperature: 0.88,
  },
  {
    name: 'Chopin / Liszt Romantic Run',
    desc: 'Wide expressive pitch spans, dramatic melodic contour climaxes, chromatic neighbor tones, mediant resolutions.',
    scale: 'natural_minor',
    complexityTarget: 'virtuoso',
    survivalThreshold: 68,
    weights: {
      scaleFidelity: 0.24,
      voiceLeading: 0.24,
      rhythmicVariety: 0.2,
      cadenceResolution: 0.16,
      motifCoherence: 0.1,
      harmonicConsonance: 0.06,
    },
    temperature: 1.05,
  },
  {
    name: 'Pure Diatonic Pop & Classical',
    desc: 'Consonant stepwise motion, tight key adherence, clean authentic cadences.',
    scale: 'major',
    complexityTarget: 'moderate',
    survivalThreshold: 65,
    weights: {
      scaleFidelity: 0.32,
      voiceLeading: 0.26,
      rhythmicVariety: 0.14,
      cadenceResolution: 0.18,
      motifCoherence: 0.1,
      harmonicConsonance: 0.1,
    },
    temperature: 0.75,
  },
];

export const TheorySettings: React.FC<TheorySettingsProps> = ({
  theoryConfig,
  evoConfig,
  onUpdateTheoryConfig,
  onUpdateEvoConfig,
  onResetEvolution,
}) => {
  const handlePresetSelect = (p: StylePreset) => {
    onUpdateTheoryConfig({
      ...theoryConfig,
      scale: p.scale,
      weights: p.weights,
    });
    onUpdateEvoConfig({
      ...evoConfig,
      complexityTarget: p.complexityTarget,
      survivalThreshold: p.survivalThreshold,
      temperature: p.temperature,
    });
  };

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 flex flex-col gap-6 shadow-xl backdrop-blur">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <Settings2 className="w-5 h-5 text-emerald-400" />
          <h3 className="text-base font-semibold text-slate-100">
            Music Theory Adjudicator &amp; Evolutionary Settings
          </h3>
        </div>
        <button
          onClick={onResetEvolution}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 transition-colors"
        >
          <RefreshCw className="w-3.5 h-3.5" /> Reset Lineage
        </button>
      </div>

      {/* Style Presets */}
      <div>
        <span className="text-xs font-semibold text-slate-300 block mb-2">
          Adjudicator &amp; Melodic Complexity Presets:
        </span>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
          {PRESETS.map((preset, idx) => (
            <button
              key={idx}
              onClick={() => handlePresetSelect(preset)}
              className="p-2.5 rounded-lg border border-slate-800 hover:border-emerald-500/50 bg-slate-950/60 hover:bg-slate-800/80 text-left transition-all group"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-200 group-hover:text-emerald-400">
                  {preset.name}
                </span>
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/40 uppercase">
                  {preset.complexityTarget}
                </span>
              </div>
              <div className="text-[11px] text-slate-400 mt-1 line-clamp-2">{preset.desc}</div>
            </button>
          ))}
        </div>
      </div>

      {/* COMPLEXITY & ADJUDICATION THRESHOLDS */}
      <div className="p-4 bg-slate-950/80 rounded-xl border border-slate-800/90 flex flex-col gap-4">
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
          <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-amber-400" />
            Adjudicator Strictness &amp; Melodic Complexity Target
          </span>
          <span className="text-[11px] font-mono text-slate-400">
            "Only the approaches that survive pass"
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {/* Complexity Target */}
          <div>
            <label className="text-xs text-slate-300 block mb-1 font-semibold flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-purple-400" />
              Melodic Complexity:
            </label>
            <select
              value={evoConfig.complexityTarget}
              onChange={e =>
                onUpdateEvoConfig({
                  ...evoConfig,
                  complexityTarget: e.target.value as 'moderate' | 'complex' | 'virtuoso',
                })
              }
              className="w-full bg-slate-900 border border-slate-700 rounded p-1.5 text-xs text-slate-200 font-mono"
            >
              <option value="moderate">Moderate (Clean classical lines)</option>
              <option value="complex">Complex (Arpeggiated runs, syncopation)</option>
              <option value="virtuoso">Virtuoso (Dense, chromatic runs, bebop grammar)</option>
            </select>
          </div>

          {/* Adjudicator Survival Threshold */}
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-300 font-semibold flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                Pass Threshold:
              </span>
              <span className="font-mono text-amber-400 font-bold">
                {evoConfig.survivalThreshold}%
              </span>
            </div>
            <input
              type="range"
              min="55"
              max="85"
              step="1"
              value={evoConfig.survivalThreshold}
              onChange={e =>
                onUpdateEvoConfig({
                  ...evoConfig,
                  survivalThreshold: parseInt(e.target.value, 10),
                })
              }
              className="w-full accent-amber-400"
            />
            <span className="text-[10px] text-slate-400 block mt-0.5">
              Models below {evoConfig.survivalThreshold}% are rejected by adjudicator
            </span>
          </div>

          {/* Neural Entropy Temperature */}
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-300 font-semibold flex items-center gap-1">
                <Zap className="w-3.5 h-3.5 text-sky-400" />
                GRU Temperature (Exploration):
              </span>
              <span className="font-mono text-sky-400 font-bold">
                {evoConfig.temperature.toFixed(2)}
              </span>
            </div>
            <input
              type="range"
              min="0.5"
              max="1.6"
              step="0.05"
              value={evoConfig.temperature}
              onChange={e =>
                onUpdateEvoConfig({
                  ...evoConfig,
                  temperature: parseFloat(e.target.value),
                })
              }
              className="w-full accent-sky-400"
            />
            <span className="text-[10px] text-slate-400 block mt-0.5">
              Higher entropy allows daring leaps &amp; chromatic excursions
            </span>
          </div>
        </div>
      </div>

      {/* Tonality / Scale Center */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-3 border-t border-slate-800">
        <div>
          <label className="text-xs font-semibold text-slate-300 block mb-1.5">
            Key Root Note:
          </label>
          <div className="grid grid-cols-6 gap-1">
            {NOTE_NAMES.map((name, idx) => (
              <button
                key={name}
                onClick={() => onUpdateTheoryConfig({ ...theoryConfig, rootNote: idx })}
                className={`py-1.5 text-xs font-mono font-bold rounded transition-colors ${
                  theoryConfig.rootNote === idx
                    ? 'bg-emerald-500 text-slate-950 shadow'
                    : 'bg-slate-800/90 hover:bg-slate-700 text-slate-300'
                }`}
              >
                {name}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="text-xs font-semibold text-slate-300 block mb-1.5">
            Theoretical Scale / Mode:
          </label>
          <select
            value={theoryConfig.scale}
            onChange={e =>
              onUpdateTheoryConfig({
                ...theoryConfig,
                scale: e.target.value as ScaleType,
              })
            }
            className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-xs text-slate-200 font-sans focus:outline-none focus:border-emerald-500"
          >
            {Object.entries(SCALES).map(([key, val]) => (
              <option key={key} value={key}>
                {val.name} &bull; {val.description}
              </option>
            ))}
          </select>
          <p className="text-[11px] text-slate-400 mt-1.5 italic">
            {SCALES[theoryConfig.scale].description}
          </p>
        </div>
      </div>

      {/* Fitness Weights Sliders */}
      <div className="pt-3 border-t border-slate-800">
        <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5 mb-3">
          <Sliders className="w-4 h-4 text-emerald-400" />
          Adjudicator Fitness Weightings:
        </span>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-300">Scale Grammar (Passing Chromaticism Allowed)</span>
              <span className="font-mono text-emerald-400">
                {(theoryConfig.weights.scaleFidelity * 100).toFixed(0)}%
              </span>
            </div>
            <input
              type="range"
              min="0.05"
              max="0.5"
              step="0.05"
              value={theoryConfig.weights.scaleFidelity}
              onChange={e =>
                onUpdateTheoryConfig({
                  ...theoryConfig,
                  weights: {
                    ...theoryConfig.weights,
                    scaleFidelity: parseFloat(e.target.value),
                  },
                })
              }
              className="w-full accent-emerald-400"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-300">Voice Leading (Steps + Arpeggio Outlines)</span>
              <span className="font-mono text-sky-400">
                {(theoryConfig.weights.voiceLeading * 100).toFixed(0)}%
              </span>
            </div>
            <input
              type="range"
              min="0.05"
              max="0.5"
              step="0.05"
              value={theoryConfig.weights.voiceLeading}
              onChange={e =>
                onUpdateTheoryConfig({
                  ...theoryConfig,
                  weights: {
                    ...theoryConfig.weights,
                    voiceLeading: parseFloat(e.target.value),
                  },
                })
              }
              className="w-full accent-sky-400"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-300">Cadential Resolution (Tonic/Dominant)</span>
              <span className="font-mono text-amber-400">
                {(theoryConfig.weights.cadenceResolution * 100).toFixed(0)}%
              </span>
            </div>
            <input
              type="range"
              min="0.05"
              max="0.4"
              step="0.05"
              value={theoryConfig.weights.cadenceResolution}
              onChange={e =>
                onUpdateTheoryConfig({
                  ...theoryConfig,
                  weights: {
                    ...theoryConfig.weights,
                    cadenceResolution: parseFloat(e.target.value),
                  },
                })
              }
              className="w-full accent-amber-400"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-300">Rhythmic Groove &amp; Syncopation</span>
              <span className="font-mono text-indigo-400">
                {(theoryConfig.weights.rhythmicVariety * 100).toFixed(0)}%
              </span>
            </div>
            <input
              type="range"
              min="0.05"
              max="0.4"
              step="0.05"
              value={theoryConfig.weights.rhythmicVariety}
              onChange={e =>
                onUpdateTheoryConfig({
                  ...theoryConfig,
                  weights: {
                    ...theoryConfig.weights,
                    rhythmicVariety: parseFloat(e.target.value),
                  },
                })
              }
              className="w-full accent-indigo-400"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-300">Downbeat Consonance &amp; Extensions</span>
              <span className="font-mono text-teal-400">
                {(theoryConfig.weights.harmonicConsonance * 100).toFixed(0)}%
              </span>
            </div>
            <input
              type="range"
              min="0.05"
              max="0.3"
              step="0.05"
              value={theoryConfig.weights.harmonicConsonance}
              onChange={e =>
                onUpdateTheoryConfig({
                  ...theoryConfig,
                  weights: {
                    ...theoryConfig.weights,
                    harmonicConsonance: parseFloat(e.target.value),
                  },
                })
              }
              className="w-full accent-teal-400"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-300">Motif Recall &amp; Sequence Expansion</span>
              <span className="font-mono text-purple-400">
                {(theoryConfig.weights.motifCoherence * 100).toFixed(0)}%
              </span>
            </div>
            <input
              type="range"
              min="0.05"
              max="0.3"
              step="0.05"
              value={theoryConfig.weights.motifCoherence}
              onChange={e =>
                onUpdateTheoryConfig({
                  ...theoryConfig,
                  weights: {
                    ...theoryConfig.weights,
                    motifCoherence: parseFloat(e.target.value),
                  },
                })
              }
              className="w-full accent-purple-400"
            />
          </div>
        </div>
      </div>

      {/* GRU Evolutionary Parameters */}
      <div className="pt-3 border-t border-slate-800">
        <span className="text-xs font-semibold text-slate-300 block mb-3">
          Evolutionary GRU Parameters:
        </span>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
          <div>
            <label className="text-slate-400 block mb-1">Population Size:</label>
            <select
              value={evoConfig.populationSize}
              onChange={e =>
                onUpdateEvoConfig({
                  ...evoConfig,
                  populationSize: parseInt(e.target.value, 10),
                })
              }
              className="w-full bg-slate-950 border border-slate-700 rounded p-1.5 text-slate-200 font-mono"
            >
              <option value={8}>8 models</option>
              <option value={16}>16 models</option>
              <option value={24}>24 models</option>
              <option value={32}>32 models</option>
            </select>
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Snippet Length:</label>
            <select
              value={evoConfig.snippetLengthSteps}
              onChange={e =>
                onUpdateEvoConfig({
                  ...evoConfig,
                  snippetLengthSteps: parseInt(e.target.value, 10),
                })
              }
              className="w-full bg-slate-950 border border-slate-700 rounded p-1.5 text-slate-200 font-mono"
            >
              <option value={16}>1 Bar (16 steps)</option>
              <option value={32}>2 Bars (32 steps)</option>
              <option value={64}>4 Bars (64 steps)</option>
            </select>
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Mutation Rate:</label>
            <input
              type="range"
              min="0.02"
              max="0.25"
              step="0.02"
              value={evoConfig.mutationRate}
              onChange={e =>
                onUpdateEvoConfig({
                  ...evoConfig,
                  mutationRate: parseFloat(e.target.value),
                })
              }
              className="w-full accent-emerald-400"
            />
            <span className="text-[11px] font-mono text-slate-400">
              {(evoConfig.mutationRate * 100).toFixed(0)}%
            </span>
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Elite Survivors:</label>
            <select
              value={evoConfig.eliteCount}
              onChange={e =>
                onUpdateEvoConfig({
                  ...evoConfig,
                  eliteCount: parseInt(e.target.value, 10),
                })
              }
              className="w-full bg-slate-950 border border-slate-700 rounded p-1.5 text-slate-200 font-mono"
            >
              <option value={1}>1 Champion strictly survives</option>
              <option value={2}>Top 2 survive</option>
              <option value={3}>Top 3 survive</option>
              <option value={4}>Top 4 survive</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  );
};
