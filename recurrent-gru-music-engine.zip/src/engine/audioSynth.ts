import { NoteEvent, SynthInstrument, TheoryConfig } from '../types/music';
import { RecurrentGRUModel } from './gru';

function midiToFrequency(midi: number): number {
  return 440 * Math.pow(2, (midi - 69) / 12);
}

export class AudioSynthEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private filterNode: BiquadFilterNode | null = null;
  private delayNode: DelayNode | null = null;
  private delayFeedback: GainNode | null = null;
  private isMuted: boolean = false;
  private instrument: SynthInstrument = 'rhodes';
  private volume: number = 0.55;

  // Active snippet audition state
  private snippetTimeouts: number[] = [];
  public isAuditioning: boolean = false;
  public auditioningSnippetId: string | null = null;
  public currentAuditionStep: number = -1;

  // Continuous playback state
  public isContinuousPlaying: boolean = false;
  private continuousTimer: number | null = null;
  private continuousStep: number = 0;
  private continuousModel: RecurrentGRUModel | null = null;
  private continuousLastPitch: number = 60;
  private continuousLastDur: number = 2;
  public continuousBpm: number = 108;
  private continuousTheory: TheoryConfig | null = null;
  public onContinuousEvent?: (note: NoteEvent, step: number, chordName?: string) => void;
  public onContinuousStepTick?: (step: number) => void;

  constructor() {
    // AudioContext will be lazily created on user interaction
  }

  private initAudio(): void {
    if (this.ctx && this.ctx.state !== 'closed') {
      if (this.ctx.state === 'suspended') {
        this.ctx.resume();
      }
      return;
    }

    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    this.ctx = new AudioContextClass();

    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.setValueAtTime(this.isMuted ? 0 : this.volume, this.ctx.currentTime);

    // Warm Lowpass Filter
    this.filterNode = this.ctx.createBiquadFilter();
    this.filterNode.type = 'lowpass';
    this.filterNode.frequency.setValueAtTime(4200, this.ctx.currentTime);
    this.filterNode.Q.setValueAtTime(1.2, this.ctx.currentTime);

    // Subtle Stereo Delay / Reverb space
    this.delayNode = this.ctx.createDelay();
    this.delayNode.delayTime.setValueAtTime(0.24, this.ctx.currentTime);

    this.delayFeedback = this.ctx.createGain();
    this.delayFeedback.gain.setValueAtTime(0.25, this.ctx.currentTime);

    // Routing: Sound -> Filter -> Master -> Out
    //                  \-> Delay -> DelayFeedback -> Delay & Master
    this.filterNode.connect(this.masterGain);
    this.filterNode.connect(this.delayNode);
    this.delayNode.connect(this.delayFeedback);
    this.delayFeedback.connect(this.delayNode);
    this.delayFeedback.connect(this.masterGain);

    this.masterGain.connect(this.ctx.destination);
  }

  public setVolume(vol: number): void {
    this.volume = Math.max(0, Math.min(1, vol));
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(this.isMuted ? 0 : this.volume, this.ctx.currentTime);
    }
  }

  public setMuted(muted: boolean): void {
    this.isMuted = muted;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(muted ? 0 : this.volume, this.ctx.currentTime);
    }
  }

  public setInstrument(inst: SynthInstrument): void {
    this.instrument = inst;
  }

  public getInstrument(): SynthInstrument {
    return this.instrument;
  }

  // Play a single note
  public triggerNote(
    pitch: number,
    durationSeconds: number,
    velocity = 0.8,
    isBassOrChord = false
  ): void {
    if (pitch <= 0 || this.isMuted) return;
    this.initAudio();
    if (!this.ctx || !this.filterNode) return;

    const now = this.ctx.currentTime;
    const freq = midiToFrequency(pitch);

    const voiceGain = this.ctx.createGain();
    voiceGain.connect(this.filterNode);

    const adjustedVel = Math.max(0.1, Math.min(1.0, velocity)) * (isBassOrChord ? 0.35 : 0.7);

    switch (this.instrument) {
      case 'rhodes': {
        // Dual sine + gentle triangle for warm electric tine
        const osc1 = this.ctx.createOscillator();
        const osc2 = this.ctx.createOscillator();
        osc1.type = 'sine';
        osc2.type = 'triangle';
        osc1.frequency.setValueAtTime(freq, now);
        osc2.frequency.setValueAtTime(freq * 2, now); // 2nd harmonic overtone

        const osc2Gain = this.ctx.createGain();
        osc2Gain.gain.setValueAtTime(0.2, now);
        osc2Gain.gain.exponentialRampToValueAtTime(0.001, now + Math.min(0.3, durationSeconds));

        osc1.connect(voiceGain);
        osc2.connect(osc2Gain);
        osc2Gain.connect(voiceGain);

        voiceGain.gain.setValueAtTime(0.001, now);
        voiceGain.gain.exponentialRampToValueAtTime(adjustedVel * 0.45, now + 0.015);
        voiceGain.gain.exponentialRampToValueAtTime(adjustedVel * 0.25, now + 0.12);
        voiceGain.gain.exponentialRampToValueAtTime(0.0001, now + durationSeconds + 0.1);

        osc1.start(now);
        osc2.start(now);
        osc1.stop(now + durationSeconds + 0.15);
        osc2.stop(now + durationSeconds + 0.15);
        break;
      }

      case 'piano': {
        // Warm upright acoustic emulation with slight detune
        const osc1 = this.ctx.createOscillator();
        const osc2 = this.ctx.createOscillator();
        osc1.type = 'triangle';
        osc2.type = 'sine';
        osc1.frequency.setValueAtTime(freq, now);
        osc2.frequency.setValueAtTime(freq + 0.6, now);

        osc1.connect(voiceGain);
        osc2.connect(voiceGain);

        voiceGain.gain.setValueAtTime(0.001, now);
        voiceGain.gain.exponentialRampToValueAtTime(adjustedVel * 0.5, now + 0.01);
        voiceGain.gain.exponentialRampToValueAtTime(adjustedVel * 0.2, now + 0.25);
        voiceGain.gain.exponentialRampToValueAtTime(0.0001, now + durationSeconds + 0.25);

        osc1.start(now);
        osc2.start(now);
        osc1.stop(now + durationSeconds + 0.3);
        osc2.stop(now + durationSeconds + 0.3);
        break;
      }

      case 'analog_synth': {
        // Rich analog sawtooth with dynamic filter sweep
        const osc = this.ctx.createOscillator();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(freq, now);

        const sub = this.ctx.createOscillator();
        sub.type = 'square';
        sub.frequency.setValueAtTime(freq / 2, now);
        const subGain = this.ctx.createGain();
        subGain.gain.setValueAtTime(0.18, now);
        sub.connect(subGain);
        subGain.connect(voiceGain);

        osc.connect(voiceGain);

        voiceGain.gain.setValueAtTime(0.001, now);
        voiceGain.gain.exponentialRampToValueAtTime(adjustedVel * 0.38, now + 0.02);
        voiceGain.gain.linearRampToValueAtTime(adjustedVel * 0.25, now + durationSeconds * 0.6);
        voiceGain.gain.exponentialRampToValueAtTime(0.0001, now + durationSeconds + 0.08);

        osc.start(now);
        sub.start(now);
        osc.stop(now + durationSeconds + 0.1);
        sub.stop(now + durationSeconds + 0.1);
        break;
      }

      case 'ambient_chime': {
        // Celestial glass sine with bell attack
        const osc1 = this.ctx.createOscillator();
        const osc2 = this.ctx.createOscillator();
        osc1.type = 'sine';
        osc2.type = 'sine';
        osc1.frequency.setValueAtTime(freq, now);
        osc2.frequency.setValueAtTime(freq * 3.01, now); // chime overtone

        const bellGain = this.ctx.createGain();
        bellGain.gain.setValueAtTime(0.25, now);
        bellGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.4);

        osc1.connect(voiceGain);
        osc2.connect(bellGain);
        bellGain.connect(voiceGain);

        voiceGain.gain.setValueAtTime(0.001, now);
        voiceGain.gain.linearRampToValueAtTime(adjustedVel * 0.42, now + 0.04);
        voiceGain.gain.exponentialRampToValueAtTime(0.0001, now + durationSeconds + 0.4);

        osc1.start(now);
        osc2.start(now);
        osc1.stop(now + durationSeconds + 0.45);
        osc2.stop(now + durationSeconds + 0.45);
        break;
      }

      case 'marimba':
      default: {
        // Woody mallet tone with fast wooden transient
        const osc = this.ctx.createOscillator();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now);
        osc.connect(voiceGain);

        voiceGain.gain.setValueAtTime(0.001, now);
        voiceGain.gain.exponentialRampToValueAtTime(adjustedVel * 0.55, now + 0.006);
        voiceGain.gain.exponentialRampToValueAtTime(0.0001, now + Math.min(0.6, durationSeconds + 0.05));

        osc.start(now);
        osc.stop(now + Math.min(0.65, durationSeconds + 0.1));
        break;
      }
    }
  }

  // Play an entire candidate snippet for user auditioning
  public playSnippet(
    snippetId: string,
    notes: NoteEvent[],
    bpm = 110,
    onStep?: (step: number) => void,
    onFinish?: () => void
  ): void {
    this.stopAudition();
    this.initAudio();

    this.isAuditioning = true;
    this.auditioningSnippetId = snippetId;

    const secondsPer16th = 60 / bpm / 4;
    const maxStep = Math.max(...notes.map(n => n.time + n.duration), 16);

    // Schedule each note
    for (const note of notes) {
      const delayMs = note.time * secondsPer16th * 1000;
      const durSec = note.duration * secondsPer16th * 0.95;

      const tId = window.setTimeout(() => {
        if (!this.isAuditioning) return;
        this.currentAuditionStep = note.time;
        if (onStep) onStep(note.time);
        if (note.pitch > 0) {
          this.triggerNote(note.pitch, durSec, note.velocity);
        }
      }, delayMs);
      this.snippetTimeouts.push(tId);
    }

    // Schedule completion
    const endMs = maxStep * secondsPer16th * 1000 + 300;
    const endTid = window.setTimeout(() => {
      this.isAuditioning = false;
      this.auditioningSnippetId = null;
      this.currentAuditionStep = -1;
      if (onFinish) onFinish();
    }, endMs);
    this.snippetTimeouts.push(endTid);
  }

  public stopAudition(): void {
    this.isAuditioning = false;
    this.auditioningSnippetId = null;
    this.currentAuditionStep = -1;
    for (const t of this.snippetTimeouts) {
      clearTimeout(t);
    }
    this.snippetTimeouts = [];
  }

  // CONTINUOUS MUSIC STREAMING: Champion Recurrent Model continuous live generation
  public startContinuous(
    model: RecurrentGRUModel,
    bpm = 108,
    theoryConfig?: TheoryConfig,
    temperature = 0.88
  ): void {
    this.stopContinuous();
    this.stopAudition();
    this.initAudio();

    this.isContinuousPlaying = true;
    this.continuousModel = model;
    this.continuousBpm = bpm;
    this.continuousTheory = theoryConfig || null;
    this.continuousStep = 0;
    this.continuousLastPitch = 60;
    this.continuousLastDur = 2;

    const secondsPer16th = 60 / bpm / 4;

    const playLoop = () => {
      if (!this.isContinuousPlaying || !this.continuousModel) return;

      // Generate next note recurrently from GRU model
      const note = this.continuousModel.generateNextNote(
        this.continuousStep,
        this.continuousLastPitch,
        this.continuousLastDur,
        temperature
      );

      const noteDurationSec = note.duration * secondsPer16th * 0.92;
      const stepWaitMs = note.duration * secondsPer16th * 1000;

      // Play melody note
      if (note.pitch > 0) {
        this.triggerNote(note.pitch, noteDurationSec, note.velocity);
      }

      // Play soft harmonic accompaniment (bass note / chord pad) on strong measure boundaries
      const isDownbeat = this.continuousStep % 16 === 0;
      let chordName = '';
      if (isDownbeat && this.continuousTheory) {
        // Derive root and 5th bass accompaniment for fullness
        const barIdx = Math.floor(this.continuousStep / 16) % 4;
        // Standard harmonic progressions in chosen key (e.g. I - vi - IV - V)
        const roots = [0, 9, 5, 7]; // degree offsets
        const bassPitch = 36 + ((this.continuousTheory.rootNote + roots[barIdx]) % 12);
        this.triggerNote(bassPitch, secondsPer16th * 8, 0.45, true);
        this.triggerNote(bassPitch + 7, secondsPer16th * 8, 0.35, true); // 5th
        chordName = `Degree ${barIdx === 0 ? 'I' : barIdx === 1 ? 'vi' : barIdx === 2 ? 'IV' : 'V'}`;
      }

      if (this.onContinuousEvent) {
        this.onContinuousEvent(note, this.continuousStep, chordName);
      }
      if (this.onContinuousStepTick) {
        this.onContinuousStepTick(this.continuousStep);
      }

      this.continuousLastPitch = note.pitch;
      this.continuousLastDur = note.duration;
      this.continuousStep += note.duration;

      this.continuousTimer = window.setTimeout(playLoop, stepWaitMs);
    };

    playLoop();
  }

  public stopContinuous(): void {
    this.isContinuousPlaying = false;
    if (this.continuousTimer !== null) {
      clearTimeout(this.continuousTimer);
      this.continuousTimer = null;
    }
  }
}
