import { CandidateSnippet, EvolutionConfig, GenerationHistoryPoint, TheoryConfig } from '../types/music';
import { RecurrentGRUModel } from './gru';
import { evaluateSnippet } from './musicTheory';

export interface PopulationMember {
  model: RecurrentGRUModel;
  currentSnippet: CandidateSnippet | null;
}

export class EvolutionEngine {
  public generation: number = 0;
  public population: PopulationMember[] = [];
  public championModel: RecurrentGRUModel;
  public championSnippet: CandidateSnippet | null = null;
  public history: GenerationHistoryPoint[] = [];
  public hallOfFame: CandidateSnippet[] = [];

  public evoConfig: EvolutionConfig = {
    populationSize: 16,
    snippetLengthSteps: 32, // 2 bars of 4/4
    mutationRate: 0.12,
    mutationStrength: 0.2,
    temperature: 0.95,
    crossoverRate: 0.4,
    eliteCount: 3,
    complexityTarget: 'complex',
    survivalThreshold: 68,
  };

  public theoryConfig: TheoryConfig;
  public isQuietEvolving: boolean = false;
  private evolveTimer: number | null = null;
  public onGenerationComplete?: (gen: number, champion: CandidateSnippet, avgFitness: number) => void;

  constructor(theoryConfig: TheoryConfig, evoConfig?: Partial<EvolutionConfig>) {
    this.theoryConfig = theoryConfig;
    if (evoConfig) {
      this.evoConfig = { ...this.evoConfig, ...evoConfig };
    }

    // Initialize first population with random GRUs
    this.championModel = new RecurrentGRUModel('champion_init');
    this.initPopulation();
  }

  public initPopulation(): void {
    this.population = [];
    this.generation = 0;
    this.history = [];
    this.hallOfFame = [];

    for (let i = 0; i < this.evoConfig.populationSize; i++) {
      const model = new RecurrentGRUModel(`gru_gen0_${i}`);
      this.population.push({
        model,
        currentSnippet: null,
      });
    }

    // Evaluate generation 0
    this.evaluateGeneration();
  }

  // Evaluates all members in the current generation against sophisticated music theory adjudicator
  public evaluateGeneration(): void {
    let totalFitness = 0;
    let totalScale = 0;
    let totalVoice = 0;
    let totalComplexity = 0;
    let passCount = 0;

    // Dynamically adjust temperature based on complexityTarget
    let effectiveTemp = this.evoConfig.temperature;
    if (this.evoConfig.complexityTarget === 'virtuoso') {
      effectiveTemp = Math.max(1.05, effectiveTemp * 1.15);
    } else if (this.evoConfig.complexityTarget === 'moderate') {
      effectiveTemp = Math.min(0.8, effectiveTemp * 0.9);
    }

    for (let i = 0; i < this.population.length; i++) {
      const member = this.population[i];
      const notes = member.model.generateSnippet(
        this.evoConfig.snippetLengthSteps,
        effectiveTemp
      );

      const evaluation = evaluateSnippet(
        notes,
        this.theoryConfig,
        this.evoConfig.snippetLengthSteps
      );

      // Adjudicator threshold check: snippet passes if fitness meets threshold and theory rules
      const passed = evaluation.fitness >= this.evoConfig.survivalThreshold && evaluation.passed;

      const snippet: CandidateSnippet = {
        id: `cand_g${this.generation}_${i}_${Math.random().toString(36).slice(2, 6)}`,
        generation: this.generation,
        notes,
        lengthSteps: this.evoConfig.snippetLengthSteps,
        fitness: evaluation.fitness,
        passed,
        complexityScore: evaluation.complexityScore,
        breakdown: evaluation.breakdown,
        theoryNotes: evaluation.feedback,
        adjudicatorComments: evaluation.adjudicatorComments,
        gruId: member.model.id,
      };

      member.currentSnippet = snippet;
      totalFitness += snippet.fitness;
      totalScale += snippet.breakdown.scaleFidelity;
      totalVoice += snippet.breakdown.voiceLeading;
      totalComplexity += snippet.complexityScore;
      if (passed) passCount++;
    }

    // Sort population descending:
    // 1st priority: Passed Adjudicator
    // 2nd priority: Fitness Score
    // 3rd priority: Melodic Complexity Score
    this.population.sort((a, b) => {
      const sa = a.currentSnippet;
      const sb = b.currentSnippet;
      if (!sa || !sb) return 0;
      if (sa.passed !== sb.passed) {
        return sa.passed ? -1 : 1; // Passed models strictly rise above failed models
      }
      return sb.fitness - sa.fitness;
    });

    const bestMember = this.population[0];
    if (bestMember.currentSnippet) {
      if (!this.championSnippet || bestMember.currentSnippet.fitness >= this.championSnippet.fitness) {
        this.championModel = bestMember.model.clone(`champ_g${this.generation}`);
        this.championSnippet = bestMember.currentSnippet;

        // Keep top entries in hall of fame
        if (!this.hallOfFame.some(s => s.id === bestMember.currentSnippet?.id)) {
          this.hallOfFame.unshift(bestMember.currentSnippet);
          if (this.hallOfFame.length > 12) this.hallOfFame.pop();
        }
      }
    }

    const avgFitness = Math.round((totalFitness / this.population.length) * 10) / 10;
    const avgScale = Math.round((totalScale / this.population.length) * 10) / 10;
    const avgVoice = Math.round((totalVoice / this.population.length) * 10) / 10;
    const avgComplexity = Math.round((totalComplexity / this.population.length) * 10) / 10;
    const passRate = Math.round((passCount / this.population.length) * 100);

    this.history.push({
      generation: this.generation,
      bestFitness: this.population[0].currentSnippet?.fitness || 0,
      avgFitness,
      passRate,
      avgComplexity,
      scaleScore: avgScale,
      voiceLeadingScore: avgVoice,
    });

    if (this.history.length > 120) {
      this.history.shift();
    }

    if (this.onGenerationComplete && this.population[0].currentSnippet) {
      this.onGenerationComplete(this.generation, this.population[0].currentSnippet, avgFitness);
    }
  }

  // Evolutionary Step: Selection, Crossover, Mutation -> Next Generation
  // "THE APPROACH SURVIVES": strictly passed adjudicator models survive to seed next gen
  public stepGeneration(): void {
    const eliteCount = Math.max(1, Math.min(this.evoConfig.eliteCount, this.population.length));
    const nextPopulation: PopulationMember[] = [];

    // Filter survivors that passed or are at top of hierarchy
    const passedSurvivors = this.population.filter(p => p.currentSnippet?.passed);
    const candidatePool = passedSurvivors.length >= 2 ? passedSurvivors : this.population.slice(0, 6);

    // 1. Elitism: Keep top N models unchanged so tested champion approaches strictly survive
    for (let i = 0; i < eliteCount; i++) {
      const eliteModel = this.population[i].model.clone(`elite_g${this.generation + 1}_${i}`);
      nextPopulation.push({
        model: eliteModel,
        currentSnippet: null,
      });
    }

    // 2. Tournament selection & Breeding from the surviving candidate pool
    while (nextPopulation.length < this.evoConfig.populationSize) {
      const parentA = this.tournamentSelectFromPool(candidatePool);
      const parentB = this.tournamentSelectFromPool(candidatePool);

      let childModel: RecurrentGRUModel;
      if (Math.random() < this.evoConfig.crossoverRate) {
        childModel = parentA.crossover(parentB);
      } else {
        childModel = parentA.clone();
      }

      // Mutate
      childModel.mutate(this.evoConfig.mutationRate, this.evoConfig.mutationStrength);
      nextPopulation.push({
        model: childModel,
        currentSnippet: null,
      });
    }

    this.population = nextPopulation;
    this.generation++;
    this.evaluateGeneration();
  }

  // Tournament selection among survivor pool
  private tournamentSelectFromPool(pool: PopulationMember[]): RecurrentGRUModel {
    const k = Math.min(3, pool.length);
    let best = pool[Math.floor(Math.random() * pool.length)];
    for (let i = 1; i < k; i++) {
      const cand = pool[Math.floor(Math.random() * pool.length)];
      if ((cand.currentSnippet?.fitness || 0) > (best.currentSnippet?.fitness || 0)) {
        best = cand;
      }
    }
    return best.model;
  }

  // Turbo Evolve: silently evolve N generations at high speed
  public turboEvolve(generations = 25): void {
    for (let i = 0; i < generations; i++) {
      this.stepGeneration();
    }
  }

  // Quiet Mode continuous runner
  public startQuietMode(stepsPerSecond = 6): void {
    if (this.isQuietEvolving) return;
    this.isQuietEvolving = true;

    const intervalMs = Math.max(15, Math.floor(1000 / stepsPerSecond));
    const loop = () => {
      if (!this.isQuietEvolving) return;
      this.stepGeneration();
      this.evolveTimer = window.setTimeout(loop, intervalMs);
    };
    this.evolveTimer = window.setTimeout(loop, intervalMs);
  }

  public stopQuietMode(): void {
    this.isQuietEvolving = false;
    if (this.evolveTimer !== null) {
      clearTimeout(this.evolveTimer);
      this.evolveTimer = null;
    }
  }

  // Set user manual champion override
  public crownAsChampion(snippet: CandidateSnippet): void {
    const member = this.population.find(m => m.currentSnippet?.id === snippet.id);
    if (member) {
      this.championModel = member.model.clone(`user_champion_${Date.now()}`);
      this.championSnippet = snippet;
    }
  }

  // Generate a long snippet from the champion model
  public generateLongChampionSnippet(lengthSteps = 64): CandidateSnippet {
    let effectiveTemp = this.evoConfig.temperature;
    if (this.evoConfig.complexityTarget === 'virtuoso') effectiveTemp *= 1.1;

    const notes = this.championModel.generateSnippet(lengthSteps, effectiveTemp);
    const evalResult = evaluateSnippet(notes, this.theoryConfig, lengthSteps);

    const passed = evalResult.fitness >= this.evoConfig.survivalThreshold && evalResult.passed;

    return {
      id: `long_champ_${Date.now()}`,
      generation: this.generation,
      notes,
      lengthSteps,
      fitness: evalResult.fitness,
      passed,
      complexityScore: evalResult.complexityScore,
      breakdown: evalResult.breakdown,
      theoryNotes: evalResult.feedback,
      adjudicatorComments: evalResult.adjudicatorComments,
      gruId: this.championModel.id,
    };
  }
}
