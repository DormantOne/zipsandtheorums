import { NoteEvent, GRUWeights } from '../types/music';

// Pitch token range: 0 is Rest, 1..36 map to MIDI 48 (C3) through 84 (C6)
export const MIN_MIDI = 48;
export const MAX_MIDI = 84;
export const PITCH_COUNT = MAX_MIDI - MIN_MIDI + 1; // 37 pitches
export const NUM_PITCH_TOKENS = PITCH_COUNT + 1; // 0 = rest, 1..37 = pitches (38 tokens total)

// Duration tokens: 1 (16th), 2 (8th), 3 (dotted 8th), 4 (quarter), 6 (dotted quarter), 8 (half)
export const DURATION_STEPS = [1, 2, 3, 4, 6, 8];

// Input size:
// - pitch one-hot or embedding features (38)
// - current step in 16-step bar normalized (1)
// - beat phase sin/cos (2)
// - previous duration normalized (1)
// Total inputSize = 38 + 1 + 2 + 1 = 42
export const INPUT_SIZE = 42;
export const HIDDEN_SIZE = 32;
// Output size: NUM_PITCH_TOKENS (38) + DURATION_STEPS.length (6) + 1 velocity = 45 outputs
export const OUTPUT_SIZE = NUM_PITCH_TOKENS + DURATION_STEPS.length;

function sigmoid(x: number): number {
  return 1 / (1 + Math.exp(-Math.max(-15, Math.min(15, x))));
}

function randn(): number {
  let u = 0, v = 0;
  while (u === 0) u = Math.random();
  while (v === 0) v = Math.random();
  return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
}

function createMatrix(rows: number, cols: number, scale = 0.2): number[][] {
  const mat: number[][] = [];
  for (let i = 0; i < rows; i++) {
    const row = new Float64Array(cols);
    for (let j = 0; j < cols; j++) {
      row[j] = randn() * scale;
    }
    mat.push(Array.from(row));
  }
  return mat;
}

function createVector(size: number, val = 0): number[] {
  return new Array(size).fill(val);
}

export class RecurrentGRUModel {
  public id: string;
  public weights: GRUWeights;
  public hiddenState: number[];
  public lastActivations: {
    rGate: number[];
    zGate: number[];
    hCand: number[];
    hidden: number[];
    pitchProbs: number[];
  };

  constructor(id?: string, weights?: GRUWeights) {
    this.id = id || `gru_${Math.random().toString(36).substring(2, 9)}`;
    this.hiddenState = createVector(HIDDEN_SIZE, 0);
    this.lastActivations = {
      rGate: createVector(HIDDEN_SIZE, 0.5),
      zGate: createVector(HIDDEN_SIZE, 0.5),
      hCand: createVector(HIDDEN_SIZE, 0),
      hidden: createVector(HIDDEN_SIZE, 0),
      pitchProbs: createVector(NUM_PITCH_TOKENS, 1 / NUM_PITCH_TOKENS),
    };

    if (weights) {
      this.weights = weights;
    } else {
      const H = HIDDEN_SIZE;
      const I = INPUT_SIZE;
      const O = OUTPUT_SIZE;
      this.weights = {
        hiddenSize: H,
        inputSize: I,
        outputSize: O,
        Wxr: createMatrix(H, I, 0.25),
        Whr: createMatrix(H, H, 0.2),
        br: createVector(H, 0),
        Wxz: createMatrix(H, I, 0.25),
        Whz: createMatrix(H, H, 0.2),
        bz: createVector(H, 0.5), // slight bias to retain state
        Wxh: createMatrix(H, I, 0.25),
        Whh: createMatrix(H, H, 0.2),
        bh: createVector(H, 0),
        Why: createMatrix(O, H, 0.3),
        by: createVector(O, 0),
      };
    }
  }

  public resetHidden(): void {
    this.hiddenState = createVector(HIDDEN_SIZE, 0);
  }

  public clone(newId?: string): RecurrentGRUModel {
    const cloneWeights: GRUWeights = {
      hiddenSize: this.weights.hiddenSize,
      inputSize: this.weights.inputSize,
      outputSize: this.weights.outputSize,
      Wxr: this.weights.Wxr.map(r => [...r]),
      Whr: this.weights.Whr.map(r => [...r]),
      br: [...this.weights.br],
      Wxz: this.weights.Wxz.map(r => [...r]),
      Whz: this.weights.Whz.map(r => [...r]),
      bz: [...this.weights.bz],
      Wxh: this.weights.Wxh.map(r => [...r]),
      Whh: this.weights.Whh.map(r => [...r]),
      bh: [...this.weights.bh],
      Why: this.weights.Why.map(r => [...r]),
      by: [...this.weights.by],
    };
    return new RecurrentGRUModel(newId, cloneWeights);
  }

  public mutate(rate = 0.08, strength = 0.15): void {
    const mutateMat = (mat: number[][]) => {
      for (let i = 0; i < mat.length; i++) {
        for (let j = 0; j < mat[i].length; j++) {
          if (Math.random() < rate) {
            mat[i][j] += randn() * strength;
          }
        }
      }
    };

    const mutateVec = (vec: number[]) => {
      for (let i = 0; i < vec.length; i++) {
        if (Math.random() < rate) {
          vec[i] += randn() * strength;
        }
      }
    };

    mutateMat(this.weights.Wxr);
    mutateMat(this.weights.Whr);
    mutateVec(this.weights.br);
    mutateMat(this.weights.Wxz);
    mutateMat(this.weights.Whz);
    mutateVec(this.weights.bz);
    mutateMat(this.weights.Wxh);
    mutateMat(this.weights.Whh);
    mutateVec(this.weights.bh);
    mutateMat(this.weights.Why);
    mutateVec(this.weights.by);
  }

  public crossover(other: RecurrentGRUModel): RecurrentGRUModel {
    const child = this.clone();
    const crossMat = (target: number[][], src: number[][]) => {
      for (let i = 0; i < target.length; i++) {
        for (let j = 0; j < target[i].length; j++) {
          if (Math.random() > 0.5) {
            target[i][j] = src[i][j];
          }
        }
      }
    };
    const crossVec = (target: number[], src: number[]) => {
      for (let i = 0; i < target.length; i++) {
        if (Math.random() > 0.5) {
          target[i] = src[i];
        }
      }
    };

    crossMat(child.weights.Wxr, other.weights.Wxr);
    crossMat(child.weights.Whr, other.weights.Whr);
    crossVec(child.weights.br, other.weights.br);
    crossMat(child.weights.Wxz, other.weights.Wxz);
    crossMat(child.weights.Whz, other.weights.Whz);
    crossVec(child.weights.bz, other.weights.bz);
    crossMat(child.weights.Wxh, other.weights.Wxh);
    crossMat(child.weights.Whh, other.weights.Whh);
    crossVec(child.weights.bh, other.weights.bh);
    crossMat(child.weights.Why, other.weights.Why);
    crossVec(child.weights.by, other.weights.by);

    return child;
  }

  // Encode input feature vector
  public buildInputVector(pitch: number, step: number, duration: number): number[] {
    const x = createVector(INPUT_SIZE, 0);
    // Pitch token
    let token = 0;
    if (pitch >= MIN_MIDI && pitch <= MAX_MIDI) {
      token = pitch - MIN_MIDI + 1;
    }
    x[token] = 1.0;

    // Metric phase features
    const barStep = step % 16;
    x[NUM_PITCH_TOKENS] = barStep / 16.0;
    const angle = (2 * Math.PI * barStep) / 16.0;
    x[NUM_PITCH_TOKENS + 1] = Math.sin(angle);
    x[NUM_PITCH_TOKENS + 2] = Math.cos(angle);

    // Duration normalized
    x[NUM_PITCH_TOKENS + 3] = Math.min(1.0, duration / 8.0);

    return x;
  }

  // Forward step: updates hidden state and returns logits
  public step(x: number[]): { logits: number[]; rGate: number[]; zGate: number[]; hCand: number[] } {
    const H = HIDDEN_SIZE;
    const w = this.weights;
    const hPrev = this.hiddenState;

    const r = new Array(H);
    const z = new Array(H);
    const hCand = new Array(H);
    const hNext = new Array(H);

    // 1. Reset gate: r = sigmoid(Wxr * x + Whr * hPrev + br)
    for (let i = 0; i < H; i++) {
      let sum = w.br[i];
      const wxrRow = w.Wxr[i];
      for (let j = 0; j < INPUT_SIZE; j++) sum += wxrRow[j] * x[j];
      const whrRow = w.Whr[i];
      for (let j = 0; j < H; j++) sum += whrRow[j] * hPrev[j];
      r[i] = sigmoid(sum);
    }

    // 2. Update gate: z = sigmoid(Wxz * x + Whz * hPrev + bz)
    for (let i = 0; i < H; i++) {
      let sum = w.bz[i];
      const wxzRow = w.Wxz[i];
      for (let j = 0; j < INPUT_SIZE; j++) sum += wxzRow[j] * x[j];
      const whzRow = w.Whz[i];
      for (let j = 0; j < H; j++) sum += whzRow[j] * hPrev[j];
      z[i] = sigmoid(sum);
    }

    // 3. Candidate hidden: hCand = tanh(Wxh * x + Whh * (r .* hPrev) + bh)
    for (let i = 0; i < H; i++) {
      let sum = w.bh[i];
      const wxhRow = w.Wxh[i];
      for (let j = 0; j < INPUT_SIZE; j++) sum += wxhRow[j] * x[j];
      const whhRow = w.Whh[i];
      for (let j = 0; j < H; j++) sum += whhRow[j] * (r[j] * hPrev[j]);
      hCand[i] = Math.tanh(sum);
    }

    // 4. New hidden: hNext = (1 - z) .* hPrev + z .* hCand
    for (let i = 0; i < H; i++) {
      hNext[i] = (1.0 - z[i]) * hPrev[i] + z[i] * hCand[i];
    }
    this.hiddenState = hNext;

    // 5. Output projection: logits = Why * hNext + by
    const logits = new Array(OUTPUT_SIZE);
    for (let i = 0; i < OUTPUT_SIZE; i++) {
      let sum = w.by[i];
      const whyRow = w.Why[i];
      for (let j = 0; j < H; j++) sum += whyRow[j] * hNext[j];
      logits[i] = sum;
    }

    // Save activations for UI neural visualization
    const pitchLogits = logits.slice(0, NUM_PITCH_TOKENS);
    const pitchProbs = softmax(pitchLogits, 1.0);
    this.lastActivations = {
      rGate: r,
      zGate: z,
      hCand: hCand,
      hidden: hNext,
      pitchProbs: pitchProbs,
    };

    return { logits, rGate: r, zGate: z, hCand };
  }

  // Generate a complete snippet
  public generateSnippet(totalSteps: number, temperature = 1.0): NoteEvent[] {
    this.resetHidden();
    const notes: NoteEvent[] = [];
    let currentStep = 0;

    let lastPitch = 60; // Start around Middle C
    let lastDur = 2; // start with 8th note

    while (currentStep < totalSteps) {
      const inputVector = this.buildInputVector(lastPitch, currentStep, lastDur);
      const { logits } = this.step(inputVector);

      // Pitch logits & sampling
      const pitchLogits = logits.slice(0, NUM_PITCH_TOKENS);
      const pitchProbs = softmax(pitchLogits, temperature);
      const chosenPitchToken = sampleFromProbs(pitchProbs);

      let pitch = 0;
      if (chosenPitchToken > 0) {
        pitch = MIN_MIDI + (chosenPitchToken - 1);
      }

      // Duration logits & sampling
      const durLogits = logits.slice(NUM_PITCH_TOKENS, NUM_PITCH_TOKENS + DURATION_STEPS.length);
      const durProbs = softmax(durLogits, temperature);
      const chosenDurIndex = sampleFromProbs(durProbs);
      let duration = DURATION_STEPS[chosenDurIndex] || 2;

      // Bound duration to fit within totalSteps
      if (currentStep + duration > totalSteps) {
        duration = Math.max(1, totalSteps - currentStep);
      }

      const velocity = pitch === 0 ? 0 : 0.65 + Math.random() * 0.25;

      notes.push({
        pitch,
        time: currentStep,
        duration,
        velocity,
      });

      lastPitch = pitch;
      lastDur = duration;
      currentStep += duration;
    }

    return notes;
  }

  // Generate a single step for continuous stream playback
  public generateNextNote(currentStep: number, lastPitch: number, lastDur: number, temperature = 1.0): NoteEvent {
    const inputVector = this.buildInputVector(lastPitch, currentStep, lastDur);
    const { logits } = this.step(inputVector);

    const pitchLogits = logits.slice(0, NUM_PITCH_TOKENS);
    const pitchProbs = softmax(pitchLogits, temperature);
    const chosenPitchToken = sampleFromProbs(pitchProbs);

    let pitch = 0;
    if (chosenPitchToken > 0) {
      pitch = MIN_MIDI + (chosenPitchToken - 1);
    }

    const durLogits = logits.slice(NUM_PITCH_TOKENS, NUM_PITCH_TOKENS + DURATION_STEPS.length);
    const durProbs = softmax(durLogits, temperature);
    const chosenDurIndex = sampleFromProbs(durProbs);
    const duration = DURATION_STEPS[chosenDurIndex] || 2;
    const velocity = pitch === 0 ? 0 : 0.68 + Math.random() * 0.22;

    return {
      pitch,
      time: currentStep,
      duration,
      velocity,
    };
  }
}

function softmax(logits: number[], temperature = 1.0): number[] {
  const t = Math.max(0.1, temperature);
  let max = -Infinity;
  for (let i = 0; i < logits.length; i++) {
    if (logits[i] > max) max = logits[i];
  }
  const exp = new Float64Array(logits.length);
  let sum = 0;
  for (let i = 0; i < logits.length; i++) {
    const val = Math.exp((logits[i] - max) / t);
    exp[i] = val;
    sum += val;
  }
  const res = new Array(logits.length);
  for (let i = 0; i < logits.length; i++) {
    res[i] = exp[i] / (sum || 1);
  }
  return res;
}

function sampleFromProbs(probs: number[]): number {
  const r = Math.random();
  let acc = 0;
  for (let i = 0; i < probs.length; i++) {
    acc += probs[i];
    if (r <= acc) return i;
  }
  return probs.length - 1;
}
