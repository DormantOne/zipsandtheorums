import { NoteEvent, TheoryBreakdown, TheoryConfig, ScaleType } from '../types/music';

export const NOTE_NAMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'Bb', 'B'];

export const SCALES: Record<ScaleType, { name: string; intervals: number[]; description: string }> = {
  major: {
    name: 'Major (Ionian)',
    intervals: [0, 2, 4, 5, 7, 9, 11],
    description: 'Bright, consonant, foundational classical and pop tonality',
  },
  natural_minor: {
    name: 'Natural Minor (Aeolian)',
    intervals: [0, 2, 3, 5, 7, 8, 10],
    description: 'Somber, melancholic, emotional tonal depth',
  },
  harmonic_minor: {
    name: 'Harmonic Minor',
    intervals: [0, 2, 3, 5, 7, 8, 11],
    description: 'Exotic leading-tone tension with augmented 2nd interval',
  },
  dorian: {
    name: 'Dorian Mode',
    intervals: [0, 2, 3, 5, 7, 9, 10],
    description: 'Soulful, medieval, jazz and funk modal character',
  },
  mixolydian: {
    name: 'Mixolydian Mode',
    intervals: [0, 2, 4, 5, 7, 9, 10],
    description: 'Bluesy major, rock, dominant 7th flavor',
  },
  lydian: {
    name: 'Lydian Mode',
    intervals: [0, 2, 4, 6, 7, 9, 11],
    description: 'Dreamy, ethereal, raised 4th cinematic floating sound',
  },
  pentatonic_major: {
    name: 'Major Pentatonic',
    intervals: [0, 2, 4, 7, 9],
    description: 'Ultra-consonant, folk, gospel, instantly melodic',
  },
  pentatonic_minor: {
    name: 'Minor Pentatonic',
    intervals: [0, 3, 5, 7, 10],
    description: 'Rock, blues, instinctual groove scale',
  },
  blues: {
    name: 'Blues Scale',
    intervals: [0, 3, 5, 6, 7, 10],
    description: 'Raw, expressive blue notes (diminished 5th)',
  },
};

export const DEFAULT_THEORY_CONFIG: TheoryConfig = {
  rootNote: 0, // C
  scale: 'major',
  weights: {
    scaleFidelity: 0.22,
    voiceLeading: 0.22,
    rhythmicVariety: 0.16,
    cadenceResolution: 0.16,
    motifCoherence: 0.12,
    harmonicConsonance: 0.12,
  },
};

export function midiToNoteName(midi: number): string {
  if (midi <= 0) return 'Rest';
  const octave = Math.floor(midi / 12) - 1;
  const note = NOTE_NAMES[midi % 12];
  return `${note}${octave}`;
}

export function midiToPitchClass(midi: number): number {
  return ((midi % 12) + 12) % 12;
}

export function isScalePitch(pitch: number, rootNote: number, scale: ScaleType): boolean {
  if (pitch <= 0) return true;
  const pc = midiToPitchClass(pitch);
  const scaleDef = SCALES[scale];
  const relativePc = (pc - rootNote + 12) % 12;
  return scaleDef.intervals.includes(relativePc);
}

export function getScaleDegree(pitch: number, rootNote: number, scale: ScaleType): number | null {
  if (pitch <= 0) return null;
  const pc = midiToPitchClass(pitch);
  const relativePc = (pc - rootNote + 12) % 12;
  const idx = SCALES[scale].intervals.indexOf(relativePc);
  return idx === -1 ? null : idx + 1; // 1-indexed scale degree
}

// Complex Theoretical Context:
// Chord progressions per key degree to judge harmonic tensions, extensions (9ths, 11ths, 13ths)
// and passing tones vs chromatic neighbor tones.
export const DIATONIC_CHORD_DEGREES: Record<number, number[]> = {
  // Degree -> pitch offsets relative to root
  0: [0, 4, 7, 11, 2, 9],    // Imaj7, 9, 13 (Tonic)
  2: [2, 5, 9, 0, 4],        // ii-7, 9, 11 (Supertonic)
  4: [4, 7, 11, 2, 9],       // iii-7 (Mediant)
  5: [5, 9, 0, 4, 2, 7],     // IVmaj7, 9, #11 (Subdominant)
  7: [7, 11, 2, 5, 9, 4],    // V7, 9, 13 (Dominant)
  9: [9, 0, 4, 7, 2],        // vi-7 (Submediant)
  11: [11, 2, 5, 8],         // viiø (Leading tone)
};

export interface AdjudicatorVerdict {
  passed: boolean;
  fitness: number;
  complexityScore: number;
  breakdown: TheoryBreakdown;
  feedback: string[];
  adjudicatorComments: {
    rule: string;
    status: 'pass' | 'fail' | 'bonus';
    detail: string;
  }[];
}

/**
 * SOPHISTICATED MUSIC THEORY ADJUDICATOR
 * Evaluates melodies capable of high virtuosic complexity (bebop chromaticism, arpeggiated outlines,
 * syncopated polyrhythms, compound melody, voice-leading resolutions) while enforcing rigorous
 * harmonic justification (appoggiaturas, passing tones, suspension resolutions, cadence arrivals).
 */
export function evaluateSnippet(
  notes: NoteEvent[],
  config: TheoryConfig,
  totalSteps: number
): AdjudicatorVerdict {
  const activeNotes = notes.filter(n => n.pitch > 0);
  const feedback: string[] = [];
  const adjudicatorComments: AdjudicatorVerdict['adjudicatorComments'] = [];

  if (activeNotes.length < 3) {
    return {
      passed: false,
      fitness: 5,
      complexityScore: 0,
      breakdown: {
        scaleFidelity: 0,
        voiceLeading: 0,
        rhythmicVariety: 0,
        cadenceResolution: 0,
        motifCoherence: 0,
        harmonicConsonance: 0,
      },
      feedback: ['Adjudicator rejected: Snippet lacks minimal melodic substance.'],
      adjudicatorComments: [{
        rule: 'Melodic Density',
        status: 'fail',
        detail: 'Fewer than 3 sounding notes found in candidate.'
      }],
    };
  }

  // --------------------------------------------------------------------------
  // 1. SOPHISTICATED SCALE & CHROMATIC PASSING TONE ADJUDICATION
  // Complex music features chromatic passing tones, neighbor tones, and bebop enclosures.
  // Instead of merely punishing chromatic notes, we check if they resolve properly!
  // --------------------------------------------------------------------------
  let diatonicCount = 0;
  let justifiedChromaticCount = 0;
  let unjustifiedChromaticCount = 0;

  for (let i = 0; i < activeNotes.length; i++) {
    const cur = activeNotes[i];
    const isDiatonic = isScalePitch(cur.pitch, config.rootNote, config.scale);

    if (isDiatonic) {
      diatonicCount++;
    } else {
      // Check for Chromatic Justification:
      // A) Chromatic Passing Tone: Stepwise motion in same direction: e.g. C -> C# -> D
      // B) Chromatic Approach / Enclosure: Resolves by half-step into next diatonic note
      // C) Off-beat placement: Chromaticism on weak 16th beats is welcome jazz/bebop language!
      const prev = i > 0 ? activeNotes[i - 1] : null;
      const next = i < activeNotes.length - 1 ? activeNotes[i + 1] : null;

      let justified = false;
      if (next && isScalePitch(next.pitch, config.rootNote, config.scale)) {
        const intervalToNext = Math.abs(next.pitch - cur.pitch);
        if (intervalToNext === 1) {
          justified = true; // Half-step leading into diatonic note
        }
      }
      if (!justified && prev && next) {
        const d1 = cur.pitch - prev.pitch;
        const d2 = next.pitch - cur.pitch;
        if (Math.abs(d1) <= 2 && Math.abs(d2) <= 2 && Math.sign(d1) === Math.sign(d2)) {
          justified = true; // Stepwise chromatic passing line
        }
      }
      // Weak beat license (step % 4 !== 0)
      if (!justified && (cur.time % 4 !== 0) && next && Math.abs(next.pitch - cur.pitch) <= 2) {
        justified = true;
      }

      if (justified) {
        justifiedChromaticCount++;
      } else {
        unjustifiedChromaticCount++;
      }
    }
  }

  const effectiveScalePoints = (diatonicCount + justifiedChromaticCount * 0.95) / activeNotes.length;
  let scaleFidelity = Math.min(100, Math.round(effectiveScalePoints * 100));
  if (unjustifiedChromaticCount > 2) {
    scaleFidelity = Math.max(15, scaleFidelity - unjustifiedChromaticCount * 7);
  }

  if (justifiedChromaticCount > 0) {
    adjudicatorComments.push({
      rule: 'Chromatic Grammar',
      status: 'pass',
      detail: `${justifiedChromaticCount} chromatic note(s) justified via passing step or diatonic enclosure.`
    });
  }
  if (unjustifiedChromaticCount > 0) {
    adjudicatorComments.push({
      rule: 'Unresolved Dissonance',
      status: 'fail',
      detail: `${unjustifiedChromaticCount} chromatic pitch(es) lack step resolution or metric justification.`
    });
  }

  // --------------------------------------------------------------------------
  // 2. VOICE LEADING & CONTOUR (Bach / Schenkerian / Arpeggiation)
  // Complex melodies often interweave scalar runs with rapid arpeggios (outline chords).
  // Arpeggios (minor/major 3rds, 4ths, 5ths within same harmony) should NOT be penalized as "bad leaps"!
  // --------------------------------------------------------------------------
  let stepwiseCount = 0;
  let arpeggioTriadLeaps = 0;
  let largeDisjunctLeaps = 0;
  let compensatedLeaps = 0;
  let contourChanges = 0;
  let lastDirection = 0;

  for (let i = 0; i < activeNotes.length - 1; i++) {
    const p1 = activeNotes[i].pitch;
    const p2 = activeNotes[i + 1].pitch;
    const interval = Math.abs(p2 - p1);
    const dir = Math.sign(p2 - p1);

    if (dir !== 0) {
      if (lastDirection !== 0 && dir !== lastDirection) {
        contourChanges++;
      }
      lastDirection = dir;
    }

    if (interval <= 2) {
      stepwiseCount++; // Conjunct step
    } else if (interval === 3 || interval === 4 || interval === 5 || interval === 7) {
      // Consonant triad leaps (minor 3rd, major 3rd, 4th, 5th)
      arpeggioTriadLeaps++;
    } else {
      largeDisjunctLeaps++; // 6th, 7th, octave or compound leap
      // Check compensation
      if (i + 2 < activeNotes.length) {
        const p3 = activeNotes[i + 2].pitch;
        const nextDir = Math.sign(p3 - p2);
        const nextInt = Math.abs(p3 - p2);
        if (nextDir !== dir && nextInt <= 4) {
          compensatedLeaps++;
        }
      }
    }
  }

  const totalIntervals = Math.max(1, activeNotes.length - 1);
  const conjunctRatio = stepwiseCount / totalIntervals;
  const triadRatio = arpeggioTriadLeaps / totalIntervals;
  const compensationRatio = largeDisjunctLeaps > 0 ? compensatedLeaps / largeDisjunctLeaps : 1.0;

  let voiceLeading = 70;
  // Complex balance: 35-65% steps, 20-45% harmonic leaps, and controlled leaps
  if (conjunctRatio >= 0.35 && conjunctRatio <= 0.75) {
    voiceLeading += 18;
  }
  if (triadRatio >= 0.2 && triadRatio <= 0.5) {
    voiceLeading += 12; // Beautiful broken chord arpeggiation
  }
  // Leap compensation
  voiceLeading += compensationRatio * 15 - 5;
  if (largeDisjunctLeaps > 4 && compensationRatio < 0.5) {
    voiceLeading -= 20; // Uncontrolled jumping
  }

  // Melodic contour arch: good melodies have an expressive high point (climax)
  const maxPitch = Math.max(...activeNotes.map(n => n.pitch));
  const climaxCount = activeNotes.filter(n => n.pitch === maxPitch).length;
  if (climaxCount === 1) {
    voiceLeading += 5; // Singular dramatic peak
  }
  voiceLeading = Math.max(10, Math.min(100, Math.round(voiceLeading)));

  // --------------------------------------------------------------------------
  // 3. RHYTHMIC COMPLEXITY & METRIC ARCHITECTURE
  // Allows high rhythmic density (16th notes, 8ths, syncopated ties, offbeat accents)
  // while ensuring musical phrasing doesn't degenerate into chaotic mush.
  // --------------------------------------------------------------------------
  const uniqueDurations = new Set(notes.map(n => n.duration));
  let downbeatNotes = 0;
  let syncopatedNotes = 0;
  let shortRuns16th = 0;

  for (let i = 0; i < notes.length; i++) {
    const n = notes[i];
    if (n.pitch > 0) {
      if (n.time % 16 === 0 || n.time % 16 === 8) {
        downbeatNotes++;
      } else if (n.time % 4 !== 0) {
        syncopatedNotes++;
      }
      if (n.duration === 1) {
        shortRuns16th++;
      }
    }
  }

  let rhythmicVariety = 55;
  if (uniqueDurations.size >= 3) rhythmicVariety += 20;
  else if (uniqueDurations.size === 2) rhythmicVariety += 10;

  // Syncopation is welcomed as melodic sophistication
  if (syncopatedNotes >= 2) rhythmicVariety += 12;
  // Rapid virtuoso runs rewarded if balanced
  if (shortRuns16th >= 4 && shortRuns16th <= 16) {
    rhythmicVariety += 10;
    adjudicatorComments.push({
      rule: 'Rhythmic Virtuosity',
      status: 'bonus',
      detail: `${shortRuns16th} sixteenth-note run(s) bring high melodic complexity and momentum.`
    });
  }
  if (downbeatNotes >= 1) rhythmicVariety += 8; // Metric anchor
  rhythmicVariety = Math.max(15, Math.min(100, rhythmicVariety));

  // --------------------------------------------------------------------------
  // 4. CADENCE RESOLUTION & FORMAL ARRIVAL
  // Evaluates harmonic destination of the phrase.
  // Perfect authentic cadence (V -> I), Half cadence (ending on V), or modal finalis.
  // --------------------------------------------------------------------------
  const lastNote = activeNotes[activeNotes.length - 1];
  const secondLastNote = activeNotes.length >= 2 ? activeNotes[activeNotes.length - 2] : null;
  let cadenceResolution = 30;

  if (lastNote) {
    const lastPc = midiToPitchClass(lastNote.pitch);
    const relPc = (lastPc - config.rootNote + 12) % 12;

    if (relPc === 0) {
      // Lands on Root (Tonic)
      cadenceResolution = 95;
      if (secondLastNote) {
        const prevPc = (midiToPitchClass(secondLastNote.pitch) - config.rootNote + 12) % 12;
        if (prevPc === 11 || prevPc === 2 || prevPc === 7) {
          // Leading-tone (7 -> 1), Supertonic (2 -> 1), or Dominant (5 -> 1)
          cadenceResolution = 100;
          adjudicatorComments.push({
            rule: 'Authentic Cadence',
            status: 'pass',
            detail: 'Exemplary cadential resolution: decisive step/fifth into Key Tonic root.'
          });
        }
      }
    } else if (relPc === 7) {
      // Half-cadence on Dominant 5th
      cadenceResolution = 88;
      adjudicatorComments.push({
        rule: 'Half Cadence',
        status: 'pass',
        detail: 'Elegant semi-cadence ending on Dominant (5th degree), creating unresolved musical inquiry.'
      });
    } else if (relPc === 4 || relPc === 3) {
      // Mediant (3rd) - warm jazz / romantic ending
      cadenceResolution = 82;
    } else if (relPc === 9 || relPc === 5) {
      cadenceResolution = 70;
    } else {
      cadenceResolution = 35;
      adjudicatorComments.push({
        rule: 'Cadence Tension',
        status: 'fail',
        detail: `Final note ${midiToNoteName(lastNote.pitch)} leaves phrase suspended on non-cadential tension.`
      });
    }
  }

  // --------------------------------------------------------------------------
  // 5. HARMONIC CONSONANCE & CHORD TONE ANCHORS (Including 7ths & 9ths)
  // Checks metric downbeats against diatonic chord tones and extensions
  // --------------------------------------------------------------------------
  let strongBeatTotal = 0;
  let strongBeatConsonant = 0;

  for (const n of activeNotes) {
    if (n.time % 8 === 0) {
      strongBeatTotal++;
      const pc = (midiToPitchClass(n.pitch) - config.rootNote + 12) % 12;
      // Is it a root, 3rd, 5th, 7th, or 9th?
      const primaryConsonant = [0, 2, 4, 5, 7, 9, 11].includes(pc);
      if (primaryConsonant) strongBeatConsonant++;
    }
  }

  const harmonicConsonance = strongBeatTotal > 0
    ? Math.min(100, Math.round((strongBeatConsonant / strongBeatTotal) * 100))
    : 65;

  // --------------------------------------------------------------------------
  // 6. MOTIF COHERENCE, REPETITION & SEQUENTIAL DEVELOPMENT
  // Recognizes melodic shapes, transpositions (musical sequences), and motivic recall.
  // --------------------------------------------------------------------------
  let motifCoherence = 40;
  if (activeNotes.length >= 6) {
    const intervals: number[] = [];
    for (let i = 0; i < activeNotes.length - 1; i++) {
      intervals.push(activeNotes[i + 1].pitch - activeNotes[i].pitch);
    }

    let exactMotifMatches = 0;
    let sequenceTranspositions = 0;

    // Check for 3-note and 4-note motivic figures
    for (let len = 2; len <= 4; len++) {
      for (let i = 0; i <= intervals.length - len * 2; i++) {
        const sliceA = intervals.slice(i, i + len);
        for (let j = i + len; j <= intervals.length - len; j++) {
          const sliceB = intervals.slice(j, j + len);
          if (sliceA.every((val, k) => val === sliceB[k])) {
            exactMotifMatches++;
          } else if (
            // Melodic contour equivalence (same directional up/down trajectory)
            sliceA.every((val, k) => Math.sign(val) === Math.sign(sliceB[k]))
          ) {
            sequenceTranspositions++;
          }
        }
      }
    }

    if (exactMotifMatches > 0) {
      motifCoherence += 35;
      adjudicatorComments.push({
        rule: 'Motivic Recurrence',
        status: 'pass',
        detail: 'Thematic motif identified and recalled later in phrase.'
      });
    }
    if (sequenceTranspositions > 0) {
      motifCoherence += 20;
      adjudicatorComments.push({
        rule: 'Sequence Development',
        status: 'bonus',
        detail: 'Contour sequence development detected (Beethovenian thematic expansion).'
      });
    }
  }
  motifCoherence = Math.min(100, motifCoherence);

  // --------------------------------------------------------------------------
  // COMPLEXITY SCORE (0 - 100)
  // Rewards pitch range, contour variety, rhythmic density, chromatic sophistication
  // --------------------------------------------------------------------------
  const pitchRange = activeNotes.length > 0
    ? Math.max(...activeNotes.map(n => n.pitch)) - Math.min(...activeNotes.map(n => n.pitch))
    : 0;
  const noteDensity = activeNotes.length / (totalSteps / 16); // notes per bar

  let rawComplexity = 0;
  // Pitch range (12 semitones octave = 25 pts, 2 octaves = 40 pts)
  rawComplexity += Math.min(35, pitchRange * 1.5);
  // Note density (4 notes/bar = 10, 8 notes/bar = 25, 12 notes/bar = 35)
  rawComplexity += Math.min(30, noteDensity * 3.5);
  // Rhythmic subdivision variety
  rawComplexity += uniqueDurations.size * 6;
  // Justified chromatic passing tones (bebop / modern complexity)
  rawComplexity += justifiedChromaticCount * 6;
  // Melodic contour changes
  rawComplexity += Math.min(15, contourChanges * 1.5);

  const complexityScore = Math.max(10, Math.min(100, Math.round(rawComplexity)));

  // --------------------------------------------------------------------------
  // FINAL ADJUDICATOR WEIGHTED FITNESS & PASS/FAIL VERDICT
  // --------------------------------------------------------------------------
  const w = config.weights;
  const totalWeight =
    w.scaleFidelity +
    w.voiceLeading +
    w.rhythmicVariety +
    w.cadenceResolution +
    w.motifCoherence +
    w.harmonicConsonance;

  const weightedScore =
    (scaleFidelity * w.scaleFidelity +
      voiceLeading * w.voiceLeading +
      rhythmicVariety * w.rhythmicVariety +
      cadenceResolution * w.cadenceResolution +
      motifCoherence * w.motifCoherence +
      harmonicConsonance * w.harmonicConsonance) /
    totalWeight;

  // Bonus for high complexity that remains grammatically sound:
  let finalFitness = weightedScore;
  if (scaleFidelity >= 70 && voiceLeading >= 65 && complexityScore >= 60) {
    const complexityBonus = (complexityScore - 50) * 0.12;
    finalFitness = Math.min(100, finalFitness + complexityBonus);
  }

  finalFitness = Math.round(finalFitness * 10) / 10;

  // ADJUDICATION PASS CRITERIA:
  // Must achieve >= 68 overall fitness, >= 65 scale adherence, and no fatal voice leading catastrophes
  const passed = finalFitness >= 68 && scaleFidelity >= 60 && voiceLeading >= 55;

  if (passed) {
    feedback.push(
      `PASSED ADJUDICATION (${finalFitness}%): ${complexityScore >= 70 ? 'Virtuosic & Highly Complex' : complexityScore >= 45 ? 'Rich Melodic Grammar' : 'Consonant Classical Phrasing'}.`
    );
  } else {
    feedback.push(
      `FAILED ADJUDICATION (${finalFitness}%): Disqualified by music theory adjudicator (threshold: 68%).`
    );
  }

  return {
    passed,
    fitness: finalFitness,
    complexityScore,
    breakdown: {
      scaleFidelity,
      voiceLeading,
      rhythmicVariety,
      cadenceResolution,
      motifCoherence,
      harmonicConsonance,
    },
    feedback,
    adjudicatorComments,
  };
}
