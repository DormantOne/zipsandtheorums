export type ScaleType =
  | 'major'
  | 'natural_minor'
  | 'harmonic_minor'
  | 'dorian'
  | 'mixolydian'
  | 'lydian'
  | 'pentatonic_major'
  | 'pentatonic_minor'
  | 'blues';

export interface NoteEvent {
  pitch: number; // MIDI number (e.g. 60 = C4). 0 indicates rest
  time: number; // in 16th note steps (0, 1, 2, ...)
  duration: number; // in 16th note steps (e.g. 1 = 16th, 2 = 8th, 4 = quarter)
  velocity: number; // 0.0 - 1.0
}

export interface TheoryBreakdown {
  scaleFidelity: number; // 0-100: adherence to chosen key/scale
  voiceLeading: number; // 0-100: stepwise motion, leap compensation, contour
  rhythmicVariety: number; // 0-100: metric accentuation, syncopation balance
  cadenceResolution: number; // 0-100: ending on tonic/dominant, cadential arrival
  motifCoherence: number; // 0-100: recurrence and development of melodic patterns
  harmonicConsonance: number; // 0-100: stable chord tones on strong beats
}

export interface AdjudicatorComment {
  rule: string;
  status: 'pass' | 'fail' | 'bonus';
  detail: string;
}

export interface CandidateSnippet {
  id: string;
  generation: number;
  notes: NoteEvent[];
  lengthSteps: number; // e.g. 16, 32, 64 steps
  fitness: number; // Overall weighted fitness score (0-100)
  passed: boolean; // Adjudicator pass/fail verdict (survival threshold)
  complexityScore: number; // 0-100: virtuosic density, melodic range, syncopation, chromaticism
  breakdown: TheoryBreakdown;
  theoryNotes: string[]; // Explanatory musical theory comments
  adjudicatorComments: AdjudicatorComment[]; // Detailed pass/fail adjudication breakdown
  gruId: string;
  userVoted?: boolean;
}

export interface GRUWeights {
  hiddenSize: number;
  inputSize: number;
  outputSize: number;
  // Reset gate
  Wxr: number[][]; // [hiddenSize][inputSize]
  Whr: number[][]; // [hiddenSize][hiddenSize]
  br: number[]; // [hiddenSize]
  // Update gate
  Wxz: number[][];
  Whz: number[][];
  bz: number[];
  // Candidate hidden
  Wxh: number[][];
  Whh: number[][];
  bh: number[];
  // Output projection
  Why: number[][]; // [outputSize][hiddenSize]
  by: number[]; // [outputSize]
}

export interface EvolutionConfig {
  populationSize: number;
  snippetLengthSteps: number; // 16 (1 bar), 32 (2 bars), 64 (4 bars)
  mutationRate: number; // 0.01 - 0.3
  mutationStrength: number; // 0.05 - 0.5
  temperature: number; // 0.5 - 2.0 (sampling softmax)
  crossoverRate: number;
  eliteCount: number;
  complexityTarget: 'moderate' | 'complex' | 'virtuoso'; // Target melodic complexity
  survivalThreshold: number; // Adjudicator strictness pass score (e.g. 68)
}

export interface TheoryConfig {
  rootNote: number; // 0 = C, 1 = C#, 2 = D, ..., 11 = B
  scale: ScaleType;
  weights: {
    scaleFidelity: number;
    voiceLeading: number;
    rhythmicVariety: number;
    cadenceResolution: number;
    motifCoherence: number;
    harmonicConsonance: number;
  };
}

export type SynthInstrument =
  | 'rhodes'
  | 'piano'
  | 'analog_synth'
  | 'ambient_chime'
  | 'marimba';

export interface GenerationHistoryPoint {
  generation: number;
  bestFitness: number;
  avgFitness: number;
  passRate: number; // % of population that passed adjudication
  avgComplexity: number;
  scaleScore: number;
  voiceLeadingScore: number;
}
