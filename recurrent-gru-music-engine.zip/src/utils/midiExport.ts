import { NoteEvent } from '../types/music';

// Helper to encode variable length values in MIDI format
function writeVarLength(value: number): number[] {
  const bytes: number[] = [];
  let buffer = value & 0x7f;
  while ((value >>= 7) > 0) {
    buffer <<= 8;
    buffer |= 0x80;
    buffer += value & 0x7f;
  }
  while (true) {
    bytes.push(buffer & 0xff);
    if (buffer & 0x80) buffer >>= 8;
    else break;
  }
  return bytes;
}

export function exportSnippetToMidi(
  notes: NoteEvent[],
  bpm = 110,
  title = 'EvoHarmonics Champion Snippet'
): Blob {
  const ticksPerQuarter = 480;
  const ticksPer16th = ticksPerQuarter / 4; // 120 ticks per 16th

  // Sort notes by start time
  const sortedNotes = [...notes]
    .filter(n => n.pitch > 0)
    .sort((a, b) => a.time - b.time);

  // Track events: Note On and Note Off
  interface MidiTrackEvent {
    tick: number;
    type: 'on' | 'off';
    pitch: number;
    velocity: number;
  }

  const events: MidiTrackEvent[] = [];
  for (const n of sortedNotes) {
    const startTick = n.time * ticksPer16th;
    const endTick = (n.time + n.duration) * ticksPer16th;
    const vel = Math.round((n.velocity || 0.8) * 127);

    events.push({ tick: startTick, type: 'on', pitch: n.pitch, velocity: vel });
    events.push({ tick: endTick, type: 'off', pitch: n.pitch, velocity: 0 });
  }

  events.sort((a, b) => a.tick - b.tick || (a.type === 'off' ? -1 : 1));

  // Build Track Chunk
  const trackBytes: number[] = [];

  // Track Title Meta Event (0xFF 0x03)
  const titleBytes = Array.from(new TextEncoder().encode(title));
  trackBytes.push(0x00, 0xff, 0x03, titleBytes.length, ...titleBytes);

  // Set Tempo Meta Event (0xFF 0x51 0x03)
  const microsecondsPerQuarter = Math.round(60000000 / bpm);
  trackBytes.push(
    0x00,
    0xff,
    0x51,
    0x03,
    (microsecondsPerQuarter >> 16) & 0xff,
    (microsecondsPerQuarter >> 8) & 0xff,
    microsecondsPerQuarter & 0xff
  );

  let lastTick = 0;
  for (const ev of events) {
    const deltaTick = ev.tick - lastTick;
    lastTick = ev.tick;

    trackBytes.push(...writeVarLength(deltaTick));
    if (ev.type === 'on') {
      trackBytes.push(0x90, ev.pitch, ev.velocity);
    } else {
      trackBytes.push(0x80, ev.pitch, 0x40);
    }
  }

  // End of Track Meta Event (0x00 0xFF 0x2F 0x00)
  trackBytes.push(0x00, 0xff, 0x2f, 0x00);

  // Header Chunk (MThd)
  const headerBytes = [
    0x4d, 0x54, 0x68, 0x64, // 'MThd'
    0x00, 0x00, 0x00, 0x06, // Chunk length (6 bytes)
    0x00, 0x00,             // Format 0 (single track)
    0x00, 0x01,             // 1 track
    (ticksPerQuarter >> 8) & 0xff,
    ticksPerQuarter & 0xff, // Ticks per quarter
  ];

  // Track Chunk (MTrk)
  const trackLength = trackBytes.length;
  const trackHeader = [
    0x4d, 0x54, 0x72, 0x6b, // 'MTrk'
    (trackLength >> 24) & 0xff,
    (trackLength >> 16) & 0xff,
    (trackLength >> 8) & 0xff,
    trackLength & 0xff,
  ];

  const fullMidi = new Uint8Array([...headerBytes, ...trackHeader, ...trackBytes]);
  return new Blob([fullMidi], { type: 'audio/midi' });
}

export function downloadMidiFile(notes: NoteEvent[], filename: string, bpm = 110): void {
  const blob = exportSnippetToMidi(notes, bpm, filename);
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename.endsWith('.mid') ? filename : `${filename}.mid`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
